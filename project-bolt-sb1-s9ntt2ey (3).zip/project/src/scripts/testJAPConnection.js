import { getJAPServices } from '../services/jap';

const testJAPConnection = async () => {
  console.log('🔍 Test de connexion à l\'API JAP...\n');

  try {
    // 1. Test de récupération des services
    console.log('1️⃣ Test de récupération des services JAP...');
    const services = await getJAPServices();
    console.log(`✅ ${services.length} services récupérés\n`);

    // 2. Afficher quelques services pour vérification
    console.log('2️⃣ Échantillon de services:');
    services.slice(0, 3).forEach(service => {
      console.log(`
        ID: ${service.service}
        Nom: ${service.name}
        Min: ${service.min}
        Max: ${service.max}
        Prix: ${service.rate}
      `);
    });

    console.log('\n🎉 Tests de connexion réussis !');
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Erreur lors des tests:', error);
    
    // Afficher des suggestions en fonction de l'erreur
    if (error.response?.status === 401) {
      console.log('\n👉 Suggestions:');
      console.log('1. Vérifiez que votre clé API est correcte');
      console.log('2. Vérifiez que la clé n\'a pas expiré');
    } else if (error.code === 'ECONNREFUSED') {
      console.log('\n👉 Suggestions:');
      console.log('1. Vérifiez votre connexion Internet');
      console.log('2. Vérifiez que l\'URL de l\'API est correcte');
      console.log('3. Vérifiez si un pare-feu bloque les connexions');
    }
    
    process.exit(1);
  }
};

testJAPConnection();