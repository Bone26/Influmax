import React from 'react';
import { motion } from 'framer-motion';
import { Users } from 'lucide-react';
import { Link } from 'react-router-dom';

const AffiliateCard = () => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl p-6 text-white"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Users className="h-6 w-6" />
          <h3 className="text-lg font-semibold">Programme d'affiliation</h3>
        </div>
      </div>

      <p className="text-white/90 mb-6">
        Gagnez jusqu'à 20% de commission sur chaque vente ! Rejoignez notre programme d'affiliation et transformez votre influence en revenus passifs.
      </p>

      <Link
        to="/affiliate"
        className="inline-flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
      >
        Commencer à gagner
      </Link>
    </motion.div>
  );
};

export default AffiliateCard;