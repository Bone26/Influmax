import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Menu, 
  X, 
  User, 
  LogOut, 
  CreditCard, 
  Settings, 
  ChevronDown, 
  Home,
  ShoppingBag,
  Calculator,
  LogIn,
  Shield,
  MessageSquare,
  MessageCircle,
  Rocket
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import UserMenu from './navigation/UserMenu';
import NotificationBell from './notifications/NotificationBell';

const Navbar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { currentUser, signOut } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const mobileMenuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  const menuItems = [
    { label: 'Dashboard', path: '/dashboard', icon: Home },
    { label: 'Mes commandes', path: '/orders', icon: ShoppingBag },
    { label: 'Mon portefeuille', path: '/wallet', icon: CreditCard },
    { label: 'Support', path: '/support', icon: MessageSquare },
    { label: 'Paramètres', path: '/settings', icon: Settings },
    ...(currentUser?.isAdmin ? [
      { label: 'Administration', path: '/admin', icon: Shield }
    ] : [])
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isMobileMenuOpen && 
        mobileMenuRef.current && 
        menuButtonRef.current &&
        !mobileMenuRef.current.contains(event.target as Node) &&
        !menuButtonRef.current.contains(event.target as Node)
      ) {
        setIsMobileMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMobileMenuOpen]);

  const handleSignOut = async () => {
    try {
      await signOut();
      setIsUserMenuOpen(false);
      setIsMobileMenuOpen(false);
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
    }
  };

  const handleNavigate = (path: string) => {
    navigate(path);
    setIsUserMenuOpen(false);
    setIsMobileMenuOpen(false);
  };

  const isActive = (path: string) => location.pathname === path;

  // Vérifier si l'utilisateur peut accéder au menu complet
  const canAccessFullMenu = currentUser && currentUser.emailVerified;

  return (
    <nav className="bg-white/90 backdrop-blur-sm sticky top-0 z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <img 
                src="https://i.imgur.com/b9jRROr.png" 
                alt="Logo" 
                className="h-16 w-auto hover:opacity-90 transition-opacity"
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/services"
              className="flex items-center space-x-2 text-lg font-medium text-gray-600 hover:text-purple-600 transition-colors"
            >
              <Rocket className="h-5 w-5" />
              <span>Services</span>
            </Link>

            <button 
              onClick={() => handleNavigate('/simulateur')}
              className="flex items-center space-x-2 text-lg font-medium text-gray-600 hover:text-purple-600 transition-colors"
            >
              <Calculator className="h-5 w-5" />
              <span>Simulateur</span>
            </button>

            <a
              href="https://t.me/influmax"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 text-lg font-medium text-gray-600 hover:text-purple-600 transition-colors"
            >
              <MessageCircle className="h-5 w-5" />
              <span>Telegram</span>
            </a>

            {canAccessFullMenu && <NotificationBell />}

            {currentUser ? (
              canAccessFullMenu ? (
                <div className="relative">
                  <button
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className="flex items-center text-lg font-medium text-gray-600 hover:text-gradient transition-colors"
                  >
                    {currentUser.photoURL ? (
                      <img
                        src={currentUser.photoURL}
                        alt={currentUser.name}
                        className="h-8 w-8 rounded-full object-cover mr-2"
                      />
                    ) : (
                      <User className="h-6 w-6 mr-2" />
                    )}
                    Mon compte
                    <ChevronDown className={`ml-1 h-4 w-4 transition-transform duration-200 ${isUserMenuOpen ? 'rotate-180' : ''}`} />
                  </button>

                  <AnimatePresence>
                    {isUserMenuOpen && (
                      <UserMenu
                        menuItems={menuItems}
                        isActive={isActive}
                        onNavigate={handleNavigate}
                        onSignOut={handleSignOut}
                      />
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                <Link
                  to="/auth/verify-email"
                  className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-2 rounded-full hover:from-purple-700 hover:to-indigo-700 transition-colors"
                >
                  <LogIn className="h-5 w-5" />
                  <span>Vérifier mon email</span>
                </Link>
              )
            ) : (
              <Link
                to="/auth/login"
                className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-2 rounded-full hover:from-purple-700 hover:to-indigo-700 transition-colors"
              >
                <LogIn className="h-5 w-5" />
                <span>Se connecter</span>
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center space-x-4">
            {canAccessFullMenu && <NotificationBell />}
            <button
              ref={menuButtonRef}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-600 hover:text-gradient p-2"
            >
              {isMobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            ref={mobileMenuRef}
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t"
          >
            <div className="px-4 pt-2 pb-3 space-y-1">
              {currentUser && (
                <div className="flex items-center space-x-3 p-4 border-b">
                  {currentUser.photoURL ? (
                    <img
                      src={currentUser.photoURL}
                      alt={currentUser.name}
                      className="h-10 w-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <span className="text-lg font-bold text-purple-600">
                        {currentUser.name[0].toUpperCase()}
                      </span>
                    </div>
                  )}
                  <div>
                    <div className="font-medium text-gray-900">{currentUser.name}</div>
                    <div className="text-sm text-gray-500">{currentUser.email}</div>
                  </div>
                </div>
              )}

              <Link
                to="/services"
                className="flex items-center w-full px-3 py-2 text-base font-medium rounded-lg transition-colors hover:bg-gray-50"
              >
                <Rocket className="h-5 w-5 mr-2" />
                Services
              </Link>

              <button
                onClick={() => handleNavigate('/simulateur')}
                className="flex items-center w-full px-3 py-2 text-base font-medium rounded-lg transition-colors hover:bg-gray-50"
              >
                <Calculator className="h-5 w-5 mr-2" />
                Simulateur
              </button>

              <a
                href="https://t.me/influmax"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center w-full px-3 py-2 text-base font-medium rounded-lg transition-colors hover:bg-gray-50"
              >
                <MessageCircle className="h-5 w-5 mr-2" />
                Telegram
              </a>

              {currentUser ? (
                canAccessFullMenu ? (
                  <div className="py-2">
                    <div className="px-3 py-2 text-sm font-medium text-gray-500">Mon compte</div>
                    {menuItems.map((item) => (
                      <button
                        key={item.path}
                        onClick={() => handleNavigate(item.path)}
                        className={`flex items-center w-full px-3 py-2 text-base font-medium rounded-lg transition-colors ${
                          isActive(item.path) ? 'bg-purple-50 text-purple-600' : 'text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        <item.icon className="h-5 w-5 mr-3" />
                        {item.label}
                      </button>
                    ))}
                    <button
                      onClick={handleSignOut}
                      className="flex items-center w-full px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
                    >
                      <LogOut className="h-5 w-5 mr-3" />
                      Déconnexion
                    </button>
                  </div>
                ) : (
                  <Link
                    to="/auth/verify-email"
                    className="flex items-center w-full px-3 py-2 text-base font-medium bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg"
                  >
                    <LogIn className="h-5 w-5 mr-2" />
                    Vérifier mon email
                  </Link>
                )
              ) : (
                <Link
                  to="/auth/login"
                  className="flex items-center w-full px-3 py-2 text-base font-medium bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg"
                >
                  <LogIn className="h-5 w-5 mr-2" />
                  Se connecter
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;