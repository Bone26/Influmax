import React from 'react';
import { motion } from 'framer-motion';
import { LogOut } from 'lucide-react';
import MenuItem from './MenuItem';

interface UserMenuProps {
  menuItems: Array<{
    label: string;
    path: string;
    icon: any;
  }>;
  isActive: (path: string) => boolean;
  onNavigate: (path: string) => void;
  onSignOut: () => void;
}

const UserMenu: React.FC<UserMenuProps> = ({ menuItems, isActive, onNavigate, onSignOut }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl py-2 border border-gray-100"
    >
      {menuItems.map((item) => (
        <MenuItem
          key={item.path}
          label={item.label}
          icon={item.icon}
          active={isActive(item.path)}
          onClick={() => onNavigate(item.path)}
        />
      ))}
      
      <hr className="my-2" />
      <button
        onClick={onSignOut}
        className="flex items-center w-full px-4 py-3 text-gray-700 hover:bg-gray-50 transition-colors"
      >
        <LogOut className="h-5 w-5 mr-3" />
        Déconnexion
      </button>
    </motion.div>
  );
};

export default UserMenu;