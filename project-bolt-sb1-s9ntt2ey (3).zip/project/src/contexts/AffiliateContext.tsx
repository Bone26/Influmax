import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import { User } from '../types/user';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { updateAffiliateStats } from '../services/affiliate';
import { toast } from 'sonner';

interface AffiliateContextType {
  affiliate: User['affiliate'] | null;
  loading: boolean;
  error: string | null;
  refreshAffiliate: () => Promise<void>;
}

const AffiliateContext = createContext<AffiliateContextType | undefined>(undefined);

export const AffiliateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [affiliate, setAffiliate] = useState<User['affiliate'] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updateTimeout, setUpdateTimeout] = useState<NodeJS.Timeout | null>(null);

  // Fonction de mise à jour des stats avec gestion d'erreur
  const updateStats = useCallback(async () => {
    if (!currentUser) return;
    
    try {
      await updateAffiliateStats(currentUser.id);
    } catch (error) {
      console.error('Error updating affiliate stats:', error);
      // Ne pas afficher de toast pour éviter de spammer l'utilisateur
    }
  }, [currentUser]);

  useEffect(() => {
    if (!currentUser) {
      setAffiliate(null);
      setLoading(false);
      return;
    }

    const unsubscribe = onSnapshot(
      doc(db, 'users', currentUser.id),
      (doc) => {
        if (doc.exists()) {
          const userData = doc.data();
          setAffiliate(userData.affiliate);

          // Planifier une mise à jour des stats avec un délai
          if (updateTimeout) {
            clearTimeout(updateTimeout);
          }
          
          const timeout = setTimeout(() => {
            updateStats();
          }, 5000); // Délai de 5 secondes
          
          setUpdateTimeout(timeout);
        }
        setLoading(false);
      },
      (err) => {
        console.error('Error listening to affiliate changes:', err);
        setError('Erreur lors du chargement des données d\'affiliation');
        setLoading(false);
      }
    );

    // Nettoyage
    return () => {
      unsubscribe();
      if (updateTimeout) {
        clearTimeout(updateTimeout);
      }
    };
  }, [currentUser, updateTimeout, updateStats]);

  const refreshAffiliate = async () => {
    if (!currentUser) return;
    
    try {
      setLoading(true);
      await updateStats();
    } catch (error) {
      console.error('Error refreshing affiliate:', error);
      toast.error('Erreur lors de la mise à jour des données');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AffiliateContext.Provider value={{
      affiliate,
      loading,
      error,
      refreshAffiliate
    }}>
      {children}
    </AffiliateContext.Provider>
  );
};

export const useAffiliate = () => {
  const context = useContext(AffiliateContext);
  if (context === undefined) {
    throw new Error('useAffiliate must be used within an AffiliateProvider');
  }
  return context;
};