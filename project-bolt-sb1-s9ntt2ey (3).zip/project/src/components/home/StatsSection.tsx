import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Clock, Users, Award } from 'lucide-react';

const stats = [
  {
    icon: Users,
    value: '5k+',
    label: 'Clients satisfaits',
    color: 'from-blue-500 to-cyan-500'
  },
  {
    icon: TrendingUp,
    value: '1M+',
    label: 'Abonnés livrés',
    color: 'from-purple-500 to-pink-500'
  },
  {
    icon: Clock,
    value: '24h',
    label: 'Délai maximum',
    color: 'from-orange-500 to-red-500'
  },
  {
    icon: Award,
    value: '99%',
    label: 'Taux de satisfaction',
    color: 'from-green-500 to-emerald-500'
  }
];

const StatsSection = () => {
  return (
    <section className="py-12 md:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              <div className="absolute inset-0 bg-white rounded-2xl shadow-lg transform transition-all duration-300 group-hover:scale-105 group-hover:shadow-xl" />
              <div className="relative p-6 flex flex-col items-center text-center">
                <div className={`bg-gradient-to-br ${stat.color} p-4 rounded-xl mb-4`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <motion.h3 
                  className="text-3xl font-bold text-gray-900 mb-2"
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                >
                  {stat.value}
                </motion.h3>
                <p className="text-gray-600">{stat.label}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;