import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, AlertCircle, ArrowLeftRight } from 'lucide-react';
import { refundOrder } from '../../services/refunds';
import { toast } from 'sonner';

interface RefundOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: {
    id: string;
    price: number;
    metadata?: {
      refunded?: boolean;
    };
  };
  adminId: string;
}

const RefundOrderModal: React.FC<RefundOrderModalProps> = ({
  isOpen,
  onClose,
  order,
  adminId
}) => {
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      toast.error('Veuillez indiquer une raison');
      return;
    }

    setLoading(true);
    try {
      await refundOrder(order.id, adminId, reason);
      onClose();
      toast.success('Commande remboursée avec succès');
    } catch (error) {
      console.error('Error refunding order:', error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error('Erreur lors du remboursement');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-xl shadow-xl max-w-md w-full"
      >
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <ArrowLeftRight className="h-6 w-6 text-white" />
              <h3 className="text-xl font-semibold text-white">
                Rembourser la commande
              </h3>
            </div>
            <button
              onClick={onClose}
              className="text-white/80 hover:text-white"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Warning */}
          <div className="flex items-center p-4 bg-yellow-50 text-yellow-800 rounded-lg">
            <AlertCircle className="h-5 w-5 flex-shrink-0 mr-3" />
            <p className="text-sm">
              Cette action est irréversible et créditera {order.price.toFixed(2)}€ sur le compte du client.
            </p>
          </div>

          {/* Reason Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Raison du remboursement
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              rows={4}
              placeholder="Indiquez la raison du remboursement..."
              required
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || !reason.trim()}
              className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              {loading ? 'Remboursement...' : 'Confirmer le remboursement'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default RefundOrderModal;