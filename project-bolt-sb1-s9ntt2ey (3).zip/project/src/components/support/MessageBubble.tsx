import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { File, Image as ImageIcon, Check, CheckCheck } from 'lucide-react';
import { TicketMessage } from '../../types/ticket';

interface MessageBubbleProps {
  message: TicketMessage;
  isLastMessage: boolean;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, isLastMessage }) => {
  const isAdmin = message.senderRole === 'admin';

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return <ImageIcon className="h-5 w-5" />;
    return <File className="h-5 w-5" />;
  };

  const formatFileSize = (size: number) => {
    if (size < 1024) return `${size} B`;
    if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
    return `${(size / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex ${isAdmin ? 'justify-end' : 'justify-start'} group`}
    >
      <div className={`
        relative max-w-[85%] md:max-w-[75%] rounded-2xl p-4
        ${isAdmin 
          ? 'bg-gradient-to-br from-purple-600 to-indigo-600 text-white' 
          : 'bg-white shadow-sm border border-gray-100'
        }
      `}>
        {/* Message Header */}
        <div className="flex items-center justify-between mb-2 text-sm">
          <span className={isAdmin ? 'text-white/90' : 'text-gray-900'}>
            {isAdmin ? 'Support' : message.senderName}
          </span>
          <span className={isAdmin ? 'text-white/75' : 'text-gray-400'}>
            {format(message.createdAt, 'HH:mm', { locale: fr })}
          </span>
        </div>

        {/* Message Content */}
        <div className={`
          whitespace-pre-wrap break-words text-base
          ${isAdmin ? 'text-white' : 'text-gray-700'}
        `}>
          {message.content}
        </div>

        {/* Attachments */}
        {message.attachments && message.attachments.length > 0 && (
          <div className="mt-3 space-y-2">
            {message.attachments.map((attachment, idx) => (
              <a
                key={idx}
                href={attachment.url}
                target="_blank"
                rel="noopener noreferrer"
                className={`
                  flex items-center p-3 rounded-xl transition-colors
                  ${isAdmin
                    ? 'bg-white/10 hover:bg-white/20'
                    : 'bg-gray-50 hover:bg-gray-100'
                  }
                `}
              >
                {getFileIcon(attachment.type)}
                <div className="ml-3 flex-1 min-w-0">
                  <p className={`text-sm font-medium truncate ${
                    isAdmin ? 'text-white' : 'text-gray-900'
                  }`}>
                    {attachment.name}
                  </p>
                  <p className={`text-xs ${
                    isAdmin ? 'text-white/75' : 'text-gray-500'
                  }`}>
                    {formatFileSize(attachment.size)}
                  </p>
                </div>
              </a>
            ))}
          </div>
        )}

        {/* Read Status */}
        {isLastMessage && (
          <div className={`absolute -bottom-5 right-2 flex items-center space-x-1 ${
            isAdmin ? 'text-white/60' : 'text-gray-400'
          }`}>
            {message.read ? (
              <CheckCheck className="h-4 w-4" />
            ) : (
              <Check className="h-4 w-4" />
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default MessageBubble;