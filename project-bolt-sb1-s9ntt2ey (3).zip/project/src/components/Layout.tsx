import React, { Suspense } from 'react';
import { useLocation } from 'react-router-dom';
import Navbar from './Navbar';
import LoadingSpinner from './LoadingSpinner';
import ErrorBoundary from './ErrorBoundary';
import EmailVerificationBanner from './EmailVerificationBanner';
import { useAuth } from '../contexts/AuthContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const { currentUser } = useAuth();
  const isReferralPage = location.pathname === '/ref';
  const isAuthPage = location.pathname.startsWith('/auth/');

  // Ne pas afficher la bannière sur les pages d'authentification
  const shouldShowBanner = currentUser && !currentUser.emailVerified && !isAuthPage;

  return (
    <ErrorBoundary>
      <div className="flex flex-col min-h-screen">
        {!isReferralPage && <Navbar />}
        {shouldShowBanner && <EmailVerificationBanner />}
        <main className="flex-grow">
          <Suspense fallback={<LoadingSpinner />}>
            {children}
          </Suspense>
        </main>
      </div>
    </ErrorBoundary>
  );
};

export default Layout;