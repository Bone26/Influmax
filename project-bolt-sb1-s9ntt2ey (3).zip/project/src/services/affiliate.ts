import { collection, doc, getDoc, getDocs, setDoc, updateDoc, increment, Timestamp, runTransaction, query, where, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { User } from '../types/user';
import { Withdrawal } from '../types/affiliate';
import { sendWithdrawalProcessingNotification, sendCommissionNotification } from './notifications';

// Récupérer un affilié par son code de parrainage
export const getAffiliateByReferralCode = async (referralCode: string): Promise<User | null> => {
  try {
    console.log('🔍 [Affiliate] Recherche du code:', referralCode);
    const usersRef = collection(db, 'users');
    const q = query(
      usersRef, 
      where('affiliate.referralCode', '==', referralCode)
    );
    
    const querySnapshot = await getDocs(q);
    if (querySnapshot.empty) {
      console.log('❌ [Affiliate] Aucun affilié trouvé pour le code:', referralCode);
      return null;
    }

    const userData = querySnapshot.docs[0].data();
    console.log('✅ [Affiliate] Affilié trouvé:', {
      id: querySnapshot.docs[0].id,
      name: userData.name,
      email: userData.email,
      referralCode: userData.affiliate?.referralCode
    });

    return {
      id: querySnapshot.docs[0].id,
      ...userData,
      createdAt: userData.createdAt.toDate(),
      updatedAt: userData.updatedAt.toDate()
    } as User;
  } catch (error) {
    console.error('❌ [Affiliate] Erreur lors de la recherche du code:', error);
    return null;
  }
};

// Récupérer un affilié par son ID utilisateur
export const getAffiliateByUserId = async (userId: string): Promise<User | null> => {
  try {
    console.log('🔍 [Affiliate] Recherche de l\'affilié:', userId);
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (!userDoc.exists()) {
      console.log('❌ [Affiliate] Utilisateur non trouvé:', userId);
      return null;
    }

    const userData = userDoc.data();
    console.log('✅ [Affiliate] Utilisateur trouvé:', {
      id: userDoc.id,
      name: userData.name,
      referralCode: userData.affiliate?.referralCode,
      stats: userData.affiliate?.stats
    });

    return {
      id: userDoc.id,
      ...userData,
      createdAt: userData.createdAt.toDate(),
      updatedAt: userData.updatedAt.toDate()
    } as User;
  } catch (error) {
    console.error('❌ [Affiliate] Erreur lors de la recherche de l\'utilisateur:', error);
    return null;
  }
};

// Mettre à jour les statistiques d'affiliation
export const updateAffiliateStats = async (userId: string): Promise<void> => {
  try {
    console.log('🔄 [Affiliate] Mise à jour des stats pour:', userId);
    const userRef = doc(db, 'users', userId);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      throw new Error('User not found');
    }

    const userData = userDoc.data();
    const stats = await getDetailedAffiliateStats(userId);

    console.log('📊 [Affiliate] Stats calculées:', {
      userId,
      totalCommissions: stats.stats.totalCommissions,
      totalReferrals: stats.stats.totalReferrals,
      directReferrals: stats.stats.directReferrals,
      indirectReferrals: stats.stats.indirectReferrals
    });

    // Calculer les gains disponibles
    const totalWithdrawn = userData.affiliate?.stats?.totalWithdrawn || 0;
    const pendingWithdrawals = userData.affiliate?.stats?.pendingWithdrawals || 0;
    const availableEarnings = Math.max(0, stats.stats.totalCommissions - (totalWithdrawn + pendingWithdrawals));

    console.log('💰 [Affiliate] Calcul des gains:', {
      totalCommissions: stats.stats.totalCommissions,
      totalWithdrawn,
      pendingWithdrawals,
      availableEarnings
    });

    // Mettre à jour les statistiques
    await updateDoc(userRef, {
      'affiliate.stats.totalEarnings': stats.stats.totalCommissions,
      'affiliate.stats.availableEarnings': availableEarnings,
      'affiliate.stats.totalReferrals': stats.stats.directReferrals + stats.stats.indirectReferrals,
      'affiliate.stats.activeReferrals': stats.stats.directReferrals,
      updatedAt: Timestamp.now()
    });

    console.log('✅ [Affiliate] Stats mises à jour avec succès');
  } catch (error) {
    console.error('❌ [Affiliate] Erreur lors de la mise à jour des stats:', error);
    throw error;
  }
};

// Récupérer les statistiques détaillées d'affiliation
export const getDetailedAffiliateStats = async (userId: string) => {
  try {
    console.log('🔍 [Affiliate] Calcul des stats détaillées pour:', userId);

    // Récupérer les filleuls directs (niveau 1)
    const level1Query = query(
      collection(db, 'users'),
      where('affiliate.referrerId', '==', userId)
    );
    const level1Snapshot = await getDocs(level1Query);
    
    console.log('👥 [Affiliate] Filleuls niveau 1 trouvés:', level1Snapshot.size);

    // Construire les données des filleuls niveau 1
    const level1Referrals = await Promise.all(level1Snapshot.docs.map(async (doc) => {
      const userData = doc.data();
      const deposits = await getUserDeposits(doc.id);
      
      // Récupérer les filleuls de niveau 2
      const level2Query = query(
        collection(db, 'users'),
        where('affiliate.referrerId', '==', doc.id)
      );
      const level2Snapshot = await getDocs(level2Query);
      
      console.log(`👥 [Affiliate] Filleuls niveau 2 trouvés pour ${doc.id}:`, level2Snapshot.size);

      // Construire les données des filleuls niveau 2
      const level2Referrals = await Promise.all(level2Snapshot.docs.map(async (subDoc) => {
        const subUserData = subDoc.data();
        const subDeposits = await getUserDeposits(subDoc.id);
        
        return {
          id: subDoc.id,
          name: subUserData.name,
          photoURL: subUserData.photoURL || null,
          totalDeposits: subDeposits.total,
          commission: subDeposits.total * 0.10, // 10% pour niveau 2
          createdAt: subUserData.createdAt.toDate()
        };
      }));

      return {
        id: doc.id,
        name: userData.name,
        photoURL: userData.photoURL || null,
        totalDeposits: deposits.total,
        commission: deposits.total * 0.20, // 20% pour niveau 1
        createdAt: userData.createdAt.toDate(),
        referrals: level2Referrals
      };
    }));

    // Calculer les totaux
    const totalDirectDeposits = level1Referrals.reduce((sum, r) => sum + r.totalDeposits, 0);
    const totalIndirectDeposits = level1Referrals.reduce((sum, r) => 
      sum + r.referrals.reduce((subSum, sub) => subSum + sub.totalDeposits, 0), 0);
    
    const totalDirectCommissions = totalDirectDeposits * 0.20;
    const totalIndirectCommissions = totalIndirectDeposits * 0.10;

    console.log('📊 [Affiliate] Statistiques calculées:', {
      totalDirectDeposits,
      totalIndirectDeposits,
      totalDirectCommissions,
      totalIndirectCommissions,
      totalReferrals: level1Referrals.length + level1Referrals.reduce((sum, r) => sum + r.referrals.length, 0),
      directReferrals: level1Referrals.length,
      indirectReferrals: level1Referrals.reduce((sum, r) => sum + r.referrals.length, 0)
    });

    return {
      referrals: level1Referrals,
      stats: {
        totalReferrals: level1Referrals.length + level1Referrals.reduce((sum, r) => sum + r.referrals.length, 0),
        directReferrals: level1Referrals.length,
        indirectReferrals: level1Referrals.reduce((sum, r) => sum + r.referrals.length, 0),
        totalDeposits: totalDirectDeposits + totalIndirectDeposits,
        directDeposits: totalDirectDeposits,
        indirectDeposits: totalIndirectDeposits,
        totalCommissions: totalDirectCommissions + totalIndirectCommissions,
        directCommissions: totalDirectCommissions,
        indirectCommissions: totalIndirectCommissions
      }
    };
  } catch (error) {
    console.error('❌ [Affiliate] Erreur lors du calcul des stats détaillées:', error);
    throw error;
  }
};

// Récupérer les retraits d'un utilisateur
export const getUserWithdrawals = async (userId: string): Promise<Withdrawal[]> => {
  try {
    console.log('🔍 [Affiliate] Récupération des retraits pour:', userId);
    
    const q = query(
      collection(db, 'withdrawals'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    const withdrawals = querySnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate()
    })) as Withdrawal[];

    console.log('✅ [Affiliate] Retraits trouvés:', withdrawals.length);
    return withdrawals;
  } catch (error) {
    console.error('❌ [Affiliate] Erreur lors de la récupération des retraits:', error);
    throw error;
  }
};

// Créer une demande de retrait
export const createWithdrawal = async (
  userId: string,
  amount: number,
  bankDetails: Withdrawal['bankDetails']
): Promise<Withdrawal> => {
  try {
    console.log('🚀 [Affiliate] Création d\'un retrait:', {
      userId,
      amount,
      bankDetails: {
        ...bankDetails,
        iban: `${bankDetails.iban.slice(0, 4)}...${bankDetails.iban.slice(-4)}`,
        bic: `${bankDetails.bic.slice(0, 4)}...`
      }
    });

    return await runTransaction(db, async (transaction) => {
      // 1. Vérifications préliminaires
      if (!userId) throw new Error('User ID is required');
      if (!amount || amount <= 0) throw new Error('Invalid amount');
      if (!bankDetails?.iban || !bankDetails?.bic || !bankDetails?.accountHolder) {
        throw new Error('Bank details are incomplete');
      }
      if (amount < 50) {
        throw new Error('Le montant minimum de retrait est de 50€');
      }

      // 2. Récupérer les données utilisateur
      const userRef = doc(db, 'users', userId);
      const userDoc = await transaction.get(userRef);
      
      if (!userDoc.exists()) {
        throw new Error('User not found');
      }

      const userData = userDoc.data();
      const availableEarnings = userData.affiliate?.stats?.availableEarnings || 0;

      console.log('💰 [Affiliate] Vérification du solde:', {
        availableEarnings,
        requestedAmount: amount
      });

      // 3. Vérifier le solde disponible
      if (availableEarnings < amount) {
        throw new Error(`Solde insuffisant. Disponible: ${availableEarnings}€`);
      }

      // 4. Créer la demande de retrait
      const withdrawalRef = doc(collection(db, 'withdrawals'));
      const now = Timestamp.now();
      
      const withdrawal = {
        id: withdrawalRef.id,
        userId,
        amount,
        bankDetails,
        status: 'pending',
        createdAt: now,
        updatedAt: now
      };

      // 5. Mettre à jour les stats de l'utilisateur
      transaction.update(userRef, {
        'affiliate.stats.availableEarnings': increment(-amount),
        'affiliate.stats.pendingWithdrawals': increment(amount),
        updatedAt: now
      });

      // 6. Sauvegarder le retrait
      transaction.set(withdrawalRef, withdrawal);

      console.log('✅ [Affiliate] Retrait créé avec succès:', {
        id: withdrawalRef.id,
        amount,
        status: 'pending'
      });

      // 7. Envoyer la notification
      await sendWithdrawalProcessingNotification(userId, amount);

      return {
        ...withdrawal,
        createdAt: now.toDate(),
        updatedAt: now.toDate()
      };
    });
  } catch (error) {
    console.error('❌ [Affiliate] Erreur lors de la création du retrait:', error);
    throw error;
  }
};

// Fonction utilitaire pour récupérer les dépôts d'un utilisateur
const getUserDeposits = async (userId: string) => {
  try {
    console.log('🔍 [Affiliate] Récupération des dépôts pour:', userId);
    
    const depositsQuery = query(
      collection(db, 'walletDeposits'),
      where('userId', '==', userId),
      where('type', '==', 'deposit'),
      where('status', '==', 'completed')
    );
    
    const depositsSnapshot = await getDocs(depositsQuery);
    const total = depositsSnapshot.docs.reduce((sum, doc) => sum + doc.data().amount, 0);
    
    console.log('✅ [Affiliate] Total des dépôts:', total);
    return { total };
  } catch (error) {
    console.error('❌ [Affiliate] Erreur lors de la récupération des dépôts:', error);
    return { total: 0 };
  }
};