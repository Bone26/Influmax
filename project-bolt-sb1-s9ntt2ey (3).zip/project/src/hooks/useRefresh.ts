import { useQueryClient } from 'react-query';
import { useNavigate } from 'react-router-dom';

export const useRefresh = () => {
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const refreshPage = (path?: string) => {
    // Invalider tous les caches de requêtes
    queryClient.invalidateQueries();
    
    if (path) {
      // Naviguer vers la nouvelle page
      navigate(path);
    } else {
      // Recharger la page actuelle
      window.location.reload();
    }
  };

  return refreshPage;
};