import { db } from '../src/lib/firebase';
import { collection, getDocs, doc, setDoc, deleteDoc, writeBatch, Timestamp } from 'firebase/firestore';

const generateReferralCode = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

const migrateAffiliation = async () => {
  console.log('🚀 Début de la migration du système d\'affiliation...');
  const batch = writeBatch(db);
  
  try {
    // 1. Récupérer tous les utilisateurs et leurs affiliés
    console.log('📚 Récupération des données...');
    const usersSnapshot = await getDocs(collection(db, 'users'));
    const affiliatesSnapshot = await getDocs(collection(db, 'affiliates'));
    
    // Créer un map des affiliés par userId
    const affiliatesByUser = new Map();
    affiliatesSnapshot.docs.forEach(doc => {
      const data = doc.data();
      if (!affiliatesByUser.has(data.userId)) {
        affiliatesByUser.set(data.userId, []);
      }
      affiliatesByUser.get(data.userId).push({
        id: doc.id,
        ...data,
        createdAt: data.createdAt.toDate()
      });
    });

    console.log(`📊 ${usersSnapshot.size} utilisateurs et ${affiliatesSnapshot.size} affiliés trouvés`);

    // 2. Migrer les données
    let migratedCount = 0;
    for (const userDoc of usersSnapshot.docs) {
      const userData = userDoc.data();
      const userAffiliates = affiliatesByUser.get(userDoc.id) || [];
      
      // Prendre le plus ancien affilié si plusieurs existent
      const affiliate = userAffiliates.sort((a, b) => 
        a.createdAt - b.createdAt
      )[0];

      // Mettre à jour l'utilisateur avec les données d'affiliation
      batch.update(doc(db, 'users', userDoc.id), {
        affiliate: {
          referralCode: affiliate?.referralCode || generateReferralCode(),
          referrerId: affiliate?.referrerId || null,
          level: affiliate?.level || 1,
          stats: {
            totalEarnings: affiliate?.totalEarnings || 0,
            pendingEarnings: affiliate?.pendingEarnings || 0,
            totalReferrals: affiliate?.totalReferrals || 0,
            activeReferrals: affiliate?.activeReferrals || 0
          }
        },
        updatedAt: Timestamp.now()
      });

      // Supprimer les anciens documents d'affiliés
      for (const oldAffiliate of userAffiliates) {
        batch.delete(doc(db, 'affiliates', oldAffiliate.id));
      }

      migratedCount++;
      if (migratedCount % 100 === 0) {
        console.log(`⏳ ${migratedCount} utilisateurs migrés...`);
      }
    }

    // 3. Exécuter les modifications
    console.log('💾 Sauvegarde des modifications...');
    await batch.commit();
    
    console.log('✅ Migration terminée avec succès !');
    console.log(`📈 Statistiques finales :`);
    console.log(`   - ${migratedCount} utilisateurs migrés`);
    console.log(`   - ${affiliatesSnapshot.size} anciens affiliés supprimés`);

  } catch (error) {
    console.error('❌ Erreur lors de la migration:', error);
    throw error;
  }
};

// Exécuter la migration
migrateAffiliation().catch(console.error);