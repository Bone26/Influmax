import { useEffect, useState } from 'react';
import { useAffiliate } from '../contexts/AffiliateContext';

export const useReferralLink = () => {
  const { affiliate } = useAffiliate();
  const [referralLink, setReferralLink] = useState('');

  useEffect(() => {
    if (affiliate?.referralCode) {
      const baseUrl = window.location.origin;
      setReferralLink(`${baseUrl}/?ref=${affiliate.referralCode}`);
    }
  }, [affiliate]);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      return true;
    } catch (err) {
      console.error('Failed to copy:', err);
      return false;
    }
  };

  return {
    referralLink,
    copyToClipboard
  };
};