// Cache des services par plateforme
export const servicesCache = new Map<string, {
  data: any[];
  timestamp: number;
  platformId: string;
}>();

// Durée de validité du cache en millisecondes (5 minutes)
export const CACHE_DURATION = 5 * 60 * 1000;