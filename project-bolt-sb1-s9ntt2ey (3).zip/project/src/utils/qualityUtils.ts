export const getAvailableQualities = (platform: string, service: string): string[] => {
  const qualities = ['standard'];

  if (platform === 'instagram') {
    if (service !== 'views') {
      qualities.push('premium', 'vip');
    }
  } else if (platform === 'tiktok') {
    if (service === 'followers' || service === 'likes') {
      qualities.push('premium');
    } else if (service === 'views') {
      qualities.push('vip');
    }
  }

  return qualities;
};