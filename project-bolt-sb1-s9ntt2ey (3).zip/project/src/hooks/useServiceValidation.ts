import { getAvailableQualities } from '../utils/qualityUtils';

export const useServiceValidation = () => {
  const validateQuantity = (platform: string, service: string) => {
    return getAvailableQualities(platform, service);
  };

  return { validateQuantity };
};