import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, Activity, Database } from 'lucide-react';

interface StatsCardsProps {
  analytics: any;
  isLoading: boolean;
}

const StatsCards: React.FC<StatsCardsProps> = ({ analytics, isLoading }) => {
  const stats = [
    {
      label: 'Commandes totales',
      value: analytics?.totalOrders || 0,
      icon: TrendingUp,
      color: 'from-pink-500 to-rose-500'
    },
    {
      label: 'Clients actifs',
      value: analytics?.activeUsers || 0,
      icon: Users,
      color: 'from-purple-500 to-indigo-500'
    },
    {
      label: 'Taux de conversion',
      value: `${analytics?.conversionRate || 0}%`,
      icon: Activity,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      label: 'Revenu total',
      value: `${analytics?.totalRevenue || 0}€`,
      icon: Database,
      color: 'from-green-500 to-emerald-500'
    }
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm p-6 animate-pulse">
            <div className="h-8 w-24 bg-gray-200 rounded mb-4"></div>
            <div className="h-10 w-32 bg-gray-300 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
            </div>
            <div className={`bg-gradient-to-br ${stat.color} rounded-lg p-3`}>
              <stat.icon className="h-6 w-6 text-white" />
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default StatsCards;