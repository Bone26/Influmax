import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { WALLET_CONFIG } from '../../config/wallet';
import { X, CreditCard, Plus } from 'lucide-react';

interface AddFundsFormProps {
  onSubmit: (amount: number) => void;
  onCancel: () => void;
}

const AddFundsForm: React.FC<AddFundsFormProps> = ({ onSubmit, onCancel }) => {
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);

    if (isNaN(numAmount)) {
      setError('Veuillez entrer un montant valide');
      return;
    }

    if (numAmount < WALLET_CONFIG.MIN_DEPOSIT) {
      setError(`Le montant minimum de dépôt est de ${WALLET_CONFIG.MIN_DEPOSIT}€`);
      return;
    }

    if (numAmount > WALLET_CONFIG.MAX_DEPOSIT) {
      setError(`Le montant maximum de dépôt est de ${WALLET_CONFIG.MAX_DEPOSIT}€`);
      return;
    }

    onSubmit(numAmount);
  };

  const presetAmounts = [10, 20, 50, 100];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-end md:items-center justify-center z-50 p-4"
    >
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-white w-full max-w-md rounded-t-2xl md:rounded-2xl shadow-xl"
      >
        {/* En-tête */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 rounded-t-2xl">
          <div className="flex items-center justify-between text-white mb-4">
            <div className="flex items-center">
              <CreditCard className="h-6 w-6 mr-3" />
              <h3 className="text-xl font-semibold">Recharger mon compte</h3>
            </div>
            <button onClick={onCancel} className="text-white/80 hover:text-white">
              <X className="h-6 w-6" />
            </button>
          </div>
          <p className="text-white/90 text-sm">
            Choisissez un montant à ajouter à votre solde
          </p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-red-50 text-red-600 rounded-lg text-sm"
            >
              {error}
            </motion.div>
          )}

          {/* Montants prédéfinis */}
          <div className="grid grid-cols-2 gap-3">
            {presetAmounts.map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setAmount(preset.toString())}
                className={`p-4 rounded-xl border-2 transition-colors ${
                  amount === preset.toString()
                    ? 'border-purple-600 bg-purple-50 text-purple-600'
                    : 'border-gray-200 hover:border-purple-200'
                }`}
              >
                <span className="text-lg font-semibold">{preset}€</span>
              </button>
            ))}
          </div>

          {/* Montant personnalisé */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ou entrez un montant personnalisé
            </label>
            <div className="relative">
              <input
                type="number"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setError('');
                }}
                min={WALLET_CONFIG.MIN_DEPOSIT}
                max={WALLET_CONFIG.MAX_DEPOSIT}
                step="0.01"
                className="w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-purple-500"
                placeholder={`${WALLET_CONFIG.MIN_DEPOSIT}.00`}
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">€</span>
            </div>
          </div>

          <div className="bg-purple-50 p-4 rounded-xl">
            <p className="text-sm text-purple-800">
              • Montant minimum : {WALLET_CONFIG.MIN_DEPOSIT}€
              <br />
              • Montant maximum : {WALLET_CONFIG.MAX_DEPOSIT}€
              <br />
              • Paiement sécurisé par carte bancaire
              <br />
              • Crédit instantané sur votre compte
            </p>
          </div>

          <div className="flex flex-col md:flex-row gap-3">
            <button
              type="submit"
              className="flex-1 flex items-center justify-center bg-purple-600 text-white px-6 py-3 rounded-xl hover:bg-purple-700 transition-colors"
            >
              <Plus className="h-5 w-5 mr-2" />
              Ajouter les fonds
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors"
            >
              Annuler
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default AddFundsForm;