import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import Step from './Step';
import { steps } from './config';

const HowItWorksSection: React.FC = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-gray-900 to-purple-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12 md:mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-3 md:mb-4">Comment ça marche ?</h2>
          <p className="text-base md:text-xl text-purple-200 max-w-3xl mx-auto">
            Un processus simple et transparent
          </p>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-8 mb-8">
          {steps.map((step, index) => (
            <Step key={index} {...step} index={index} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 md:mt-16 text-center"
        >
          <Link
            to="/services"
            className="inline-flex items-center px-6 md:px-8 py-3 md:py-4 bg-gradient-to-r from-purple-500 via-purple-600 to-pink-500 rounded-full text-base md:text-lg font-semibold hover:from-purple-600 hover:via-purple-700 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 hover:shadow-lg"
          >
            Voir nos tarifs
          </Link>
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorksSection;