export interface DeliveryLimit {
  min: number;
  max: number;
  isActive: boolean;
}

export interface DeliveryLimits {
  instant: DeliveryLimit;
  '24h': DeliveryLimit;
  '3days': DeliveryLimit;
  '7days': DeliveryLimit;
  '1month': DeliveryLimit;
}

export interface JAPServiceMapping {
  japServiceId: string;
  japServiceName: string;
  minQuantity: number;
  maxQuantity: number;
  maxSpeed: number;
}

export interface TelegramReactionMapping {
  emoji: string;
  japServiceId: string;
  japServiceName: string;
  minQuantity: number;
  maxQuantity: number;
  maxSpeed: number;
}

export interface ServicePriceConfig {
  id: string;
  platformId: string;
  serviceType: string;
  quality: 'standard' | 'premium' | 'vip';
  basePrice: number;
  deliveryLimits: DeliveryLimits;
  japMapping?: JAPServiceMapping;
  telegramReactions?: {
    individual: TelegramReactionMapping[];
    mixedPacks: {
      positive: JAPServiceMapping;
      negative: JAPServiceMapping;
    };
  };
  isActive: boolean;
  updatedAt: Date;
  updatedBy: string;
}