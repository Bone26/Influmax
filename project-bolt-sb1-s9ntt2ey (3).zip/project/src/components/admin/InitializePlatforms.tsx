import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { collection, doc, setDoc, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

const InitializePlatforms = () => {
  const [loading, setLoading] = useState(false);

  const initializePlatforms = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir initialiser les plateformes ? Cette action est irréversible.')) {
      return;
    }

    const platforms = [
      {
        name: 'Instagram',
        icon: 'Instagram',
        description: 'Services de croissance pour Instagram',
        gradient: 'from-pink-500 to-purple-500',
        isActive: true
      },
      {
        name: 'TikTok', 
        icon: 'Music2',
        description: 'Services de croissance pour TikTok',
        gradient: 'from-pink-500 to-red-500',
        isActive: true
      },
      {
        name: 'Telegram',
        icon: 'MessageCircle',
        description: 'Services de croissance pour Telegram',
        gradient: 'from-blue-400 to-cyan-500',
        isActive: true
      }
    ];

    setLoading(true);
    console.log('🚀 Initialisation des plateformes...');
    
    try {
      for (const platform of platforms) {
        const platformRef = doc(collection(db, 'platforms'));
        const now = new Date();
        
        await setDoc(platformRef, {
          id: platformRef.id,
          ...platform,
          createdAt: Timestamp.fromDate(now),
          updatedAt: Timestamp.fromDate(now)
        });
        
        console.log(`✅ Plateforme créée : ${platform.name}`);
        toast.success(`Plateforme créée : ${platform.name}`);
      }

      toast.success('Initialisation des plateformes terminée avec succès !');
    } catch (error) {
      console.error('Error initializing platforms:', error);
      toast.error('Erreur lors de l\'initialisation des plateformes');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-6 right-6"
    >
      <button
        onClick={initializePlatforms}
        disabled={loading}
        className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-3 rounded-xl shadow-lg hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 transition-all duration-300"
      >
        {loading ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Initialisation...</span>
          </>
        ) : (
          <span>Initialiser les plateformes</span>
        )}
      </button>
    </motion.div>
  );
};

export default InitializePlatforms;