import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, Trash2, Loader2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { uploadProfilePhoto, deleteProfilePhoto } from '../../services/storage';
import { toast } from 'sonner';

const ProfilePhotoUpload = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;

    setLoading(true);
    try {
      await uploadProfilePhoto(currentUser.id, file);
      toast.success('Photo de profil mise à jour');
    } catch (error) {
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error('Erreur lors de la mise à jour de la photo');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!currentUser?.photoURL) return;
    
    setLoading(true);
    try {
      await deleteProfilePhoto(currentUser.id);
      toast.success('Photo de profil supprimée');
    } catch (error) {
      toast.error('Erreur lors de la suppression de la photo');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <div className="w-32 h-32 rounded-full overflow-hidden bg-gray-100">
          {currentUser?.photoURL ? (
            <img
              src={currentUser.photoURL}
              alt={currentUser.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-purple-100 text-purple-600 text-4xl font-bold">
              {currentUser?.name?.[0]?.toUpperCase()}
            </div>
          )}
        </div>

        {loading && (
          <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center">
            <Loader2 className="h-8 w-8 text-white animate-spin" />
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>

      <div className="flex space-x-2">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => fileInputRef.current?.click()}
          disabled={loading}
          className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
        >
          <Camera className="h-5 w-5 mr-2" />
          Changer la photo
        </motion.button>

        {currentUser?.photoURL && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDelete}
            disabled={loading}
            className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
          >
            <Trash2 className="h-5 w-5 mr-2" />
            Supprimer
          </motion.button>
        )}
      </div>

      <p className="text-sm text-gray-500">
        JPG, PNG ou WebP • Max 2MB
      </p>
    </div>
  );
};

export default ProfilePhotoUpload;