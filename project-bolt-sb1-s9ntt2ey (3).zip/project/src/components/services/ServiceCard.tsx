import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Check } from 'lucide-react';
import { platformStyles } from '../../config/platformStyles';

interface ServiceProps {
  service: {
    icon: any;
    title: string;
    description: string;
    price: string;
    features: string[];
    platform: 'instagram' | 'tiktok' | 'telegram';
    type: string;
    minQuantity?: number;
  };
  index: number;
}

const ServiceCard = ({ service, index }: ServiceProps) => {
  const [isHovered, setIsHovered] = useState(false);
  const navigate = useNavigate();
  const Icon = service.icon;
  const styles = platformStyles[service.platform];

  const handleOrder = () => {
    navigate('/simulateur', { 
      state: { 
        platform: service.platform,
        service: service.type
      }
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-500 hover:-translate-y-2 hover:shadow-xl h-full"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-purple-600/5 to-indigo-600/5"></div>
      <div className="relative p-4 md:p-6 flex flex-col h-full">
        <motion.div
          animate={{
            scale: isHovered ? 1.1 : 1,
            rotate: isHovered ? 5 : 0
          }}
          transition={{ duration: 0.3 }}
          className={`bg-gradient-to-br ${styles.gradients.secondary} p-3 rounded-xl inline-block mb-4`}
        >
          <Icon className={`h-6 w-6 ${styles.colors.primary}`} />
        </motion.div>
        
        <h3 className="text-lg md:text-xl font-bold mb-2 text-gray-900">{service.title}</h3>
        <p className="text-sm md:text-base text-gray-600 mb-4">{service.description}</p>
        
        <div className="mb-4 mt-auto">
          <div className="text-xs text-gray-500 mb-1">À partir de</div>
          <div className={`text-2xl font-bold bg-gradient-to-r ${styles.gradients.text} bg-clip-text text-transparent`}>
            {service.price}€
          </div>
        </div>

        <ul className="space-y-2 mb-4 text-sm">
          {service.features.slice(0, 2).map((feature, idx) => (
            <motion.li
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * idx }}
              className="flex items-center text-gray-600"
            >
              <Check className={`h-4 w-4 mr-2 ${styles.colors.primary}`} />
              <span className="text-sm">{feature}</span>
            </motion.li>
          ))}
        </ul>

        <button
          onClick={handleOrder}
          className={`group w-full bg-gradient-to-r ${styles.gradients.primary} text-white py-2 px-4 rounded-lg font-medium flex items-center justify-center transition-all duration-300 text-sm`}
        >
          Commander
          <ChevronRight className="ml-1 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
        </button>
      </div>
    </motion.div>
  );
};

export default ServiceCard;