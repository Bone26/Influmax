import React from 'react';
import { motion } from 'framer-motion';

interface OrderFiltersProps {
  statusFilter: string;
  onFilterChange: (status: string) => void;
}

const OrderFilters: React.FC<OrderFiltersProps> = ({ statusFilter, onFilterChange }) => {
  const filters = [
    { id: 'all', label: 'Tous' },
    { id: 'processing', label: 'En cours' },
    { id: 'completed', label: 'Terminés' },
    { id: 'cancelled', label: 'Annulés' }
  ];

  return (
    <div className="flex flex-wrap gap-2">
      {filters.map((filter) => (
        <motion.button
          key={filter.id}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => onFilterChange(filter.id)}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
            statusFilter === filter.id
              ? getFilterStyle(filter.id)
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          {filter.label}
        </motion.button>
      ))}
    </div>
  );
};

const getFilterStyle = (status: string): string => {
  switch (status) {
    case 'completed':
      return 'bg-green-600 text-white';
    case 'processing':
      return 'bg-blue-600 text-white';
    case 'cancelled':
      return 'bg-red-600 text-white';
    default:
      return 'bg-purple-600 text-white';
  }
};

export default OrderFilters;