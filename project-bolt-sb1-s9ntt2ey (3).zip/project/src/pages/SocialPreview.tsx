import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Instagram, Music2, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { calculatePreviewCosts } from '../utils/previewCalculator';
import { useSimulator } from '../components/simulator/SimulatorContext';

const SocialPreview = () => {
  const navigate = useNavigate();
  const { setPreviewData } = useSimulator();
  const [platform, setPlatform] = useState<'instagram' | 'tiktok'>('instagram');
  
  // Statistiques actuelles
  const [currentStats] = useState({
    followers: 340,
    posts: 20,
    averageLikes: 0
  });

  // Objectifs souhaités
  const [targetStats, setTargetStats] = useState({
    followers: 2502,
    likesPerPost: 500
  });

  // Calcul des différences
  const differences = {
    followers: Math.max(0, targetStats.followers - currentStats.followers),
    likes: Math.max(0, targetStats.likesPerPost - currentStats.averageLikes)
  };

  // Calcul des coûts
  const costs = calculatePreviewCosts(platform, differences);

  const handleContinue = () => {
    setPreviewData({
      platform,
      differences,
      costs
    });
    navigate('/simulateur');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-8">
            <h1 className="text-3xl font-bold text-white mb-2">
              Prévisualisez votre croissance
            </h1>
            <p className="text-purple-100">
              Simulez l'évolution de votre compte et estimez le coût de vos objectifs
            </p>
          </div>

          {/* Platform Selection */}
          <div className="p-8">
            <div className="flex space-x-4 mb-8">
              <button
                onClick={() => setPlatform('instagram')}
                className={`flex items-center px-6 py-3 rounded-xl transition-all ${
                  platform === 'instagram'
                    ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Instagram className="h-5 w-5 mr-2" />
                Instagram
              </button>
              <button
                onClick={() => setPlatform('tiktok')}
                className={`flex items-center px-6 py-3 rounded-xl transition-all ${
                  platform === 'tiktok'
                    ? 'bg-gradient-to-r from-pink-500 to-red-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Music2 className="h-5 w-5 mr-2" />
                TikTok
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Statistiques actuelles */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Statistiques actuelles</h2>
                
                <div className="bg-gray-50 rounded-xl p-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <div className="text-sm text-gray-500">Abonnés</div>
                      <div className="text-2xl font-bold text-gray-900">{currentStats.followers}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Publications</div>
                      <div className="text-2xl font-bold text-gray-900">{currentStats.posts}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-500">Likes/post</div>
                      <div className="text-2xl font-bold text-gray-900">{currentStats.averageLikes}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Objectifs souhaités */}
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Objectifs souhaités</h2>
                
                <div className="bg-gray-50 rounded-xl p-6">
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Nombre d'abonnés souhaité
                      </label>
                      <input
                        type="number"
                        value={targetStats.followers}
                        onChange={(e) => setTargetStats(prev => ({
                          ...prev,
                          followers: parseInt(e.target.value) || 0
                        }))}
                        className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Likes souhaités par publication
                      </label>
                      <input
                        type="number"
                        value={targetStats.likesPerPost}
                        onChange={(e) => setTargetStats(prev => ({
                          ...prev,
                          likesPerPost: parseInt(e.target.value) || 0
                        }))}
                        className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Cost Summary */}
            <div className="mt-12 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-6 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold">Coût total estimé</h3>
                  <p className="text-purple-200">Services nécessaires pour atteindre vos objectifs</p>
                </div>
                <div className="text-3xl font-bold">{costs.total.toFixed(2)}€</div>
              </div>

              <button
                onClick={handleContinue}
                disabled={costs.total === 0}
                className="mt-6 w-full flex items-center justify-center px-6 py-3 bg-white text-purple-600 rounded-xl hover:bg-purple-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Commander maintenant
                <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SocialPreview;