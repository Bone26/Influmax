import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Wallet, TrendingUp, Users, Coins } from 'lucide-react';

interface CommissionWalletStatsProps {
  stats: {
    totalCommissions: number;
    pendingCommissions: number;
    totalWithdrawn: number;
    averageCommission: number;
    totalAffiliates: number;
    activeAffiliates: number;
    dailyStats: Array<{
      date: string;
      commissions: number;
      withdrawals: number;
    }>;
    withdrawalStats: {
      pending: number;
      processing: number;
      completed: number;
      rejected: number;
      averageProcessingTime: number;
    };
  };
}

const CommissionWalletStats: React.FC<CommissionWalletStatsProps> = ({ stats }) => {
  const quickStats = [
    {
      icon: Wallet,
      label: 'Total des commissions',
      value: `${stats.totalCommissions.toFixed(2)}€`,
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: TrendingUp,
      label: 'En attente',
      value: `${stats.pendingCommissions.toFixed(2)}€`,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Users,
      label: 'Affiliés actifs',
      value: stats.activeAffiliates,
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Coins,
      label: 'Commission moyenne',
      value: `${stats.averageCommission.toFixed(2)}€`,
      color: 'from-amber-500 to-orange-500'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Le reste du code reste inchangé */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickStats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color}`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-sm text-gray-600">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Le reste du composant reste inchangé */}
    </div>
  );
};

export default CommissionWalletStats;