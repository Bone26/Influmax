import { initializeApp } from 'firebase/app';
import { getFirestore, collection, query, where, getDocs, writeBatch, doc } from 'firebase/firestore';

// Configuration Firebase
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.VITE_FIREBASE_APP_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const cleanWithdrawals = async () => {
  console.log('🧹 Nettoyage des retraits...');
  
  try {
    const batch = writeBatch(db);
    
    // 1. Récupérer tous les retraits
    const withdrawalsRef = collection(db, 'withdrawals');
    const withdrawalsSnapshot = await getDocs(withdrawalsRef);
    
    // 2. Récupérer tous les utilisateurs
    const usersRef = collection(db, 'users');
    const usersSnapshot = await getDocs(usersRef);
    const users = new Map();
    
    usersSnapshot.docs.forEach(doc => {
      users.set(doc.id, doc.data());
    });

    // 3. Pour chaque utilisateur, réinitialiser les stats
    for (const [userId, userData] of users) {
      const userRef = doc(db, 'users', userId);
      const userWithdrawals = withdrawalsSnapshot.docs
        .filter(w => w.data().userId === userId)
        .map(w => ({
          ...w.data(),
          id: w.id
        }));

      // Calculer les montants totaux
      const totalPending = userWithdrawals
        .filter(w => w.status === 'pending')
        .reduce((sum, w) => sum + w.amount, 0);

      const totalWithdrawn = userWithdrawals
        .filter(w => w.status === 'completed')
        .reduce((sum, w) => sum + w.amount, 0);

      // Mettre à jour les stats de l'utilisateur
      batch.update(userRef, {
        'affiliate.stats.pendingWithdrawals': totalPending,
        'affiliate.stats.totalWithdrawn': totalWithdrawn,
        'affiliate.stats.availableEarnings': userData.affiliate?.stats?.totalEarnings - (totalPending + totalWithdrawn),
        updatedAt: new Date()
      });
    }

    // 4. Exécuter le batch
    await batch.commit();
    console.log('✅ Nettoyage terminé avec succès');

  } catch (error) {
    console.error('❌ Erreur lors du nettoyage:', error);
  }
};

const main = async () => {
  try {
    await cleanWithdrawals();
    console.log('✨ Script terminé avec succès');
    process.exit(0);
  } catch (error) {
    console.error('💥 Erreur fatale:', error);
    process.exit(1);
  }
};

main();