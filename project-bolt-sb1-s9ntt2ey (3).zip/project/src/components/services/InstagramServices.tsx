import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Users, Heart, Eye } from 'lucide-react';
import ServiceCard from './ServiceCard';

const services = [
  {
    icon: Users,
    title: "Followers Instagram",
    description: "Augmentez votre nombre d'abonnés",
    price: "0.50",
    features: [
      "Choisissez votre niveau de qualité",
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'instagram',
    type: 'followers',
    minQuantity: 100
  },
  {
    icon: Heart,
    title: "Likes Instagram",
    description: "Boostez vos publications",
    price: "0.20",
    features: [
      "Choisissez votre niveau de qualité",
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'instagram',
    type: 'likes',
    minQuantity: 100
  },
  {
    icon: Eye,
    title: "Vues Réels",
    description: "Faites grimper vos vues",
    price: "0.50",
    features: [
      "Prix très bas",
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'instagram',
    type: 'views',
    minQuantity: 1000
  }
];

const InstagramServices = () => {
  return (
    <div>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="flex items-center justify-center gap-4 mb-8"
      >
        <div className="bg-gradient-to-br from-purple-100 to-indigo-100 p-4 rounded-xl">
          <Instagram className="h-8 w-8 text-purple-600" />
        </div>
        <h2 className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
          Services Instagram
        </h2>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
        {services.map((service, index) => (
          <ServiceCard key={index} service={service} index={index} />
        ))}
      </div>
    </div>
  );
};

export default InstagramServices;