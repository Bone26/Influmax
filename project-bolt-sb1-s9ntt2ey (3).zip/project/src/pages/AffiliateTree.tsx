import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import ReferralTree from '../components/affiliate/ReferralTree';
import { getDetailedAffiliateStats } from '../services/affiliate';
import { toast } from 'sonner';

const AffiliateTree = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<{
    referrals: any[];
    stats: any;
  } | null>(null);

  useEffect(() => {
    if (!currentUser) {
      navigate('/auth/login');
      return;
    }

    const loadData = async () => {
      try {
        setLoading(true);
        const affiliateData = await getDetailedAffiliateStats(currentUser.id);
        setData(affiliateData);
      } catch (error) {
        console.error('Error loading affiliate data:', error);
        setError('Une erreur est survenue lors du chargement des données');
        toast.error('Erreur lors du chargement des données');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [currentUser, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-8">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/affiliate')}
                className="text-white/80 hover:text-white transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div>
                <h1 className="text-3xl font-bold text-white">Mon réseau d'affiliation</h1>
                <p className="text-purple-100 mt-1">
                  Visualisez votre réseau sur 2 niveaux
                </p>
              </div>
            </div>
          </div>

          <div className="p-8">
            {error ? (
              <div className="bg-red-50 text-red-600 p-4 rounded-lg">
                {error}
              </div>
            ) : data ? (
              <ReferralTree
                currentUser={{
                  name: currentUser?.name || '',
                  email: currentUser?.email || ''
                }}
                referrals={data.referrals || []}
                stats={data.stats}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">Aucune donnée disponible</p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AffiliateTree;