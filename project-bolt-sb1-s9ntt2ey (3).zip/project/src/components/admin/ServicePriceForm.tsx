import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Save } from 'lucide-react';
import { ServicePriceConfig } from '../../types/pricing';

interface ServicePriceFormProps {
  price: ServicePriceConfig;
  formData: Partial<ServicePriceConfig>;
  onChange: (data: Partial<ServicePriceConfig>) => void;
  onSave: () => void;
}

const ServicePriceForm: React.FC<ServicePriceFormProps> = ({
  price,
  formData,
  onChange,
  onSave
}) => {
  const handleBaseChange = (value: number) => {
    onChange({
      ...formData,
      basePrice: value
    });
  };

  const handleDeliveryLimitChange = (
    deliveryTime: string,
    field: 'min' | 'max' | 'isActive',
    value: number | boolean
  ) => {
    onChange({
      ...formData,
      deliveryLimits: {
        ...formData.deliveryLimits,
        [deliveryTime]: {
          ...formData.deliveryLimits?.[deliveryTime],
          [field]: value
        }
      }
    });
  };

  const handleJapMappingChange = (field: string, value: string | number) => {
    onChange({
      ...formData,
      japMapping: {
        ...formData.japMapping,
        [field]: value
      }
    });
  };

  // Ordre chronologique des durées d'envoi
  const deliveryTimeOrder = ['instant', '24h', '3days', '7days', '1month'] as const;
  const deliveryTimeLabels = {
    'instant': 'Instantané',
    '24h': '24 heures',
    '3days': '3 jours',
    '7days': '7 jours',
    '1month': '1 mois'
  };

  return (
    <div className="space-y-8">
      {/* Prix de base */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Prix de base</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Prix unitaire (€)
            </label>
            <input
              type="number"
              value={formData.basePrice || 0}
              onChange={(e) => handleBaseChange(parseFloat(e.target.value) || 0)}
              step="0.00000001"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>
      </div>

      {/* Limites par durée d'envoi */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-2 mb-6">
          <Clock className="h-5 w-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Limites par durée d'envoi</h3>
        </div>

        <div className="space-y-4">
          {deliveryTimeOrder.map((time) => (
            <div key={time} className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.deliveryLimits?.[time]?.isActive ?? false}
                    onChange={(e) => handleDeliveryLimitChange(time, 'isActive', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                  <span className="ml-3 text-sm font-medium text-gray-700">
                    {deliveryTimeLabels[time]}
                  </span>
                </label>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Min
                </label>
                <input
                  type="number"
                  value={formData.deliveryLimits?.[time]?.min || 0}
                  onChange={(e) => handleDeliveryLimitChange(time, 'min', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Max
                </label>
                <input
                  type="number"
                  value={formData.deliveryLimits?.[time]?.max || 0}
                  onChange={(e) => handleDeliveryLimitChange(time, 'max', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Configuration JAP */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Configuration API JAP</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              ID du service JAP
            </label>
            <input
              type="text"
              value={formData.japMapping?.japServiceId || ''}
              onChange={(e) => handleJapMappingChange('japServiceId', e.target.value)}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              placeholder="ex: 4343"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nom du service JAP
            </label>
            <input
              type="text"
              value={formData.japMapping?.japServiceName || ''}
              onChange={(e) => handleJapMappingChange('japServiceName', e.target.value)}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              placeholder="ex: Instagram Likes"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantité minimum JAP
            </label>
            <input
              type="number"
              value={formData.japMapping?.minQuantity || 0}
              onChange={(e) => handleJapMappingChange('minQuantity', parseInt(e.target.value) || 0)}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              min="10"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Quantité maximum JAP
            </label>
            <input
              type="number"
              value={formData.japMapping?.maxQuantity || 0}
              onChange={(e) => handleJapMappingChange('maxQuantity', parseInt(e.target.value) || 0)}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              max="300000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Vitesse maximum par jour
            </label>
            <input
              type="number"
              value={formData.japMapping?.maxSpeed || 0}
              onChange={(e) => handleJapMappingChange('maxSpeed', parseInt(e.target.value) || 0)}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              max="50000"
            />
          </div>
        </div>
      </div>

      {/* Bouton de validation */}
      <div className="flex justify-end pt-4 border-t">
        <button
          onClick={onSave}
          className="flex items-center space-x-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Save className="h-5 w-5" />
          <span>Enregistrer les modifications</span>
        </button>
      </div>
    </div>
  );
};

export default ServicePriceForm;