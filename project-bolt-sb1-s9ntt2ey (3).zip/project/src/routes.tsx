import React, { lazy, Suspense } from 'react';
import { Navigate } from 'react-router-dom';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorBoundary from './components/ErrorBoundary';
import ProtectedRoute from './components/ProtectedRoute';

// Lazy load components
const Home = lazy(() => import('./pages/Home'));
const Services = lazy(() => import('./pages/Services'));
const ServiceSimulator = lazy(() => import('./pages/ServiceSimulator'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Orders = lazy(() => import('./pages/Orders'));
const Wallet = lazy(() => import('./pages/Wallet'));
const Settings = lazy(() => import('./pages/Settings'));
const Affiliate = lazy(() => import('./pages/Affiliate'));
const AffiliateTree = lazy(() => import('./pages/AffiliateTree'));
const WithdrawalHistory = lazy(() => import('./pages/WithdrawalHistory'));
const Admin = lazy(() => import('./pages/Admin'));
const OrderManagement = lazy(() => import('./pages/admin/OrderManagement'));
const PlatformManagement = lazy(() => import('./pages/admin/PlatformManagement'));
const PriceManagement = lazy(() => import('./pages/admin/PriceManagement'));
const WithdrawalManagement = lazy(() => import('./pages/admin/WithdrawalManagement'));
const RewardManagement = lazy(() => import('./pages/admin/RewardManagement'));
const TicketManagement = lazy(() => import('./pages/admin/TicketManagement'));
const APIManagement = lazy(() => import('./pages/admin/APIManagement'));
const ClientOrders = lazy(() => import('./pages/admin/ClientOrders'));
const Rewards = lazy(() => import('./pages/Rewards'));
const Login = lazy(() => import('./pages/auth/Login'));
const Register = lazy(() => import('./pages/auth/Register'));
const VerifyEmail = lazy(() => import('./pages/auth/VerifyEmail'));
const ForgotPassword = lazy(() => import('./pages/auth/ForgotPassword'));
const Contact = lazy(() => import('./pages/Contact'));
const ReferralLanding = lazy(() => import('./pages/ReferralLanding'));
const Support = lazy(() => import('./pages/Support'));
const MentionsLegales = lazy(() => import('./pages/legal/MentionsLegales'));
const PolitiqueConfidentialite = lazy(() => import('./pages/legal/PolitiqueConfidentialite'));
const PaymentSuccess = lazy(() => import('./pages/PaymentSuccess'));

// Helper function to wrap components with Suspense and ErrorBoundary
const withSuspense = (Component: React.ComponentType) => (
  <ErrorBoundary>
    <Suspense fallback={<LoadingSpinner />}>
      <Component />
    </Suspense>
  </ErrorBoundary>
);

const routes = [
  {
    path: '/',
    element: withSuspense(Home)
  },
  {
    path: '/services',
    element: withSuspense(Services)
  },
  {
    path: '/simulateur',
    element: withSuspense(ServiceSimulator)
  },
  {
    path: '/dashboard',
    element: <ProtectedRoute>{withSuspense(Dashboard)}</ProtectedRoute>
  },
  {
    path: '/orders',
    element: <ProtectedRoute>{withSuspense(Orders)}</ProtectedRoute>
  },
  {
    path: '/wallet',
    element: <ProtectedRoute>{withSuspense(Wallet)}</ProtectedRoute>
  },
  {
    path: '/settings',
    element: <ProtectedRoute>{withSuspense(Settings)}</ProtectedRoute>
  },
  {
    path: '/affiliate',
    element: <ProtectedRoute>{withSuspense(Affiliate)}</ProtectedRoute>
  },
  {
    path: '/affiliate/tree',
    element: <ProtectedRoute>{withSuspense(AffiliateTree)}</ProtectedRoute>
  },
  {
    path: '/affiliate/withdrawals',
    element: <ProtectedRoute>{withSuspense(WithdrawalHistory)}</ProtectedRoute>
  },
  {
    path: '/rewards',
    element: <ProtectedRoute>{withSuspense(Rewards)}</ProtectedRoute>
  },
  {
    path: '/admin',
    element: <ProtectedRoute adminOnly>{withSuspense(Admin)}</ProtectedRoute>
  },
  {
    path: '/admin/orders',
    element: <ProtectedRoute adminOnly>{withSuspense(OrderManagement)}</ProtectedRoute>
  },
  {
    path: '/admin/platforms',
    element: <ProtectedRoute adminOnly>{withSuspense(PlatformManagement)}</ProtectedRoute>
  },
  {
    path: '/admin/prices',
    element: <ProtectedRoute adminOnly>{withSuspense(PriceManagement)}</ProtectedRoute>
  },
  {
    path: '/admin/withdrawals',
    element: <ProtectedRoute adminOnly>{withSuspense(WithdrawalManagement)}</ProtectedRoute>
  },
  {
    path: '/admin/rewards',
    element: <ProtectedRoute adminOnly>{withSuspense(RewardManagement)}</ProtectedRoute>
  },
  {
    path: '/admin/tickets',
    element: <ProtectedRoute adminOnly>{withSuspense(TicketManagement)}</ProtectedRoute>
  },
  {
    path: '/admin/api',
    element: <ProtectedRoute adminOnly>{withSuspense(APIManagement)}</ProtectedRoute>
  },
  {
    path: '/admin/client-orders',
    element: <ProtectedRoute adminOnly>{withSuspense(ClientOrders)}</ProtectedRoute>
  },
  {
    path: '/auth/login',
    element: withSuspense(Login)
  },
  {
    path: '/auth/register',
    element: withSuspense(Register)
  },
  {
    path: '/auth/verify-email',
    element: withSuspense(VerifyEmail)
  },
  {
    path: '/auth/forgot-password',
    element: withSuspense(ForgotPassword)
  },
  {
    path: '/contact',
    element: withSuspense(Contact)
  },
  {
    path: '/ref',
    element: withSuspense(ReferralLanding)
  },
  {
    path: '/support',
    element: <ProtectedRoute>{withSuspense(Support)}</ProtectedRoute>
  },
  {
    path: '/mentions-legales',
    element: withSuspense(MentionsLegales)
  },
  {
    path: '/confidentialite',
    element: withSuspense(PolitiqueConfidentialite)
  },
  {
    path: '/payment/success',
    element: <ProtectedRoute>{withSuspense(PaymentSuccess)}</ProtectedRoute>
  },
  // Catch all route - redirect to home
  {
    path: '*',
    element: <Navigate to="/" replace />
  }
];

export default routes;

export { routes };