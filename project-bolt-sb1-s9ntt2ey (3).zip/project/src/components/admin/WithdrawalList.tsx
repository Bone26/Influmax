import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Eye, AlertTriangle, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { toast } from 'sonner';

interface WithdrawalListProps {
  withdrawals: any[];
  loading: boolean;
  error: string | null;
  onComplete: (id: string) => Promise<void>;
  onReject: (id: string) => Promise<void>;
}

const WithdrawalList: React.FC<WithdrawalListProps> = ({
  withdrawals,
  loading,
  error,
  onComplete,
  onReject
}) => {
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<any | null>(null);
  const [processing, setProcessing] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<{
    type: 'complete' | 'reject';
    withdrawal: any;
  } | null>(null);

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: {
        label: 'En attente',
        class: 'bg-orange-100 text-orange-800 border border-orange-200'
      },
      completed: {
        label: 'Terminé',
        class: 'bg-green-100 text-green-800 border border-green-200'
      },
      rejected: {
        label: 'Rejeté',
        class: 'bg-red-100 text-red-800 border border-red-200'
      }
    };

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;
    return (
      <span className={`px-3 py-1.5 rounded-full text-sm font-medium ${config.class}`}>
        {config.label}
      </span>
    );
  };

  const handleAction = async (type: 'complete' | 'reject', withdrawal: any) => {
    if (!withdrawal?.id) {
      toast.error('ID du retrait manquant');
      return;
    }

    setProcessing(withdrawal.id);
    try {
      if (type === 'complete') {
        await onComplete(withdrawal.id);
        toast.success('Retrait marqué comme terminé');
      } else {
        await onReject(withdrawal.id);
        toast.success('Retrait rejeté avec succès');
      }
    } catch (error) {
      console.error(`Error ${type}ing withdrawal:`, error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error(`Erreur lors du traitement du retrait`);
      }
    } finally {
      setProcessing(null);
      setConfirmAction(null);
    }
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <Loader2 className="mx-auto h-12 w-12 text-purple-600 animate-spin" />
        <p className="mt-4 text-gray-600">Chargement des retraits...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-6 rounded-lg flex items-center">
        <AlertTriangle className="h-6 w-6 mr-3 flex-shrink-0" />
        <div>
          <p className="font-medium">Une erreur est survenue</p>
          <p className="text-sm mt-1">{error}</p>
        </div>
      </div>
    );
  }

  if (withdrawals.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-lg">
        <p className="text-gray-500 font-medium">
          Aucune demande de retrait
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Montant
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Statut
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {withdrawals.map((withdrawal) => (
              <motion.tr
                key={withdrawal.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="hover:bg-gray-50 transition-colors"
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm text-gray-900">
                    {format(withdrawal.createdAt, 'PPP à HH:mm', { locale: fr })}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm font-medium text-gray-900">
                    {withdrawal.amount.toFixed(2)}€
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {getStatusBadge(withdrawal.status)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => setSelectedWithdrawal(withdrawal)}
                      className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors"
                      title="Voir les détails"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                    {withdrawal.status === 'pending' && (
                      <>
                        <button
                          onClick={() => setConfirmAction({ type: 'complete', withdrawal })}
                          className="text-green-600 hover:text-green-700 p-2 rounded-full hover:bg-green-50 transition-colors"
                          title="Marquer comme terminé"
                        >
                          <Check className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => setConfirmAction({ type: 'reject', withdrawal })}
                          className="text-red-600 hover:text-red-700 p-2 rounded-full hover:bg-red-50 transition-colors"
                          title="Rejeter"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal de détails */}
      {selectedWithdrawal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-lg p-6 max-w-lg w-full"
          >
            <h3 className="text-lg font-bold mb-4">Détails du retrait</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">ID</p>
                <p className="font-medium font-mono">{selectedWithdrawal.id}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Montant</p>
                <p className="font-medium">{selectedWithdrawal.amount.toFixed(2)}€</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">IBAN</p>
                <p className="font-medium font-mono">{selectedWithdrawal.bankDetails.iban}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">BIC</p>
                <p className="font-medium font-mono">{selectedWithdrawal.bankDetails.bic}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Titulaire</p>
                <p className="font-medium">{selectedWithdrawal.bankDetails.accountHolder}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Date de demande</p>
                <p className="font-medium">
                  {format(selectedWithdrawal.createdAt, 'PPP à HH:mm', { locale: fr })}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Statut</p>
                {getStatusBadge(selectedWithdrawal.status)}
              </div>
            </div>
            <button
              onClick={() => setSelectedWithdrawal(null)}
              className="mt-6 w-full bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Fermer
            </button>
          </motion.div>
        </div>
      )}

      {/* Modal de confirmation */}
      {confirmAction && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-lg p-6 max-w-md w-full"
          >
            <div className="flex items-center space-x-3 mb-4">
              {confirmAction.type === 'complete' ? (
                <>
                  <div className="p-2 bg-green-100 rounded-full">
                    <Check className="h-6 w-6 text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Confirmer la finalisation</h3>
                </>
              ) : (
                <>
                  <div className="p-2 bg-red-100 rounded-full">
                    <X className="h-6 w-6 text-red-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Confirmer le rejet</h3>
                </>
              )}
            </div>
            
            <p className="text-gray-600 mb-6">
              {confirmAction.type === 'complete'
                ? 'Êtes-vous sûr de vouloir marquer ce retrait comme terminé ?'
                : 'Êtes-vous sûr de vouloir rejeter ce retrait ? Le montant sera recrédité sur le compte de l\'utilisateur.'
              }
            </p>

            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Montant</span>
                <span className="font-medium">{confirmAction.withdrawal.amount.toFixed(2)}€</span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-600">Titulaire</span>
                <span className="font-medium">{confirmAction.withdrawal.bankDetails.accountHolder}</span>
              </div>
            </div>

            <div className="flex justify-end space-x-4">
              <button
                onClick={() => setConfirmAction(null)}
                className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={() => handleAction(confirmAction.type, confirmAction.withdrawal)}
                disabled={!!processing}
                className={`px-6 py-2 rounded-lg text-white transition-colors ${
                  confirmAction.type === 'complete'
                    ? 'bg-green-600 hover:bg-green-700'
                    : 'bg-red-600 hover:bg-red-700'
                } disabled:opacity-50`}
              >
                {processing === confirmAction.withdrawal.id ? (
                  <div className="flex items-center">
                    <Loader2 className="animate-spin h-5 w-5 mr-2" />
                    {confirmAction.type === 'complete' ? 'Finalisation...' : 'Rejet...'}
                  </div>
                ) : (
                  confirmAction.type === 'complete' ? 'Finaliser' : 'Rejeter'
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </>
  );
};

export default WithdrawalList;