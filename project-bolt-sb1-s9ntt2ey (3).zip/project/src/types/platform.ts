export interface Platform {
  id: string;
  name: string;
  icon: string;
  description?: string;
  gradient: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}