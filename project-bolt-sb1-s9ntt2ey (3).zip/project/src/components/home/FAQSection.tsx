import React from 'react';
import { motion } from 'framer-motion';

const faq = [
  {
    question: "Comment fonctionne le service ?",
    answer: "Nous proposons un service d'augmentation de visibilité pour renforcer votre crédibilité sociale sur les réseaux. Aucun accès à vos identifiants n'est requis."
  },
  {
    question: "Combien de temps pour voir les résultats ?",
    answer: "Les résultats commencent à apparaître dans l'heure suivant votre commande pour la plupart des services. La durée complète de livraison dépend du volume choisi et de l'option sélectionnée."
  },
  {
    question: "Les abonnés sont-ils réels ?",
    answer: "Non, les comptes ne sont pas réels. Ils servent uniquement à booster votre crédibilité sociale et attirer davantage d'engagement organique sur vos contenus."
  },
  {
    question: "Proposez-vous une garantie ?",
    answer: "Nous ne proposons pas de garantie de remplacement. Toutefois, si votre commande n'est pas livrée, un remboursement intégral sera effectué."
  }
];

const FAQSection = () => {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Questions fréquentes
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tout ce que vous devez savoir sur nos services
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {faq.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-50 rounded-xl p-6 hover:shadow-md transition-shadow duration-300"
            >
              <h3 className="text-lg font-semibold text-gray-900 mb-3">{item.question}</h3>
              <p className="text-gray-600">{item.answer}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;