// Cache des plateformes
export const platformsCache = new Map<string, {
  data: any[];
  timestamp: number;
}>();

// Durée de validité du cache en millisecondes (5 minutes)
export const CACHE_DURATION = 5 * 60 * 1000;