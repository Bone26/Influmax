// Base de données des couleurs avec thèmes et variations
export const colorDatabase = {
  'Violet': {
    name: 'Violet',
    description: 'Tons violets et pourpres',
    colors: [
      {
        name: 'Violet Royal',
        gradient: 'from-violet-500 to-purple-500',
        variants: [
          { name: 'Clair', gradient: 'from-violet-400 to-purple-400' },
          { name: 'Standard', gradient: 'from-violet-500 to-purple-500' },
          { name: 'Foncé', gradient: 'from-violet-600 to-purple-600' }
        ]
      },
      {
        name: 'Violet Indigo',
        gradient: 'from-purple-500 to-indigo-500',
        variants: [
          { name: 'Clair', gradient: 'from-purple-400 to-indigo-400' },
          { name: 'Standard', gradient: 'from-purple-500 to-indigo-500' },
          { name: 'Foncé', gradient: 'from-purple-600 to-indigo-600' }
        ]
      }
    ]
  },
  'Rose': {
    name: 'Rose',
    description: 'Tons roses et fuchsia',
    colors: [
      {
        name: 'Rose Vif',
        gradient: 'from-pink-500 to-rose-500',
        variants: [
          { name: 'Clair', gradient: 'from-pink-400 to-rose-400' },
          { name: 'Standard', gradient: 'from-pink-500 to-rose-500' },
          { name: 'Foncé', gradient: 'from-pink-600 to-rose-600' }
        ]
      },
      {
        name: 'Rose Rouge',
        gradient: 'from-rose-500 to-red-500',
        variants: [
          { name: 'Clair', gradient: 'from-rose-400 to-red-400' },
          { name: 'Standard', gradient: 'from-rose-500 to-red-500' },
          { name: 'Foncé', gradient: 'from-rose-600 to-red-600' }
        ]
      }
    ]
  },
  'Bleu': {
    name: 'Bleu',
    description: 'Tons bleus et cyan',
    colors: [
      {
        name: 'Bleu Océan',
        gradient: 'from-blue-500 to-cyan-500',
        variants: [
          { name: 'Clair', gradient: 'from-blue-400 to-cyan-400' },
          { name: 'Standard', gradient: 'from-blue-500 to-cyan-500' },
          { name: 'Foncé', gradient: 'from-blue-600 to-cyan-600' }
        ]
      },
      {
        name: 'Bleu Ciel',
        gradient: 'from-sky-500 to-blue-500',
        variants: [
          { name: 'Clair', gradient: 'from-sky-400 to-blue-400' },
          { name: 'Standard', gradient: 'from-sky-500 to-blue-500' },
          { name: 'Foncé', gradient: 'from-sky-600 to-blue-600' }
        ]
      }
    ]
  }
};

// Fonction utilitaire pour obtenir toutes les couleurs disponibles
export const getAllColors = () => {
  const allColors: { name: string; gradient: string }[] = [];
  
  Object.values(colorDatabase).forEach(category => {
    category.colors.forEach(color => {
      color.variants.forEach(variant => {
        allColors.push({
          name: `${color.name} ${variant.name}`,
          gradient: variant.gradient
        });
      });
    });
  });

  return allColors;
};

// Fonction utilitaire pour obtenir les couleurs par catégorie
export const getColorsByCategory = (categoryName: string) => {
  return colorDatabase[categoryName as keyof typeof colorDatabase]?.colors || [];
};