import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';

// Configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyANW3adUidkA-20D7Z2DWuSkIuyAIh_E0U",
  authDomain: "influmax-2025.firebaseapp.com",
  projectId: "influmax-2025",
  storageBucket: "influmax-2025.firebasestorage.app",
  messagingSenderId: "14225266685",
  appId: "1:14225266685:web:92b36f8eeed3e5b78aab94"
};

const testConnection = async () => {
  console.log('🔍 Test de connexion Firebase...\n');

  try {
    // 1. Test d'initialisation
    console.log('1️⃣ Test d\'initialisation de Firebase...');
    const app = initializeApp(firebaseConfig);
    console.log('✅ Firebase initialisé avec succès\n');

    // 2. Test de connexion Firestore
    console.log('2️⃣ Test de connexion à Firestore...');
    const db = getFirestore(app);
    
    // 3. Test de lecture
    console.log('3️⃣ Test de lecture Firestore...');
    const testCollection = collection(db, 'test_connection');
    await getDocs(testCollection);
    console.log('✅ Lecture Firestore réussie\n');

    console.log('🎉 Tous les tests de connexion ont réussi !');
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Erreur lors du test de connexion:');
    console.error(error);
    
    // Afficher des suggestions en fonction de l'erreur
    if (error.code === 'permission-denied') {
      console.log('\n👉 Suggestions:');
      console.log('1. Vérifiez les règles Firestore dans la console Firebase');
      console.log('2. Assurez-vous que les règles permettent au moins la lecture');
    } else if (error.code === 'unavailable') {
      console.log('\n👉 Suggestions:');
      console.log('1. Vérifiez votre connexion Internet');
      console.log('2. Vérifiez si un pare-feu bloque les connexions');
      console.log('3. Essayez de désactiver temporairement votre VPN si vous en utilisez un');
    }
    
    process.exit(1);
  }
};

testConnection();