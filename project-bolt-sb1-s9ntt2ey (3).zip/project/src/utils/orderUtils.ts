import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

export const formatRemainingTime = (startDate: Date, deliveryTime: string): string => {
  const now = new Date();
  const elapsed = now.getTime() - startDate.getTime();
  
  let totalDuration: number;
  switch (deliveryTime) {
    case '24h':
      totalDuration = 24 * 60 * 60 * 1000;
      break;
    case '3days':
      totalDuration = 3 * 24 * 60 * 60 * 1000;
      break;
    case '7days':
      totalDuration = 7 * 24 * 60 * 60 * 1000;
      break;
    case '1month':
      totalDuration = 30 * 24 * 60 * 60 * 1000;
      break;
    default: // instant
      totalDuration = 60 * 60 * 1000; // 1 heure
  }

  const remaining = totalDuration - elapsed;
  
  // Si le temps est écoulé, retourner "Terminé"
  if (remaining <= 0) {
    return 'Terminé';
  }

  const days = Math.floor(remaining / (1000 * 60 * 60 * 24));
  const hours = Math.floor((remaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));

  if (days > 0) {
    return `${days}j ${hours}h restants`;
  } else if (hours > 0) {
    return `${hours}h ${minutes}min restantes`;
  } else {
    return `${minutes} minutes restantes`;
  }
};

export const shouldCompleteOrder = (startDate: Date, deliveryTime: string): boolean => {
  const now = new Date();
  const elapsed = now.getTime() - startDate.getTime();
  
  let totalDuration: number;
  switch (deliveryTime) {
    case '24h':
      totalDuration = 24 * 60 * 60 * 1000;
      break;
    case '3days':
      totalDuration = 3 * 24 * 60 * 60 * 1000;
      break;
    case '7days':
      totalDuration = 7 * 24 * 60 * 60 * 1000;
      break;
    case '1month':
      totalDuration = 30 * 24 * 60 * 60 * 1000;
      break;
    default: // instant
      totalDuration = 60 * 60 * 1000; // 1 heure
  }

  return elapsed >= totalDuration;
};

// Reste du code existant...