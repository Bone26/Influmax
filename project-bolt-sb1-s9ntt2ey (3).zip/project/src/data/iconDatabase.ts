// Base de données des icônes organisée par catégories
export const iconDatabase = {
  'Réseaux sociaux': {
    name: 'Réseaux sociaux',
    description: 'Icônes pour les plateformes sociales',
    icons: [
      { name: 'Instagram', keywords: ['photo', 'social', 'media'] },
      { name: 'Facebook', keywords: ['social', 'network'] },
      { name: 'Twitter', keywords: ['social', 'tweet', 'x'] },
      { name: 'Youtube', keywords: ['video', 'streaming'] },
      { name: 'Twitch', keywords: ['streaming', 'live'] },
      { name: 'TikTok', keywords: ['video', 'short'] },
      { name: 'Linkedin', keywords: ['professional', 'business'] },
      { name: 'Github', keywords: ['code', 'development'] },
      { name: 'Discord', keywords: ['chat', 'gaming'] },
      { name: 'Snapchat', keywords: ['photo', 'social'] }
    ]
  },
  'Communication': {
    name: 'Communication',
    description: 'Icônes pour la messagerie et les interactions',
    icons: [
      { name: 'MessageCircle', keywords: ['chat', 'message', 'talk'] },
      { name: 'Mail', keywords: ['email', 'contact'] },
      { name: 'Phone', keywords: ['call', 'telephone'] },
      { name: 'Send', keywords: ['message', 'paper plane'] },
      { name: 'Share', keywords: ['social', 'spread'] },
      { name: 'Share2', keywords: ['social', 'network'] },
      { name: 'MessageSquare', keywords: ['chat', 'comment'] },
      { name: 'MessagesSquare', keywords: ['chat', 'comments'] },
      { name: 'BellRing', keywords: ['notification', 'alert'] },
      { name: 'AtSign', keywords: ['email', 'mention'] }
    ]
  },
  'Interface': {
    name: 'Interface',
    description: 'Icônes pour les éléments d\'interface',
    icons: [
      { name: 'Home', keywords: ['house', 'dashboard'] },
      { name: 'Settings', keywords: ['gear', 'preferences'] },
      { name: 'User', keywords: ['person', 'profile'] },
      { name: 'Users', keywords: ['people', 'group'] },
      { name: 'Search', keywords: ['find', 'magnifier'] },
      { name: 'Bell', keywords: ['notification', 'alert'] },
      { name: 'Menu', keywords: ['hamburger', 'navigation'] },
      { name: 'LayoutGrid', keywords: ['grid', 'view'] },
      { name: 'List', keywords: ['items', 'view'] },
      { name: 'Filter', keywords: ['sort', 'funnel'] }
    ]
  },
  'Actions': {
    name: 'Actions',
    description: 'Icônes pour les actions et contrôles',
    icons: [
      { name: 'Plus', keywords: ['add', 'create', 'new'] },
      { name: 'Minus', keywords: ['remove', 'subtract'] },
      { name: 'Check', keywords: ['validate', 'success'] },
      { name: 'X', keywords: ['close', 'delete', 'remove'] },
      { name: 'Edit', keywords: ['modify', 'pencil'] },
      { name: 'Trash', keywords: ['delete', 'bin'] },
      { name: 'Download', keywords: ['save', 'arrow'] },
      { name: 'Upload', keywords: ['send', 'arrow'] },
      { name: 'Refresh', keywords: ['reload', 'sync'] },
      { name: 'RotateCcw', keywords: ['undo', 'back'] }
    ]
  },
  'Médias': {
    name: 'Médias',
    description: 'Icônes pour le contenu multimédia',
    icons: [
      { name: 'Image', keywords: ['photo', 'picture'] },
      { name: 'Video', keywords: ['movie', 'film'] },
      { name: 'Music', keywords: ['song', 'audio'] },
      { name: 'Camera', keywords: ['photo', 'picture'] },
      { name: 'Mic', keywords: ['microphone', 'audio'] },
      { name: 'Play', keywords: ['start', 'video'] },
      { name: 'Pause', keywords: ['stop', 'video'] },
      { name: 'Volume2', keywords: ['sound', 'speaker'] },
      { name: 'Film', keywords: ['video', 'movie'] },
      { name: 'Headphones', keywords: ['audio', 'music'] }
    ]
  }
};