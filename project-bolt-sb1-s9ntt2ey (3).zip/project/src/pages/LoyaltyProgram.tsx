import React from 'react';
import { motion } from 'framer-motion';
import { Crown, Star, Shield, Gift, Sparkles, Clock, Percent, Headphones, Zap } from 'lucide-react';

const LoyaltyProgram = () => {
  const levels = [
    {
      name: 'Bronze',
      icon: Shield,
      color: 'from-amber-700 to-amber-500',
      minSpend: 0,
      benefits: [
        {
          icon: Headphones,
          title: 'Support prioritaire',
          description: 'Accès à notre équipe de support en priorité'
        },
        {
          icon: Percent,
          title: '2% de cashback',
          description: 'Sur toutes vos commandes'
        }
      ]
    },
    {
      name: 'Argent',
      icon: Star,
      color: 'from-gray-400 to-gray-300',
      minSpend: 100,
      benefits: [
        {
          icon: Headphones,
          title: 'Support prioritaire',
          description: 'Accès à notre équipe de support en priorité'
        },
        {
          icon: Percent,
          title: '5% de cashback',
          description: 'Sur toutes vos commandes'
        },
        {
          icon: Sparkles,
          title: 'Remises exclusives',
          description: 'Accès à des offres spéciales mensuelles'
        }
      ]
    },
    {
      name: 'Or',
      icon: Crown,
      color: 'from-yellow-500 to-yellow-400',
      minSpend: 500,
      benefits: [
        {
          icon: Headphones,
          title: 'Support VIP 24/7',
          description: 'Ligne directe avec notre équipe support'
        },
        {
          icon: Percent,
          title: '10% de cashback',
          description: 'Sur toutes vos commandes'
        },
        {
          icon: Sparkles,
          title: 'Remises exclusives',
          description: 'Accès à des offres spéciales hebdomadaires'
        },
        {
          icon: Zap,
          title: 'Accès anticipé',
          description: 'Accès en avant-première aux nouveaux services'
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Programme de Fidélité
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez nos différents niveaux et leurs avantages exclusifs. Plus vous commandez, plus vous gagnez !
          </p>
        </motion.div>

        {/* Levels Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {levels.map((level, index) => (
            <motion.div
              key={level.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-lg overflow-hidden"
            >
              {/* Level Header */}
              <div className={`bg-gradient-to-r ${level.color} p-6 text-white`}>
                <div className="flex items-center justify-between mb-4">
                  <level.icon className="h-8 w-8" />
                  <div className="text-sm font-medium">
                    À partir de {level.minSpend}€
                  </div>
                </div>
                <h3 className="text-2xl font-bold">{level.name}</h3>
              </div>

              {/* Benefits List */}
              <div className="p-6">
                <ul className="space-y-6">
                  {level.benefits.map((benefit, benefitIndex) => (
                    <li key={benefitIndex} className="flex items-start">
                      <div className="flex-shrink-0">
                        <benefit.icon className="h-6 w-6 text-purple-600" />
                      </div>
                      <div className="ml-4">
                        <h4 className="text-lg font-medium text-gray-900">
                          {benefit.title}
                        </h4>
                        <p className="text-gray-500">{benefit.description}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            Questions fréquentes
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900">
                Comment fonctionne le cashback ?
              </h3>
              <p className="mt-2 text-gray-600">
                Le cashback est automatiquement crédité sur votre compte après chaque commande. Vous pouvez l'utiliser pour vos prochains achats.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900">
                Comment passer au niveau supérieur ?
              </h3>
              <p className="mt-2 text-gray-600">
                Votre niveau est calculé en fonction du montant total de vos commandes. Dès que vous atteignez le seuil requis, vous passez automatiquement au niveau supérieur.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900">
                Les avantages sont-ils cumulables ?
              </h3>
              <p className="mt-2 text-gray-600">
                Oui, tous les avantages de votre niveau sont cumulables et s'appliquent automatiquement à vos commandes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoyaltyProgram;