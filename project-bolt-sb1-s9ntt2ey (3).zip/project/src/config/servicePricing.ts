export interface ServicePricing {
  minQuantity: number;
  maxQuantity: number;
  basePrice: number;
  japServiceId?: string;
}

interface QualityPricing {
  standard: ServicePricing;
  premium?: ServicePricing;
  vip?: ServicePricing;
}

export const servicePricing = {
  instagram: {
    followers: {
      standard: { 
        minQuantity: 100, 
        maxQuantity: 1000000, 
        basePrice: 0.005,
        japServiceId: '9569'
      },
      premium: { 
        minQuantity: 50, 
        maxQuantity: 10000, 
        basePrice: 0.06,
        japServiceId: '6074'
      },
      vip: { 
        minQuantity: 25, 
        maxQuantity: 1000, 
        basePrice: 0.1,
        japServiceId: '9345'
      }
    },
    likes: {
      standard: { 
        minQuantity: 100, 
        maxQuantity: 500000, 
        basePrice: 0.002,
        japServiceId: '4343'
      },
      premium: { 
        minQuantity: 50, 
        maxQuantity: 15000, 
        basePrice: 0.0375,
        japServiceId: '6073'
      },
      vip: { 
        minQuantity: 25, 
        maxQuantity: 1000, 
        basePrice: 0.1,
        japServiceId: '9346'
      }
    },
    views: {
      standard: { 
        minQuantity: 100, 
        maxQuantity: 100000000, 
        basePrice: 0.0005,
        japServiceId: '3528'
      },
      vip: { 
        minQuantity: 1000, 
        maxQuantity: 1000000, 
        basePrice: 0.0025,
        japServiceId: '3528'
      }
    }
  },
  tiktok: {
    followers: {
      standard: { 
        minQuantity: 100, 
        maxQuantity: 100000, 
        basePrice: 0.006,
        japServiceId: '8548'
      },
      premium: { 
        minQuantity: 25, 
        maxQuantity: 2500, 
        basePrice: 0.009,
        japServiceId: '8728'
      }
    },
    likes: {
      standard: { 
        minQuantity: 100, 
        maxQuantity: 100000, 
        basePrice: 0.001,
        japServiceId: '9297'
      },
      premium: { 
        minQuantity: 25, 
        maxQuantity: 2500, 
        basePrice: 0.01,
        japServiceId: '9367'
      }
    },
    views: {
      standard: { 
        minQuantity: 50, 
        maxQuantity: 30000000, 
        basePrice: 0.00002,
        japServiceId: '2260'
      },
      vip: { 
        minQuantity: 50, 
        maxQuantity: 30000000, 
        basePrice: 0.0001,
        japServiceId: '2260'
      }
    },
    saves: {
      standard: { 
        minQuantity: 50, 
        maxQuantity: 100000, 
        basePrice: 0.001,
        japServiceId: '54'
      }
    },
    shares: {
      standard: { 
        minQuantity: 100, 
        maxQuantity: 2000000, 
        basePrice: 0.001,
        japServiceId: '8105'
      }
    }
  },
  telegram: {
    members: {
      standard: { 
        minQuantity: 500, 
        maxQuantity: 10000, 
        basePrice: 0.01,
        japServiceId: '363'
      }
    },
    views: {
      standard: { 
        minQuantity: 300, 
        maxQuantity: 45000, 
        basePrice: 0.0005,
        japServiceId: '6584'
      }
    },
    reactions: {
      standard: {
        minQuantity: 50,
        maxQuantity: 50000,
        basePrice: 0.001,
        japServiceId: '6571'
      }
    }
  }
};

export const getServicePricing = (
  platform: keyof typeof servicePricing,
  serviceType: string,
  quality: string = 'standard'
): ServicePricing => {
  try {
    const platformPricing = servicePricing[platform];
    if (!platformPricing) {
      console.warn(`Platform ${platform} not found, using default pricing`);
      return { minQuantity: 100, maxQuantity: 100000, basePrice: 0.001 };
    }

    const serviceKey = Object.keys(platformPricing).find(
      key => key.toLowerCase() === serviceType.toLowerCase()
    );

    if (!serviceKey) {
      console.warn(`Service type ${serviceType} not found for platform ${platform}, using default pricing`);
      return { minQuantity: 100, maxQuantity: 100000, basePrice: 0.001 };
    }

    const servicePricingByType = platformPricing[serviceKey as keyof typeof platformPricing];
    const qualityPricing = servicePricingByType[quality as keyof QualityPricing];

    if (!qualityPricing) {
      console.warn(`Quality ${quality} not found for service ${serviceType}, using standard quality`);
      return servicePricingByType.standard;
    }

    return qualityPricing;
  } catch (error) {
    console.warn('Error getting service pricing, using default:', error);
    return { minQuantity: 100, maxQuantity: 100000, basePrice: 0.001 };
  }
};