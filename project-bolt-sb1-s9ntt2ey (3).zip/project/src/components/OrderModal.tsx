import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { X, Eye } from 'lucide-react';
import QualityComparison from './QualityComparison';
import EmojiSelector from './telegram/emoji/EmojiSelector';
import { getServicePricing } from '../config/servicePricing';
import { calculatePrice } from '../utils/priceCalculator';
import { platformStyles } from '../config/platformStyles';

interface Service {
  title: string;
  description: string;
  price: string;
  icon: any;
  features: string[];
  platform: 'instagram' | 'tiktok' | 'telegram';
  type: string;
  minQuantity?: number;
}

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  service: Service;
}

const orderSchema = z.object({
  link: z.string().min(1, "Le lien est requis"),
  quantity: z.number()
    .min(100, "La quantité minimale est de 100")
    .max(100000, "La quantité maximale est de 100 000"),
  quality: z.enum(['standard', 'premium', 'vip']),
  deliveryTime: z.enum(['instant', '24h', '3days', '7days', '1month'])
});

type OrderFormData = z.infer<typeof orderSchema>;

const OrderModal: React.FC<OrderModalProps> = ({ isOpen, onClose, service }) => {
  const [showQualityComparison, setShowQualityComparison] = useState(false);
  const [selectedEmojis, setSelectedEmojis] = useState<string[]>([]);
  const [totalPrice, setTotalPrice] = useState(0);
  const styles = platformStyles[service.platform];

  const { register, handleSubmit, watch, formState: { errors } } = useForm<OrderFormData>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      quantity: service.minQuantity || 100,
      quality: 'standard',
      deliveryTime: 'instant'
    }
  });

  const quantity = watch('quantity');
  const quality = watch('quality');
  const deliveryTime = watch('deliveryTime');

  useEffect(() => {
    try {
      const pricing = getServicePricing(service.platform, service.type, quality);
      const price = calculatePrice(quantity, pricing, deliveryTime);
      setTotalPrice(price);
    } catch (error) {
      console.error('Error calculating price:', error);
      setTotalPrice(0);
    }
  }, [quantity, quality, deliveryTime, service]);

  const onSubmit = async (data: OrderFormData) => {
    console.log('Order data:', { ...data, totalPrice, selectedEmojis });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-md transform transition-all">
        <div className={`bg-gradient-to-r ${styles.gradients.primary} p-4 rounded-t-lg flex items-center justify-between`}>
          <h2 className="text-lg font-semibold text-white">{service.title}</h2>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="p-4 space-y-4">
          <div>
            <input
              type="text"
              {...register('link')}
              placeholder="Lien de la publication"
              className={`w-full px-3 py-2 border rounded-lg text-sm ${styles.colors.focus}`}
            />
            {errors.link && (
              <p className="mt-1 text-xs text-red-500">{errors.link.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <input
                type="number"
                {...register('quantity', { valueAsNumber: true })}
                placeholder="Quantité"
                className={`w-full px-3 py-2 border rounded-lg text-sm ${styles.colors.focus}`}
              />
              {errors.quantity && (
                <p className="mt-1 text-xs text-red-500">{errors.quantity.message}</p>
              )}
            </div>

            <div>
              <select
                {...register('quality')}
                className={`w-full px-3 py-2 border rounded-lg text-sm ${styles.colors.focus}`}
              >
                <option value="standard">Standard</option>
                {service.type !== 'views' && (
                  <>
                    <option value="premium">Premium</option>
                    <option value="vip">VIP 🇫🇷</option>
                  </>
                )}
              </select>
            </div>
          </div>

          {service.platform === 'telegram' && service.type === 'reactions' && (
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sélectionnez vos réactions
              </label>
              <div className="border rounded-lg">
                <EmojiSelector
                  selectedEmojis={selectedEmojis}
                  onSelect={(emoji) => setSelectedEmojis([...selectedEmojis, emoji])}
                  onRemove={(emoji) => setSelectedEmojis(selectedEmojis.filter(e => e !== emoji))}
                />
              </div>
            </div>
          )}

          {service.type !== 'views' && (
            <button
              type="button"
              onClick={() => setShowQualityComparison(true)}
              className={`w-full text-sm flex items-center justify-center ${styles.colors.primary} hover:opacity-80 py-1`}
            >
              <Eye className="h-4 w-4 mr-1" />
              Comparer les qualités
            </button>
          )}

          <select
            {...register('deliveryTime')}
            className={`w-full px-3 py-2 border rounded-lg text-sm ${styles.colors.focus}`}
          >
            <option value="instant">Instantané (0%)</option>
            <option value="24h">24 heures (+10%)</option>
            <option value="3days">3 jours (+20%)</option>
            <option value="7days">7 jours (+30%)</option>
            <option value="1month">1 mois (+50%)</option>
          </select>

          <div className="flex items-center justify-between py-2">
            <span className="text-sm text-gray-600">Prix total:</span>
            <span className={`text-xl font-bold bg-gradient-to-r ${styles.gradients.text} bg-clip-text text-transparent`}>
              {totalPrice.toFixed(2)}€
            </span>
          </div>

          <button
            type="submit"
            className={`w-full bg-gradient-to-r ${styles.gradients.primary} text-white py-2 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity`}
          >
            Commander
          </button>
        </form>
      </div>

      <QualityComparison
        isOpen={showQualityComparison}
        onClose={() => setShowQualityComparison(false)}
        platform={service.platform}
        type={service.type}
      />
    </div>
  );
};

export default OrderModal;