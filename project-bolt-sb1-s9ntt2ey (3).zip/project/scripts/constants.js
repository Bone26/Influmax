// Packs d'emojis prédéfinis
export const POSITIVE_EMOJIS = ['👍', '❤️', '🔥', '🎉', '🤩'];
export const NEGATIVE_EMOJIS = ['👎', '😢', '💩', '🤮'];

// Mapping des emojis vers les IDs JAP
export const EMOJI_JAP_MAPPING = {
  // Emojis positifs
  '👍': '6571',
  '❤️': '6573',
  '🔥': '6574',
  '🎉': '6575',
  '🤩': '6576',
  '😁': '6578',
  '💯': '8806',
  '🍾': '8800',
  '🏆': '8805',
  '🙏': '8794',
  '👌': '8798',
  
  // Emojis négatifs
  '👎': '6572',
  '😢': '6579',
  '💩': '6580',
  '🤮': '6581',
  '😱': '6577',
  '🤡': '8795',
  '😐': '8809',
  '🖕': '8803',
  '🥱': '8799',
  '🌭': '8796'
};

// IDs des packs d'emojis mixés
export const MIXED_PACKS = {
  positive: '7256', // Pack d'emojis positifs mixés
  negative: '7257'  // Pack d'emojis négatifs mixés
};