export interface Order {
  id: string;
  userId: string;
  service: {
    platform: 'instagram' | 'tiktok' | 'telegram';
    type: string;
    quality: 'standard' | 'premium' | 'vip';
    japServiceId?: string;
    japServiceName?: string;
  };
  link: string;
  quantity: number;
  price: number;
  status: 'processing' | 'completed' | 'cancelled';
  deliveryTime: 'instant' | '24h' | '3days' | '7days' | '1month';
  progress?: {
    current: number;
    total: number;
    lastUpdate: Date;
  };
  metadata?: {
    selectedEmojis?: string[];
    startCount?: number;
    japOrderId?: string;
    refunded?: boolean;
    refundId?: string;
    refundReason?: string;
    refundedAt?: Date;
    refundedBy?: string;
    dripFeed?: {
      runs: number;
      interval: number;
      quantityPerRun: number;
      completedRuns: number;
    };
  };
  timestamps: {
    createdAt: Date;
    updatedAt: Date;
    startedAt?: Date;
    completedAt?: Date;
    cancelledAt?: Date;
  };
}

export interface OrderNote {
  id: string;
  content: string;
  type: 'internal' | 'customer' | 'system';
  createdBy: string;
  createdAt: Date;
}

export interface OrderStatusChange {
  id: string;
  orderId: string;
  previousStatus: Order['status'];
  newStatus: Order['status'];
  reason?: string;
  changedBy: string;
  changedAt: Date;
}

export interface OrderRefund {
  id: string;
  orderId: string;
  userId: string;
  amount: number;
  reason: string;
  status: 'completed';
  createdAt: Date;
  createdBy: string;
}

export type OrderStatus = Order['status'];