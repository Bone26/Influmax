import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Plus, Save, AlertTriangle, Power, ChevronDown, ChevronUp, Edit2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getAllPrices, updatePrice, createPrice } from '../../services/pricing';
import { ServicePriceConfig } from '../../types/pricing';
import { toast } from 'sonner';
import InitializePrices from '../../components/admin/InitializePrices';
import CreateServiceForm from '../../components/admin/CreateServiceForm';
import TelegramReactionPriceForm from '../../components/admin/TelegramReactionPriceForm';
import ServicePriceForm from '../../components/admin/ServicePriceForm';

const PriceManagement = () => {
  const { currentUser } = useAuth();
  const [prices, setPrices] = useState<ServicePriceConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editingPrice, setEditingPrice] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<ServicePriceConfig>>({});
  const [selectedPlatform, setSelectedPlatform] = useState<string>('telegram');
  const [selectedQuality, setSelectedQuality] = useState<string>('standard');
  const [expandedService, setExpandedService] = useState<string | null>(null);
  const [showCreateForm, setShowCreateForm] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const data = await getAllPrices();
      setPrices(data);
    } catch (error) {
      console.error('Error loading prices:', error);
      setError('Erreur lors du chargement des prix');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateService = async (data: Partial<ServicePriceConfig>) => {
    try {
      await createPrice(data);
      await loadData();
      setShowCreateForm(false);
      toast.success('Service créé avec succès');
    } catch (error) {
      console.error('Error creating service:', error);
      toast.error('Erreur lors de la création du service');
    }
  };

  const handleEdit = (price: ServicePriceConfig) => {
    setEditingPrice(price.id);
    setFormData(price);
    setExpandedService(price.id);
  };

  const handleSave = async (id: string) => {
    try {
      if (!currentUser) return;
      await updatePrice(id, formData, currentUser.id);
      await loadData();
      setEditingPrice(null);
      setFormData({});
      setExpandedService(null);
      toast.success('Prix mis à jour avec succès');
    } catch (error) {
      console.error('Error updating price:', error);
      toast.error('Erreur lors de la mise à jour du prix');
    }
  };

  const handleToggleActive = async (price: ServicePriceConfig) => {
    try {
      if (!currentUser) return;
      await updatePrice(price.id, { isActive: !price.isActive }, currentUser.id);
      await loadData();
      toast.success(`Service ${price.isActive ? 'désactivé' : 'activé'} avec succès`);
    } catch (error) {
      console.error('Error toggling service status:', error);
      toast.error('Erreur lors de la modification du statut');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link to="/admin" className="text-white/80 hover:text-white">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div>
                  <h1 className="text-2xl font-bold text-white">Gestion des prix</h1>
                  <p className="text-purple-100 text-sm">
                    Modifiez les prix et limites des services
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowCreateForm(true)}
                className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors"
              >
                <Plus className="h-5 w-5" />
                <span>Nouveau service</span>
              </button>
            </div>
          </div>

          <div className="p-4 space-y-6">
            {error && (
              <div className="p-4 bg-red-50 text-red-600 rounded-lg flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                {error}
              </div>
            )}

            {/* Platform & Quality Selection */}
            <div className="p-4 space-y-4">
              {/* Platform Selector */}
              <div className="flex space-x-4">
                {['instagram', 'tiktok', 'telegram'].map(platform => (
                  <button
                    key={platform}
                    onClick={() => setSelectedPlatform(platform)}
                    className={`flex items-center px-6 py-3 rounded-xl transition-all ${
                      selectedPlatform === platform
                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                        : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                  >
                    <span className="font-medium capitalize">{platform}</span>
                  </button>
                ))}
              </div>

              {/* Quality Selector */}
              <div className="flex space-x-4">
                {['standard', 'premium', 'vip'].map(quality => (
                  <button
                    key={quality}
                    onClick={() => setSelectedQuality(quality)}
                    className={`px-6 py-3 rounded-xl transition-all ${
                      selectedQuality === quality
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                  >
                    {quality === 'vip' ? 'VIP' : quality.charAt(0).toUpperCase() + quality.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Price List */}
            <div className="space-y-4">
              {prices
                .filter(price => 
                  price.platformId === selectedPlatform && 
                  price.quality === selectedQuality
                )
                .map((price) => (
                  <motion.div
                    key={price.id}
                    initial={false}
                    animate={{ backgroundColor: price.isActive ? '#ffffff' : '#fef2f2' }}
                    className="border rounded-lg overflow-hidden"
                  >
                    {/* Service Header */}
                    <div 
                      className="flex items-center justify-between p-4 cursor-pointer"
                      onClick={() => setExpandedService(expandedService === price.id ? null : price.id)}
                    >
                      <div>
                        <h3 className="font-medium text-gray-900 capitalize">{price.serviceType}</h3>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-sm text-gray-500">
                            Prix: {price.basePrice}€
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleActive(price);
                            }}
                            className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${
                              price.isActive
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            <Power className="h-3 w-3" />
                            <span>{price.isActive ? 'Actif' : 'Inactif'}</span>
                          </button>
                        </div>
                      </div>
                      {expandedService === price.id ? (
                        <ChevronUp className="h-5 w-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-gray-400" />
                      )}
                    </div>

                    {/* Expanded Content */}
                    {expandedService === price.id && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="border-t"
                      >
                        {editingPrice === price.id ? (
                          price.serviceType === 'reactions' ? (
                            <TelegramReactionPriceForm
                              price={price}
                              formData={formData}
                              onChange={setFormData}
                              onSave={() => handleSave(price.id)}
                            />
                          ) : (
                            <ServicePriceForm
                              price={price}
                              formData={formData}
                              onChange={setFormData}
                              onSave={() => handleSave(price.id)}
                            />
                          )
                        ) : (
                          <div className="p-4 space-y-4">
                            {/* Affichage des limites par durée */}
                            <div className="space-y-2">
                              <h4 className="text-sm font-medium text-gray-900">Limites par durée d'envoi</h4>
                              {Object.entries(price.deliveryLimits).map(([time, limits]) => (
                                <div key={time} className="flex justify-between items-center text-sm bg-gray-50 p-2 rounded-lg">
                                  <div className="flex items-center space-x-2">
                                    <span className={`w-2 h-2 rounded-full ${limits.isActive ? 'bg-green-500' : 'bg-red-500'}`} />
                                    <span className="text-gray-600">{time}</span>
                                  </div>
                                  <span className="font-medium">
                                    {limits.min ? limits.min.toLocaleString() : '-'} - {limits.max ? limits.max.toLocaleString() : '-'}
                                  </span>
                                </div>
                              ))}
                            </div>

                            {/* Affichage du mapping JAP */}
                            {price.japMapping && (
                              <div className="space-y-2">
                                <h4 className="text-sm font-medium text-gray-900">Configuration JAP</h4>
                                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                                  <p className="text-sm">
                                    <span className="font-medium">ID:</span> {price.japMapping.japServiceId}
                                  </p>
                                  <p className="text-sm">
                                    <span className="font-medium">Service:</span> {price.japMapping.japServiceName}
                                  </p>
                                  <p className="text-sm">
                                    <span className="font-medium">Limites:</span> {price.japMapping.minQuantity} - {price.japMapping.maxQuantity}
                                  </p>
                                  <p className="text-sm">
                                    <span className="font-medium">Vitesse max/jour:</span> {price.japMapping.maxSpeed}
                                  </p>
                                </div>
                              </div>
                            )}

                            {/* Affichage des réactions Telegram */}
                            {price.telegramReactions && (
                              <div className="space-y-4">
                                <h4 className="text-sm font-medium text-gray-900">Réactions Telegram</h4>
                                
                                {/* Packs mixés */}
                                <div className="grid grid-cols-2 gap-4">
                                  <div className="bg-green-50 p-4 rounded-lg">
                                    <h5 className="font-medium text-green-800 mb-2">Pack positif</h5>
                                    <div className="space-y-1 text-sm">
                                      <p>ID: {price.telegramReactions.mixedPacks.positive.japServiceId}</p>
                                      <p>Service: {price.telegramReactions.mixedPacks.positive.japServiceName}</p>
                                      <p>Limites: {price.telegramReactions.mixedPacks.positive.minQuantity} - {price.telegramReactions.mixedPacks.positive.maxQuantity}</p>
                                    </div>
                                  </div>
                                  <div className="bg-red-50 p-4 rounded-lg">
                                    <h5 className="font-medium text-red-800 mb-2">Pack négatif</h5>
                                    <div className="space-y-1 text-sm">
                                      <p>ID: {price.telegramReactions.mixedPacks.negative.japServiceId}</p>
                                      <p>Service: {price.telegramReactions.mixedPacks.negative.japServiceName}</p>
                                      <p>Limites: {price.telegramReactions.mixedPacks.negative.minQuantity} - {price.telegramReactions.mixedPacks.negative.maxQuantity}</p>
                                    </div>
                                  </div>
                                </div>

                                {/* Réactions individuelles */}
                                <div className="bg-gray-50 p-4 rounded-lg">
                                  <h5 className="font-medium text-gray-900 mb-2">Réactions individuelles</h5>
                                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                    {price.telegramReactions.individual.map((reaction, idx) => (
                                      <div key={idx} className="bg-white p-3 rounded-lg shadow-sm">
                                        <div className="flex items-center justify-between mb-2">
                                          <span className="text-2xl">{reaction.emoji}</span>
                                          <span className="text-xs text-gray-500">ID: {reaction.japServiceId}</span>
                                        </div>
                                        <div className="text-xs text-gray-600">
                                          <p>Min: {reaction.minQuantity}</p>
                                          <p>Max: {reaction.maxQuantity}</p>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            )}

                            <button
                              onClick={() => handleEdit(price)}
                              className="w-full mt-4 flex items-center justify-center space-x-2 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors"
                            >
                              <Edit2 className="h-4 w-4" />
                              <span>Modifier</span>
                            </button>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </motion.div>
                ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Formulaire de création */}
      <CreateServiceForm
        isOpen={showCreateForm}
        onClose={() => setShowCreateForm(false)}
        onSubmit={handleCreateService}
        platformId={selectedPlatform}
      />

      <InitializePrices onSuccess={loadData} />
    </div>
  );
};

export default PriceManagement;