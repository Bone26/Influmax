import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import { Search, X, Check } from 'lucide-react';

interface IconSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (iconName: string) => void;
  currentIcon?: string;
}

const IconSelector: React.FC<IconSelectorProps> = ({
  isOpen,
  onClose,
  onSelect,
  currentIcon
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [availableIcons, setAvailableIcons] = useState<string[]>([]);

  useEffect(() => {
    // Filtrer et catégoriser les icônes
    const icons = Object.keys(LucideIcons).filter(name => 
      typeof LucideIcons[name as keyof typeof LucideIcons] === 'function' &&
      name !== 'createLucideIcon' &&
      name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    setAvailableIcons(icons);
  }, [searchTerm]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden"
      >
        {/* Header */}
        <div className="p-6 border-b sticky top-0 bg-white z-10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-semibold">Sélectionner une icône</h3>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="flex items-center space-x-4">
            {/* Barre de recherche */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Rechercher une icône..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* Grille d'icônes */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-4">
            {availableIcons.map((name) => {
              const Icon = LucideIcons[name as keyof typeof LucideIcons];
              return (
                <motion.button
                  key={name}
                  type="button"
                  onClick={() => {
                    onSelect(name);
                    onClose();
                  }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`p-4 rounded-xl flex flex-col items-center space-y-2 hover:bg-purple-50 transition-colors relative group ${
                    currentIcon === name ? 'bg-purple-50 ring-2 ring-purple-500' : ''
                  }`}
                >
                  <Icon className="h-6 w-6 text-gray-600 group-hover:text-purple-600" />
                  <span className="text-xs text-gray-500 group-hover:text-purple-600 truncate w-full text-center">
                    {name}
                  </span>
                  {currentIcon === name && (
                    <div className="absolute top-1 right-1">
                      <Check className="h-4 w-4 text-purple-600" />
                    </div>
                  )}
                </motion.button>
              );
            })}
          </div>

          {availableIcons.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              Aucune icône trouvée pour "{searchTerm}"
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default IconSelector;