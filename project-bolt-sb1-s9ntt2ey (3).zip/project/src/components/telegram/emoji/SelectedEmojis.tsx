import React from 'react';
import { motion } from 'framer-motion';

interface SelectedEmojisProps {
  selectedEmojis: string[];
  maxSelections: number;
  onRemove: (emoji: string) => void;
  onClearAll: () => void;
}

export const SelectedEmojis: React.FC<SelectedEmojisProps> = ({
  selectedEmojis,
  maxSelections,
  onRemove,
  onClearAll
}) => (
  <div className="mt-4">
    <div className="flex items-center justify-between mb-2">
      <p className="text-sm text-gray-600">
        {selectedEmojis.length}/{maxSelections} réactions sélectionnées
      </p>
      {selectedEmojis.length > 0 && (
        <button
          onClick={onClearAll}
          className="text-xs text-red-600 hover:text-red-700"
        >
          Tout désélectionner
        </button>
      )}
    </div>
    
    {selectedEmojis.length > 0 && (
      <div className="p-3 bg-gray-50 rounded-lg">
        <p className="text-sm font-medium text-gray-700 mb-2">Sélection actuelle:</p>
        <div className="flex flex-wrap gap-2">
          {selectedEmojis.map((emoji) => (
            <motion.button
              key={emoji}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onRemove(emoji)}
              className="text-xl p-2 bg-white rounded-lg shadow-sm hover:bg-red-50 transition-colors"
            >
              {emoji}
            </motion.button>
          ))}
        </div>
      </div>
    )}
  </div>
);