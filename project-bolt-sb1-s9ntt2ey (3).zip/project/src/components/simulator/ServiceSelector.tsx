import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Heart, Eye, Save, Share2, MessageCircle, Vote } from 'lucide-react';
import { getAllPrices } from '../../services/pricing';

interface ServiceSelectorProps {
  platform: string;
  selectedService: string;
  onServiceChange: (service: string) => void;
}

const ServiceSelector: React.FC<ServiceSelectorProps> = ({
  platform,
  selectedService,
  onServiceChange
}) => {
  const [services, setServices] = React.useState<any[]>([]);

  React.useEffect(() => {
    const loadServices = async () => {
      try {
        const prices = await getAllPrices();
        const platformServices = prices
          .filter(p => p.platformId === platform.toLowerCase() && p.isActive)
          .reduce((acc: any[], curr) => {
            if (!acc.find((s: any) => s.type === curr.serviceType)) {
              acc.push({
                type: curr.serviceType,
                minQuantity: curr.minQuantity
              });
            }
            return acc;
          }, []);
        setServices(platformServices);
      } catch (error) {
        console.error('Error loading services:', error);
      }
    };

    loadServices();
  }, [platform]);

  const getServiceIcon = (type: string) => {
    switch (type) {
      case 'followers':
        return Users;
      case 'likes':
        return Heart;
      case 'views':
        return Eye;
      case 'saves':
        return Save;
      case 'shares':
        return Share2;
      case 'members':
        return Users;
      case 'reactions':
        return Heart;
      case 'votes':
        return Vote;
      default:
        return MessageCircle;
    }
  };

  const getServiceName = (type: string) => {
    switch (type) {
      case 'followers':
        return 'Abonnés';
      case 'likes':
        return 'Likes';
      case 'views':
        return 'Vues';
      case 'saves':
        return 'Enregistrements';
      case 'shares':
        return 'Partages';
      case 'members':
        return 'Membres';
      case 'reactions':
        return 'Réactions';
      case 'votes':
        return 'Votes';
      default:
        return type;
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Service
      </label>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <AnimatePresence mode="wait">
          {services.map((service, index) => {
            const Icon = getServiceIcon(service.type);
            const isSelected = selectedService === service.type;
            
            return (
              <motion.button
                key={service.type}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => onServiceChange(service.type)}
                className={`flex items-center space-x-3 p-4 rounded-xl border-2 transition-all ${
                  isSelected 
                    ? 'border-purple-500 bg-purple-50 text-purple-700'
                    : 'border-gray-200 hover:border-purple-200 hover:bg-purple-50/50'
                }`}
              >
                <Icon className={`h-5 w-5 ${isSelected ? 'text-purple-500' : 'text-gray-400'}`} />
                <span className="font-medium">{getServiceName(service.type)}</span>
              </motion.button>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ServiceSelector;