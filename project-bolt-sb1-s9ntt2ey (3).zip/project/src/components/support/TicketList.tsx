import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { MessageSquare, AlertCircle, Clock, CheckCircle, XCircle, ExternalLink, Trash2, AlertTriangle } from 'lucide-react';
import { Ticket } from '../../types/ticket';
import { toast } from 'sonner';
import { deleteTicket } from '../../services/tickets';
import { useAuth } from '../../contexts/AuthContext';

interface TicketListProps {
  tickets: Ticket[];
  loading: boolean;
  onSelectTicket: (ticket: Ticket) => void;
  selectedTicketId?: string;
}

const TicketList: React.FC<TicketListProps> = ({
  tickets,
  loading,
  onSelectTicket,
  selectedTicketId
}) => {
  const { currentUser } = useAuth();
  const [deletingTicketId, setDeletingTicketId] = useState<string | null>(null);
  const [ticketsState, setTicketsState] = useState<Ticket[]>(tickets);

  // Mettre à jour ticketsState quand tickets change
  React.useEffect(() => {
    setTicketsState(tickets);
  }, [tickets]);

  const getStatusConfig = (status: Ticket['status']) => {
    switch (status) {
      case 'open':
        return {
          icon: AlertCircle,
          color: 'text-yellow-600',
          bg: 'bg-yellow-100',
          text: 'En attente'
        };
      case 'processing':
        return {
          icon: Clock,
          color: 'text-blue-600',
          bg: 'bg-blue-100',
          text: 'En cours'
        };
      case 'resolved':
        return {
          icon: CheckCircle,
          color: 'text-green-600',
          bg: 'bg-green-100',
          text: 'Résolu'
        };
      case 'closed':
        return {
          icon: XCircle,
          color: 'text-gray-600',
          bg: 'bg-gray-100',
          text: 'Fermé'
        };
      default:
        return {
          icon: MessageSquare,
          color: 'text-gray-600',
          bg: 'bg-gray-100',
          text: status
        };
    }
  };

  const getCategoryText = (category: Ticket['category']): string => {
    switch (category) {
      case 'order':
        return 'Commande';
      case 'deposit':
        return 'Dépôt';
      case 'withdrawal':
        return 'Retrait';
      case 'affiliate':
        return 'Affiliation';
      case 'technical':
        return 'Technique';
      case 'other':
        return 'Autre';
      default:
        return category;
    }
  };

  const handleDelete = async (ticketId: string) => {
    if (!currentUser) return;
    
    try {
      setDeletingTicketId(ticketId);
      await deleteTicket(ticketId, currentUser.id);
      
      // Mettre à jour l'état local immédiatement
      setTicketsState(prev => prev.filter(t => t.id !== ticketId));
      
      toast.success('Ticket supprimé avec succès');
    } catch (error) {
      console.error('Error deleting ticket:', error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error('Erreur lors de la suppression du ticket');
      }
    } finally {
      setDeletingTicketId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg p-4 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Liste des tickets */}
      <div className="flex-1 overflow-y-auto p-4">
        {ticketsState.length === 0 ? (
          <div className="text-center py-12">
            <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Aucun ticket</h3>
            <p className="mt-2 text-gray-500">
              Vous n'avez pas encore créé de ticket de support
            </p>
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {ticketsState.map((ticket) => {
              const statusConfig = getStatusConfig(ticket.status);
              const StatusIcon = statusConfig.icon;
              const canDelete = ['open', 'pending'].includes(ticket.status);

              return (
                <motion.div
                  key={ticket.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -100 }}
                  className={`w-full text-left p-4 rounded-lg transition-all mb-2 ${
                    selectedTicketId === ticket.id
                      ? 'bg-purple-50 border-2 border-purple-200'
                      : 'bg-white hover:bg-gray-50 border border-gray-200'
                  }`}
                >
                  {deletingTicketId === ticket.id ? (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="p-4 bg-red-50 rounded-lg"
                    >
                      <div className="flex items-center space-x-2 text-red-600 mb-4">
                        <AlertTriangle className="h-5 w-5" />
                        <span className="font-medium">Confirmer la suppression ?</span>
                      </div>
                      <div className="flex justify-end space-x-3">
                        <button
                          onClick={() => setDeletingTicketId(null)}
                          className="px-3 py-1 text-gray-600 hover:text-gray-800"
                        >
                          Annuler
                        </button>
                        <button
                          onClick={() => handleDelete(ticket.id)}
                          className="px-3 py-1 bg-red-600 text-white rounded-lg hover:bg-red-700"
                        >
                          Supprimer
                        </button>
                      </div>
                    </motion.div>
                  ) : (
                    <div 
                      className="flex-1 min-w-0 cursor-pointer"
                      onClick={() => onSelectTicket(ticket)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <h3 className="text-sm font-medium text-gray-900 truncate">
                              {ticket.subject}
                            </h3>
                            {ticket.unreadCount > 0 && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800">
                                {ticket.unreadCount} {ticket.unreadCount === 1 ? 'nouveau' : 'nouveaux'}
                              </span>
                            )}
                          </div>
                          <div className="mt-1 flex items-center space-x-2 text-sm text-gray-500">
                            <span className="truncate">#{ticket.id.slice(0, 8)}</span>
                            <span>•</span>
                            <span>{format(ticket.createdAt, 'PPp', { locale: fr })}</span>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 ml-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusConfig.bg} ${statusConfig.color}`}>
                            {statusConfig.text}
                          </span>
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                            {getCategoryText(ticket.category)}
                          </span>
                          {ticket.orderId && (
                            <ExternalLink className="h-4 w-4 text-gray-400" />
                          )}
                          {canDelete && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setDeletingTicketId(ticket.id);
                              }}
                              className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      {ticket.lastMessage && (
                        <div className="mt-2 text-sm text-gray-600 line-clamp-1">
                          <span className="font-medium">{ticket.lastMessage.content}</span>
                        </div>
                      )}
                    </div>
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
};

export default TicketList;