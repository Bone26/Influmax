import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, MessageSquare, AlertCircle, Send, ShoppingBag, Wallet, Users, Wrench, MoreHorizontal } from 'lucide-react';
import { Ticket } from '../../types/ticket';
import { createTicket } from '../../services/tickets';
import { useAuth } from '../../contexts/AuthContext';

interface CreateTicketModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  orderId?: string;
}

const CreateTicketModal: React.FC<CreateTicketModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  orderId
}) => {
  const { currentUser } = useAuth();
  const [formData, setFormData] = useState({
    subject: '',
    category: 'other' as Ticket['category'],
    message: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const categories = [
    { id: 'order', label: 'Commande', icon: ShoppingBag },
    { id: 'deposit', label: 'Dépôt', icon: Wallet },
    { id: 'withdrawal', label: 'Retrait', icon: Wallet },
    { id: 'affiliate', label: 'Affiliation', icon: Users },
    { id: 'technical', label: 'Technique', icon: Wrench },
    { id: 'other', label: 'Autre', icon: MoreHorizontal }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setLoading(true);
    setError('');

    try {
      await createTicket(
        currentUser.id,
        currentUser.name,
        formData.subject,
        formData.category,
        formData.message,
        orderId
      );
      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error creating ticket:', error);
      setError('Une erreur est survenue lors de la création du ticket');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white w-full max-w-lg rounded-2xl shadow-xl"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <MessageSquare className="h-6 w-6 text-white mr-3" />
              <h3 className="text-xl font-semibold text-white">Nouveau ticket</h3>
            </div>
            <button onClick={onClose} className="text-white/80 hover:text-white">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm"
            >
              <AlertCircle className="h-4 w-4 mr-1 inline-block" />
              {error}
            </motion.div>
          )}

          {/* Catégories */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                type="button"
                onClick={() => setFormData(prev => ({ ...prev, category: category.id as Ticket['category'] }))}
                className={`flex items-center px-3 py-1.5 rounded-full text-sm transition-colors ${
                  formData.category === category.id
                    ? 'bg-purple-100 text-purple-700'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <category.icon className="h-4 w-4 mr-1.5" />
                {category.label}
              </button>
            ))}
          </div>

          {/* Sujet */}
          <div>
            <input
              type="text"
              value={formData.subject}
              onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-purple-500"
              placeholder="Sujet de votre demande"
              required
            />
          </div>

          {/* Message */}
          <div>
            <textarea
              value={formData.message}
              onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
              rows={4}
              className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-purple-500"
              placeholder="Décrivez votre demande en détail..."
              required
            />
          </div>

          {/* Boutons */}
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || !formData.subject || !formData.message}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                  Envoi...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Envoyer
                </>
              )}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default CreateTicketModal;