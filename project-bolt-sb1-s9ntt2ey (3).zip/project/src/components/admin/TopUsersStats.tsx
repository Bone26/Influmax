import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Crown, Medal, Users, TrendingUp, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface TopUser {
  id: string;
  name: string;
  photoURL?: string;
  totalEarnings: number;
  level1Earnings: number;
  level2Earnings: number;
  totalReferrals: number;
  level1Referrals: number;
  level2Referrals: number;
  monthlyGrowth: number;
  lastMonthEarnings: number;
}

interface TopUsersStatsProps {
  users: TopUser[];
}

const TopUsersStats: React.FC<TopUsersStatsProps> = ({ users = [] }) => {
  if (users.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
        <h2 className="text-xl font-semibold mb-4">Top 5 Affiliés</h2>
        <p className="text-gray-500 text-center py-4">
          Aucun affilié avec des gains pour le moment
        </p>
      </div>
    );
  }

  const getIcon = (index: number) => {
    switch (index) {
      case 0:
        return Crown;
      case 1:
        return Trophy;
      case 2:
        return Medal;
      default:
        return Trophy;
    }
  };

  const getGradient = (index: number) => {
    switch (index) {
      case 0:
        return 'from-yellow-500 to-yellow-400';
      case 1:
        return 'from-gray-400 to-gray-300';
      case 2:
        return 'from-amber-700 to-amber-500';
      default:
        return 'from-gray-500 to-gray-400';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
      <h2 className="text-xl font-semibold mb-6">Top 5 Affiliés</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {users.map((user, index) => {
          const Icon = getIcon(index);
          const growthIsPositive = user.monthlyGrowth >= 0;

          return (
            <motion.div
              key={user.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-50 rounded-xl p-6 relative"
            >
              {/* Position Badge */}
              <div className={`absolute -top-3 -right-3 w-8 h-8 rounded-full bg-gradient-to-r ${getGradient(index)} flex items-center justify-center text-white font-bold shadow-lg`}>
                #{index + 1}
              </div>

              <div className="flex items-center space-x-4 mb-4">
                {/* User Avatar */}
                <div className="relative">
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                      <span className="text-lg font-bold text-purple-600">
                        {user.name[0].toUpperCase()}
                      </span>
                    </div>
                  )}
                  <div className={`absolute -bottom-1 -right-1 p-1.5 rounded-full bg-gradient-to-r ${getGradient(index)}`}>
                    <Icon className="h-3 w-3 text-white" />
                  </div>
                </div>

                {/* User Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-medium text-gray-900 truncate">
                    {user.name}
                  </h3>
                  <p className="text-lg font-bold text-purple-600">
                    {user.totalEarnings.toLocaleString()}€
                  </p>
                </div>
              </div>

              {/* Detailed Stats */}
              <div className="space-y-4">
                {/* Monthly Growth */}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Croissance mensuelle</span>
                  <div className={`flex items-center ${
                    growthIsPositive ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {growthIsPositive ? (
                      <ArrowUpRight className="h-4 w-4 mr-1" />
                    ) : (
                      <ArrowDownRight className="h-4 w-4 mr-1" />
                    )}
                    {Math.abs(user.monthlyGrowth)}%
                  </div>
                </div>

                {/* Referrals */}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Filleuls</span>
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-gray-400" />
                    <span className="font-medium">
                      {user.totalReferrals} ({user.level1Referrals} + {user.level2Referrals})
                    </span>
                  </div>
                </div>

                {/* Level Distribution */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Niveau 1</span>
                    <span>{user.level1Earnings.toLocaleString()}€</span>
                  </div>
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>Niveau 2</span>
                    <span>{user.level2Earnings.toLocaleString()}€</span>
                  </div>
                </div>

                {/* Monthly Trend */}
                <div className="pt-4 border-t">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Dernier mois</span>
                    <span className="font-medium">
                      {user.lastMonthEarnings.toLocaleString()}€
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};

export default TopUsersStats;