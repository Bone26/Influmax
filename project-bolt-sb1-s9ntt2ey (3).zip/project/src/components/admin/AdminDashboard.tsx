import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { MessageCircle, ExternalLink, Clock, Menu, X, Settings, DollarSign, Wallet, Gift, Database, Users } from 'lucide-react';
import AdminStats from './AdminStats';
import AdminCharts from './AdminCharts';
import OrdersTable from './OrdersTable';

interface AdminDashboardProps {
  orders: any[];
  loading: boolean;
  searchTerm: string;
  statusFilter: string;
  onSearchChange: (value: string) => void;
  onStatusChange: (value: string) => void;
  onValidate: (orderId: string) => Promise<void>;
  onReject: (orderId: string) => Promise<void>;
  adminLinks: Array<{
    to: string;
    icon: any;
    label: string;
    primary?: boolean;
  }>;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({
  orders,
  loading,
  searchTerm,
  statusFilter,
  onSearchChange,
  onStatusChange,
  onValidate,
  onReject,
  adminLinks
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="space-y-6">
      {/* Mobile Menu Button */}
      <div className="lg:hidden flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Administration</h2>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 text-gray-600 hover:text-gray-900"
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:hidden bg-white rounded-xl shadow-lg p-4 mb-6"
        >
          <div className="grid grid-cols-2 gap-4">
            {adminLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`flex flex-col items-center p-4 rounded-lg transition-colors ${
                  link.primary
                    ? 'bg-purple-600 text-white hover:bg-purple-700'
                    : 'bg-gray-50 hover:bg-gray-100'
                }`}
              >
                <link.icon className={`h-6 w-6 mb-2 ${link.primary ? 'text-white' : 'text-purple-600'}`} />
                <span className={`text-sm font-medium ${link.primary ? 'text-white' : 'text-gray-900'}`}>
                  {link.label}
                </span>
              </Link>
            ))}
          </div>
        </motion.div>
      )}

      {/* Desktop Navigation */}
      <div className="hidden lg:flex justify-between items-center">
        <h2 className="text-2xl font-bold">Administration</h2>
        <div className="flex space-x-4">
          {adminLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
                link.primary
                  ? 'bg-purple-600 text-white hover:bg-purple-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <link.icon className="h-5 w-5 mr-2" />
              {link.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid gap-6">
        <AdminStats orders={orders} />
      </div>

      {/* Charts Section */}
      <div className="hidden md:block">
        <AdminCharts orders={orders} />
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <OrdersTable
          orders={orders}
          isLoading={loading}
          onValidate={onValidate}
          onReject={onReject}
        />
      </div>
    </div>
  );
};

export default AdminDashboard;