import { Handler } from '@netlify/functions';
import axios from 'axios';
import qs from 'qs';

const handler: Handler = async (event) => {
  // CORS headers
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: corsHeaders,
      body: ''
    };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Parse request body
    const body = JSON.parse(event.body || '{}');
    
    // Add API key
    const data = new URLSearchParams({
      key: process.env.JAP_API_KEY!,
      ...body
    });

    // Log request in development
    if (process.env.NODE_ENV === 'development') {
      console.log('📤 Request:', {
        ...body,
        key: '[REDACTED]'
      });
    }

    // Make request to JAP API with retry logic
    let retries = 3;
    let lastError;

    while (retries > 0) {
      try {
        const response = await axios.post('https://justanotherpanel.com/api/v2', data.toString(), {
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Cache-Control': 'no-cache',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Connection': 'keep-alive',
            'Keep-Alive': 'timeout=60, max=100'
          },
          timeout: 10000
        });

        // Log response in development
        if (process.env.NODE_ENV === 'development') {
          console.log('📥 Response:', response.data);
        }

        return {
          statusCode: 200,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders
          },
          body: JSON.stringify(response.data)
        };
      } catch (error) {
        lastError = error;
        retries--;
        
        if (retries > 0) {
          // Wait before retrying (exponential backoff)
          await new Promise(resolve => setTimeout(resolve, (3 - retries) * 1000));
          continue;
        }
        throw error;
      }
    }

    throw lastError;
  } catch (error) {
    console.error('❌ Error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders
      },
      body: JSON.stringify({
        error: 'Internal Server Error',
        message: error instanceof Error ? error.message : 'Unknown error'
      })
    };
  }
};

export { handler };