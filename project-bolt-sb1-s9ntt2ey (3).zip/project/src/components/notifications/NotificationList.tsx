import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Bell, ShoppingBag, Wallet, Users, Gift, MessageCircle, Check } from 'lucide-react';

interface NotificationListProps {
  notifications: any[];
  onClose: () => void;
  onNotificationClick: (id: string) => void;
  onMarkAllAsRead: () => void;
}

const NotificationList: React.FC<NotificationListProps> = ({ 
  notifications, 
  onClose, 
  onNotificationClick,
  onMarkAllAsRead
}) => {
  const getIcon = (type: string) => {
    switch (type) {
      case 'order':
        return ShoppingBag;
      case 'deposit':
      case 'withdrawal':
        return Wallet;
      case 'referral':
        return Users;
      case 'reward':
        return Gift;
      case 'admin':
        return MessageCircle;
      default:
        return Bell;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'bg-green-100 text-green-600';
      case 'warning':
        return 'bg-yellow-100 text-yellow-600';
      case 'error':
        return 'bg-red-100 text-red-600';
      default:
        return 'bg-blue-100 text-blue-600';
    }
  };

  return (
    <div className="max-h-[80vh] overflow-hidden flex flex-col">
      <div className="p-4 bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white">Notifications</h3>
        {notifications.some(n => !n.read) && (
          <button
            onClick={onMarkAllAsRead}
            className="text-sm text-white/80 hover:text-white flex items-center space-x-1"
          >
            <Check className="h-4 w-4" />
            <span>Tout marquer comme lu</span>
          </button>
        )}
      </div>

      <div className="overflow-y-auto flex-1">
        {notifications.length === 0 ? (
          <div className="p-8 text-center text-gray-500">
            <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>Aucune notification</p>
          </div>
        ) : (
          <div className="divide-y">
            {notifications.map((notification) => {
              const Icon = getIcon(notification.type);
              return (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  onClick={() => onNotificationClick(notification.id)}
                  className={`p-4 hover:bg-gray-50 transition-colors cursor-pointer ${
                    !notification.read ? 'bg-purple-50/50' : ''
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg ${getTypeColor(notification.type)}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 truncate">{notification.title}</p>
                      <p className="text-sm text-gray-600 line-clamp-2">{notification.message}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        {format(notification.createdAt, 'PPp', { locale: fr })}
                      </p>
                    </div>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-purple-500 rounded-full mt-2" />
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationList;