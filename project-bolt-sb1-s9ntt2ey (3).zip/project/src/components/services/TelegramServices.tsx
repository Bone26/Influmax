import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Users, Eye } from 'lucide-react';
import ServiceCard from './ServiceCard';

const services = [
  {
    icon: Users,
    title: "Membres Telegram",
    description: "Augmentez vos membres",
    price: "10",
    features: [
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Canal public ou groupe",
      "Support 24/7"
    ],
    platform: 'telegram',
    type: 'members',
    minQuantity: 500
  },
  {
    icon: Eye,
    title: "Vues Telegram",
    description: "Augmentez la visibilité",
    price: "1",
    features: [
      "Livraison personnalisable",
      "Aucun mot de passe requis", 
      "Canal public ou groupe",
      "Support 24/7"
    ],
    platform: 'telegram',
    type: 'views',
    minQuantity: 300
  }
];

const TelegramServices = () => {
  return (
    <div>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="flex items-center justify-center gap-4 mb-8"
      >
        <div className="bg-gradient-to-br from-blue-100 to-cyan-100 p-4 rounded-xl">
          <MessageCircle className="h-8 w-8 text-blue-600" />
        </div>
        <h2 className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
          Services Telegram
        </h2>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
        {services.map((service, index) => (
          <ServiceCard key={index} service={service} index={index} />
        ))}
      </div>
    </div>
  );
};

export default TelegramServices;

export default TelegramServices