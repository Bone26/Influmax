import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Package, AlertTriangle, Smile } from 'lucide-react';
import { EMOJI_JAP_MAPPING } from './constants';

interface EmojiSelectorProps {
  selectedEmojis: string[];
  onSelect: (emoji: string) => void;
  onRemove: (emoji: string) => void;
  onSelectPack?: (type: 'positive' | 'negative' | null) => void;
}

const EmojiSelector: React.FC<EmojiSelectorProps> = ({
  selectedEmojis,
  onSelect,
  onRemove,
  onSelectPack
}) => {
  const [mode, setMode] = useState<'custom' | 'pack'>('custom');
  const [selectedPack, setSelectedPack] = useState<'positive' | 'negative' | null>(null);

  // Tous les emojis disponibles pour le mode personnalisé
  const allEmojis = Object.keys(EMOJI_JAP_MAPPING);

  const handleEmojiClick = (emoji: string) => {
    if (selectedEmojis.includes(emoji)) {
      onRemove(emoji);
    } else if (selectedEmojis.length === 0) { // Limiter à un seul emoji
      onSelect(emoji);
    }
  };

  const handlePackSelect = (packType: 'positive' | 'negative') => {
    if (selectedPack === packType) {
      setSelectedPack(null);
      onSelectPack?.(null);
    } else {
      setSelectedPack(packType);
      onSelectPack?.(packType);
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Mode selector */}
      <div className="grid grid-cols-2 gap-4">
        <button
          type="button"
          onClick={() => {
            setMode('custom');
            setSelectedPack(null);
            onSelectPack?.(null);
          }}
          className={`flex flex-col items-center justify-center p-6 rounded-xl border-2 transition-all ${
            mode === 'custom'
              ? 'border-purple-500 bg-purple-50 text-purple-700'
              : 'border-gray-200 hover:border-purple-200'
          }`}
        >
          <Smile className="h-8 w-8 mb-2" />
          <span className="font-medium">Réaction personnalisée</span>
          <p className="text-sm text-gray-500 mt-2">
            Choisissez une réaction
          </p>
        </button>

        <button
          type="button"
          onClick={() => {
            setMode('pack');
            selectedEmojis.forEach(onRemove); // Vider la sélection custom
          }}
          className={`flex flex-col items-center justify-center p-6 rounded-xl border-2 transition-all ${
            mode === 'pack'
              ? 'border-purple-500 bg-purple-50 text-purple-700'
              : 'border-gray-200 hover:border-purple-200'
          }`}
        >
          <Package className="h-8 w-8 mb-2" />
          <span className="font-medium">Pack de réactions</span>
          <p className="text-sm text-gray-500 mt-2">
            Utilisez un pack prédéfini
          </p>
        </button>
      </div>

      {/* Message d'information */}
      <div className="bg-blue-50 p-4 rounded-xl">
        <div className="flex items-center text-sm text-blue-700">
          <AlertTriangle className="h-5 w-5 mr-2" />
          <p>
            {mode === 'custom' 
              ? selectedEmojis.length === 1
                ? "Pour ajouter d'autres réactions, créez une nouvelle commande"
                : "Sélectionnez une réaction"
              : "Choisissez un pack de réactions prédéfini"
            }
          </p>
        </div>
      </div>

      {mode === 'custom' ? (
        // Sélection des réactions individuelles
        <div className="space-y-6">
          <div className="grid grid-cols-5 gap-2">
            {allEmojis.map((emoji) => (
              <motion.button
                key={emoji}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleEmojiClick(emoji)}
                className={`text-2xl p-2 rounded-lg transition-colors ${
                  selectedEmojis.includes(emoji)
                    ? 'bg-purple-100 ring-2 ring-purple-500 shadow-md'
                    : selectedEmojis.length === 1
                    ? 'bg-gray-100 cursor-not-allowed opacity-50'
                    : 'bg-gray-50 hover:bg-gray-100'
                }`}
                disabled={selectedEmojis.length === 1 && !selectedEmojis.includes(emoji)}
              >
                {emoji}
              </motion.button>
            ))}
          </div>

          {selectedEmojis.length > 0 && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-gray-600">
                  Réaction sélectionnée
                </p>
                <button
                  onClick={() => selectedEmojis.forEach(onRemove)}
                  className="text-xs text-red-600 hover:text-red-700"
                >
                  Désélectionner
                </button>
              </div>
              
              <div className="p-3 bg-gray-50 rounded-lg">
                <div className="flex flex-wrap gap-2">
                  {selectedEmojis.map((emoji) => (
                    <motion.button
                      key={emoji}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => onRemove(emoji)}
                      className="text-xl p-2 bg-white rounded-lg shadow-sm hover:bg-red-50 transition-colors"
                    >
                      {emoji}
                    </motion.button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        // Sélection du pack
        <div className="grid grid-cols-2 gap-4">
          <motion.button
            type="button"
            onClick={() => handlePackSelect('positive')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`relative p-6 rounded-xl transition-all transform ${
              selectedPack === 'positive'
                ? 'bg-green-100 ring-2 ring-green-500 shadow-lg scale-[1.02]'
                : 'bg-green-50 hover:bg-green-100'
            }`}
          >
            {selectedPack === 'positive' && (
              <div className="absolute -top-2 -right-2 bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium shadow-lg">
                Sélectionné
              </div>
            )}
            <h4 className="font-medium text-green-800 mb-4">Pack positif</h4>
            <div className="flex flex-wrap gap-2 justify-center">
              <span className="text-3xl">👍🏼</span>
              <span className="text-3xl">❤️</span>
              <span className="text-3xl">🔥</span>
              <span className="text-3xl">🎉</span>
              <span className="text-3xl">🤩</span>
            </div>
          </motion.button>

          <motion.button
            type="button"
            onClick={() => handlePackSelect('negative')}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`relative p-6 rounded-xl transition-all transform ${
              selectedPack === 'negative'
                ? 'bg-red-100 ring-2 ring-red-500 shadow-lg scale-[1.02]'
                : 'bg-red-50 hover:bg-red-100'
            }`}
          >
            {selectedPack === 'negative' && (
              <div className="absolute -top-2 -right-2 bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium shadow-lg">
                Sélectionné
              </div>
            )}
            <h4 className="font-medium text-red-800 mb-4">Pack négatif</h4>
            <div className="flex flex-wrap gap-2 justify-center">
              <span className="text-3xl">👎🏼</span>
              <span className="text-3xl">😥</span>
              <span className="text-3xl">💩</span>
              <span className="text-3xl">🤮</span>
            </div>
          </motion.button>
        </div>
      )}
    </div>
  );
};

export default EmojiSelector;