import React from 'react';
import { motion } from 'framer-motion';
import { Clock } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface StatusChange {
  id: string;
  status: string;
  changedAt: Date;
  changedBy: string;
  note?: string;
}

interface StatusHistoryProps {
  orderId: string;
  history: StatusChange[];
}

const StatusHistory: React.FC<StatusHistoryProps> = ({ orderId, history }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Terminé';
      case 'processing':
        return 'En cours';
      case 'pending':
        return 'En attente';
      case 'cancelled':
        return 'Annulé';
      default:
        return status;
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Historique des statuts</h3>

      <div className="relative">
        {/* Ligne verticale */}
        <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200" />

        <div className="space-y-6">
          {history.map((change, index) => (
            <motion.div
              key={change.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="relative pl-10"
            >
              {/* Point sur la ligne */}
              <div className="absolute left-2.5 -translate-x-1/2 w-3 h-3 rounded-full bg-white border-2 border-purple-600" />

              <div className="bg-white p-4 rounded-lg border">
                <div className="flex items-center justify-between mb-2">
                  <span className={`px-2 py-1 rounded-full text-sm font-medium border ${getStatusColor(change.status)}`}>
                    {getStatusText(change.status)}
                  </span>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {format(change.changedAt, 'PPP à HH:mm', { locale: fr })}
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">
                    Modifié par {change.changedBy}
                  </span>
                </div>
                {change.note && (
                  <p className="mt-2 text-sm text-gray-600 border-t pt-2">
                    {change.note}
                  </p>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StatusHistory;