import 'dotenv/config';
import axios from 'axios';

const testClientOrder = async () => {
  console.log('🔍 Test de commande client...\n');

  // Vérifier les variables d'environnement
  if (!process.env.VITE_API_URL) {
    console.error('❌ URL de l\'API manquante dans .env');
    process.exit(1);
  }

  if (!process.env.VITE_API_KEY) {
    console.error('❌ Clé API manquante dans .env');
    process.exit(1);
  }

  console.log('URL:', process.env.VITE_API_URL);
  console.log('API Key:', '✓ Présente\n');

  // Créer l'instance axios avec la bonne configuration
  const japApi = axios.create({
    baseURL: process.env.VITE_API_URL,
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'User-Agent': 'PostmanRuntime/7.43.0'
    },
    timeout: 30000
  });

  try {
    // Test de l'endpoint /services
    console.log('1️⃣ Test de l\'endpoint /services...');
    const servicesResponse = await japApi.post('/services', {
      key: process.env.VITE_API_KEY,
      action: 'services'
    });
    
    if (servicesResponse.data.error) {
      throw new Error(servicesResponse.data.error);
    }

    console.log('✅ Services récupérés:', servicesResponse.data.length);

    // Créer une commande test
    console.log('\n2️⃣ Test de création de commande...');
    const orderData = {
      key: process.env.VITE_API_KEY,
      action: 'add',
      service: '4343', // Instagram Likes [Standard]
      link: 'https://www.instagram.com/p/example',
      quantity: 100
    };

    console.log('📦 Données de la commande:', orderData);
    const orderResponse = await japApi.post('/add', orderData);
    
    if (orderResponse.data.error) {
      throw new Error(orderResponse.data.error);
    }

    console.log('\n✅ Commande créée avec succès !');
    console.log('🔍 Réponse:', orderResponse.data);

    // Vérifier le statut de la commande
    console.log('\n3️⃣ Vérification du statut...');
    const statusResponse = await japApi.post('/status', {
      key: process.env.VITE_API_KEY,
      action: 'status',
      orders: [orderResponse.data.order]
    });

    console.log('📊 Statut:', statusResponse.data);

    console.log('\n🎉 Test terminé avec succès !');
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Erreur lors du test:', error.message);
    
    if (error.response) {
      console.error(`Status: ${error.response.status}`);
      console.error('Message:', error.response.data);
      
      if (error.response.status === 401) {
        console.log('\n👉 Erreur d\'authentification');
        console.log('Suggestions:');
        console.log('1. Vérifiez que votre clé API est correcte');
        console.log('2. Vérifiez que la clé n\'a pas expiré');
      }
    }
    
    process.exit(1);
  }
};

testClientOrder();