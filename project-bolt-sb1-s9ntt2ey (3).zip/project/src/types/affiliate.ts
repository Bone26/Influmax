export interface AffiliateStats {
  totalEarnings: number;
  availableEarnings: number;
  totalReferrals: number;
  activeReferrals: number;
  totalWithdrawn: number;
}

export interface Affiliate {
  id: string;
  userId: string;
  referralCode: string;
  referrerId: string | null;
  stats: AffiliateStats;
  createdAt: Date;
  updatedAt: Date;
}

export interface Withdrawal {
  id: string;
  userId: string;
  amount: number;
  status: 'pending' | 'completed' | 'rejected';
  bankDetails: {
    iban: string;
    bic: string;
    accountHolder: string;
  };
  createdAt: Date;
  updatedAt: Date;
}