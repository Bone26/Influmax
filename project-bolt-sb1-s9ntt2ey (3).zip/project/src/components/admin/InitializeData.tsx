import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { collection, doc, setDoc, getDocs, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { toast } from 'sonner';

const InitializeData = () => {
  const [loading, setLoading] = useState(false);

  const initializePlatforms = async () => {
    const platforms = [
      {
        name: 'Instagram',
        icon: 'Instagram',
        isActive: true
      },
      {
        name: 'TikTok', 
        icon: 'Music2',
        isActive: true
      },
      {
        name: 'Telegram',
        icon: 'MessageCircle', 
        isActive: true
      }
    ];

    console.log('Initializing platforms...');
    
    for (const platform of platforms) {
      const platformRef = doc(collection(db, 'platforms'));
      const now = new Date();
      
      await setDoc(platformRef, {
        id: platformRef.id,
        ...platform,
        createdAt: Timestamp.fromDate(now),
        updatedAt: Timestamp.fromDate(now)
      });
      
      console.log(`Created platform: ${platform.name}`);
      toast.success(`Plateforme créée : ${platform.name}`);
    }
  };

  const initializeServices = async () => {
    // Récupérer les IDs des plateformes
    const platformsSnapshot = await getDocs(collection(db, 'platforms'));
    const platforms = {};
    platformsSnapshot.forEach(doc => {
      platforms[doc.data().name.toLowerCase()] = doc.id;
    });

    const services = [
      // Instagram Services
      {
        name: 'Followers Instagram',
        platformId: platforms.instagram,
        type: 'followers',
        basePrice: 0.50,
        minQuantity: 20,
        maxQuantity: 10000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'premium', multiplier: 1.5, isAvailable: true },
          { type: 'vip', multiplier: 2, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Likes Instagram',
        platformId: platforms.instagram,
        type: 'likes',
        basePrice: 0.20,
        minQuantity: 10,
        maxQuantity: 10000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'premium', multiplier: 1.5, isAvailable: true },
          { type: 'vip', multiplier: 2, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Vues Réels',
        platformId: platforms.instagram,
        type: 'views',
        basePrice: 0.50,
        minQuantity: 1000,
        maxQuantity: 100000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },

      // TikTok Services
      {
        name: 'Followers TikTok',
        platformId: platforms.tiktok,
        type: 'followers',
        basePrice: 2,
        minQuantity: 100,
        maxQuantity: 10000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'premium', multiplier: 1.5, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Likes TikTok',
        platformId: platforms.tiktok,
        type: 'likes',
        basePrice: 1,
        minQuantity: 1000,
        maxQuantity: 100000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'premium', multiplier: 1.5, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Vues TikTok',
        platformId: platforms.tiktok,
        type: 'views',
        basePrice: 0.02,
        minQuantity: 1000,
        maxQuantity: 1000000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'vip', multiplier: 2, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Enregistrements TikTok',
        platformId: platforms.tiktok,
        type: 'saves',
        basePrice: 0.50,
        minQuantity: 1000,
        maxQuantity: 100000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Partages TikTok',
        platformId: platforms.tiktok,
        type: 'shares',
        basePrice: 1,
        minQuantity: 1000,
        maxQuantity: 100000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },

      // Telegram Services
      {
        name: 'Membres Telegram',
        platformId: platforms.telegram,
        type: 'members',
        basePrice: 10,
        minQuantity: 500,
        maxQuantity: 100000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Réactions Telegram',
        platformId: platforms.telegram,
        type: 'reactions',
        basePrice: 1,
        minQuantity: 100,
        maxQuantity: 100000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Vues Telegram',
        platformId: platforms.telegram,
        type: 'views',
        basePrice: 1,
        minQuantity: 100,
        maxQuantity: 1000000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      {
        name: 'Votes Sondage Telegram',
        platformId: platforms.telegram,
        type: 'votes',
        basePrice: 3,
        minQuantity: 100,
        maxQuantity: 100000,
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      }
    ];

    console.log('Initializing services...');

    for (const service of services) {
      const serviceRef = doc(collection(db, 'services'));
      const now = new Date();
      
      await setDoc(serviceRef, {
        id: serviceRef.id,
        ...service,
        createdAt: Timestamp.fromDate(now),
        updatedAt: Timestamp.fromDate(now)
      });
      
      console.log(`Created service: ${service.name}`);
      toast.success(`Service créé : ${service.name}`);
    }
  };

  const handleInitialize = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir initialiser les données ? Cette action est irréversible.')) {
      return;
    }

    setLoading(true);
    try {
      await initializePlatforms();
      await initializeServices();
      toast.success('Initialisation des données terminée avec succès !');
    } catch (error) {
      console.error('Error initializing data:', error);
      toast.error('Erreur lors de l\'initialisation des données');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6">
      <button
        onClick={handleInitialize}
        disabled={loading}
        className="bg-purple-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-purple-700 disabled:opacity-50"
      >
        {loading ? 'Initialisation...' : 'Initialiser les données'}
      </button>
    </div>
  );
};

export default InitializeData;