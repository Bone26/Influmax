import React from 'react';
import { motion } from 'framer-motion';

interface TypingIndicatorProps {
  userName: string;
}

const TypingIndicator: React.FC<TypingIndicatorProps> = ({ userName }) => {
  // Afficher "Le support" pour les administrateurs
  const displayName = userName === 'Admin' || userName === 'Support' || userName === 'Benoit Camus' ? 'Le support' : userName;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      className="flex items-center space-x-2 px-4 py-2 bg-white/50 backdrop-blur-sm rounded-xl border border-gray-100 shadow-sm max-w-[75%]"
    >
      <div className="flex space-x-1">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.4, 1, 0.4]
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            repeatType: "loop",
            times: [0, 0.5, 1]
          }}
          className="w-2 h-2 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full"
        />
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.4, 1, 0.4]
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            repeatType: "loop",
            delay: 0.2,
            times: [0, 0.5, 1]
          }}
          className="w-2 h-2 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full"
        />
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.4, 1, 0.4]
          }}
          transition={{
            duration: 1,
            repeat: Infinity,
            repeatType: "loop",
            delay: 0.4,
            times: [0, 0.5, 1]
          }}
          className="w-2 h-2 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-full"
        />
      </div>
      <span className="text-sm text-gray-600 font-medium">{displayName} est en train d'écrire...</span>
    </motion.div>
  );
};

export default TypingIndicator;