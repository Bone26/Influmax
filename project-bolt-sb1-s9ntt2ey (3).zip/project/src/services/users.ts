import { 
  createUserWithEmailAndPassword,
  sendEmailVerification
} from 'firebase/auth';
import { doc, setDoc, collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { User } from '../types/user';

// Générer un code de parrainage unique
const generateReferralCode = (): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

export const createUser = async (email: string, password: string, name: string, referralCode?: string | null): Promise<User> => {
  try {
    console.log('🚀 [Users] Creating user:', { email, name, referralCode });

    // 1. Créer l'utilisateur Firebase
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;

    // 2. Envoyer l'email de vérification
    await sendEmailVerification(user);

    // 3. Récupérer les infos du parrain si un code est fourni
    let referrerId = null;
    if (referralCode) {
      console.log('🔍 [Users] Checking referral code:', referralCode);
      const referrersQuery = query(
        collection(db, 'users'),
        where('affiliate.referralCode', '==', referralCode)
      );
      const referrersSnapshot = await getDocs(referrersQuery);
      
      if (!referrersSnapshot.empty) {
        referrerId = referrersSnapshot.docs[0].id;
        console.log('✅ [Users] Found referrer:', referrerId);
      } else {
        console.log('❌ [Users] Referrer not found for code:', referralCode);
      }
    }

    const now = new Date();
    // 4. Créer le document utilisateur
    const userData = {
      email,
      name,
      emailVerified: false,
      isAdmin: email === 'b.camus26@hotmail.fr',
      affiliate: {
        referralCode: generateReferralCode(),
        referrerId,
        level: 1,
        stats: {
          totalEarnings: 0,
          availableEarnings: 0,
          totalReferrals: 0,
          activeReferrals: 0,
          pendingWithdrawals: 0,
          totalWithdrawn: 0
        }
      },
      createdAt: Timestamp.fromDate(now),
      updatedAt: Timestamp.fromDate(now)
    };

    console.log('📝 [Users] Creating user document:', {
      id: user.uid,
      email,
      name,
      referralCode: userData.affiliate.referralCode,
      referrerId
    });

    await setDoc(doc(db, 'users', user.uid), userData);

    return {
      id: user.uid,
      ...userData,
      createdAt: now,
      updatedAt: now
    };
  } catch (error) {
    console.error('❌ [Users] Error creating user:', error);
    throw error;
  }
};