import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Bell, Send } from 'lucide-react';
import { sendAdminNotification } from '../../services/notifications';
import { toast } from 'sonner';

const NotificationManager = () => {
  const [formData, setFormData] = useState({
    title: '',
    message: '',
    target: 'all' as 'all' | 'specific',
    userId: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await sendAdminNotification(
        formData.title,
        formData.message,
        formData.target === 'specific' ? formData.userId : undefined
      );

      setFormData({
        title: '',
        message: '',
        target: 'all',
        userId: ''
      });

      toast.success('Notification envoyée avec succès');
    } catch (error) {
      console.error('Error sending notification:', error);
      toast.error('Erreur lors de l\'envoi de la notification');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Envoyer une notification</h2>
        <Bell className="h-6 w-6 text-gray-400" />
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Titre
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Message
          </label>
          <textarea
            value={formData.message}
            onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            rows={4}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Destinataire
          </label>
          <select
            value={formData.target}
            onChange={(e) => setFormData(prev => ({ 
              ...prev, 
              target: e.target.value as 'all' | 'specific'
            }))}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
          >
            <option value="all">Tous les utilisateurs</option>
            <option value="specific">Utilisateur spécifique</option>
          </select>
        </div>

        {formData.target === 'specific' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              ID de l'utilisateur
            </label>
            <input
              type="text"
              value={formData.userId}
              onChange={(e) => setFormData(prev => ({ ...prev, userId: e.target.value }))}
              className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              required
            />
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full flex items-center justify-center space-x-2 bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 disabled:opacity-50 transition-colors"
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
              <span>Envoi en cours...</span>
            </>
          ) : (
            <>
              <Send className="h-5 w-5" />
              <span>Envoyer la notification</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default NotificationManager;