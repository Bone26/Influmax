import React from 'react';
import { motion } from 'framer-motion';
import { Rocket, ShieldCheck, Zap, Medal } from 'lucide-react';

const features = [
  {
    icon: Rocket,
    title: "Croissance Organique",
    description: "Des profils réels et actifs pour une croissance durable",
    color: "from-blue-500 to-cyan-500"
  },
  {
    icon: ShieldCheck,
    title: "100% Sécurisé",
    description: "Aucun mot de passe requis, respect des règles",
    color: "from-purple-500 to-pink-500"
  },
  {
    icon: Zap,
    title: "Livraison Rapide",
    description: "Résultats visibles en quelques heures",
    color: "from-orange-500 to-red-500"
  },
  {
    icon: Medal,
    title: "Qualité Premium",
    description: "Engagement de haute qualité garanti",
    color: "from-green-500 to-emerald-500"
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-24 bg-gray-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12 md:mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Pourquoi choisir{' '}
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Influmax
            </span>
            ?
          </h2>
          <p className="text-base md:text-xl text-gray-600 max-w-3xl mx-auto px-4">
            Découvrez nos avantages exclusifs
          </p>
        </motion.div>

        {/* Desktop Version - Scrolling Animation */}
        <div className="hidden md:block relative">
          <div className="absolute inset-0 pointer-events-none bg-gradient-to-r from-gray-50 via-transparent to-gray-50 z-10" />
          <div className="overflow-hidden">
            <motion.div
              animate={{ x: ["0%", "-50%"] }}
              transition={{
                x: {
                  duration: 20,
                  repeat: Infinity,
                  ease: "linear"
                }
              }}
              className="flex gap-8 w-fit"
            >
              {[...features, ...features].map((feature, index) => (
                <div
                  key={index}
                  className="w-72 flex-shrink-0 bg-white rounded-xl shadow p-6"
                >
                  <div className={`bg-gradient-to-r ${feature.color} p-3 rounded-lg inline-block mb-4`}>
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-gray-900">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>

        {/* Mobile Version - Static Grid */}
        <div className="grid grid-cols-1 gap-6 md:hidden">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl shadow p-6"
            >
              <div className="flex items-center space-x-4">
                <div className={`bg-gradient-to-r ${feature.color} p-3 rounded-lg`}>
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-gray-600 mt-1">
                    {feature.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;