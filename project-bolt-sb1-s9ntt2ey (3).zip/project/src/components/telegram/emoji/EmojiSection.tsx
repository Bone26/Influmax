import React from 'react';
import { EmojiButton } from './EmojiButton';

interface EmojiSectionProps {
  title: string;
  description: string;
  emojis: readonly string[];
  selectedEmojis: string[];
  onEmojiClick: (emoji: string) => void;
  maxSelections: number;
}

export const EmojiSection: React.FC<EmojiSectionProps> = ({
  title,
  description,
  emojis,
  selectedEmojis,
  onEmojiClick,
  maxSelections
}) => (
  <div className="mb-6">
    <div className="flex items-center justify-between mb-2">
      <h4 className="text-sm font-medium text-gray-700">{title}</h4>
      <span className="text-xs text-gray-500">{description}</span>
    </div>
    <div className="grid grid-cols-5 gap-2">
      {emojis.map((emoji) => (
        <EmojiButton
          key={emoji}
          emoji={emoji}
          isSelected={selectedEmojis.includes(emoji)}
          onClick={() => onEmojiClick(emoji)}
          disabled={selectedEmojis.length >= maxSelections && !selectedEmojis.includes(emoji)}
        />
      ))}
    </div>
  </div>
);