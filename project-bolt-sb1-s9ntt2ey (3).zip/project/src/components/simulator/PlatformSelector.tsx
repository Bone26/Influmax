import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import { getPlatformStyles } from '../../config/platformStyles';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { platformsCache, CACHE_DURATION } from '../../utils/platformsCache';

interface Platform {
  id: string;
  name: string;
  icon: string;
  isActive: boolean;
}

interface PlatformSelectorProps {
  selectedPlatform: string;
  onPlatformChange: (platform: string) => void;
}

const PlatformSelector: React.FC<PlatformSelectorProps> = ({ 
  selectedPlatform, 
  onPlatformChange 
}) => {
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadPlatforms = async () => {
      try {
        setLoading(true);
        setError(null);

        // Vérifier le cache
        const cachedData = platformsCache.get('platforms');
        if (cachedData && Date.now() - cachedData.timestamp < CACHE_DURATION) {
          setPlatforms(cachedData.data);
          
          // Sélectionner la première plateforme si nécessaire
          if (!selectedPlatform && cachedData.data.length > 0) {
            onPlatformChange(cachedData.data[0].name.toLowerCase());
          }
          
          setLoading(false);
          return;
        }

        // Charger depuis Firestore
        const platformsQuery = query(
          collection(db, 'platforms'),
          where('isActive', '==', true)
        );
        
        const querySnapshot = await getDocs(platformsQuery);
        const platformsData = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Platform[];

        // Trier les plateformes dans l'ordre souhaité
        const orderedPlatforms = platformsData.sort((a, b) => {
          const order = {
            'Instagram': 1,
            'TikTok': 2,
            'Telegram': 3
          };
          return order[a.name as keyof typeof order] - order[b.name as keyof typeof order];
        });

        // Mettre en cache
        platformsCache.set('platforms', {
          data: orderedPlatforms,
          timestamp: Date.now()
        });

        setPlatforms(orderedPlatforms);

        // Sélectionner la première plateforme si nécessaire
        if (!selectedPlatform && orderedPlatforms.length > 0) {
          onPlatformChange(orderedPlatforms[0].name.toLowerCase());
        }
      } catch (error) {
        console.error('Erreur lors du chargement des plateformes:', error);
        setError('Erreur lors du chargement des plateformes');
      } finally {
        setLoading(false);
      }
    };

    loadPlatforms();
  }, []); // Ne dépend plus de selectedPlatform

  if (loading) {
    return (
      <div className="flex justify-center gap-4 md:grid md:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="w-16 h-16 md:w-full md:h-auto md:p-4 rounded-2xl bg-gray-100 animate-pulse"
          />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center text-red-600 p-4">
        {error}
      </div>
    );
  }

  return (
    <div className="flex justify-center gap-4 md:grid md:grid-cols-3">
      {platforms.map(platform => {
        const platformKey = platform.name.toLowerCase();
        const isSelected = selectedPlatform === platformKey;
        const IconComponent = LucideIcons[platform.icon as keyof typeof LucideIcons] || LucideIcons.HelpCircle;
        const styles = getPlatformStyles(platformKey);
        
        return (
          <motion.button
            key={platform.id}
            onClick={() => onPlatformChange(platformKey)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`
              relative w-16 h-16 md:w-full md:h-auto md:p-4 
              rounded-2xl transition-all duration-300
              ${isSelected 
                ? `bg-gradient-to-r ${styles.gradients.primary} shadow-lg`
                : 'bg-gray-50 hover:bg-gray-100'
              }
            `}
          >
            <div className="flex items-center justify-center h-full">
              <IconComponent className={`
                h-8 w-8 md:h-6 md:w-6
                ${isSelected ? 'text-white' : styles.colors.primary}
              `} />
              <span className={`hidden md:inline ml-2 font-medium ${isSelected ? 'text-white' : ''}`}>
                {platform.name}
              </span>
            </div>
            {isSelected && (
              <motion.div
                layoutId="platformIndicator"
                className="absolute -bottom-2 left-1/2 transform -translate-x-1/2"
                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
              >
                <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${styles.gradients.primary}`} />
              </motion.div>
            )}
          </motion.button>
        );
      })}
    </div>
  );
};

export default PlatformSelector;