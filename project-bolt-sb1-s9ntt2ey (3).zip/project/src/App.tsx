import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { AuthProvider } from './contexts/AuthContext';
import { AffiliateProvider } from './contexts/AffiliateContext';
import { SimulatorProvider } from './components/simulator/SimulatorContext';
import Layout from './components/Layout';
import ScrollToTop from './components/ScrollToTop';
import PreviewBanner from './components/simulator/PreviewBanner';
import { routes } from './routes';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      refetchOnMount: true,
      refetchOnReconnect: true,
      retry: 1,
      staleTime: 5 * 1000,
      useErrorBoundary: true,
      structuralSharing: false,
      onError: (error) => {
        console.error('Query error:', error);
      }
    },
  },
});

// Component to handle referral redirects
const ReferralHandler = () => {
  const location = useLocation();
  const navigate = useNavigate();

  React.useEffect(() => {
    const params = new URLSearchParams(location.search);
    const refCode = params.get('ref');
    
    if (refCode) {
      console.log('[ReferralHandler] Code de parrainage détecté:', refCode);
      localStorage.setItem('referralCode', refCode);
      console.log('[ReferralHandler] Code stocké dans localStorage');
      
      // If we're on the homepage with a ref code, redirect to the referral landing page
      if (location.pathname === '/') {
        console.log('[ReferralHandler] Redirection vers la landing page');
        navigate(`/ref?ref=${refCode}`, { replace: true });
      }
    }
  }, [location.search, location.pathname, navigate]);

  return null;
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AffiliateProvider>
          <SimulatorProvider>
            <Router>
              <ScrollToTop />
              <ReferralHandler />
              <PreviewBanner />
              <Layout>
                <Routes>
                  {routes.map((route) => (
                    <Route
                      key={route.path}
                      path={route.path}
                      element={route.element}
                    />
                  ))}
                </Routes>
              </Layout>
              <Toaster position="top-right" />
            </Router>
          </SimulatorProvider>
        </AffiliateProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;