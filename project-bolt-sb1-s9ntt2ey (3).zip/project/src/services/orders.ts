import { collection, doc, setDoc, updateDoc, increment, Timestamp, runTransaction, query, where, getDocs, writeBatch, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Order, OrderRefund } from '../types/order';
import { createJAPOrder } from './jap';
import { sendOrderNotification, sendRefundNotification } from './notifications';
import { toast } from 'sonner';
import { calculateDripFeed } from '../utils/serviceUtils';
import { ServicePriceConfig } from '../types/pricing';

export const createOrder = async (userId: string, orderData: {
  service: {
    platform: string;
    type: string;
    quality: string;
  };
  link: string;
  quantity: number;
  price: number;
  selectedEmojis?: string[];
  deliveryTime: string;
}): Promise<Order> => {
  try {
    console.log('🚀 Creating order with data:', {
      ...orderData,
      userId,
      timestamp: new Date().toISOString()
    });

    // Récupérer la configuration du service
    const priceConfig = await getPriceConfig(
      orderData.service.platform,
      orderData.service.type,
      orderData.service.quality
    );

    console.log('📝 Service price config:', priceConfig);

    if (!priceConfig) {
      throw new Error('Configuration du service non trouvée');
    }

    // Pour les réactions Telegram, utiliser le bon service JAP selon l'emoji
    let japServiceId = priceConfig.japMapping?.japServiceId;
    let japServiceName = priceConfig.japMapping?.japServiceName;

    if (orderData.service.platform === 'telegram' && orderData.service.type === 'reactions' && orderData.selectedEmojis) {
      if (orderData.selectedEmojis.length === 0) {
        throw new Error('Veuillez sélectionner au moins une réaction');
      }

      // Vérifier si c'est un pack ou des réactions individuelles
      const isPackOrder = orderData.selectedEmojis.includes('pack_positive') || orderData.selectedEmojis.includes('pack_negative');

      if (isPackOrder) {
        // Utiliser le service du pack approprié
        const packType = orderData.selectedEmojis[0] === 'pack_positive' ? 'positive' : 'negative';
        japServiceId = priceConfig.telegramReactions?.mixedPacks[packType].japServiceId;
        japServiceName = priceConfig.telegramReactions?.mixedPacks[packType].japServiceName;
      } else {
        // Pour les réactions individuelles, créer une commande pour chaque emoji
        const firstEmoji = orderData.selectedEmojis[0];
        const reactionConfig = priceConfig.telegramReactions?.individual.find(r => r.emoji === firstEmoji);
        if (!reactionConfig) {
          throw new Error('Configuration de réaction non trouvée');
        }
        japServiceId = reactionConfig.japServiceId;
        japServiceName = reactionConfig.japServiceName;
      }
    }

    if (!japServiceId) {
      throw new Error('ID du service JAP non trouvé');
    }

    // Calculer les paramètres de drip feed
    const dripFeed = calculateDripFeed(
      orderData.quantity,
      orderData.deliveryTime,
      priceConfig.deliveryLimits,
      priceConfig.japMapping?.minQuantity,
      priceConfig.japMapping?.maxQuantity,
      priceConfig.japMapping?.maxSpeed
    );

    console.log('⚙️ Drip feed calculation:', dripFeed);

    if (!dripFeed.isValid) {
      throw new Error(dripFeed.error || 'Paramètres de drip feed invalides');
    }

    // Créer la commande JAP
    console.log('📦 Creating JAP order with service ID:', japServiceId);
    const japResponse = await createJAPOrder({
      service: japServiceId,
      link: orderData.link,
      quantity: dripFeed.quantityPerRun,
      runs: dripFeed.runs,
      interval: dripFeed.interval
    });

    console.log('✅ JAP order created:', japResponse);

    // Créer la commande dans notre base
    return await runTransaction(db, async (transaction) => {
      if (!userId) throw new Error('User ID is required');
      
      console.log('💳 Checking wallet balance...');
      // Vérifier le solde
      const walletRef = doc(db, 'depositWallets', userId);
      const walletDoc = await transaction.get(walletRef);
      
      if (!walletDoc.exists()) {
        throw new Error('Wallet not found');
      }

      const wallet = walletDoc.data();
      if (wallet.balance < orderData.price) {
        throw new Error('Solde insuffisant');
      }

      const now = Timestamp.now();
      
      // Utiliser l'ID de commande JAP comme ID principal
      const orderId = japResponse.order;
      
      console.log('📝 Creating order document...');
      // Ajouter les informations de drip feed aux métadonnées
      const metadata = {
        selectedEmojis: orderData.selectedEmojis,
        japOrderId: japResponse.order,
        dripFeed: {
          runs: dripFeed.runs,
          interval: dripFeed.interval,
          quantityPerRun: dripFeed.quantityPerRun,
          completedRuns: 0
        }
      };

      const order: Order = {
        id: orderId,
        userId,
        service: {
          ...orderData.service,
          japServiceId,
          japServiceName
        },
        link: orderData.link,
        quantity: orderData.quantity,
        price: orderData.price,
        status: 'processing',
        deliveryTime: orderData.deliveryTime,
        metadata,
        timestamps: {
          createdAt: now.toDate(),
          updatedAt: now.toDate(),
          startedAt: now.toDate()
        }
      };

      // Sauvegarder la commande
      const orderRef = doc(db, 'orders', orderId);
      transaction.set(orderRef, {
        ...order,
        timestamps: {
          createdAt: now,
          updatedAt: now,
          startedAt: now
        }
      });

      console.log('💰 Updating wallet balance...');
      // Déduire le montant du wallet
      transaction.update(walletRef, {
        balance: increment(-orderData.price),
        updatedAt: now
      });

      // Créer la transaction
      const transactionRef = doc(collection(db, 'walletDeposits'));
      transaction.set(transactionRef, {
        id: transactionRef.id,
        userId,
        amount: -orderData.price,
        type: 'order',
        status: 'completed',
        description: `Order #${orderId}`,
        orderId,
        createdAt: now
      });

      console.log('🔔 Sending notification...');
      // Envoyer la notification
      await sendOrderNotification(userId, orderId);

      console.log('✨ Order creation completed successfully!');
      return order;
    });

  } catch (error) {
    console.error('❌ Error creating order:', error);
    if (error instanceof Error) {
      toast.error(error.message);
    } else {
      toast.error('Erreur lors de la création de la commande');
    }
    throw error;
  }
};

// Récupérer la configuration du prix
const getPriceConfig = async (platform: string, serviceType: string, quality: string): Promise<ServicePriceConfig | null> => {
  try {
    console.log('🔍 Getting price config for:', { platform, serviceType, quality });
    const q = query(
      collection(db, 'servicePrices'),
      where('platformId', '==', platform),
      where('serviceType', '==', serviceType),
      where('quality', '==', quality),
      where('isActive', '==', true)
    );

    const snapshot = await getDocs(q);
    if (snapshot.empty) {
      console.log('❌ No price config found');
      return null;
    }

    const priceConfig = snapshot.docs[0].data() as ServicePriceConfig;
    console.log('✅ Price config found:', priceConfig);
    return {
      ...priceConfig,
      updatedAt: priceConfig.updatedAt.toDate()
    };
  } catch (error) {
    console.error('❌ Error getting price config:', error);
    return null;
  }
};

// Vérifier les commandes en cours
export const checkProcessingOrders = async (): Promise<void> => {
  try {
    console.log('🔄 Checking processing orders...');
    // 1. Récupérer toutes les commandes en cours
    const processingOrdersQuery = query(
      collection(db, 'orders'),
      where('status', '==', 'processing')
    );

    const snapshot = await getDocs(processingOrdersQuery);
    if (snapshot.empty) {
      console.log('ℹ️ No processing orders found');
      return;
    }

    const batch = writeBatch(db);
    const now = Timestamp.now();

    for (const doc of snapshot.docs) {
      const order = doc.data();
      
      // Vérifier si le temps d'envoi est écoulé
      const startedAt = order.timestamps?.startedAt?.toDate();
      if (!startedAt) continue;

      let duration: number;
      switch (order.deliveryTime) {
        case '24h':
          duration = 24 * 60 * 60 * 1000;
          break;
        case '3days':
          duration = 3 * 24 * 60 * 60 * 1000;
          break;
        case '7days':
          duration = 7 * 24 * 60 * 60 * 1000;
          break;
        case '1month':
          duration = 30 * 24 * 60 * 60 * 1000;
          break;
        default: // instant
          duration = 60 * 60 * 1000; // 1 heure
      }

      const elapsed = now.toDate().getTime() - startedAt.getTime();
      
      // Si le temps est écoulé, marquer comme terminé
      if (elapsed >= duration) {
        batch.update(doc.ref, {
          status: 'completed',
          'timestamps.completedAt': now,
          'timestamps.updatedAt': now
        });
        
        console.log(`✅ Order ${doc.id} marked as completed after ${elapsed}ms`);
      }
    }

    // Exécuter toutes les mises à jour
    await batch.commit();
    console.log('✨ Order check completed');
  } catch (error) {
    console.error('❌ Error checking processing orders:', error);
  }
};

// Export des fonctions de l'API
export { getAllOrders, updateOrderStatus } from './api';