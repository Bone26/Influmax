import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Instagram, Music2, MessageCircle } from 'lucide-react';
import ServicesHeader from './ServicesHeader';
import InstagramServices from './InstagramServices';
import TikTokServices from './TikTokServices';
import TelegramServices from './TelegramServices';
import { platformStyles } from '../../config/platformStyles';

const Services = () => {
  const [selectedPlatform, setSelectedPlatform] = useState('instagram');

  const platforms = [
    { 
      id: 'instagram', 
      name: 'Instagram', 
      icon: Instagram,
      styles: platformStyles.instagram
    },
    { 
      id: 'tiktok', 
      name: 'TikTok', 
      icon: Music2,
      styles: platformStyles.tiktok
    },
    { 
      id: 'telegram', 
      name: 'Telegram', 
      icon: MessageCircle,
      styles: platformStyles.telegram
    }
  ];

  const renderServiceSection = () => {
    switch (selectedPlatform) {
      case 'instagram':
        return <InstagramServices />;
      case 'tiktok':
        return <TikTokServices />;
      case 'telegram':
        return <TelegramServices />;
      default:
        return <InstagramServices />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-purple-50">
      <ServicesHeader />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center mb-16"
        >
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {platforms.map((platform) => {
              const isSelected = selectedPlatform === platform.id;
              
              return (
                <motion.button
                  key={platform.id}
                  onClick={() => setSelectedPlatform(platform.id)}
                  className={`relative flex items-center space-x-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                    isSelected 
                      ? `bg-gradient-to-r ${platform.styles.gradients.primary} text-white shadow-lg`
                      : `bg-white text-gray-700 hover:${platform.styles.colors.background}`
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <platform.icon className="h-5 w-5" />
                  <span>{platform.name}</span>
                  {isSelected && (
                    <motion.div
                      className="absolute -bottom-4 left-1/2 transform -translate-x-1/2"
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${platform.styles.gradients.primary}`} />
                    </motion.div>
                  )}
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          <motion.div
            key={selectedPlatform}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            {renderServiceSection()}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Services;