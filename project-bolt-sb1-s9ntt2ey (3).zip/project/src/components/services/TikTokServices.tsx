import React from 'react';
import { motion } from 'framer-motion';
import { Music2, Users, Heart, Eye, Save, Share2 } from 'lucide-react';
import ServiceCard from './ServiceCard';

const services = [
  {
    icon: Users,
    title: "Followers TikTok",
    description: "Développez votre communauté",
    price: "2",
    features: [
      "Choisissez votre niveau de qualité",
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'tiktok',
    type: 'followers',
    minQuantity: 100
  },
  {
    icon: Heart,
    title: "Likes TikTok",
    description: "Augmentez l'engagement",
    price: "1",
    features: [
      "Choisissez votre niveau de qualité",
      "Livraison personnalisable", 
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'tiktok',
    type: 'likes',
    minQuantity: 1000
  },
  {
    icon: Eye,
    title: "Vues TikTok",
    description: "Boostez la visibilité",
    price: "0.02",
    features: [
      "Choisissez votre niveau de qualité",
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'tiktok',
    type: 'views',
    minQuantity: 1000
  },
  {
    icon: Save,
    title: "Enregistrements",
    description: "Ajoutez des sauvegardes",
    price: "0.50",
    features: [
      "Prix très bas",
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'tiktok',
    type: 'saves',
    minQuantity: 1000
  },
  {
    icon: Share2,
    title: "Partages",
    description: "Faites partager vos vidéos",
    price: "1",
    features: [
      "Prix très bas",
      "Livraison personnalisable",
      "Aucun mot de passe requis",
      "Support 24/7"
    ],
    platform: 'tiktok',
    type: 'shares',
    minQuantity: 1000
  }
];

const TikTokServices = () => {
  return (
    <div>
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="flex items-center justify-center gap-4 mb-8"
      >
        <div className="bg-gradient-to-br from-pink-100 to-red-100 p-4 rounded-xl">
          <Music2 className="h-8 w-8 text-pink-600" />
        </div>
        <h2 className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-pink-600 to-red-600 bg-clip-text text-transparent">
          Services TikTok
        </h2>
      </motion.div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8">
        {services.map((service, index) => (
          <ServiceCard key={index} service={service} index={index} />
        ))}
      </div>
    </div>
  );
};

export default TikTokServices;