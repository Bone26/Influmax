// Ajouter le champ de mapping JAP dans le formulaire de service
const ServiceForm = ({ service, onSubmit }) => {
  const [formData, setFormData] = useState({
    // ... autres champs existants
    japMapping: {
      japServiceId: service?.japMapping?.japServiceId || '',
      japServiceName: service?.japMapping?.japServiceName || '',
      minQuantity: service?.japMapping?.minQuantity || 10,
      maxQuantity: service?.japMapping?.maxQuantity || 300000,
      maxSpeed: service?.japMapping?.maxSpeed || 50000
    }
  });

  return (
    <form onSubmit={handleSubmit}>
      {/* ... autres champs existants */}
      
      <div className="bg-gray-50 rounded-xl p-6 mt-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">
          Configuration API JAP
        </h3>
        
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              ID du service JAP
            </label>
            <input
              type="text"
              value={formData.japMapping.japServiceId}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                japMapping: {
                  ...prev.japMapping,
                  japServiceId: e.target.value
                }
              }))}
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500"
              placeholder="ex: 4343"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Nom du service JAP
            </label>
            <input
              type="text"
              value={formData.japMapping.japServiceName}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                japMapping: {
                  ...prev.japMapping,
                  japServiceName: e.target.value
                }
              }))}
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500"
              placeholder="ex: Instagram Likes"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Quantité minimum JAP
            </label>
            <input
              type="number"
              value={formData.japMapping.minQuantity}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                japMapping: {
                  ...prev.japMapping,
                  minQuantity: parseInt(e.target.value)
                }
              }))}
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500"
              min="10"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Quantité maximum JAP
            </label>
            <input
              type="number"
              value={formData.japMapping.maxQuantity}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                japMapping: {
                  ...prev.japMapping,
                  maxQuantity: parseInt(e.target.value)
                }
              }))}
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500"
              max="300000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Vitesse maximum par jour
            </label>
            <input
              type="number"
              value={formData.japMapping.maxSpeed}
              onChange={(e) => setFormData(prev => ({
                ...prev,
                japMapping: {
                  ...prev.japMapping,
                  maxSpeed: parseInt(e.target.value)
                }
              }))}
              className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-purple-500 focus:border-purple-500"
              max="50000"
            />
          </div>
        </div>
      </div>

      {/* ... reste du formulaire */}
    </form>
  );
};