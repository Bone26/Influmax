import React, { createContext, useContext, useState } from 'react';

interface SimulatorContextType {
  previewData: {
    platform: string;
    differences: {
      followers: number;
      likes: number;
      reelViews: number;
      reelLikes: number;
    };
    costs: {
      followers: number;
      likes: number;
      reelViews: number;
      reelLikes: number;
      total: number;
    };
  } | null;
  setPreviewData: (data: any) => void;
  clearPreviewData: () => void;
}

const SimulatorContext = createContext<SimulatorContextType | undefined>(undefined);

export const SimulatorProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [previewData, setPreviewData] = useState<SimulatorContextType['previewData']>(() => {
    const saved = localStorage.getItem('previewData');
    return saved ? JSON.parse(saved) : null;
  });

  const handleSetPreviewData = (data: any) => {
    setPreviewData(data);
    localStorage.setItem('previewData', JSON.stringify(data));
  };

  const clearPreviewData = () => {
    setPreviewData(null);
    localStorage.removeItem('previewData');
  };

  return (
    <SimulatorContext.Provider value={{
      previewData,
      setPreviewData: handleSetPreviewData,
      clearPreviewData
    }}>
      {children}
    </SimulatorContext.Provider>
  );
};

export const useSimulator = () => {
  const context = useContext(SimulatorContext);
  if (context === undefined) {
    throw new Error('useSimulator must be used within a SimulatorProvider');
  }
  return context;
};