import { useState, useEffect } from 'react';
import { getAllOrders, validateOrder, rejectOrder, Order } from '../services/orders';

export const useOrders = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchOrders = async () => {
    try {
      const data = await getAllOrders();
      setOrders(data);
    } catch (err) {
      setError('Erreur lors du chargement des commandes');
      console.error('Error fetching orders:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleValidateOrder = async (orderId: string) => {
    try {
      await validateOrder(orderId);
      await fetchOrders(); // Rafraîchir la liste
    } catch (err) {
      throw err;
    }
  };

  const handleRejectOrder = async (orderId: string) => {
    try {
      await rejectOrder(orderId);
      await fetchOrders(); // Rafraîchir la liste
    } catch (err) {
      throw err;
    }
  };

  return {
    orders,
    loading,
    error,
    validateOrder: handleValidateOrder,
    rejectOrder: handleRejectOrder,
    refreshOrders: fetchOrders
  };
};