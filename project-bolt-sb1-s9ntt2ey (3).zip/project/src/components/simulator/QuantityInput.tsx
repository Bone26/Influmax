import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Minus, Plus } from 'lucide-react';

interface QuantityInputProps {
  platform: string;
  service: string;
  value: number | '';
  onChange: (value: number | '') => void;
  deliveryTime: string;
}

const QuantityInput: React.FC<QuantityInputProps> = ({
  platform,
  service,
  value,
  onChange,
  deliveryTime
}) => {
  const [inputValue, setInputValue] = useState(value === '' ? '' : value.toLocaleString());

  useEffect(() => {
    setInputValue(value === '' ? '' : value.toLocaleString());
  }, [value]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawValue = e.target.value.replace(/[^0-9]/g, '');
    const formattedValue = rawValue ? parseInt(rawValue, 10).toLocaleString() : '';
    setInputValue(formattedValue);
    
    const numValue = parseInt(rawValue, 10);
    if (!isNaN(numValue)) {
      onChange(numValue);
    } else if (rawValue === '') {
      onChange('');
    }
  };

  const handleStep = (step: number) => {
    const currentValue = typeof value === 'number' ? value : 0;
    const newValue = currentValue + step;
    
    // Ne pas permettre des valeurs négatives
    if (newValue < 0) return;
    
    setInputValue(newValue.toLocaleString());
    onChange(newValue);
  };

  return (
    <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
      <div className="p-4">
        <div className="flex items-center space-x-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleStep(-1)}
            className="w-12 h-12 flex items-center justify-center rounded-xl border hover:bg-gray-50 active:bg-gray-100 transition-colors"
          >
            <Minus className="h-5 w-5 text-gray-600" />
          </motion.button>

          <div className="flex-1">
            <input
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              className="w-full text-center text-3xl font-bold bg-transparent border-none focus:outline-none focus:ring-0 text-gray-900"
              placeholder="0"
            />
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleStep(1)}
            className="w-12 h-12 flex items-center justify-center rounded-xl border hover:bg-gray-50 active:bg-gray-100 transition-colors"
          >
            <Plus className="h-5 w-5 text-gray-600" />
          </motion.button>
        </div>
      </div>
    </div>
  );
};

export default QuantityInput;