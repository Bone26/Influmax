import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Shield, Star, Crown, Trophy, Diamond, Gift, ChevronRight } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useAffiliate } from '../contexts/AffiliateContext';
import { claimReward } from '../services/rewards';
import { toast } from 'sonner';
import RewardClaimHistory from '../components/rewards/RewardClaimHistory';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';

const Rewards = () => {
  const { currentUser } = useAuth();
  const { affiliate } = useAffiliate();
  const [selectedReward, setSelectedReward] = useState<any | null>(null);
  const [shippingAddress, setShippingAddress] = useState('');
  const [claims, setClaims] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [claimedRewards, setClaimedRewards] = useState<{[key: string]: boolean}>({});

  useEffect(() => {
    if (!currentUser) return;

    const q = query(
      collection(db, 'rewardClaims'),
      where('userId', '==', currentUser.id),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const claimsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt.toDate(),
        updatedAt: doc.data().updatedAt.toDate()
      }));
      
      const claimed = claimsData.reduce((acc, claim) => ({
        ...acc,
        [claim.rewardLevel]: true
      }), {});
      
      setClaims(claimsData);
      setClaimedRewards(claimed);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentUser]);

  const totalEarnings = affiliate?.stats?.totalEarnings || 0;

  const rewards = [
    {
      level: 'bronze',
      name: 'Bronze',
      IconComponent: Shield,
      unlockAmount: 3000,
      color: 'from-amber-700 to-amber-500',
      reward: 'AirPods Max',
      imageUrl: 'https://images.unsplash.com/photo-1613040809024-b4ef7ba99bc3?auto=format&fit=crop&q=80&w=1000',
      description: 'Débloquez votre première récompense en atteignant 3 000€ de gains totaux.'
    },
    {
      level: 'silver',
      name: 'Silver',
      IconComponent: Star,
      unlockAmount: 15000,
      color: 'from-gray-400 to-gray-300',
      reward: 'iPhone Pro',
      imageUrl: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?auto=format&fit=crop&q=80&w=1000',
      description: 'Passez au niveau supérieur avec 15 000€ de gains totaux.'
    },
    {
      level: 'gold',
      name: 'Gold',
      IconComponent: Crown,
      unlockAmount: 30000,
      color: 'from-yellow-500 to-yellow-400',
      reward: 'MacBook Pro',
      imageUrl: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&q=80&w=1000',
      description: 'Atteignez le niveau Gold avec 30 000€ de gains totaux.'
    },
    {
      level: 'platinum',
      name: 'Platinum',
      IconComponent: Star,
      unlockAmount: 250000,
      color: 'from-slate-400 to-slate-300',
      reward: 'Rolex',
      imageUrl: 'https://i.imgur.com/klnA0pK.jpeg',
      description: 'Devenez membre Platinum avec 250 000€ de gains totaux.'
    },
    {
      level: 'diamond',
      name: 'Diamond',
      IconComponent: Diamond,
      unlockAmount: 1000000,
      color: 'from-blue-400 to-cyan-300',
      reward: 'Ferrari',
      imageUrl: 'https://i.imgur.com/XGPXKOM.jpeg',
      description: 'Atteignez le sommet avec 1 000 000€ de gains totaux et repartez au volant d\'une Ferrari.'
    },
    {
      level: 'legend',
      name: 'Legend',
      IconComponent: Trophy,
      unlockAmount: 5000000,
      color: 'from-red-500 to-orange-500',
      reward: 'Appartement',
      imageUrl: 'https://i.imgur.com/CRkznqy.jpeg',
      description: 'Devenez une légende avec 5 000 000€ de gains totaux et gagnez un appartement d\'une valeur de 300 000 euros dans le pays de votre choix.'
    }
  ];

  // Trouver le niveau actuel et le prochain niveau
  const getCurrentAndNextLevel = () => {
    let currentLevel = null;
    let nextLevel = rewards[0]; // Par défaut, le premier niveau (Bronze)

    for (let i = 0; i < rewards.length; i++) {
      if (totalEarnings >= rewards[i].unlockAmount) {
        currentLevel = rewards[i];
        nextLevel = rewards[i + 1] || null;
      } else {
        if (!currentLevel) {
          nextLevel = rewards[i];
        }
        break;
      }
    }

    return { currentLevel, nextLevel };
  };

  const { currentLevel, nextLevel } = getCurrentAndNextLevel();
  const progress = nextLevel ? Math.min((totalEarnings / nextLevel.unlockAmount) * 100, 100) : 100;

  const handleClaimReward = async (reward: any) => {
    if (claimedRewards[reward.level]) {
      toast.error('Cette récompense a déjà été réclamée');
      return;
    }
    setSelectedReward(reward);
  };

  const handleSubmitClaim = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !selectedReward) return;

    try {
      await claimReward(
        currentUser.id,
        currentUser.name,
        currentUser.email,
        selectedReward.level,
        selectedReward.reward,
        shippingAddress
      );
      toast.success('Demande de récompense envoyée avec succès');
      setSelectedReward(null);
      setShippingAddress('');
    } catch (error) {
      console.error('Error claiming reward:', error);
      toast.error('Erreur lors de la demande de récompense');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50 py-6 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header avec gradient */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 md:p-8">
            <div className="flex items-center space-x-4">
              <Link to="/affiliate" className="text-white/80 hover:text-white">
                <ArrowLeft className="h-6 w-6" />
              </Link>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
                  Programme de récompenses
                </h1>
                <p className="text-purple-100 text-sm md:text-base">
                  Débloquez des récompenses exceptionnelles en développant votre réseau
                </p>
              </div>
            </div>
          </div>

          {/* Status Section */}
          <div className="p-8 bg-gray-50 border-b">
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${currentLevel ? currentLevel.color : nextLevel.color}`}>
                    {currentLevel ? <currentLevel.IconComponent className="h-6 w-6 text-white" /> : <nextLevel.IconComponent className="h-6 w-6 text-white" />}
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-gray-900">{currentLevel ? `Niveau ${currentLevel.name}` : 'Aucun Niveau'}</h2>
                    <p className="text-sm text-gray-600">{totalEarnings.toLocaleString()}€ gagnés</p>
                  </div>
                </div>
                {nextLevel && (
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Prochain niveau</p>
                    <p className="font-bold text-gray-900">{nextLevel.name}</p>
                  </div>
                )}
              </div>

              {nextLevel && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Progression vers {nextLevel.name}</span>
                    <span className="font-medium">{progress.toFixed(2)}%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${nextLevel.color} transition-all duration-500`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <p className="text-sm text-gray-500">
                    Plus que {(nextLevel.unlockAmount - totalEarnings).toLocaleString()}€ pour atteindre le niveau {nextLevel.name}
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="p-8 space-y-8">
            {/* Grid des récompenses */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {rewards.map((reward, index) => {
                const isUnlocked = totalEarnings >= reward.unlockAmount;
                const isClaimed = claimedRewards[reward.level];
                const { IconComponent } = reward;
                const rewardProgress = Math.min((totalEarnings / reward.unlockAmount) * 100, 100);

                return (
                  <motion.div
                    key={reward.level}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`group bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl ${
                      !isUnlocked ? 'opacity-75' : ''
                    }`}
                  >
                    {/* Image Container */}
                    <div className="relative h-48 overflow-hidden">
                      <img
                        src={reward.imageUrl}
                        alt={reward.reward}
                        className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                      
                      {/* Level Badge */}
                      <div className="absolute top-4 right-4">
                        <div className={`bg-gradient-to-r ${reward.color} px-4 py-1 rounded-full text-sm font-medium text-white shadow-lg`}>
                          Niveau {reward.name}
                        </div>
                      </div>

                      {/* Unlock Amount */}
                      <div className="absolute bottom-4 left-4 text-white">
                        <p className="text-sm opacity-75">Débloqué à</p>
                        <p className="text-xl font-bold">{reward.unlockAmount.toLocaleString()}€</p>
                      </div>
                    </div>

                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${reward.color}`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900">{reward.reward}</h3>
                      </div>

                      <p className="text-gray-600 text-sm mb-6">{reward.description}</p>

                      {/* Progress Bar */}
                      <div className="space-y-2 mb-6">
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className={`h-full bg-gradient-to-r ${reward.color} transition-all duration-500`}
                            style={{ width: `${rewardProgress}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>{rewardProgress.toFixed(1)}% complété</span>
                          <span>{reward.unlockAmount.toLocaleString()}€</span>
                        </div>
                      </div>

                      <button
                        onClick={() => isUnlocked && !isClaimed && handleClaimReward(reward)}
                        disabled={!isUnlocked || isClaimed}
                        className={`w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-lg font-medium transition-all duration-300 ${
                          !isUnlocked
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : isClaimed
                            ? 'bg-green-100 text-green-700 cursor-not-allowed'
                            : `bg-gradient-to-r ${reward.color} text-white hover:opacity-90 transform hover:scale-105`
                        }`}
                      >
                        {!isUnlocked 
                          ? `${rewardProgress.toFixed(2)}%`
                          : isClaimed 
                          ? 'Déjà réclamé' 
                          : (
                            <>
                              <span>Réclamer ma récompense</span>
                              <ChevronRight className="h-5 w-5" />
                            </>
                          )}
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Historique des réclamations */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="bg-gray-50 rounded-xl p-6"
            >
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Historique de vos récompenses
              </h2>
              <RewardClaimHistory claims={claims} />
            </motion.div>
          </div>
        </motion.div>

        {/* Modal de réclamation */}
        {selectedReward && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-xl shadow-xl max-w-md w-full p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-3">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${selectedReward.color}`}>
                    <selectedReward.IconComponent className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{selectedReward.reward}</h3>
                    <p className="text-sm text-gray-600">Niveau {selectedReward.name}</p>
                  </div>
                </div>
              </div>
              
              <form onSubmit={handleSubmitClaim} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Adresse de livraison
                  </label>
                  <textarea
                    value={shippingAddress}
                    onChange={(e) => setShippingAddress(e.target.value)}
                    rows={4}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                    placeholder="Adresse complète de livraison"
                    required
                  />
                </div>

                <div className="flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={() => setSelectedReward(null)}
                    className="px-4 py-2 text-gray-600 hover:text-gray-800"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className={`px-6 py-2 bg-gradient-to-r ${selectedReward.color} text-white rounded-lg hover:opacity-90 transition-opacity`}
                  >
                    Confirmer
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Rewards;