import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Link as LinkIcon, AlertCircle, Info } from 'lucide-react';

interface LinkInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (link: string) => void;
  platform: string;
  service?: string;
}

const LinkInputModal: React.FC<LinkInputModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  platform,
  service
}) => {
  const [link, setLink] = useState('');
  const [error, setError] = useState('');

  const validateLink = (url: string): boolean => {
    try {
      const parsedUrl = new URL(url);
      switch (platform) {
        case 'instagram':
          return parsedUrl.hostname === 'instagram.com' || parsedUrl.hostname === 'www.instagram.com';
        case 'tiktok':
          // Accepter uniquement les liens vm.tiktok.com
          return parsedUrl.hostname === 'vm.tiktok.com';
        case 'telegram':
          return parsedUrl.hostname === 't.me' || parsedUrl.hostname === 'telegram.me';
        default:
          return true;
      }
    } catch {
      return false;
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!link.trim()) {
      setError('Le lien est requis');
      return;
    }

    if (!validateLink(link)) {
      if (platform === 'tiktok') {
        setError('Veuillez entrer un lien TikTok au format vm.tiktok.com');
      } else {
        setError(`Veuillez entrer un lien ${platform} valide`);
      }
      return;
    }

    onSubmit(link);
  };

  const getPlaceholder = () => {
    switch (platform) {
      case 'instagram':
        return service === 'followers' ? 'https://instagram.com/username' : 'https://instagram.com/p/...';
      case 'tiktok':
        return 'https://vm.tiktok.com/...';
      case 'telegram':
        return 'https://t.me/...';
      default:
        return 'https://...';
    }
  };

  const getTitle = () => {
    if (platform === 'instagram' && service === 'followers') {
      return 'Lien du profil';
    }
    if (platform === 'telegram' && service === 'members') {
      return 'Lien du Groupe/Canal';
    }
    return 'Lien de la publication';
  };

  const getSubtitle = () => {
    if (platform === 'instagram' && service === 'followers') {
      return 'Entrez le lien de votre profil';
    }
    if (platform === 'telegram' && service === 'members') {
      return 'Entrez le lien';
    }
    return 'Entrez le lien de votre publication';
  };

  const getWarningMessage = () => {
    if (platform === 'instagram') {
      if (service === 'followers') {
        return '⚠️ IMPORTANT : Votre profil Instagram doit être public. Les profils privés ne sont pas traités et aucun remboursement ne sera effectué.';
      }
      return '⚠️ IMPORTANT : Votre publication Instagram doit être publique. Les publications privées ne sont pas traitées et aucun remboursement ne sera effectué.';
    }
    if (platform === 'tiktok') {
      if (service === 'followers') {
        return '⚠️ IMPORTANT : Votre profil TikTok doit être public. Les profils privés ne sont pas traités et aucun remboursement ne sera effectué.';
      }
      return '⚠️ IMPORTANT : Votre vidéo TikTok doit être publique. Les vidéos privées ne sont pas traitées et aucun remboursement ne sera effectué.';
    }
    if (platform === 'telegram') {
      if (service === 'members') {
        return '⚠️ IMPORTANT : Votre groupe/canal Telegram doit être public. Les groupes/canaux privés ne sont pas traités et aucun remboursement ne sera effectué.';
      }
      return '⚠️ IMPORTANT : Votre message Telegram doit être dans un groupe/canal public. Les messages privés ne sont pas traités et aucun remboursement ne sera effectué.';
    }
    return '';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white w-full max-w-md rounded-xl shadow-xl overflow-hidden"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-white">{getTitle()}</h2>
            <button onClick={onClose} className="text-white/80 hover:text-white">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Avertissement important */}
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-lg">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-yellow-400" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-yellow-700">
                  {getWarningMessage()}
                </p>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {getSubtitle()}
            </label>
            <div className="relative">
              <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="url"
                value={link}
                onChange={(e) => {
                  setLink(e.target.value);
                  setError('');
                }}
                placeholder={getPlaceholder()}
                className="w-full pl-10 pr-4 py-3 border rounded-xl text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-purple-500"
              />
            </div>
            {error && (
              <div className="mt-2 flex items-center text-sm text-red-600">
                <AlertCircle className="h-4 w-4 mr-1" />
                {error}
              </div>
            )}
          </div>

          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-6 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700"
            >
              Continuer vers le paiement
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default LinkInputModal;