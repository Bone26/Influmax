import React from 'react';
import { motion } from 'framer-motion';

interface EmojiSelectorProps {
  selectedEmojis: string[];
  onSelect: (emoji: string) => void;
  onRemove: (emoji: string) => void;
  maxSelections?: number;
}

const EmojiSelector: React.FC<EmojiSelectorProps> = ({
  selectedEmojis,
  onSelect,
  onRemove,
  maxSelections = 6
}) => {
  const positiveEmojis = ['👍', '❤️', '🔥', '👏', '🥰', '🤩', '🌟', '🎉', '💯', '⭐️'];
  const negativeEmojis = ['👎', '😱', '😢', '🤮', '💩', '🤡', '😡', '😤', '🙄', '😒'];

  const handleEmojiClick = (emoji: string) => {
    if (selectedEmojis.includes(emoji)) {
      onRemove(emoji);
    } else if (selectedEmojis.length < maxSelections) {
      onSelect(emoji);
    }
  };

  const renderEmojiSection = (title: string, emojis: string[], description: string) => (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <h4 className="text-sm font-medium text-gray-700">{title}</h4>
        <span className="text-xs text-gray-500">{description}</span>
      </div>
      <div className="grid grid-cols-5 gap-2">
        {emojis.map((emoji) => (
          <motion.button
            key={emoji}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleEmojiClick(emoji)}
            className={`text-2xl p-2 rounded-lg transition-colors ${
              selectedEmojis.includes(emoji)
                ? 'bg-purple-100 border-2 border-purple-500'
                : 'bg-gray-50 hover:bg-gray-100'
            }`}
            disabled={selectedEmojis.length >= maxSelections && !selectedEmojis.includes(emoji)}
          >
            {emoji}
          </motion.button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="p-4">
      {renderEmojiSection(
        'Réactions positives',
        positiveEmojis,
        'Pour encourager et soutenir'
      )}
      {renderEmojiSection(
        'Réactions négatives',
        negativeEmojis,
        'Pour exprimer le désaccord'
      )}
      
      <div className="mt-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm text-gray-600">
            {selectedEmojis.length}/{maxSelections} réactions sélectionnées
          </p>
          {selectedEmojis.length > 0 && (
            <button
              onClick={() => selectedEmojis.forEach(onRemove)}
              className="text-xs text-red-600 hover:text-red-700"
            >
              Tout désélectionner
            </button>
          )}
        </div>
        
        {selectedEmojis.length > 0 && (
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-sm font-medium text-gray-700 mb-2">Sélection actuelle:</p>
            <div className="flex flex-wrap gap-2">
              {selectedEmojis.map((emoji) => (
                <motion.button
                  key={emoji}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => onRemove(emoji)}
                  className="text-xl p-2 bg-white rounded-lg shadow-sm hover:bg-red-50 transition-colors"
                >
                  {emoji}
                </motion.button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmojiSelector;