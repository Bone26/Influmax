{/* Modification de la ligne qui affiche le pourcentage de progression */}
{nextLevel && (
  <p className="text-sm text-gray-500 mt-2">
    {`${progress.toFixed(2)}% complété - Plus que ${(nextLevel.minSpend - totalSpent).toFixed(2)}€ pour atteindre le niveau ${nextLevel.name}`}
  </p>
)}