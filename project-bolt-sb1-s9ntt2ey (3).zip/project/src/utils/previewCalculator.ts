import { servicePricing } from '../config/servicePricing';

export const calculatePreviewCosts = (
  platform: string,
  differences: {
    followers: number;
    likes: number;
    reelViews: number;
    reelLikes: number;
  }
) => {
  const costs = {
    followers: 0,
    likes: 0,
    reelViews: 0,
    reelLikes: 0,
    total: 0
  };

  try {
    const platformPricing = servicePricing[platform as keyof typeof servicePricing];
    if (!platformPricing) return costs;

    // Calcul pour les followers (qualité standard uniquement)
    if (differences.followers > 0) {
      const followersPricing = platformPricing.followers.standard;
      costs.followers = differences.followers * followersPricing.pricePerUnit;
    }

    // Calcul pour les likes (qualité standard uniquement)
    if (differences.likes > 0) {
      const likesPricing = platformPricing.likes.standard;
      costs.likes = differences.likes * likesPricing.pricePerUnit;
    }

    // Calcul pour les vues de Reels (qualité standard uniquement)
    if (differences.reelViews > 0) {
      const viewsPricing = platformPricing.views.standard;
      costs.reelViews = differences.reelViews * viewsPricing.pricePerUnit;
    }

    // Calcul pour les likes de Reels (qualité standard uniquement)
    if (differences.reelLikes > 0) {
      const reelLikesPricing = platformPricing.likes.standard;
      costs.reelLikes = differences.reelLikes * reelLikesPricing.pricePerUnit;
    }

    // Calcul du total
    costs.total = costs.followers + costs.likes + costs.reelViews + costs.reelLikes;

    // Arrondir tous les montants à 2 décimales
    Object.keys(costs).forEach(key => {
      costs[key as keyof typeof costs] = Math.round(costs[key as keyof typeof costs] * 100) / 100;
    });

    return costs;
  } catch (error) {
    console.error('Error calculating preview costs:', error);
    return costs;
  }
};