import { 
  collection, 
  query, 
  where, 
  getDocs, 
  Timestamp,
  orderBy 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { subDays, format } from 'date-fns';

interface CommissionWalletStats {
  totalCommissions: number;
  pendingCommissions: number;
  totalWithdrawn: number;
  averageCommission: number;
  totalAffiliates: number;
  activeAffiliates: number;
  dailyStats: Array<{
    date: string;
    commissions: number;
    withdrawals: number;
  }>;
  withdrawalStats: {
    pending: number;
    processing: number;
    completed: number;
    rejected: number;
    averageProcessingTime: number;
  };
}

export const getCommissionWalletStats = async (days: number = 30): Promise<CommissionWalletStats> => {
  try {
    const endDate = new Date();
    const startDate = subDays(endDate, days);

    // Initialiser les statistiques par défaut
    const defaultStats: CommissionWalletStats = {
      totalCommissions: 0,
      pendingCommissions: 0,
      totalWithdrawn: 0,
      averageCommission: 0,
      totalAffiliates: 0,
      activeAffiliates: 0,
      dailyStats: [],
      withdrawalStats: {
        pending: 0,
        processing: 0,
        completed: 0,
        rejected: 0,
        averageProcessingTime: 0
      }
    };

    // Préparer les statistiques journalières
    for (let i = 0; i < days; i++) {
      const date = format(subDays(endDate, i), 'yyyy-MM-dd');
      defaultStats.dailyStats.push({
        date,
        commissions: 0,
        withdrawals: 0
      });
    }

    // Récupérer les affiliés
    const affiliatesSnapshot = await getDocs(collection(db, 'affiliates'));
    defaultStats.totalAffiliates = affiliatesSnapshot.size;

    // Récupérer les commissions
    const commissionsQuery = query(
      collection(db, 'commissionTransactions'),
      where('createdAt', '>=', Timestamp.fromDate(startDate)),
      where('createdAt', '<=', Timestamp.fromDate(endDate)),
      orderBy('createdAt', 'desc')
    );
    const commissionsSnapshot = await getDocs(commissionsQuery);
    const commissions = commissionsSnapshot.docs.map(doc => ({
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate()
    }));

    // Récupérer les retraits
    const withdrawalsQuery = query(
      collection(db, 'commissionWithdrawals'),
      where('createdAt', '>=', Timestamp.fromDate(startDate)),
      where('createdAt', '<=', Timestamp.fromDate(endDate)),
      orderBy('createdAt', 'desc')
    );
    const withdrawalsSnapshot = await getDocs(withdrawalsQuery);
    const withdrawals = withdrawalsSnapshot.docs.map(doc => ({
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate(),
      processedAt: doc.data().processedAt?.toDate()
    }));

    // Calculer les statistiques
    if (commissions.length > 0) {
      defaultStats.totalCommissions = commissions.reduce((sum, tx) => sum + (tx.amount || 0), 0);
      defaultStats.pendingCommissions = commissions
        .filter(tx => tx.status === 'pending')
        .reduce((sum, tx) => sum + (tx.amount || 0), 0);
      defaultStats.averageCommission = defaultStats.totalCommissions / commissions.length;
    }

    if (withdrawals.length > 0) {
      defaultStats.totalWithdrawn = withdrawals
        .filter(w => w.status === 'completed')
        .reduce((sum, w) => sum + (w.amount || 0), 0);

      // Mettre à jour les statistiques de retrait
      withdrawals.forEach(w => {
        if (w.status in defaultStats.withdrawalStats) {
          defaultStats.withdrawalStats[w.status as keyof typeof defaultStats.withdrawalStats]++;
        }
      });

      // Calculer le temps moyen de traitement
      const processingTimes = withdrawals
        .filter(w => w.status === 'completed' && w.processedAt)
        .map(w => {
          const start = w.createdAt;
          const end = w.processedAt;
          return (end.getTime() - start.getTime()) / (1000 * 60 * 60); // en heures
        });

      if (processingTimes.length > 0) {
        defaultStats.withdrawalStats.averageProcessingTime = 
          processingTimes.reduce((sum, time) => sum + time, 0) / processingTimes.length;
      }
    }

    // Mettre à jour les statistiques journalières
    defaultStats.dailyStats.forEach(stat => {
      const dayCommissions = commissions.filter(tx => 
        format(tx.createdAt, 'yyyy-MM-dd') === stat.date
      );
      const dayWithdrawals = withdrawals.filter(w => 
        format(w.createdAt, 'yyyy-MM-dd') === stat.date && w.status === 'completed'
      );

      stat.commissions = dayCommissions.reduce((sum, tx) => sum + (tx.amount || 0), 0);
      stat.withdrawals = dayWithdrawals.reduce((sum, w) => sum + (w.amount || 0), 0);
    });

    return defaultStats;
  } catch (error) {
    console.error('Error getting commission wallet stats:', error);
    throw error;
  }
};