import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, Plus } from 'lucide-react';
import { WALLET_CONFIG } from '../../config/wallet';

interface WalletBalanceProps {
  balance: number;
}

const WalletBalance: React.FC<WalletBalanceProps> = ({ balance }) => {
  useEffect(() => {
    // Load Stripe script dynamically
    const script = document.createElement('script');
    script.src = 'https://js.stripe.com/v3/buy-button.js';
    script.async = true;
    document.body.appendChild(script);

    // Add custom CSS for Stripe button styling
    const style = document.createElement('style');
    style.textContent = `
      /* Custom styling for Stripe Buy Button */
      stripe-buy-button {
        --button-height: auto !important;
        --button-width: 100% !important;
        --button-border-radius: 12px !important;
        --button-border-color: transparent !important;
        --button-hover-border-color: transparent !important;
        --button-active-border-color: transparent !important;
        --button-box-shadow: none !important;
        --button-hover-box-shadow: none !important;
        --button-active-box-shadow: none !important;
        width: 100% !important;
      }

      stripe-buy-button::part(root) {
        width: 100% !important;
      }

      stripe-buy-button::part(button) {
        width: 100% !important;
        height: auto !important;
        padding: 0 !important;
        margin: 0 !important;
        border: none !important;
        background: transparent !important;
      }

      stripe-buy-button::part(content) {
        background: linear-gradient(to right, rgb(147, 51, 234), rgb(79, 70, 229)) !important;
        border-radius: 12px !important;
        padding: 16px !important;
        width: 100% !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 8px !important;
        transition: transform 0.2s ease, opacity 0.2s ease !important;
      }

      stripe-buy-button::part(content):hover {
        opacity: 0.95 !important;
        transform: translateY(-1px) !important;
      }

      stripe-buy-button::part(content):active {
        transform: translateY(0) !important;
      }

      stripe-buy-button::part(price) {
        font-size: 24px !important;
        font-weight: 700 !important;
        color: white !important;
        margin-bottom: 8px !important;
      }

      stripe-buy-button::part(description) {
        font-size: 14px !important;
        color: rgba(255, 255, 255, 0.9) !important;
        margin-bottom: 16px !important;
      }

      stripe-buy-button::part(button-text) {
        font-size: 16px !important;
        font-weight: 600 !important;
        color: white !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 8px !important;
      }
    `;
    document.head.appendChild(style);

    return () => {
      // Cleanup script and styles on unmount
      const existingScript = document.querySelector('script[src="https://js.stripe.com/v3/buy-button.js"]');
      if (existingScript) {
        document.body.removeChild(existingScript);
      }
      if (style.parentNode) {
        style.parentNode.removeChild(style);
      }
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg p-6"
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-900">Solde actuel</h2>
        <CreditCard className="h-6 w-6 text-purple-600" />
      </div>
      <p className="text-4xl font-bold text-purple-600 mb-6">{balance.toFixed(2)}€</p>

      {/* Stripe Buy Button Card */}
      <div className="mb-6">
        <div className="relative group">
          {/* Glow effect */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl blur opacity-30 group-hover:opacity-50 transition duration-300"></div>
          
          {/* Card container */}
          <div className="relative bg-white rounded-xl overflow-hidden">
            <stripe-buy-button
              buy-button-id="buy_btn_1R5YeDHwmWt6IUj6KUzsZMhS"
              publishable-key="pk_test_51QMZYlHwmWt6IUj6MSmaNY7zJd1PvE9dB7PyNDieTeai68kNt2ANRAhBDbGKetWQRMEH49vbwKXI4XTlMlnn52l400bOA6GPxT"
            >
            </stripe-buy-button>
          </div>
        </div>
      </div>

      {/* Important Information */}
      <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-4 rounded-xl space-y-2">
        <div className="flex items-center space-x-2 mb-3">
          <Plus className="h-4 w-4 text-purple-600" />
          <span className="text-sm font-medium text-purple-800">Bonus de bienvenue</span>
        </div>
        <p className="text-sm text-purple-800 pl-6">
          • 10€ offerts pour votre premier dépôt de 50€ ou plus
        </p>
        <div className="border-t border-purple-100 my-3"></div>
        <p className="text-sm text-purple-800">
          • Montant minimum de dépôt : {WALLET_CONFIG.MIN_DEPOSIT}€
        </p>
        <p className="text-sm text-purple-800">
          • Montant maximum de dépôt : {WALLET_CONFIG.MAX_DEPOSIT}€
        </p>
        <p className="text-sm text-purple-800">
          • Paiement sécurisé par carte bancaire
        </p>
        <p className="text-sm text-purple-800">
          • Crédit instantané sur votre compte
        </p>
      </div>
    </motion.div>
  );
};

export default WalletBalance;