import { Platform } from '../types/service';

export interface PlatformStyle {
  gradients: {
    primary: string;
    secondary: string;
    text: string;
    hover: string;
  };
  colors: {
    primary: string;
    background: string;
    focus: string;
  };
}

const defaultStyle: PlatformStyle = {
  gradients: {
    primary: 'from-purple-500 to-indigo-500',
    secondary: 'from-purple-100 to-indigo-100',
    text: 'from-purple-600 to-indigo-600',
    hover: 'from-purple-700 to-indigo-700'
  },
  colors: {
    primary: 'text-purple-600',
    background: 'bg-purple-50',
    focus: 'focus:ring-purple-500 focus:border-purple-500'
  }
};

export const platformStyles: Record<string, PlatformStyle> = {
  instagram: {
    gradients: {
      primary: 'from-pink-500 to-purple-500',
      secondary: 'from-pink-100 to-purple-100',
      text: 'from-pink-600 to-purple-600',
      hover: 'from-pink-700 to-purple-700'
    },
    colors: {
      primary: 'text-pink-600',
      background: 'bg-pink-50',
      focus: 'focus:ring-pink-500 focus:border-pink-500'
    }
  },
  tiktok: {
    gradients: {
      primary: 'from-pink-500 to-red-500',
      secondary: 'from-pink-100 to-red-100',
      text: 'from-pink-600 to-red-600',
      hover: 'from-pink-700 to-red-700'
    },
    colors: {
      primary: 'text-pink-600',
      background: 'bg-pink-50',
      focus: 'focus:ring-pink-500 focus:border-pink-500'
    }
  },
  telegram: {
    gradients: {
      primary: 'from-blue-400 to-cyan-500',
      secondary: 'from-blue-100 to-cyan-100',
      text: 'from-blue-600 to-cyan-600',
      hover: 'from-blue-700 to-cyan-700'
    },
    colors: {
      primary: 'text-blue-600',
      background: 'bg-blue-50',
      focus: 'focus:ring-blue-500 focus:border-blue-500'
    }
  }
};

export const getPlatformStyles = (platform: Platform | string | null | undefined): PlatformStyle => {
  if (!platform) return defaultStyle;

  const platformKey = typeof platform === 'string' 
    ? platform.toLowerCase() 
    : typeof platform === 'object' && platform?.name 
      ? platform.name.toLowerCase()
      : '';

  return platformStyles[platformKey] || defaultStyle;
};