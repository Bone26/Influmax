import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Clock, MoreVertical, Timer } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { formatRemainingTime } from '../../utils/orderUtils';

interface OrdersTableProps {
  orders: any[];
  isLoading: boolean;
  onValidate: (orderId: string) => Promise<void>;
  onReject: (orderId: string) => Promise<void>;
}

const OrdersTable: React.FC<OrdersTableProps> = ({ orders, isLoading, onValidate, onReject }) => {
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);

  const formatDate = (date: Date | string | null) => {
    if (!date) return '';
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return format(dateObj, 'PPP à HH:mm', { locale: fr });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border border-green-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 border border-blue-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Terminé';
      case 'processing':
        return 'En cours';
      case 'cancelled':
        return 'Annulé';
      default:
        return status;
    }
  };

  const getDeliveryTimeText = (deliveryTime: string) => {
    switch (deliveryTime) {
      case 'instant':
        return '1 heure';
      case '24h':
        return '24 heures';
      case '3days':
        return '3 jours';
      case '7days':
        return '7 jours';
      case '1month':
        return '1 mois';
      default:
        return '1 heure';
    }
  };

  const getProcessingTime = (order: any) => {
    if (order.status === 'processing' && order.timestamps.startedAt) {
      return formatRemainingTime(
        new Date(order.timestamps.startedAt),
        order.deliveryTime || 'instant'
      );
    }
    return null;
  };

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Chargement des commandes...</p>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Aucune commande trouvée</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              ID
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Service
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Quantité
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Prix
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Durée d'envoi
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Statut
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Date
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {orders.map((order) => (
            <motion.tr
              key={order.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="hover:bg-gray-50"
            >
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                #{order.id.slice(0, 8)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {order.service?.platform} - {order.service?.type}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {order.quantity}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {order.price?.toFixed(2)}€
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center text-sm text-purple-600">
                  <Timer className="h-4 w-4 mr-1" />
                  {order.deliveryTime || 'Instantané'}
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                  {getStatusText(order.status)}
                </span>
                {order.status === 'processing' && order.timestamps?.startedAt && (
                  <div className="mt-1 flex items-center text-xs text-blue-600">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatRemainingTime(new Date(order.timestamps.startedAt), order.deliveryTime)}
                  </div>
                )}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatDate(order.timestamps?.createdAt)}
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrdersTable;