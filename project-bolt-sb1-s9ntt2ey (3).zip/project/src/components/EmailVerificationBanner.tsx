import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Mail, ArrowRight } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { resendVerificationEmail } from '../services/auth';
import { useNavigate } from 'react-router-dom';

const EmailVerificationBanner = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [sending, setSending] = useState(false);

  if (!currentUser || currentUser.emailVerified) {
    return null;
  }

  const handleResend = async () => {
    setSending(true);
    try {
      await resendVerificationEmail();
      navigate('/auth/verify-email');
    } catch (error) {
      console.error('Error resending verification email:', error);
    } finally {
      setSending(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white"
    >
      <div className="max-w-7xl mx-auto py-3 px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between flex-wrap">
          <div className="w-0 flex-1 flex items-center">
            <span className="flex p-2 rounded-lg bg-white/10">
              <AlertTriangle className="h-6 w-6" />
            </span>
            <p className="ml-3 font-medium truncate">
              <span>Veuillez vérifier votre adresse email pour accéder à toutes les fonctionnalités</span>
            </p>
          </div>
          <div className="flex-shrink-0">
            <button
              onClick={handleResend}
              disabled={sending}
              className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md text-sm font-medium text-yellow-600 bg-white hover:bg-yellow-50 transition-colors"
            >
              {sending ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-yellow-600 border-t-transparent mr-2" />
                  Envoi en cours...
                </div>
              ) : (
                <>
                  <Mail className="h-4 w-4 mr-2" />
                  Renvoyer l'email
                  <ArrowRight className="h-4 w-4 ml-2" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default EmailVerificationBanner;