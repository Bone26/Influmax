import axios, { AxiosError } from 'axios';
import qs from 'qs';
import { collection, doc, setDoc, updateDoc, increment, Timestamp, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'sonner';
import { Order, OrderStatus } from '../types/order';

// Configuration
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;
const API_TIMEOUT = 30000;

// Create axios instance with persistent configuration
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  timeout: API_TIMEOUT,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Cache-Control': 'no-cache',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  }
});

// Track API errors
const trackAPIError = async (error: any) => {
  try {
    const errorRef = doc(collection(db, 'apiErrors'));
    await setDoc(errorRef, {
      id: errorRef.id,
      error: error.message,
      code: error.code,
      timestamp: Timestamp.now(),
      details: error.response?.data || null
    });

    // Update global stats
    const statsRef = doc(db, 'apiStats', 'global');
    await updateDoc(statsRef, {
      errors: increment(1),
      lastError: Timestamp.now()
    });
  } catch (err) {
    console.error('Error tracking API error:', err);
  }
};

// Retry function with exponential backoff
const retryRequest = async <T>(
  fn: () => Promise<T>,
  retries: number = MAX_RETRIES,
  delay: number = RETRY_DELAY
): Promise<T> => {
  try {
    return await fn();
  } catch (error) {
    if (retries === 0) throw error;
    
    await new Promise(resolve => setTimeout(resolve, delay));
    return retryRequest(fn, retries - 1, delay * 2);
  }
};

// Generic API call function
const makeAPICall = async <T>(
  action: string,
  params: Record<string, any>,
  options: {
    silent?: boolean;
    retries?: number;
  } = {}
): Promise<T> => {
  const { silent = false, retries = MAX_RETRIES } = options;

  try {
    const data = {
      key: import.meta.env.VITE_API_KEY,
      action,
      ...params
    };

    console.log('Making API call:', { action, params: { ...params, key: '[REDACTED]' } });

    const response = await retryRequest(
      () => api.post('', qs.stringify(data)),
      retries
    );

    console.log('API response:', response.data);

    if (response.data.error) {
      throw new Error(response.data.error);
    }

    return response.data;
  } catch (error) {
    console.error('API call error:', error);
    await trackAPIError(error);

    // User-friendly error messages
    let userMessage = 'Une erreur est survenue. Veuillez réessayer plus tard.';
    
    if (error instanceof AxiosError) {
      switch (error.code) {
        case 'ECONNABORTED':
          userMessage = 'La requête a pris trop de temps. Veuillez réessayer.';
          break;
        case 'ERR_NETWORK':
          userMessage = 'Problème de connexion. Vérifiez votre connexion Internet.';
          break;
        case 'ERR_BAD_REQUEST':
          userMessage = 'Paramètres invalides. Veuillez vérifier vos informations.';
          break;
        default:
          if (error.response?.status === 429) {
            userMessage = 'Trop de requêtes. Veuillez patienter quelques instants.';
          } else if (error.response?.status === 500) {
            userMessage = 'Erreur serveur. Veuillez réessayer dans quelques instants.';
          }
      }
    }

    if (!silent) {
      toast.error(userMessage);
    }

    throw new Error(userMessage);
  }
};

// Export API functions
export const getAllOrders = async (userId?: string): Promise<Order[]> => {
  try {
    let ordersQuery;
    
    if (userId === 'admin') {
      // For admin, get all orders
      ordersQuery = query(
        collection(db, 'orders'),
        orderBy('timestamps.createdAt', 'desc')
      );
    } else {
      // For normal users, filter by userId
      ordersQuery = query(
        collection(db, 'orders'),
        where('userId', '==', userId),
        orderBy('timestamps.createdAt', 'desc')
      );
    }

    const querySnapshot = await getDocs(ordersQuery);
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        userId: data.userId,
        service: data.service,
        link: data.link,
        quantity: data.quantity,
        price: data.price,
        status: data.status,
        deliveryTime: data.deliveryTime,
        metadata: data.metadata,
        timestamps: {
          createdAt: data.timestamps?.createdAt?.toDate(),
          updatedAt: data.timestamps?.updatedAt?.toDate(),
          startedAt: data.timestamps?.startedAt?.toDate(),
          completedAt: data.timestamps?.completedAt?.toDate(),
          cancelledAt: data.timestamps?.cancelledAt?.toDate()
        }
      };
    });
  } catch (error) {
    console.error('Error getting orders:', error);
    throw error;
  }
};

export const updateOrderStatus = async (orderId: string, newStatus: OrderStatus): Promise<void> => {
  try {
    if (!orderId) {
      throw new Error('Order ID is required');
    }

    const orderRef = doc(db, 'orders', orderId);
    const now = Timestamp.now();
    
    const updates: any = {
      status: newStatus,
      'timestamps.updatedAt': now
    };

    // Add specific timestamp based on status
    if (newStatus === 'completed') {
      updates['timestamps.completedAt'] = now;
    } else if (newStatus === 'cancelled') {
      updates['timestamps.cancelledAt'] = now;
    }

    await updateDoc(orderRef, updates);
  } catch (error) {
    console.error('Error updating order status:', error);
    toast.error('Error updating order status');
    throw error;
  }
};

// Create order
export const createOrder = async (params: {
  service: string;
  link: string;
  quantity: number;
  runs?: number;
  interval?: number;
}): Promise<{ order: string }> => {
  console.log('Creating JAP order with params:', { ...params, service: params.service });
  
  try {
    const response = await makeAPICall<{ order: string }>('add', params);

    if (!response.order) {
      throw new Error('Invalid response from JAP API');
    }

    return response;
  } catch (error) {
    console.error('Error in createOrder:', error);
    throw error;
  }
};

export const getOrderStatus = async (orderId: string): Promise<any> => {
  return makeAPICall('status', { orders: [orderId] }, { silent: true });
};

export const getServices = async (): Promise<any[]> => {
  return makeAPICall('services', {});
};

// Export types
export type { Order, OrderStatus } from '../types/order';