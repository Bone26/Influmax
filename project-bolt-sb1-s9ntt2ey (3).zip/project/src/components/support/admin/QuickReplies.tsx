import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit2, Save, X } from 'lucide-react';

interface QuickRepliesProps {
  onSelect: (reply: string) => void;
}

const QuickReplies: React.FC<QuickRepliesProps> = ({ onSelect }) => {
  const [replies, setReplies] = useState([
    "Bonjour, merci de nous avoir contacté. Comment puis-je vous aider ?",
    "Votre demande a bien été prise en compte. Nous allons la traiter dans les plus brefs délais.",
    "Pouvez-vous me fournir plus de détails sur votre problème ?",
    "Je comprends votre situation. Laissez-moi vérifier cela pour vous.",
    "N'hésitez pas si vous avez d'autres questions.",
    "Je vous en prie, bonne journée !"
  ]);
  const [isEditing, setIsEditing] = useState(false);
  const [newReply, setNewReply] = useState('');

  const handleAddReply = () => {
    if (!newReply.trim()) return;
    setReplies([...replies, newReply]);
    setNewReply('');
  };

  const handleRemoveReply = (index: number) => {
    setReplies(replies.filter((_, i) => i !== index));
  };

  return (
    <div className="bg-white border-t p-4 max-h-48 overflow-y-auto">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-gray-700">Réponses rapides</h3>
        <button
          onClick={() => setIsEditing(!isEditing)}
          className="text-purple-600 hover:text-purple-700"
        >
          {isEditing ? <Save className="h-4 w-4" /> : <Edit2 className="h-4 w-4" />}
        </button>
      </div>

      <div className="space-y-2">
        {isEditing ? (
          <>
            <div className="flex space-x-2">
              <input
                type="text"
                value={newReply}
                onChange={(e) => setNewReply(e.target.value)}
                placeholder="Nouvelle réponse rapide..."
                className="flex-1 px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              />
              <button
                onClick={handleAddReply}
                className="p-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
            {replies.map((reply, index) => (
              <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-600">{reply}</span>
                <button
                  onClick={() => handleRemoveReply(index)}
                  className="text-red-500 hover:text-red-600"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
          </>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {replies.map((reply, index) => (
              <motion.button
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onSelect(reply)}
                className="p-2 text-left text-sm text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
              >
                {reply}
              </motion.button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default QuickReplies;