import { collection, doc, setDoc, updateDoc, increment, Timestamp, runTransaction } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { OrderRefund } from '../types/order';
import { sendRefundNotification } from './notifications';
import { toast } from 'sonner';

export const refundOrder = async (orderId: string, adminId: string, reason: string): Promise<void> => {
  try {
    console.log('🔄 Starting refund process for order:', orderId);
    await runTransaction(db, async (transaction) => {
      // 1. Récupérer la commande
      const orderRef = doc(db, 'orders', orderId);
      const orderDoc = await transaction.get(orderRef);
      if (!orderDoc.exists()) {
        throw new Error('Commande introuvable');
      }

      const order = orderDoc.data();
      
      // 2. Vérifier que la commande peut être remboursée
      if (!['completed', 'cancelled'].includes(order.status)) {
        throw new Error('Seules les commandes terminées ou annulées peuvent être remboursées');
      }

      if (order.metadata?.refunded) {
        throw new Error('Cette commande a déjà été remboursée');
      }

      // 3. Récupérer le wallet du client
      const walletRef = doc(db, 'depositWallets', order.userId);
      const walletDoc = await transaction.get(walletRef);
      if (!walletDoc.exists()) {
        throw new Error('Wallet du client introuvable');
      }

      const now = Timestamp.now();

      console.log('💰 Processing refund amount:', order.price);

      // 4. Créer le remboursement
      const refundRef = doc(collection(db, 'refunds'));
      const refund: OrderRefund = {
        id: refundRef.id,
        orderId,
        userId: order.userId,
        amount: order.price,
        reason,
        status: 'completed',
        createdAt: now.toDate(),
        createdBy: adminId
      };

      // 5. Créditer le wallet du client
      transaction.update(walletRef, {
        balance: increment(order.price),
        updatedAt: now
      });

      // 6. Créer la transaction dans l'historique
      const transactionRef = doc(collection(db, 'walletDeposits'));
      transaction.set(transactionRef, {
        id: transactionRef.id,
        userId: order.userId,
        amount: order.price,
        type: 'refund',
        status: 'completed',
        description: `Remboursement de la commande #${orderId}`,
        orderId,
        createdAt: now
      });

      // 7. Sauvegarder le remboursement
      transaction.set(refundRef, {
        ...refund,
        createdAt: now
      });

      // 8. Mettre à jour le statut de la commande
      transaction.update(orderRef, {
        status: 'cancelled',
        'metadata.refunded': true,
        'metadata.refundId': refundRef.id,
        'metadata.refundReason': reason,
        'metadata.refundedAt': now,
        'metadata.refundedBy': adminId,
        'timestamps.updatedAt': now,
        'timestamps.cancelledAt': now
      });

      console.log('🔔 Sending refund notification...');
      // 9. Envoyer la notification
      await sendRefundNotification(order.userId, orderId, order.price, reason);
    });

    console.log('✅ Refund completed successfully');
    toast.success('Commande remboursée avec succès');
  } catch (error) {
    console.error('❌ Error refunding order:', error);
    if (error instanceof Error) {
      toast.error(error.message);
    } else {
      toast.error('Erreur lors du remboursement');
    }
    throw error;
  }
};