import { collection, doc, getDoc, setDoc, updateDoc, Timestamp, runTransaction, increment, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { sendRewardUnlockedNotification } from './notifications';

// Vérifier si une récompense a déjà été réclamée
const hasClaimedReward = async (userId: string, rewardLevel: string): Promise<boolean> => {
  try {
    const q = query(
      collection(db, 'rewardClaims'),
      where('userId', '==', userId),
      where('rewardLevel', '==', rewardLevel)
    );
    
    const querySnapshot = await getDocs(q);
    return !querySnapshot.empty;
  } catch (error) {
    console.error('Error checking claimed reward:', error);
    return false;
  }
};

// Vérifier l'éligibilité pour une récompense
const checkEligibility = async (userId: string, rewardLevel: string): Promise<boolean> => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (!userDoc.exists()) return false;

    const userData = userDoc.data();
    const totalEarnings = userData.affiliate?.stats?.totalEarnings || 0;

    // Définir les seuils pour chaque niveau
    const thresholds = {
      bronze: 3000,
      silver: 15000,
      gold: 30000,
      platinum: 250000,
      diamond: 1000000,
      legend: 5000000
    };

    return totalEarnings >= thresholds[rewardLevel as keyof typeof thresholds];
  } catch (error) {
    console.error('Error checking eligibility:', error);
    return false;
  }
};

// Réclamer une récompense
export const claimReward = async (
  userId: string,
  userName: string,
  userEmail: string,
  rewardLevel: string,
  reward: string,
  shippingAddress: string
): Promise<void> => {
  try {
    // Vérifier si la récompense a déjà été réclamée
    const alreadyClaimed = await hasClaimedReward(userId, rewardLevel);
    if (alreadyClaimed) {
      throw new Error('Cette récompense a déjà été réclamée');
    }

    // Vérifier l'éligibilité
    const isEligible = await checkEligibility(userId, rewardLevel);
    if (!isEligible) {
      throw new Error('Vous n\'avez pas encore atteint le niveau requis pour cette récompense');
    }

    // Créer la réclamation
    const claimRef = doc(collection(db, 'rewardClaims'));
    const now = Timestamp.now();

    await setDoc(claimRef, {
      id: claimRef.id,
      userId,
      userName,
      userEmail,
      rewardLevel,
      reward,
      status: 'pending',
      shippingDetails: {
        address: shippingAddress
      },
      createdAt: now,
      updatedAt: now
    });

    // Envoyer une notification
    await sendRewardUnlockedNotification(userId, reward);

  } catch (error) {
    console.error('Error claiming reward:', error);
    throw error;
  }
};