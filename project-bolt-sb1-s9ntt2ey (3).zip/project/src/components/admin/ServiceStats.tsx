import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Clock, Award, DollarSign } from 'lucide-react';

interface ServiceStatsProps {
  serviceId: string;
  stats: {
    totalOrders: number;
    totalRevenue: number;
    averageOrderValue: number;
    successRate: number;
    averageDeliveryTime: number;
    dailyStats: Array<{
      date: string;
      orders: number;
      revenue: number;
    }>;
    qualityDistribution: {
      standard: number;
      premium: number;
      vip: number;
    };
    deliveryTimeDistribution: {
      instant: number;
      '24h': number;
      '3days': number;
      '7days': number;
      '1month': number;
    };
  };
}

const ServiceStats: React.FC<ServiceStatsProps> = ({ serviceId, stats }) => {
  const quickStats = [
    {
      icon: TrendingUp,
      label: 'Commandes totales',
      value: stats.totalOrders,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: DollarSign,
      label: 'Revenu total',
      value: `${stats.totalRevenue.toFixed(2)}€`,
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Award,
      label: 'Taux de réussite',
      value: `${(stats.successRate * 100).toFixed(1)}%`,
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Clock,
      label: 'Temps moyen de livraison',
      value: `${stats.averageDeliveryTime.toFixed(1)}h`,
      color: 'from-orange-500 to-red-500'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Statistiques rapides */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quickStats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color}`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-sm text-gray-600">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Commandes par jour */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Commandes par jour
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={stats.dailyStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="orders"
                  stroke="#8b5cf6"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Revenu par jour */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Revenu par jour
          </h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={stats.dailyStats}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#10b981"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* Distribution des qualités et temps de livraison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Distribution des qualités */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Distribution des qualités
          </h3>
          <div className="space-y-4">
            {Object.entries(stats.qualityDistribution).map(([quality, percentage]) => (
              <div key={quality}>
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span className="capitalize">{quality}</span>
                  <span>{(percentage * 100).toFixed(1)}%</span>
                </div>
                <div className="mt-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-purple-600 rounded-full"
                    style={{ width: `${percentage * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Distribution des temps de livraison */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Distribution des temps de livraison
          </h3>
          <div className="space-y-4">
            {Object.entries(stats.deliveryTimeDistribution).map(([time, percentage]) => (
              <div key={time}>
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>{time}</span>
                  <span>{(percentage * 100).toFixed(1)}%</span>
                </div>
                <div className="mt-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-green-600 rounded-full"
                    style={{ width: `${percentage * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ServiceStats;