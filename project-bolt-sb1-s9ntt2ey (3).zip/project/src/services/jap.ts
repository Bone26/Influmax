import axios from 'axios';
import qs from 'qs';
import { collection, doc, setDoc, updateDoc, increment, Timestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'sonner';

// Configuration
const MAX_RETRIES = 3;
const RETRY_DELAY = 1000;
const API_TIMEOUT = 60000;

// Create axios instance with persistent configuration
const japApi = axios.create({
  baseURL: '/api/v2',
  timeout: API_TIMEOUT,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Cache-Control': 'no-cache',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
  }
});

// Track API errors
const trackAPIError = async (error: any) => {
  try {
    const errorRef = doc(collection(db, 'apiErrors'));
    await setDoc(errorRef, {
      id: errorRef.id,
      error: error.message,
      code: error.code,
      timestamp: Timestamp.now(),
      details: error.response?.data || null
    });

    // Update global stats
    const statsRef = doc(db, 'apiStats', 'global');
    await updateDoc(statsRef, {
      errors: increment(1),
      lastError: Timestamp.now()
    });
  } catch (err) {
    console.error('Error tracking API error:', err);
  }
};

// Retry function with exponential backoff
const retryRequest = async <T>(
  fn: () => Promise<T>,
  retries: number = MAX_RETRIES,
  delay: number = RETRY_DELAY
): Promise<T> => {
  try {
    return await fn();
  } catch (error) {
    if (retries === 0) throw error;
    
    await new Promise(resolve => setTimeout(resolve, delay));
    return retryRequest(fn, retries - 1, delay * 2);
  }
};

// Generic API call function
const makeAPICall = async <T>(
  action: string,
  params: Record<string, any>,
  options: {
    silent?: boolean;
    retries?: number;
  } = {}
): Promise<T> => {
  const { silent = false, retries = MAX_RETRIES } = options;

  try {
    const data = {
      key: import.meta.env.VITE_API_KEY,
      action,
      ...params
    };

    console.log('Making API call:', { action, params: { ...params, key: '[REDACTED]' } });

    const response = await retryRequest(
      () => japApi.post('', qs.stringify(data)),
      retries
    );

    console.log('API response:', response.data);

    if (response.data.error) {
      throw new Error(response.data.error);
    }

    return response.data;
  } catch (error) {
    console.error('API call error:', error);
    await trackAPIError(error);

    // User-friendly error messages
    let userMessage = 'Une erreur est survenue. Veuillez réessayer plus tard.';
    
    if (axios.isAxiosError(error)) {
      switch (error.code) {
        case 'ECONNABORTED':
          userMessage = 'La requête a pris trop de temps. Veuillez réessayer.';
          break;
        case 'ERR_NETWORK':
          userMessage = 'Problème de connexion. Vérifiez votre connexion Internet.';
          break;
        case 'ERR_BAD_REQUEST':
          userMessage = 'Paramètres invalides. Veuillez vérifier vos informations.';
          break;
        default:
          if (error.response?.status === 429) {
            userMessage = 'Trop de requêtes. Veuillez patienter quelques instants.';
          } else if (error.response?.status === 500) {
            userMessage = 'Erreur serveur. Veuillez réessayer dans quelques instants.';
          }
      }
    }

    if (!silent) {
      toast.error(userMessage);
    }

    throw new Error(userMessage);
  }
};

// Export API functions
export const createJAPOrder = async (params: {
  service: string;
  link: string;
  quantity: number;
  runs?: number;
  interval?: number;
}): Promise<{ order: string }> => {
  console.log('🚀 [JAP Client] Creating order:', {
    ...params,
    service: params.service
  });

  try {
    const data = {
      action: 'add',
      service: params.service,
      link: params.link,
      quantity: params.quantity
    };

    // Add drip feed parameters if present
    if (params.runs && params.runs > 1) {
      Object.assign(data, {
        runs: params.runs,
        interval: params.interval || 15
      });
    }

    console.log('📤 [JAP Client] Sending request:', data);

    const response = await makeAPICall<{ order: string }>('add', data);

    console.log('📥 [JAP Client] Received response:', response);

    return { order: String(response.order) };
  } catch (error) {
    console.error('❌ [JAP Client] Error:', error);
    throw error;
  }
};

export const getJAPServices = async () => {
  try {
    console.log('🔍 [JAP Client] Getting services list');
    
    const response = await makeAPICall('services', {});

    console.log('📥 [JAP Client] Services response:', response);

    return response;
  } catch (error) {
    console.error('❌ [JAP Client] Error getting services:', error);
    throw error;
  }
};

export const getJAPOrderStatus = async (orderId: string) => {
  try {
    console.log('🔍 [JAP Client] Getting order status:', orderId);
    
    const response = await makeAPICall('status', {
      orders: [orderId]
    });

    console.log('📥 [JAP Client] Status response:', response);

    return response;
  } catch (error) {
    console.error('❌ [JAP Client] Error getting order status:', error);
    throw error;
  }
};