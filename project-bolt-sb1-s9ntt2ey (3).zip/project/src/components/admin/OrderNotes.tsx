import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Plus, Save } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface Note {
  id: string;
  content: string;
  createdAt: Date;
  createdBy: string;
}

interface OrderNotesProps {
  orderId: string;
  notes: Note[];
  onAddNote: (content: string) => Promise<void>;
}

const OrderNotes: React.FC<OrderNotesProps> = ({ orderId, notes, onAddNote }) => {
  const [newNote, setNewNote] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;

    setLoading(true);
    try {
      await onAddNote(newNote);
      setNewNote('');
      setIsAdding(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Notes internes</h3>
        {!isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="flex items-center text-purple-600 hover:text-purple-700"
          >
            <Plus className="h-4 w-4 mr-1" />
            Ajouter une note
          </button>
        )}
      </div>

      {isAdding && (
        <motion.form
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          onSubmit={handleSubmit}
          className="space-y-4"
        >
          <textarea
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
            placeholder="Votre note..."
            className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500"
            rows={3}
          />
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading || !newNote.trim()}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Enregistrer
                </>
              )}
            </button>
          </div>
        </motion.form>
      )}

      <div className="space-y-3">
        {notes.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>Aucune note pour cette commande</p>
          </div>
        ) : (
          notes.map((note) => (
            <motion.div
              key={note.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gray-50 p-4 rounded-lg"
            >
              <div className="flex justify-between items-start mb-2">
                <span className="font-medium">{note.createdBy}</span>
                <span className="text-sm text-gray-500">
                  {format(note.createdAt, 'PPP à HH:mm', { locale: fr })}
                </span>
              </div>
              <p className="text-gray-700 whitespace-pre-wrap">{note.content}</p>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

export default OrderNotes;