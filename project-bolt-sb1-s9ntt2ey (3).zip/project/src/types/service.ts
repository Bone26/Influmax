export interface DeliveryLimit {
  min: number;
  max: number;
}

export interface DeliveryLimits {
  instant: DeliveryLimit;
  '24h': DeliveryLimit;
  '3days': DeliveryLimit;
  '7days': DeliveryLimit;
  '1month': DeliveryLimit;
}

export interface ServiceQuality {
  type: 'standard' | 'premium' | 'vip';
  isAvailable: boolean;
  name: string;
  description: string;
  imageUrl: string;
  features: {
    label: string;
    value: boolean;
    info?: string;
  }[];
}

export interface ServiceDeliveryTime {
  type: 'instant' | '24h' | '3days' | '7days' | '1month';
  multiplier: number;
  isAvailable: boolean;
}

export interface Service {
  id: string;
  name: string;
  platformId: string;
  basePrice: number;
  deliveryLimits: DeliveryLimits;
  qualities: ServiceQuality[];
  deliveryTimes: ServiceDeliveryTime[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  japMapping?: JAPServiceMapping;
}

export interface JAPServiceMapping {
  japServiceId: string;
  japServiceName: string;
  minQuantity: number;
  maxQuantity: number;
  maxSpeed: number;
}