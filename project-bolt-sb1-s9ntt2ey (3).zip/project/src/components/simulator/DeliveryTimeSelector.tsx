import React, { useState, useEffect } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface DeliveryTimeSelectorProps {
  selectedTime: string;
  onTimeChange: (time: string) => void;
  platform: string;
  service: string;
}

const DeliveryTimeSelector: React.FC<DeliveryTimeSelectorProps> = ({
  selectedTime,
  onTimeChange,
  platform,
  service
}) => {
  const [availableTimes, setAvailableTimes] = useState<Array<{
    type: string;
    label: string;
    multiplier: number;
    isActive: boolean;
  }>>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadDeliveryTimes = async () => {
      if (!platform || !service) {
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);

        // Récupérer le service avec ses limites de livraison
        const servicesQuery = query(
          collection(db, 'servicePrices'),
          where('platformId', '==', platform.toLowerCase()),
          where('serviceType', '==', service),
          where('isActive', '==', true)
        );
        
        const serviceSnapshot = await getDocs(servicesQuery);
        if (serviceSnapshot.empty) {
          setError('Service non disponible');
          setLoading(false);
          return;
        }

        const serviceData = serviceSnapshot.docs[0].data();
        const deliveryLimits = serviceData.deliveryLimits || {};

        // Créer le tableau des durées disponibles avec leurs labels et multiplicateurs
        const times = [
          { type: 'instant', label: 'Instantané', multiplier: 1 },
          { type: '24h', label: '24 heures', multiplier: 1.1 },
          { type: '3days', label: '3 jours', multiplier: 1.2 },
          { type: '7days', label: '7 jours', multiplier: 1.3 },
          { type: '1month', label: '1 mois', multiplier: 1.5 }
        ].map(time => ({
          ...time,
          isActive: deliveryLimits[time.type]?.isActive ?? false,
          label: `${time.label} ${time.multiplier > 1 ? `(+${((time.multiplier - 1) * 100).toFixed(0)}%)` : ''}`
        }));

        setAvailableTimes(times);

        // Vérifier si le temps sélectionné est toujours disponible
        const selectedTimeData = times.find(t => t.type === selectedTime);
        if (!selectedTimeData?.isActive) {
          // Sélectionner le premier temps actif disponible
          const firstActiveTime = times.find(t => t.isActive);
          if (firstActiveTime) {
            onTimeChange(firstActiveTime.type);
          }
        }

      } catch (error) {
        console.error('Error loading delivery times:', error);
        setError('Erreur lors du chargement des options de livraison');
      } finally {
        setLoading(false);
      }
    };

    loadDeliveryTimes();
  }, [platform, service]); // Ne pas inclure selectedTime dans les dépendances

  if (loading) {
    return (
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Durée d'envoi
        </label>
        <div className="w-full p-3 border rounded-xl bg-gray-50">
          Chargement...
        </div>
      </div>
    );
  }

  // Filtrer les durées actives
  const activeTimes = availableTimes.filter(time => time.isActive);

  if (activeTimes.length === 0) {
    return (
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Durée d'envoi
        </label>
        <div className="w-full p-3 border rounded-xl bg-red-50 text-red-600">
          Aucune durée d'envoi disponible
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        Durée d'envoi
      </label>
      
      <div className="relative">
        <select
          value={selectedTime}
          onChange={(e) => onTimeChange(e.target.value)}
          className={`
            w-full p-3 border rounded-xl text-gray-700 transition-colors
            ${error ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'focus:ring-purple-500 focus:border-purple-500'}
          `}
        >
          {activeTimes.map((time) => (
            <option key={time.type} value={time.type}>
              {time.label}
            </option>
          ))}
        </select>
      </div>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="flex items-center space-x-2 text-sm p-2 rounded-lg bg-red-50 text-red-600">
              <AlertCircle className="h-4 w-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default DeliveryTimeSelector;