import React, { useState, useEffect } from 'react';
import { Eye } from 'lucide-react';
import QualityComparison from '../QualityComparison';
import { getAllPrices } from '../../services/pricing';

interface QualitySelectorProps {
  platform: string;
  service: string;
  selectedQuality: string;
  onQualityChange: (quality: string) => void;
}

const QualitySelector: React.FC<QualitySelectorProps> = ({
  platform,
  service,
  selectedQuality,
  onQualityChange
}) => {
  const [showQualityComparison, setShowQualityComparison] = useState(false);
  const [availableQualities, setAvailableQualities] = useState<string[]>([]);

  useEffect(() => {
    const loadQualities = async () => {
      try {
        const prices = await getAllPrices();
        const qualities = prices
          .filter(p => 
            p.platformId === platform &&
            p.serviceType === service &&
            p.isActive
          )
          .map(p => p.quality);

        setAvailableQualities([...new Set(qualities)]);
      } catch (error) {
        console.error('Error loading qualities:', error);
      }
    };

    loadQualities();
  }, [platform, service]);

  if (availableQualities.length <= 1) return null;

  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <label className="block text-sm font-medium text-gray-700">
          Qualité
        </label>
        <button
          type="button"
          onClick={() => setShowQualityComparison(true)}
          className="text-purple-600 hover:text-purple-700 text-sm flex items-center"
        >
          <Eye className="h-4 w-4 mr-1" />
          Comparer les qualités
        </button>
      </div>
      <select
        value={selectedQuality}
        onChange={(e) => onQualityChange(e.target.value)}
        className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
      >
        {availableQualities.map(quality => (
          <option key={quality} value={quality}>
            {quality === 'vip' ? 'VIP 🇫🇷' : quality.charAt(0).toUpperCase() + quality.slice(1)}
          </option>
        ))}
      </select>

      <QualityComparison
        isOpen={showQualityComparison}
        onClose={() => setShowQualityComparison(false)}
        platform={platform as 'instagram' | 'tiktok'}
        type={service}
      />
    </div>
  );
};

export default QualitySelector;