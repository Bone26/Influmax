import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator, Lightbulb } from 'lucide-react';
import PlatformSelector from './PlatformSelector';
import ServiceSelector from './ServiceSelector';
import QualitySelector from './QualitySelector';
import DeliveryTimeSelector from './DeliveryTimeSelector';
import QuantityInput from './QuantityInput';
import PriceDisplay from './PriceDisplay';
import PaymentButton from './PaymentButton';
import EmojiSelector from '../telegram/emoji/EmojiSelector';
import StrategyTip from './StrategyTip';
import { useServiceSimulator } from '../../hooks/useServiceSimulator';
import { getPlatformStyles } from '../../config/platformStyles';

const ServiceSimulator = () => {
  const { 
    formData, 
    price, 
    error,
    minQuantity,
    maxQuantity,
    selectedEmojis, 
    handleChange, 
    handleEmojiSelect, 
    handleEmojiRemove,
    handlePackSelect,
    emojiMode,
    setEmojiMode
  } = useServiceSimulator();

  const [showStrategyTip, setShowStrategyTip] = React.useState(false);

  // Vérifier si la commande est valide
  const isValidOrder = typeof formData?.quantity === 'number' && formData.quantity > 0;
  const styles = getPlatformStyles(formData?.platform);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50 py-4 px-4 md:py-12">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className={`bg-gradient-to-r ${styles?.gradients?.primary || 'from-purple-600 to-indigo-600'} p-4 md:p-6`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Calculator className="h-6 w-6 text-white mr-3" />
                <h1 className="text-xl md:text-3xl font-bold text-white">
                  Simulateur de prix
                </h1>
              </div>
              <button
                onClick={() => setShowStrategyTip(true)}
                className="flex items-center space-x-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
              >
                <Lightbulb className="h-5 w-5" />
                <span className="hidden md:inline">Notre astuce</span>
              </button>
            </div>
          </div>

          <div className="p-4 md:p-8 space-y-6">
            <div className="mb-8">
              <PlatformSelector
                selectedPlatform={formData?.platform || ''}
                onPlatformChange={(platform) => handleChange('platform', platform)}
              />
            </div>

            {formData?.platform && (
              <div className="mb-6">
                <ServiceSelector
                  platform={formData.platform}
                  selectedService={formData?.service || ''}
                  onServiceChange={(service) => handleChange('service', service)}
                />
              </div>
            )}

            {formData?.platform && formData?.service && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <QualitySelector
                    platform={formData.platform}
                    service={formData.service}
                    selectedQuality={formData?.quality || 'standard'}
                    onQualityChange={(quality) => handleChange('quality', quality)}
                  />

                  <DeliveryTimeSelector
                    selectedTime={formData?.deliveryTime || 'instant'}
                    onTimeChange={(time) => handleChange('deliveryTime', time)}
                    platform={formData.platform}
                    service={formData.service}
                  />
                </div>

                <div className="mt-6">
                  <QuantityInput
                    platform={formData.platform}
                    service={formData.service}
                    value={formData?.quantity || ''}
                    onChange={(value) => handleChange('quantity', value)}
                    deliveryTime={formData?.deliveryTime || 'instant'}
                  />
                </div>

                {formData.platform === 'telegram' && formData.service === 'reactions' && (
                  <div className="border rounded-xl overflow-hidden">
                    <EmojiSelector
                      selectedEmojis={selectedEmojis}
                      onSelect={handleEmojiSelect}
                      onRemove={handleEmojiRemove}
                      onSelectPack={handlePackSelect}
                    />
                  </div>
                )}

                <div className="mt-6">
                  <PriceDisplay 
                    price={price} 
                    isValid={isValidOrder}
                    platform={formData.platform}
                    error={error}
                  />
                </div>

                <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t md:relative md:border-0 md:p-0 md:bg-transparent">
                  <PaymentButton 
                    price={price}
                    isValid={isValidOrder}
                    formData={{ 
                      ...formData, 
                      selectedEmojis,
                      mode: emojiMode
                    }}
                  />
                </div>

                <div className="h-24 md:h-0" />
              </>
            )}
          </div>
        </motion.div>
      </div>

      <StrategyTip 
        isOpen={showStrategyTip} 
        onClose={() => setShowStrategyTip(false)} 
      />
    </div>
  );
};

export default ServiceSimulator;