import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Eye, Download } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import { CommissionWithdrawal } from '../../types/affiliate';

interface WithdrawalRequestsProps {
  withdrawals: CommissionWithdrawal[];
  onApprove: (withdrawalId: string) => Promise<void>;
  onReject: (withdrawalId: string) => Promise<void>;
  onExport: () => void;
  loading: boolean;
}

const WithdrawalRequests: React.FC<WithdrawalRequestsProps> = ({
  withdrawals,
  onApprove,
  onReject,
  onExport,
  loading
}) => {
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<CommissionWithdrawal | null>(null);

  const getStatusBadge = (status: CommissionWithdrawal['status']) => {
    const badges = {
      pending: 'bg-yellow-100 text-yellow-800',
      processing: 'bg-blue-100 text-blue-800',
      completed: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800'
    };
    return badges[status];
  };

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
        <p className="mt-4 text-gray-600">Chargement des demandes...</p>
      </div>
    );
  }

  if (withdrawals.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        Aucune demande de retrait en attente
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold">Demandes de retrait</h2>
        <button
          onClick={onExport}
          className="flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
        >
          <Download className="h-4 w-4" />
          <span>Exporter</span>
        </button>
      </div>

      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              ID
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Montant
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Date
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Statut
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {withdrawals.map((withdrawal) => (
            <motion.tr
              key={withdrawal.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {withdrawal.id.slice(0, 8)}...
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {withdrawal.amount.toFixed(2)}€
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatDistanceToNow(withdrawal.createdAt, { addSuffix: true, locale: fr })}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusBadge(withdrawal.status)}`}>
                  {withdrawal.status}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setSelectedWithdrawal(withdrawal)}
                    className="p-1 rounded-full hover:bg-gray-100"
                    title="Voir les détails"
                  >
                    <Eye className="h-4 w-4" />
                  </button>
                  {withdrawal.status === 'pending' && (
                    <>
                      <button
                        onClick={() => onApprove(withdrawal.id)}
                        className="p-1 rounded-full hover:bg-green-100 text-green-600"
                        title="Approuver"
                      >
                        <Check className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => onReject(withdrawal.id)}
                        className="p-1 rounded-full hover:bg-red-100 text-red-600"
                        title="Rejeter"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </>
                  )}
                </div>
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>

      {/* Modal de détails */}
      {selectedWithdrawal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-lg w-full m-4">
            <h3 className="text-lg font-bold mb-4">Détails du retrait</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">ID</p>
                <p className="font-medium">{selectedWithdrawal.id}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Montant</p>
                <p className="font-medium">{selectedWithdrawal.amount.toFixed(2)}€</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Date de demande</p>
                <p className="font-medium">
                  {selectedWithdrawal.createdAt.toLocaleDateString()}
                </p>
              </div>
              {selectedWithdrawal.bankDetails && (
                <>
                  <div>
                    <p className="text-sm text-gray-500">IBAN</p>
                    <p className="font-medium">{selectedWithdrawal.bankDetails.iban}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">BIC</p>
                    <p className="font-medium">{selectedWithdrawal.bankDetails.bic}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Titulaire</p>
                    <p className="font-medium">{selectedWithdrawal.bankDetails.accountHolder}</p>
                  </div>
                </>
              )}
            </div>
            <button
              onClick={() => setSelectedWithdrawal(null)}
              className="mt-6 w-full bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition-colors"
            >
              Fermer
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default WithdrawalRequests;