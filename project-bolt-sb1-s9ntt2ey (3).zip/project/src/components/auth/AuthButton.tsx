import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogIn } from 'lucide-react';

const AuthButton = () => {
  return (
    <Link to="/auth/login">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-4 py-2 rounded-full hover:from-purple-700 hover:to-indigo-700 transition-colors"
      >
        <LogIn className="h-5 w-5" />
        <span>Se connecter</span>
      </motion.button>
    </Link>
  );
};

export default AuthButton;