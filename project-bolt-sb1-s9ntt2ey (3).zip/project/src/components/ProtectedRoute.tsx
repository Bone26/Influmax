import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  adminOnly?: boolean;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, adminOnly = false }) => {
  const { currentUser, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  // Rediriger vers la page de connexion si non connecté
  if (!currentUser) {
    return <Navigate to="/auth/login" state={{ from: location }} />;
  }

  // Vérifier si l'email est vérifié
  if (!currentUser.emailVerified) {
    // Liste des routes autorisées sans vérification email
    const allowedRoutes = [
      '/auth/verify-email',
      '/auth/logout',
      '/mentions-legales',
      '/confidentialite'
    ];

    // Rediriger vers la vérification email si la route n'est pas autorisée
    if (!allowedRoutes.includes(location.pathname)) {
      return <Navigate to="/auth/verify-email" />;
    }
  }

  // Vérifier les droits admin
  if (adminOnly && !currentUser.isAdmin) {
    return <Navigate to="/" />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;