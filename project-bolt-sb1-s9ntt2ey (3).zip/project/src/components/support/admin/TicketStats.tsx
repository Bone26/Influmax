import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Clock, CheckCircle, XCircle, Inbox, Wallet, Users, Wrench, MoreHorizontal } from 'lucide-react';

interface TicketStatsProps {
  tickets: any[];
}

const TicketStats: React.FC<TicketStatsProps> = ({ tickets }) => {
  // Calculer les statistiques par statut
  const statusStats = {
    open: tickets.filter(t => t.status === 'open').length,
    processing: tickets.filter(t => t.status === 'processing').length,
    resolved: tickets.filter(t => t.status === 'resolved').length,
    closed: tickets.filter(t => t.status === 'closed').length
  };

  // Calculer les statistiques par catégorie
  const categoryStats = {
    order: tickets.filter(t => t.category === 'order').length,
    deposit: tickets.filter(t => t.category === 'deposit').length,
    withdrawal: tickets.filter(t => t.category === 'withdrawal').length,
    affiliate: tickets.filter(t => t.category === 'affiliate').length,
    technical: tickets.filter(t => t.category === 'technical').length,
    other: tickets.filter(t => t.category === 'other').length
  };

  const statusCards = [
    { label: 'En attente', value: statusStats.open, icon: MessageSquare, color: 'from-yellow-500 to-amber-500' },
    { label: 'En cours', value: statusStats.processing, icon: Clock, color: 'from-blue-500 to-cyan-500' },
    { label: 'Résolus', value: statusStats.resolved, icon: CheckCircle, color: 'from-green-500 to-emerald-500' },
    { label: 'Fermés', value: statusStats.closed, icon: XCircle, color: 'from-gray-500 to-slate-500' }
  ];

  const categoryCards = [
    { label: 'Commandes', value: categoryStats.order, icon: Inbox, color: 'from-purple-500 to-indigo-500' },
    { label: 'Dépôts', value: categoryStats.deposit, icon: Wallet, color: 'from-pink-500 to-rose-500' },
    { label: 'Retraits', value: categoryStats.withdrawal, icon: Wallet, color: 'from-orange-500 to-red-500' },
    { label: 'Affiliation', value: categoryStats.affiliate, icon: Users, color: 'from-teal-500 to-emerald-500' },
    { label: 'Technique', value: categoryStats.technical, icon: Wrench, color: 'from-blue-500 to-indigo-500' },
    { label: 'Autre', value: categoryStats.other, icon: MoreHorizontal, color: 'from-gray-500 to-slate-500' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      className="bg-white rounded-xl shadow-sm p-6 mb-6"
    >
      {/* Statistiques par statut */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Par statut</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {statusCards.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl border p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-2">
                <div className={`p-2 rounded-lg bg-gradient-to-r ${stat.color}`}>
                  <stat.icon className="h-5 w-5 text-white" />
                </div>
                <span className="text-2xl font-bold">{stat.value}</span>
              </div>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Statistiques par catégorie */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Par catégorie</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {categoryCards.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl border p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-center justify-between mb-2">
                <div className={`p-2 rounded-lg bg-gradient-to-r ${stat.color}`}>
                  <stat.icon className="h-5 w-5 text-white" />
                </div>
                <span className="text-2xl font-bold">{stat.value}</span>
              </div>
              <p className="text-sm text-gray-600">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default TicketStats;