import React from 'react';
import { motion } from 'framer-motion';
import { Lightbulb, TrendingUp, DollarSign, BarChart, Target, ChevronRight, X, Sparkles, Zap } from 'lucide-react';

interface StrategyTipProps {
  isOpen: boolean;
  onClose: () => void;
}

const StrategyTip: React.FC<StrategyTipProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-0 md:p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white w-full h-full md:h-auto md:rounded-2xl md:max-w-4xl md:w-full overflow-hidden"
      >
        {/* Header avec gradient animé */}
        <div className="sticky top-0 z-10 bg-gradient-to-r from-purple-600 via-indigo-600 via-blue-600 via-purple-600 to-indigo-600 bg-300% animate-gradient p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-white/10 p-2 rounded-lg">
                <Lightbulb className="h-6 w-6 text-white" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold text-white">Notre stratégie optimale</h2>
            </div>
            <button onClick={onClose} className="text-white/80 hover:text-white">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto max-h-[calc(100vh-80px)] md:max-h-[70vh]">
          {/* Introduction avec effet de brillance */}
          <div className="relative overflow-hidden bg-gradient-to-br from-purple-50 to-indigo-50 p-6 md:p-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10"
            >
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="h-5 w-5 text-purple-600" />
                <h3 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
                  La stratégie 80/20
                </h3>
              </div>
              <p className="text-gray-700 leading-relaxed">
                Notre expérience nous a permis de développer une approche optimale pour maximiser votre impact tout en maîtrisant votre budget. Découvrez comment obtenir les meilleurs résultats avec une stratégie intelligente.
              </p>
            </motion.div>
            {/* Effet de brillance */}
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-r from-purple-300/20 to-indigo-300/20 rounded-full blur-3xl animate-pulse" />
            <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-r from-indigo-300/20 to-purple-300/20 rounded-full blur-3xl animate-pulse delay-1000" />
          </div>

          {/* Répartition avec cartes modernes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 border border-green-100"
            >
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-green-100 p-3 rounded-xl">
                  <TrendingUp className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-green-900">80% Standard</h4>
                  <p className="text-sm text-green-700">Base solide et économique</p>
                </div>
              </div>
              <p className="text-green-800 leading-relaxed">
                La majorité de vos abonnés ou likes seront en qualité standard, parfaits pour augmenter rapidement vos chiffres à moindre coût.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 border border-blue-100"
            >
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-blue-100 p-3 rounded-xl">
                  <Target className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-blue-900">20% Premium/VIP</h4>
                  <p className="text-sm text-blue-700">Touche de qualité</p>
                </div>
              </div>
              <p className="text-blue-800 leading-relaxed">
                Une portion stratégique en haute qualité pour renforcer la crédibilité de votre profil et assurer une image professionnelle.
              </p>
            </motion.div>
          </div>

          {/* Explication avec icônes et cartes */}
          <div className="p-6 space-y-6">
            <h3 className="text-xl font-bold text-gray-900 flex items-center space-x-2">
              <Zap className="h-5 w-5 text-purple-600" />
              <span>Pourquoi cette stratégie fonctionne ?</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
              >
                <div className="flex items-center space-x-3 mb-4">
                  <div className="bg-purple-100 p-3 rounded-xl">
                    <BarChart className="h-5 w-5 text-purple-600" />
                  </div>
                  <h4 className="font-bold text-gray-900">Tri par date</h4>
                </div>
                <p className="text-gray-600 leading-relaxed">
                  La majorité des utilisateurs consultent le contenu par date d'ajout ou de like. La qualité des profils n'est pas le critère principal de visibilité.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
              >
                <div className="flex items-center space-x-3 mb-4">
                  <div className="bg-purple-100 p-3 rounded-xl">
                    <DollarSign className="h-5 w-5 text-purple-600" />
                  </div>
                  <h4 className="font-bold text-gray-900">Budget optimisé</h4>
                </div>
                <p className="text-gray-600 leading-relaxed">
                  En investissant stratégiquement dans les deux qualités, vous maximisez votre impact tout en maintenant un coût raisonnable.
                </p>
              </motion.div>
            </div>

            {/* Exemple concret avec design moderne */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl p-6 mt-8"
            >
              <h3 className="text-xl font-bold text-gray-900 mb-4">Exemple concret</h3>
              <p className="text-gray-700 mb-4">
                Pour une commande de 1000 abonnés, voici notre recommandation :
              </p>
              
              <div className="space-y-4">
                <div className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-lg font-semibold text-gray-900">800 abonnés Standard</span>
                      <p className="text-sm text-gray-500">Base solide pour la croissance</p>
                    </div>
                    <ChevronRight className="h-5 w-5 text-purple-400" />
                  </div>
                </div>
                
                <div className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-lg font-semibold text-gray-900">200 abonnés Premium/VIP</span>
                      <p className="text-sm text-gray-500">Renforcement de la crédibilité</p>
                    </div>
                    <ChevronRight className="h-5 w-5 text-purple-400" />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default StrategyTip;