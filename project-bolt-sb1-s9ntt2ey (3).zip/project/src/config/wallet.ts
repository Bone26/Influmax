export const WALLET_CONFIG = {
  MIN_DEPOSIT: 5,
  MAX_DEPOSIT: 1000,
  CURRENCY: 'EUR'
} as const;