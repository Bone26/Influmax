import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, Timestamp } from 'firebase/firestore';

// Configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyANW3adUidkA-20D7Z2DWuSkIuyAIh_E0U",
  authDomain: "influmax-2025.firebaseapp.com",
  projectId: "influmax-2025",
  storageBucket: "influmax-2025.firebasestorage.app",
  messagingSenderId: "14225266685",
  appId: "1:14225266685:web:92b36f8eeed3e5b78aab94"
};

// Fonction pour attendre que la connexion soit établie
const waitForConnection = (maxAttempts = 5) => {
  return new Promise((resolve, reject) => {
    let attempts = 0;
    
    const checkConnection = async () => {
      try {
        attempts++;
        console.log(`🔄 Tentative de connexion ${attempts}/${maxAttempts}...`);
        
        // Tester la connexion avec une petite opération
        const testRef = doc(collection(db, '_connection_test'));
        await setDoc(testRef, { timestamp: Timestamp.now() });
        await delay(1000); // Attendre 1s pour s'assurer que la connexion est stable
        
        console.log('✅ Connexion établie avec succès');
        resolve(true);
      } catch (error) {
        console.log(`⚠️ Échec de la tentative ${attempts}`);
        
        if (attempts >= maxAttempts) {
          reject(new Error('Impossible d\'établir une connexion après plusieurs tentatives'));
          return;
        }
        
        // Attendre avant la prochaine tentative
        setTimeout(checkConnection, 2000);
      }
    };
    
    checkConnection();
  });
};

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Initialiser Firebase et attendre la connexion
console.log('🏃 Démarrage du script...');
console.log('🔥 Initialisation de Firebase...');

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const platforms = [
  {
    name: 'Instagram',
    icon: 'Instagram',
    gradient: 'from-pink-500 to-purple-500',
    isActive: true
  },
  {
    name: 'TikTok',
    icon: 'Music2',
    gradient: 'from-pink-500 to-red-500',
    isActive: true
  },
  {
    name: 'Telegram',
    icon: 'MessageCircle',
    gradient: 'from-blue-400 to-cyan-500',
    isActive: true
  }
];

const initializePlatforms = async () => {
  console.log('🚀 Initialisation des plateformes...');
  
  for (const platform of platforms) {
    try {
      console.log(`⏳ Création de la plateforme ${platform.name}...`);
      
      const platformRef = doc(collection(db, 'platforms'));
      const now = new Date();
      
      await setDoc(platformRef, {
        id: platformRef.id,
        ...platform,
        createdAt: Timestamp.fromDate(now),
        updatedAt: Timestamp.fromDate(now)
      });

      console.log(`✅ Plateforme ${platform.name} créée avec succès (ID: ${platformRef.id})`);
      await delay(2000); // Attendre 2s entre chaque création
    } catch (error) {
      console.error(`❌ Erreur lors de la création de ${platform.name}:`, error);
      throw error; // Arrêter le processus en cas d'erreur
    }
  }
};

const main = async () => {
  try {
    // Attendre que la connexion soit établie
    await waitForConnection();
    
    // Initialiser les plateformes
    await initializePlatforms();
    
    console.log('✨ Initialisation terminée avec succès');
    process.exit(0);
  } catch (error) {
    console.error('💥 Erreur fatale:', error);
    process.exit(1);
  }
};

// Démarrer le script
main();