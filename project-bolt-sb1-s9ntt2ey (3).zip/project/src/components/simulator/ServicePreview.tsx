import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Music2, MessageCircle, Info } from 'lucide-react';
import { platformStyles } from '../../config/platformStyles';

interface ServicePreviewProps {
  platform: string;
  service: string;
  quality: string;
  quantity: number;
  deliveryTime: string;
}

const ServicePreview: React.FC<ServicePreviewProps> = ({
  platform,
  service,
  quality,
  quantity,
  deliveryTime
}) => {
  const styles = platformStyles[platform as keyof typeof platformStyles];
  
  const getPlatformIcon = () => {
    switch (platform) {
      case 'instagram':
        return Instagram;
      case 'tiktok':
        return Music2;
      case 'telegram':
        return MessageCircle;
      default:
        return Info;
    }
  };

  const Icon = getPlatformIcon();

  const getDeliveryTimeText = () => {
    switch (deliveryTime) {
      case 'instant':
        return '1 heure';
      case '24h':
        return '24 heures';
      case '3days':
        return '3 jours';
      case '7days':
        return '7 jours';
      case '1month':
        return '1 mois';
      default:
        return 'Instantané';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden"
    >
      <div className={`bg-gradient-to-r ${styles.gradients.primary} p-6`}>
        <div className="flex items-center space-x-3">
          <Icon className="h-6 w-6 text-white" />
          <h3 className="text-xl font-semibold text-white">Aperçu de la commande</h3>
        </div>
      </div>

      <div className="p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Service</p>
            <p className="font-medium">{service}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Quantité</p>
            <p className="font-medium">{quantity.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Qualité</p>
            <p className="font-medium capitalize">{quality}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Délai de livraison</p>
            <p className="font-medium">{getDeliveryTimeText()}</p>
          </div>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">Garanties</h4>
          <ul className="space-y-2 text-sm text-gray-600">
            <li>• Livraison garantie ou remboursé</li>
            <li>• Support client 24/7</li>
            <li>• Aucun mot de passe requis</li>
            <li>• Paiement sécurisé</li>
          </ul>
        </div>
      </div>
    </motion.div>
  );
};

export default ServicePreview;