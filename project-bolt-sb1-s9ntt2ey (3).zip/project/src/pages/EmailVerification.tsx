import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowRight } from 'lucide-react';

const EmailVerification = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-purple-100">
              <Mail className="h-6 w-6 text-purple-600" />
            </div>
            <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
              Vérifiez votre email
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              Un email de vérification a été envoyé à votre adresse email.
              Veuillez cliquer sur le lien dans l'email pour activer votre compte.
            </p>
          </div>

          <div className="mt-8">
            <div className="space-y-4">
              <div className="bg-purple-50 p-4 rounded-md">
                <h3 className="text-sm font-medium text-purple-800">Instructions :</h3>
                <ul className="mt-2 text-sm text-purple-700 list-disc list-inside">
                  <li>Vérifiez votre boîte de réception</li>
                  <li>Vérifiez également vos spams si nécessaire</li>
                  <li>Cliquez sur le lien de vérification dans l'email</li>
                  <li>Une fois vérifié, vous pourrez vous connecter</li>
                </ul>
              </div>

              <Link
                to="/connexion"
                className="w-full flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
              >
                Aller à la page de connexion
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailVerification;