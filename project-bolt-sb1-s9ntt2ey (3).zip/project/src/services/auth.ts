import { 
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  sendEmailVerification,
  sendPasswordResetEmail as firebaseSendPasswordResetEmail,
  onAuthStateChanged,
  reload,
  setPersistence,
  browserLocalPersistence
} from 'firebase/auth';
import { doc, setDoc, getDoc, collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { User } from '../types/user';
import { toast } from 'sonner';

// Configure auth persistence
setPersistence(auth, browserLocalPersistence);

export const signIn = async (email: string, password: string): Promise<User> => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    
    // Force token refresh
    await userCredential.user.getIdToken(true);
    
    // Force reload to get latest user data
    await userCredential.user.reload();
    
    const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
    
    if (!userDoc.exists()) {
      throw new Error('User data not found');
    }

    // Check email verification
    if (!userCredential.user.emailVerified) {
      throw new Error('EMAIL_NOT_VERIFIED');
    }

    const userData = userDoc.data();
    return {
      id: userCredential.user.uid,
      email: userCredential.user.email!,
      name: userData.name,
      emailVerified: userCredential.user.emailVerified,
      isAdmin: userData.isAdmin || false,
      affiliate: userData.affiliate,
      createdAt: userData.createdAt.toDate(),
      updatedAt: userData.updatedAt.toDate()
    };
  } catch (error) {
    console.error('Error signing in:', error);
    throw error;
  }
};

export const signOut = async (): Promise<void> => {
  try {
    await firebaseSignOut(auth);
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = '/';
  } catch (error) {
    console.error('Error signing out:', error);
    throw error;
  }
};

export const resendVerificationEmail = async (): Promise<void> => {
  try {
    const user = auth.currentUser;
    if (!user) {
      throw new Error('No user logged in');
    }

    // Forcer le rafraîchissement avant d'envoyer
    await user.reload();
    
    // Vérifier si l'email n'est pas déjà vérifié
    if (user.emailVerified) {
      throw new Error('Email already verified');
    }

    await sendEmailVerification(user);
    toast.success('Email de vérification envoyé avec succès');
  } catch (error) {
    console.error('Error sending verification email:', error);
    toast.error('Erreur lors de l\'envoi de l\'email de vérification');
    throw error;
  }
};

export const sendPasswordResetEmail = async (email: string): Promise<void> => {
  try {
    await firebaseSendPasswordResetEmail(auth, email);
    toast.success('Email de réinitialisation envoyé avec succès');
  } catch (error) {
    console.error('Error sending password reset email:', error);
    toast.error('Erreur lors de l\'envoi de l\'email de réinitialisation');
    throw error;
  }
};

// Fonction pour vérifier périodiquement le statut de vérification
export const checkEmailVerification = async (): Promise<boolean> => {
  try {
    const user = auth.currentUser;
    if (!user) return false;

    // Forcer le rafraîchissement du token
    await user.reload();

    // Mettre à jour le document utilisateur si l'email est vérifié
    if (user.emailVerified) {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, {
        emailVerified: true,
        updatedAt: Timestamp.now()
      }, { merge: true });
    }

    return user.emailVerified;
  } catch (error) {
    console.error('Error checking email verification:', error);
    return false;
  }
};