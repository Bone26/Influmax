import { useQuery, useMutation, useQueryClient } from 'react-query';
import axios from 'axios';

// Mock data for development
const mockOrders = [
  {
    id: '1',
    status: 'completed',
    service: 'Instagram Followers',
    link: 'https://instagram.com/user1',
    quantity: 1000,
    charge: 25,
    remains: 0,
    start_count: 5000,
    currency: 'EUR',
    created_at: '2024-03-15T10:00:00Z',
    updated_at: '2024-03-15T12:00:00Z'
  },
  {
    id: '2',
    status: 'processing',
    service: 'TikTok Likes',
    link: 'https://tiktok.com/video2',
    quantity: 500,
    charge: 15,
    remains: 200,
    start_count: 1000,
    currency: 'EUR',
    created_at: '2024-03-15T14:00:00Z',
    updated_at: '2024-03-15T14:30:00Z'
  }
];

const mockServices = [
  {
    service: 'instagram-followers',
    name: 'Instagram Followers',
    type: 'followers',
    rate: 2.5,
    min: 100,
    max: 10000,
    category: 'Instagram',
    description: 'High quality Instagram followers'
  },
  {
    service: 'tiktok-likes',
    name: 'TikTok Likes',
    type: 'likes',
    rate: 1.5,
    min: 100,
    max: 5000,
    category: 'TikTok',
    description: 'Real TikTok likes'
  }
];

export interface JAPService {
  service: string;
  name: string;
  type: string;
  rate: number;
  min: number;
  max: number;
  category: string;
  description?: string;
}

export interface JAPOrder {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  service: string;
  link: string;
  quantity: number;
  charge: number;
  remains: number;
  start_count: number;
  currency: string;
  created_at: string;
  updated_at: string;
}

export const useJapApi = () => {
  const queryClient = useQueryClient();

  const useServices = () => {
    return useQuery<JAPService[]>(
      'services',
      async () => {
        // Return mock data for development
        return mockServices;
      },
      {
        staleTime: 5 * 60 * 1000,
        cacheTime: 10 * 60 * 1000,
        retry: 2
      }
    );
  };

  const useOrders = () => {
    return useQuery<JAPOrder[]>(
      'orders',
      async () => {
        // Return mock data for development
        return mockOrders;
      },
      {
        staleTime: 30 * 1000,
        refetchInterval: 60 * 1000
      }
    );
  };

  const useCreateOrder = () => {
    return useMutation<JAPOrder, Error, { service: string; link: string; quantity: number }>(
      async (orderData) => {
        // Simulate API call
        const newOrder: JAPOrder = {
          id: Math.random().toString(36).substr(2, 9),
          status: 'pending',
          ...orderData,
          charge: 0,
          remains: orderData.quantity,
          start_count: 0,
          currency: 'EUR',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        };
        return newOrder;
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries('orders');
        }
      }
    );
  };

  const useUpdateOrderStatus = () => {
    return useMutation<JAPOrder, Error, { orderId: string; status: string }>(
      async ({ orderId, status }) => {
        // Simulate API call
        const order = mockOrders.find(o => o.id === orderId);
        if (!order) throw new Error('Order not found');
        return {
          ...order,
          status: status as JAPOrder['status'],
          updated_at: new Date().toISOString()
        };
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries('orders');
        }
      }
    );
  };

  return {
    useServices,
    useCreateOrder,
    useOrders,
    useUpdateOrderStatus
  };
};