import React from 'react';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';

interface PlatformPreviewProps {
  name: string;
  icon: string;
  gradient: string;
}

const PlatformPreview: React.FC<PlatformPreviewProps> = ({ name, icon, gradient }) => {
  const Icon = LucideIcons[icon as keyof typeof LucideIcons] || LucideIcons.HelpCircle;

  return (
    <div className="space-y-6">
      <h3 className="text-sm font-medium text-gray-700">Aperçu</h3>
      
      {/* Card Preview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl shadow-lg p-6"
      >
        <div className="flex items-center space-x-4">
          <div className={`p-3 rounded-lg bg-gradient-to-r ${gradient}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className={`text-lg font-semibold bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}>
              {name || 'Nom de la plateforme'}
            </h3>
            <p className="text-sm text-gray-500">Exemple de description</p>
          </div>
        </div>
      </motion.div>

      {/* Button Preview */}
      <motion.button
        className={`w-full flex items-center justify-center px-4 py-3 rounded-lg bg-gradient-to-r ${gradient} text-white hover:opacity-90 transition-opacity`}
      >
        <Icon className="h-5 w-5 mr-2" />
        Exemple de bouton
      </motion.button>

      {/* Badge Preview */}
      <div className="flex items-center space-x-4">
        <span className={`px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r ${gradient} bg-opacity-10 text-gray-900`}>
          Badge normal
        </span>
        <span className={`px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r ${gradient} text-white`}>
          Badge gradient
        </span>
      </div>
    </div>
  );
};

export default PlatformPreview;