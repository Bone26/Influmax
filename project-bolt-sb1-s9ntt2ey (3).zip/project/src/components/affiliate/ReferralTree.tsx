import React from 'react';
import { motion } from 'framer-motion';
import { User, Users, TrendingUp, Wallet } from 'lucide-react';

interface Referral {
  id: string;
  name: string;
  photoURL?: string;
  totalDeposits: number;
  commission: number;
  referrals?: Referral[];
}

interface ReferralTreeProps {
  currentUser: {
    name: string;
    photoURL?: string;
  };
  referrals: Referral[];
  stats?: {
    totalCommissions: number;
    totalDeposits: number;
  };
}

const ReferralTree: React.FC<ReferralTreeProps> = ({ currentUser, referrals = [], stats }) => {
  const renderReferral = (referral: Referral, level: number) => {
    return (
      <motion.div
        key={referral.id}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ 
          type: "spring",
          stiffness: 260,
          damping: 20,
          delay: level * 0.1 
        }}
        className="flex flex-col items-center"
      >
        {/* Carte de l'affilié */}
        <div className="w-[180px] mb-8">
          <div className={`
            bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300
            transform hover:-translate-y-1 border-2 ${level === 0 ? 'border-purple-200' : 'border-indigo-200'}
          `}>
            <div className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-12 h-12 rounded-full overflow-hidden ${
                  level === 0 ? 'bg-purple-100' : 'bg-indigo-100'
                }`}>
                  {referral.photoURL ? (
                    <img
                      src={referral.photoURL}
                      alt={referral.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <User className={`h-6 w-6 ${
                        level === 0 ? 'text-purple-600' : 'text-indigo-600'
                      }`} />
                    </div>
                  )}
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                  level === 0 
                    ? 'bg-purple-100 text-purple-700'
                    : 'bg-indigo-100 text-indigo-700'
                }`}>
                  Niveau {level + 1}
                </span>
              </div>

              <div className="text-center">
                <p className="font-medium text-gray-900 truncate">
                  {referral.name || 'Utilisateur'}
                </p>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 pt-4 border-t">
                <div className="text-center">
                  <div className="flex items-center justify-center text-gray-500 mb-1">
                    <Wallet className="h-3 w-3 mr-1" />
                    <span className="text-xs">Dépôts</span>
                  </div>
                  <p className="text-sm font-medium text-gray-900">
                    {referral.totalDeposits.toLocaleString()}€
                  </p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center text-gray-500 mb-1">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    <span className="text-xs">Gains</span>
                  </div>
                  <p className="text-sm font-medium text-green-600">
                    {referral.commission.toLocaleString()}€
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sous-affiliés */}
        {referral.referrals && referral.referrals.length > 0 && (
          <div className="relative">
            <div className="absolute left-1/2 -top-4 w-px h-4 bg-gray-200" />
            <div className="grid grid-cols-2 gap-12">
              {referral.referrals.map((subReferral) => (
                <div key={subReferral.id} className="relative">
                  <div className="absolute -top-4 left-1/2 w-px h-4 bg-gray-200" />
                  {renderReferral(subReferral, level + 1)}
                </div>
              ))}
            </div>
          </div>
        )}
      </motion.div>
    );
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-2">
          <Users className="h-6 w-6 text-purple-600" />
          <h3 className="text-xl font-semibold">Mon réseau d'affiliation</h3>
        </div>
      </div>

      <div className="flex flex-col items-center space-y-12">
        {/* Utilisateur principal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-[220px]"
        >
          <div className="bg-gradient-to-br from-purple-500 to-indigo-500 rounded-2xl p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <div className="w-16 h-16 rounded-full overflow-hidden bg-white/10">
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt={currentUser.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <User className="h-8 w-8 text-white" />
                  </div>
                )}
              </div>
              <div className="bg-white/10 px-3 py-1 rounded-full text-sm">
                Vous
              </div>
            </div>
            <div className="text-center">
              <p className="font-medium text-lg">{currentUser.name}</p>
              {stats && (
                <p className="text-sm text-purple-100 mt-1">
                  {stats.totalCommissions.toFixed(2)}€ de commissions
                </p>
              )}
            </div>
          </div>
        </motion.div>

        {/* Ligne de connexion verticale */}
        {referrals.length > 0 && (
          <div className="w-px h-8 bg-gray-200" />
        )}

        {/* Affiliés */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {referrals.map((referral) => (
            <div key={referral.id}>
              {renderReferral(referral, 0)}
            </div>
          ))}
        </div>

        {referrals.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <p className="text-xl font-medium text-gray-900 mb-2">
              Vous n'avez pas encore d'affiliés
            </p>
            <p className="text-gray-500">
              Partagez votre lien pour commencer à gagner des commissions
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReferralTree;