import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User as FirebaseUser,
  onAuthStateChanged,
  onIdTokenChanged
} from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot, updateDoc, Timestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { User } from '../types/user';
import { signIn, signOut } from '../services/auth';
import { createUser } from '../services/users';

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  createUser: (email: string, password: string, name: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Écouter les changements d'état d'authentification
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          // Écouter les changements du document utilisateur
          const unsubscribeDoc = onSnapshot(
            doc(db, 'users', firebaseUser.uid),
            async (docSnapshot) => {
              if (docSnapshot.exists()) {
                const userData = docSnapshot.data();
                
                // Si le statut de vérification a changé dans Firebase Auth
                if (firebaseUser.emailVerified !== userData.emailVerified) {
                  // Mettre à jour le statut dans Firestore
                  await updateDoc(doc(db, 'users', firebaseUser.uid), {
                    emailVerified: firebaseUser.emailVerified,
                    updatedAt: Timestamp.now()
                  });
                }

                setCurrentUser({
                  id: firebaseUser.uid,
                  email: firebaseUser.email!,
                  name: userData.name,
                  photoURL: userData.photoURL,
                  emailVerified: firebaseUser.emailVerified,
                  isAdmin: firebaseUser.email === 'b.camus26@hotmail.fr',
                  createdAt: userData.createdAt.toDate(),
                  updatedAt: userData.updatedAt.toDate(),
                  affiliate: userData.affiliate
                });
              }
              setLoading(false);
            },
            (error) => {
              console.error('Error listening to user document:', error);
              setCurrentUser(null);
              setLoading(false);
            }
          );

          return () => unsubscribeDoc();
        } catch (error) {
          console.error('Error getting user data:', error);
          setCurrentUser(null);
          setLoading(false);
        }
      } else {
        setCurrentUser(null);
        setLoading(false);
      }
    });

    // Écouter les changements de token pour détecter la vérification d'email
    const unsubscribeToken = onIdTokenChanged(auth, async (user) => {
      if (user) {
        // Forcer le rafraîchissement du token pour obtenir le dernier statut de vérification
        await user.getIdToken(true);
      }
    });

    return () => {
      unsubscribeAuth();
      unsubscribeToken();
    };
  }, []);

  return (
    <AuthContext.Provider value={{
      currentUser,
      loading,
      signIn: async (email, password) => {
        await signIn(email, password);
      },
      signOut,
      createUser: async (email, password, name) => {
        await createUser(email, password, name);
      }
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};