import React, { useState } from 'react';
import { motion } from 'framer-motion';
import * as LucideIcons from 'lucide-react';
import { Platform } from '../../types/platform';
import { Check, AlertTriangle, ChevronRight } from 'lucide-react';
import ColorPicker from './ColorPicker';
import IconSelector from './IconSelector';

interface PlatformFormProps {
  platform?: Partial<Platform>;
  onSubmit: (data: any) => Promise<void>;
  onCancel: () => void;
}

const PlatformForm: React.FC<PlatformFormProps> = ({
  platform,
  onSubmit,
  onCancel
}) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: platform?.name || '',
    icon: platform?.icon || 'Instagram',
    description: platform?.description || '',
    gradient: platform?.gradient || 'from-purple-500 to-indigo-500',
    isActive: platform?.isActive ?? true
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showIconSelector, setShowIconSelector] = useState(false);
  const [isCustomGradient, setIsCustomGradient] = useState(false);
  const [customGradient, setCustomGradient] = useState({
    from: '#6366f1',
    to: '#8b5cf6'
  });

  const steps = [
    { number: 1, title: 'Informations' },
    { number: 2, title: 'Apparence' },
    { number: 3, title: 'Configuration' }
  ];

  const validateStep = (currentStep: number): boolean => {
    const newErrors: Record<string, string> = {};

    switch (currentStep) {
      case 1:
        if (!formData.name.trim()) {
          newErrors.name = 'Le nom est requis';
        }
        break;
      case 2:
        if (!formData.icon) {
          newErrors.icon = 'L\'icône est requise';
        }
        if (!formData.gradient && !isCustomGradient) {
          newErrors.gradient = 'Le thème est requis';
        }
        break;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    setStep(prev => prev - 1);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep(step)) return;

    setLoading(true);
    try {
      // Si un gradient personnalisé est utilisé, le construire
      const finalData = {
        ...formData,
        gradient: isCustomGradient 
          ? `from-[${customGradient.from}] to-[${customGradient.to}]`
          : formData.gradient
      };

      await onSubmit(finalData);
    } catch (error) {
      setErrors({ submit: 'Une erreur est survenue' });
    } finally {
      setLoading(false);
    }
  };

  const handleGradientTypeChange = (type: 'preset' | 'custom') => {
    setIsCustomGradient(type === 'custom');
  };

  const handleCustomGradientChange = (color: string, type: 'from' | 'to') => {
    setCustomGradient(prev => ({
      ...prev,
      [type]: color
    }));
  };

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nom de la plateforme
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                placeholder="ex: Instagram"
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-600">{errors.name}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description (optionnelle)
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                rows={3}
                placeholder="Description de la plateforme..."
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">
                Icône
              </label>
              <div className="grid grid-cols-4 gap-4">
                <button
                  type="button"
                  onClick={() => setShowIconSelector(true)}
                  className="aspect-square rounded-xl flex items-center justify-center bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  {React.createElement(
                    LucideIcons[formData.icon as keyof typeof LucideIcons] || LucideIcons.HelpCircle,
                    { className: "h-6 w-6 text-gray-600" }
                  )}
                </button>
              </div>
              {errors.icon && (
                <p className="mt-1 text-sm text-red-600">{errors.icon}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">
                Thème de couleur
              </label>
              <div className="space-y-4">
                <div className="flex space-x-4">
                  <button
                    type="button"
                    onClick={() => handleGradientTypeChange('preset')}
                    className={`flex-1 px-4 py-2 rounded-lg border-2 transition-colors ${
                      !isCustomGradient
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-200 hover:border-purple-200'
                    }`}
                  >
                    Préréglages
                  </button>
                  <button
                    type="button"
                    onClick={() => handleGradientTypeChange('custom')}
                    className={`flex-1 px-4 py-2 rounded-lg border-2 transition-colors ${
                      isCustomGradient
                        ? 'border-purple-500 bg-purple-50 text-purple-700'
                        : 'border-gray-200 hover:border-purple-200'
                    }`}
                  >
                    Personnalisé
                  </button>
                </div>

                {isCustomGradient ? (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Couleur de début
                      </label>
                      <input
                        type="color"
                        value={customGradient.from}
                        onChange={(e) => handleCustomGradientChange(e.target.value, 'from')}
                        className="w-full h-12 rounded-lg cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Couleur de fin
                      </label>
                      <input
                        type="color"
                        value={customGradient.to}
                        onChange={(e) => handleCustomGradientChange(e.target.value, 'to')}
                        className="w-full h-12 rounded-lg cursor-pointer"
                      />
                    </div>
                    <div className="h-20 rounded-lg overflow-hidden">
                      <div 
                        className="w-full h-full"
                        style={{
                          background: `linear-gradient(to right, ${customGradient.from}, ${customGradient.to})`
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  <ColorPicker
                    selectedColor={formData.gradient}
                    onChange={(gradient) => setFormData(prev => ({ ...prev, gradient }))}
                  />
                )}
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Aperçu</h3>
              <div className={`bg-gradient-to-r ${isCustomGradient ? `from-[${customGradient.from}] to-[${customGradient.to}]` : formData.gradient} rounded-xl p-6 text-white`}>
                <div className="flex items-center space-x-4">
                  {React.createElement(
                    LucideIcons[formData.icon as keyof typeof LucideIcons] || LucideIcons.HelpCircle,
                    { className: "h-8 w-8" }
                  )}
                  <div>
                    <h4 className="text-xl font-bold">{formData.name}</h4>
                    {formData.description && (
                      <p className="text-sm text-white/80">{formData.description}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Configuration</h3>
              <div className="space-y-4">
                <label className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    checked={formData.isActive}
                    onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
                    className="h-5 w-5 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="text-gray-700">Activer la plateforme</span>
                </label>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between relative">
          {steps.map((s, i) => (
            <React.Fragment key={s.number}>
              <div className="flex items-center">
                <div className={`
                  w-10 h-10 rounded-full flex items-center justify-center
                  ${step >= s.number ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-500'}
                `}>
                  {step > s.number ? (
                    <Check className="h-6 w-6" />
                  ) : (
                    <span>{s.number}</span>
                  )}
                </div>
                <span className="ml-3 text-sm font-medium hidden sm:block">
                  {s.title}
                </span>
              </div>
              {i < steps.length - 1 && (
                <div className="flex-1 mx-4">
                  <div className={`h-1 ${
                    step > s.number ? 'bg-purple-600' : 'bg-gray-200'
                  }`} />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Form Content */}
      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-6 mb-6">
        {renderStepContent()}
      </form>

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <button
          type="button"
          onClick={handleBack}
          className={`px-6 py-3 text-gray-600 hover:text-gray-900 font-medium rounded-xl ${
            step === 1 ? 'invisible' : ''
          }`}
        >
          Retour
        </button>
        
        {step < steps.length ? (
          <button
            type="button"
            onClick={handleNext}
            className="flex items-center px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700"
          >
            Suivant
            <ChevronRight className="ml-2 h-5 w-5" />
          </button>
        ) : (
          <button
            type="submit"
            disabled={loading}
            className="flex items-center px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 disabled:opacity-50"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent mr-2" />
                Enregistrement...
              </>
            ) : (
              <>
                <Check className="mr-2 h-5 w-5" />
                Terminer
              </>
            )}
          </button>
        )}
      </div>

      {errors.submit && (
        <div className="mt-4 p-4 bg-red-50 rounded-xl flex items-center text-red-600">
          <AlertTriangle className="h-5 w-5 mr-2" />
          {errors.submit}
        </div>
      )}

      <IconSelector
        isOpen={showIconSelector}
        onClose={() => setShowIconSelector(false)}
        onSelect={(icon) => setFormData(prev => ({ ...prev, icon }))}
        currentIcon={formData.icon}
      />
    </div>
  );
};

export default PlatformForm;