export type TicketStatus = 'open' | 'processing' | 'resolved' | 'closed';
export type TicketCategory = 
  | 'order'      // Commande
  | 'deposit'    // Dépôt
  | 'withdrawal' // Retrait
  | 'affiliate'  // Affiliation
  | 'technical'  // Technique
  | 'other';     // Autre

export interface TicketMessage {
  id: string;
  ticketId: string;
  content: string;
  senderId: string;
  senderName: string;
  senderRole: 'user' | 'admin';
  attachments?: {
    url: string;
    name: string;
    type: string;
    size: number;
  }[];
  createdAt: Date;
  read: boolean;
}

export interface Ticket {
  id: string;
  userId: string;
  userName: string;
  subject: string;
  category: TicketCategory;
  status: TicketStatus;
  orderId?: string | null;
  lastMessage?: {
    content: string;
    createdAt: Date;
  };
  unreadCount: number;
  createdAt: Date;
  updatedAt: Date;
  closedAt?: Date;
}

export interface TypingStatus {
  ticketId: string;
  userId: string;
  userName: string;
  timestamp: Date;
}