import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wallet, AlertCircle, Info } from 'lucide-react';
import { useAffiliate } from '../../contexts/AffiliateContext';
import { useAuth } from '../../contexts/AuthContext';
import { createWithdrawal } from '../../services/affiliate';
import { toast } from 'sonner';

const WithdrawalForm = () => {
  const { currentUser } = useAuth();
  const { affiliate, refreshAffiliate } = useAffiliate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [bankDetails, setBankDetails] = useState({
    iban: '',
    bic: '',
    accountHolder: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser?.id || !affiliate) return;

    setLoading(true);
    setError('');

    try {
      // Créer le retrait
      await createWithdrawal(currentUser.id, affiliate.stats.availableEarnings, bankDetails);
      await refreshAffiliate();
      
      // Réinitialiser le formulaire
      setBankDetails({
        iban: '',
        bic: '',
        accountHolder: ''
      });
      toast.success('Demande de retrait créée avec succès');
    } catch (error) {
      if (error instanceof Error) {
        setError(error.message);
      } else {
        setError('Une erreur est survenue lors de la demande de retrait');
      }
      console.error('Error creating withdrawal:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg p-6"
    >
      <div className="flex items-center space-x-2 mb-6">
        <Wallet className="h-6 w-6 text-purple-600" />
        <h3 className="text-lg font-semibold">Retirer mes gains</h3>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 rounded-lg flex items-center text-red-600 text-sm">
          <AlertCircle className="h-4 w-4 mr-2" />
          {error}
        </div>
      )}

      <div className="bg-purple-50 p-4 rounded-lg mb-6">
        <div className="flex items-center justify-between">
          <p className="text-purple-900 font-medium">Gains disponibles</p>
          {affiliate?.stats.pendingWithdrawals > 0 && (
            <span className="text-sm text-purple-700">
              ({affiliate.stats.pendingWithdrawals.toFixed(2)}€ en attente)
            </span>
          )}
        </div>
        <p className="text-2xl font-bold text-purple-700">
          {affiliate?.stats.availableEarnings.toFixed(2)}€
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            IBAN
          </label>
          <input
            type="text"
            value={bankDetails.iban}
            onChange={(e) => setBankDetails({ ...bankDetails, iban: e.target.value.toUpperCase() })}
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="FR76..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            BIC/SWIFT
          </label>
          <input
            type="text"
            value={bankDetails.bic}
            onChange={(e) => setBankDetails({ ...bankDetails, bic: e.target.value.toUpperCase() })}
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="BNPAFRPP..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Titulaire du compte
          </label>
          <input
            type="text"
            value={bankDetails.accountHolder}
            onChange={(e) => setBankDetails({ ...bankDetails, accountHolder: e.target.value })}
            className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="Prénom NOM"
            required
          />
        </div>

        <div className="bg-gray-50 p-4 rounded-lg space-y-2">
          <div className="flex items-center text-sm text-gray-600">
            <Info className="h-4 w-4 mr-2 text-gray-400" />
            <span>Informations importantes</span>
          </div>
          <p className="text-sm text-gray-600 flex items-center">
            <span className="mr-2">•</span>
            Montant minimum de retrait : 50€
          </p>
          <p className="text-sm text-gray-600 flex items-center">
            <span className="mr-2">•</span>
            Délai de traitement : 1-3 jours ouvrés
          </p>
          <p className="text-sm text-gray-600 flex items-center">
            <span className="mr-2">•</span>
            Virement bancaire uniquement
          </p>
        </div>

        <button
          type="submit"
          disabled={loading || !affiliate || affiliate.stats.availableEarnings < 50}
          className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
            !affiliate || affiliate.stats.availableEarnings < 50
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:opacity-90'
          }`}
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
              Traitement en cours...
            </span>
          ) : (
            <span>
              {!affiliate || affiliate.stats.availableEarnings < 50 
                ? `Minimum 50€ requis (${affiliate?.stats.availableEarnings.toFixed(2)}€ disponibles)`
                : `Retirer ${affiliate.stats.availableEarnings.toFixed(2)}€`
              }
            </span>
          )}
        </button>
      </form>
    </motion.div>
  );
};

export default WithdrawalForm;