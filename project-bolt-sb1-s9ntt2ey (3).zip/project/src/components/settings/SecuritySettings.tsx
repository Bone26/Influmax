import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Key, Smartphone, AlertTriangle } from 'lucide-react';

const SecuritySettings = () => {
  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [showTwoFactor, setShowTwoFactor] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    setError('');
  };

  const validatePassword = (password: string) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*]/.test(password);

    const errors = [];
    if (password.length < minLength) {
      errors.push('Au moins 8 caractères');
    }
    if (!hasUpperCase) {
      errors.push('Une majuscule');
    }
    if (!hasLowerCase) {
      errors.push('Une minuscule');
    }
    if (!hasNumbers) {
      errors.push('Un chiffre');
    }
    if (!hasSpecialChar) {
      errors.push('Un caractère spécial');
    }

    return errors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.newPassword !== formData.confirmPassword) {
      setError('Les mots de passe ne correspondent pas');
      return;
    }

    const passwordErrors = validatePassword(formData.newPassword);
    if (passwordErrors.length > 0) {
      setError(`Le mot de passe doit contenir : ${passwordErrors.join(', ')}`);
      return;
    }

    setIsSaving(true);
    try {
      // Simulation de mise à jour
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFormData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
    } catch (error) {
      setError('Une erreur est survenue');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Sécurité</h2>
        <div className="flex items-center text-green-600">
          <Shield className="h-5 w-5 mr-2" />
          <span className="text-sm font-medium">Compte sécurisé</span>
        </div>
      </div>

      {/* Changement de mot de passe */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center mb-4">
          <Key className="h-5 w-5 text-purple-600 mr-2" />
          <h3 className="text-lg font-medium text-gray-900">Mot de passe</h3>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Mot de passe actuel
            </label>
            <input
              type="password"
              name="currentPassword"
              value={formData.currentPassword}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Nouveau mot de passe
            </label>
            <input
              type="password"
              name="newPassword"
              value={formData.newPassword}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Confirmer le nouveau mot de passe
            </label>
            <input
              type="password"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50"
          >
            {isSaving ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
                Mise à jour...
              </div>
            ) : (
              'Mettre à jour le mot de passe'
            )}
          </button>
        </form>
      </div>

      {/* Double authentification */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Smartphone className="h-5 w-5 text-purple-600 mr-2" />
            <h3 className="text-lg font-medium text-gray-900">Double authentification</h3>
          </div>
          <button
            onClick={() => setShowTwoFactor(!showTwoFactor)}
            className="text-purple-600 hover:text-purple-700 font-medium"
          >
            Configurer
          </button>
        </div>
        <p className="mt-2 text-sm text-gray-600">
          Ajoutez une couche de sécurité supplémentaire à votre compte en activant la double authentification.
        </p>
      </div>

      {/* Sessions actives */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-purple-600 mr-2" />
            <h3 className="text-lg font-medium text-gray-900">Sessions actives</h3>
          </div>
          <button className="text-red-600 hover:text-red-700 font-medium">
            Déconnecter toutes les sessions
          </button>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium text-gray-900">Chrome - Windows</p>
              <p className="text-sm text-gray-500">Dernière activité: Il y a 2 minutes</p>
            </div>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              Session actuelle
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecuritySettings;