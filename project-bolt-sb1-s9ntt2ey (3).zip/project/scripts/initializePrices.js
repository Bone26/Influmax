import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, getDocs, query, where, Timestamp, writeBatch } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'sonner';

const initializePrices = async () => {
  try {
    // 1. Supprimer les anciens prix
    const batch = writeBatch(db);
    const oldPricesQuery = query(collection(db, 'servicePrices'));
    const oldPricesSnapshot = await getDocs(oldPricesQuery);
    console.log(`🗑️ Suppression de ${oldPricesSnapshot.size} anciens prix...`);
    
    oldPricesSnapshot.docs.forEach(doc => {
      batch.delete(doc.ref);
    });
    await batch.commit();

    // 2. Définir les nouveaux prix avec mapping JAP
    const prices = [
      // Telegram Members
      {
        platformId: 'telegram',
        serviceType: 'members',
        quality: 'standard',
        basePrice: 0.01,
        deliveryLimits: {
          instant: { min: 500, max: 10000, isActive: true },
          '24h': { min: 750, max: 7500, isActive: true },
          '3days': { min: 1000, max: 5000, isActive: true },
          '7days': { min: 2500, max: 25000, isActive: false },
          '1month': { min: 5000, max: 10000, isActive: false }
        },
        japMapping: {
          japServiceId: '363',
          japServiceName: 'Telegram Channel Members [Public]',
          minQuantity: 500,
          maxQuantity: 10000,
          maxSpeed: 10000
        },
        isActive: true
      },

      // Telegram Views
      {
        platformId: 'telegram',
        serviceType: 'views',
        quality: 'standard',
        basePrice: 0.0005,
        deliveryLimits: {
          instant: { min: 300, max: 45000, isActive: true },
          '24h': { min: 600, max: 35000, isActive: true },
          '3days': { min: 1500, max: 25000, isActive: true },
          '7days': { min: 3000, max: 15000, isActive: true },
          '1month': { min: 6000, max: 10000, isActive: true }
        },
        japMapping: {
          japServiceId: '6584',
          japServiceName: 'Telegram Post Views',
          minQuantity: 300,
          maxQuantity: 45000,
          maxSpeed: 45000
        },
        isActive: true
      },

      // Telegram Reactions
      {
        platformId: 'telegram',
        serviceType: 'reactions',
        quality: 'standard',
        basePrice: 0.001,
        deliveryLimits: {
          instant: { min: 50, max: 50000, isActive: true },
          '24h': { min: 100, max: 45000, isActive: true },
          '3days': { min: 250, max: 35000, isActive: true },
          '7days': { min: 500, max: 25000, isActive: true },
          '1month': { min: 1000, max: 10000, isActive: true }
        },
        telegramReactions: {
          individual: [
            { emoji: '👍', japServiceId: '6571', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '❤️', japServiceId: '6573', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🔥', japServiceId: '6574', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🎉', japServiceId: '6575', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🤩', japServiceId: '6576', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '😁', japServiceId: '6578', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '💯', japServiceId: '8806', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🍾', japServiceId: '8800', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🏆', japServiceId: '8805', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🙏', japServiceId: '8794', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '👌', japServiceId: '8798', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '👎', japServiceId: '6572', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '😢', japServiceId: '6579', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '💩', japServiceId: '6580', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🤮', japServiceId: '6581', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '😱', japServiceId: '6577', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🤡', japServiceId: '8795', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '😐', japServiceId: '8809', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🖕', japServiceId: '8803', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🥱', japServiceId: '8799', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 },
            { emoji: '🌭', japServiceId: '8796', minQuantity: 50, maxQuantity: 300000, maxSpeed: 10000 }
          ],
          mixedPacks: {
            positive: {
              japServiceId: '7256',
              japServiceName: 'Telegram Post Reactions + Views [Positive] [Mixed]',
              minQuantity: 10,
              maxQuantity: 50000,
              maxSpeed: 50000
            },
            negative: {
              japServiceId: '7257',
              japServiceName: 'Telegram Post Reactions + Views [Negative] [Mixed]',
              minQuantity: 10,
              maxQuantity: 50000,
              maxSpeed: 50000
            }
          }
        },
        isActive: true
      }
    ];

    // 3. Créer les nouveaux prix
    for (const price of prices) {
      try {
        const priceRef = doc(collection(db, 'servicePrices'));
        const now = new Date();
        
        await setDoc(priceRef, {
          id: priceRef.id,
          ...price,
          updatedAt: Timestamp.fromDate(now),
          updatedBy: 'system'
        });
        
        console.log(`✅ Prix créé pour ${price.platformId} - ${price.serviceType} (${price.quality})`);
        await new Promise(resolve => setTimeout(resolve, 500)); // Attendre un peu entre chaque création
      } catch (error) {
        console.error(`❌ Erreur lors de la création du prix pour ${price.platformId} - ${price.serviceType} (${price.quality}):`, error);
      }
    }

    console.log('✨ Initialisation des prix terminée avec succès !');
  } catch (error) {
    console.error('❌ Erreur lors de l\'initialisation des prix:', error);
    throw error;
  }
};

// Exécuter l'initialisation
initializePrices();