import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Shield } from 'lucide-react';

const MentionsLegales = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center space-x-4">
              <Link to="/" className="text-white/80 hover:text-white">
                <ArrowLeft className="h-6 w-6" />
              </Link>
              <div className="flex items-center">
                <Shield className="h-6 w-6 text-white mr-3" />
                <h1 className="text-2xl font-bold text-white">Mentions Légales</h1>
              </div>
            </div>
          </div>

          <div className="p-6 md:p-8 space-y-8">
            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Éditeur du site</h2>
              <p className="text-gray-600">
                Le site Influmax est édité par la société Influmax, SASU au capital de 1000€,
                immatriculée au Registre du Commerce et des Sociétés de Paris sous le numéro 123456789.
              </p>
              <div className="mt-4 space-y-2 text-gray-600">
                <p>Siège social : 1 rue de la Paix, 75001 Paris, France</p>
                <p>Numéro de TVA intracommunautaire : FR12345678900</p>
                <p>Directeur de la publication : John Doe</p>
                <p>Email : contact@influmax.fr</p>
              </div>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">2. Hébergement</h2>
              <p className="text-gray-600">
                Le site est hébergé par Firebase (Google Cloud Platform), société du groupe Google LLC,
                dont le siège social est situé au 1600 Amphitheatre Parkway, Mountain View, CA 94043,
                États-Unis.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">3. Propriété intellectuelle</h2>
              <p className="text-gray-600">
                L'ensemble du contenu du site (textes, images, vidéos, etc.) est protégé par le droit
                d'auteur. Toute reproduction ou représentation, totale ou partielle, du site ou de
                l'un des éléments qui le composent, sans l'autorisation expresse d'Influmax, est interdite
                et constituerait une contrefaçon sanctionnée par le Code de la propriété intellectuelle.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Protection des données personnelles</h2>
              <p className="text-gray-600">
                Les informations collectées sur le site font l'objet d'un traitement informatique
                destiné à la gestion de la relation client et aux opérations promotionnelles.
                Conformément à la loi "Informatique et Libertés" du 6 janvier 1978 modifiée et au
                Règlement Général sur la Protection des Données (RGPD), vous disposez d'un droit
                d'accès, de rectification, et d'opposition aux données vous concernant.
              </p>
              <p className="mt-4 text-gray-600">
                Pour plus d'informations sur la gestion de vos données personnelles, veuillez consulter notre{' '}
                <Link to="/confidentialite" className="text-purple-600 hover:text-purple-700">
                  Politique de confidentialité
                </Link>
                .
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">5. Cookies</h2>
              <p className="text-gray-600">
                Le site utilise des cookies pour améliorer l'expérience utilisateur. En naviguant
                sur le site, vous acceptez l'utilisation de cookies conformément à notre politique
                de cookies.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">6. Limitation de responsabilité</h2>
              <p className="text-gray-600">
                Influmax s'efforce d'assurer au mieux de ses possibilités l'exactitude et la mise
                à jour des informations diffusées sur le site. Toutefois, Influmax ne peut garantir
                l'exactitude, la précision ou l'exhaustivité des informations mises à disposition
                sur le site.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">7. Droit applicable</h2>
              <p className="text-gray-600">
                Les présentes mentions légales sont soumises au droit français. En cas de litige,
                les tribunaux français seront seuls compétents.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">8. Contact</h2>
              <p className="text-gray-600">
                Pour toute question concernant ces mentions légales, vous pouvez nous contacter à
                l'adresse suivante : contact@influmax.fr
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">9. Modification des mentions légales</h2>
              <p className="text-gray-600">
                Influmax se réserve le droit de modifier les présentes mentions légales à tout
                moment. Les utilisateurs du site sont donc invités à les consulter régulièrement.
              </p>
              <p className="mt-4 text-sm text-gray-500">
                Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}
              </p>
            </section>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default MentionsLegales;