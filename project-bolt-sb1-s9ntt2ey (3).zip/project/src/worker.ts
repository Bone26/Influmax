export interface Env {
  JAP_API_KEY: string;
  ENVIRONMENT: string;
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    };

    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: corsHeaders,
      });
    }

    // Only allow POST
    if (request.method !== 'POST') {
      return new Response(JSON.stringify({ error: 'Method not allowed' }), {
        status: 405,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      });
    }

    try {
      // Parse request body
      const body = await request.json();
      
      // Add API key
      const data = new URLSearchParams({
        key: env.JAP_API_KEY,
        ...body
      });

      // Log request in development
      if (env.ENVIRONMENT === 'development') {
        console.log('📤 Request:', {
          ...body,
          key: '[REDACTED]'
        });
      }

      // Make request to JAP API with retry logic
      let retries = 3;
      let lastError;

      while (retries > 0) {
        try {
          const response = await fetch('https://justanotherpanel.com/api/v2', {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/x-www-form-urlencoded',
              'Cache-Control': 'no-cache',
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
              'Connection': 'keep-alive',
              'Keep-Alive': 'timeout=60, max=100'
            },
            body: data.toString()
          });

          // Check for Cloudflare errors
          if (response.status === 530 || response.status === 403) {
            throw new Error('Cloudflare protection triggered');
          }

          const responseData = await response.json();

          // Log response in development
          if (env.ENVIRONMENT === 'development') {
            console.log('📥 Response:', responseData);
          }

          // Return response
          return new Response(JSON.stringify(responseData), {
            status: response.status,
            headers: {
              'Content-Type': 'application/json',
              ...corsHeaders,
            },
          });
        } catch (error) {
          lastError = error;
          retries--;
          
          if (retries > 0) {
            // Wait before retrying (exponential backoff)
            await new Promise(resolve => setTimeout(resolve, (3 - retries) * 1000));
            continue;
          }
          throw error;
        }
      }

      throw lastError;
    } catch (error) {
      console.error('❌ Error:', error);
      
      return new Response(
        JSON.stringify({
          error: 'Internal Server Error',
          message: error instanceof Error ? error.message : 'Unknown error'
        }),
        {
          status: 500,
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders,
          },
        }
      );
    }
  },
};