export interface Commission {
  id: string;
  userId: string;           // ID de l'affilié qui reçoit la commission
  fromUserId: string;       // ID du filleul qui a généré la commission
  amount: number;           // Montant de la commission
  type: 'deposit';          // Type de commission (pour évolution future)
  status: 'pending' | 'processing' | 'completed' | 'cancelled';
  depositId: string;        // ID du dépôt qui a généré la commission
  withdrawalId?: string;    // ID du retrait associé
  createdAt: Date;
  processedAt?: Date;
}

export interface Withdrawal {
  id: string;
  userId: string;
  amount: number;
  status: 'pending' | 'processing' | 'completed' | 'rejected';
  bankDetails: {
    iban: string;
    bic: string;
    accountHolder: string;
  };
  commissionIds: string[];  // IDs des commissions incluses dans le retrait
  createdAt: Date;
  processedAt?: Date;
}