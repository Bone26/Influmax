export interface Reward {
  id: string;
  level: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond' | 'legend';
  name: string;
  description: string;
  imageUrl: string;
  unlockAmount: number;
  reward: string;
}

export interface RewardClaim {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  rewardLevel: Reward['level'];
  reward: string;
  status: 'pending' | 'approved' | 'rejected' | 'shipped';
  createdAt: Date;
  updatedAt: Date;
  shippingDetails?: {
    address: string;
    trackingNumber?: string;
  };
}