import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import { collection, doc, setDoc, getDocs, query, Timestamp, writeBatch } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { toast } from 'sonner';

interface InitializePricesProps {
  onSuccess: () => void;
}

const InitializePrices: React.FC<InitializePricesProps> = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false);

  const initializePrices = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir réinitialiser tous les prix ? Cette action est irréversible.')) {
      return;
    }

    setLoading(true);
    console.log('🚀 Initialisation des prix...');

    try {
      // Supprimer les anciens prix
      const batch = writeBatch(db);
      const oldPricesQuery = query(collection(db, 'servicePrices'));
      const oldPricesSnapshot = await getDocs(oldPricesQuery);
      console.log(`🗑️ Suppression de ${oldPricesSnapshot.size} anciens prix...`);
      
      oldPricesSnapshot.docs.forEach(doc => {
        batch.delete(doc.ref);
      });
      await batch.commit();

      // Définir les nouveaux prix avec mapping JAP
      const prices = [
        // Instagram Likes
        {
          platformId: 'instagram',
          serviceType: 'likes',
          quality: 'standard',
          basePrice: 0.002,
          deliveryLimits: {
            instant: { min: 100, max: 500000, isActive: true },
            '24h': { min: 150, max: 400000, isActive: true },
            '3days': { min: 200, max: 300000, isActive: true },
            '7days': { min: 500, max: 200000, isActive: true },
            '1month': { min: 1000, max: 100000, isActive: true }
          },
          japMapping: {
            japServiceId: '4343',
            japServiceName: 'Instagram Likes [Standard]',
            minQuantity: 10,
            maxQuantity: 500000,
            maxSpeed: 50000
          },
          isActive: true
        },
        {
          platformId: 'instagram',
          serviceType: 'likes',
          quality: 'premium',
          basePrice: 0.0375,
          deliveryLimits: {
            instant: { min: 50, max: 15000, isActive: true },
            '24h': { min: 100, max: 10000, isActive: true },
            '3days': { min: 200, max: 7500, isActive: true },
            '7days': { min: 500, max: 5000, isActive: true },
            '1month': { min: 1000, max: 2500, isActive: false }
          },
          japMapping: {
            japServiceId: '6073',
            japServiceName: 'Instagram Likes [Premium]',
            minQuantity: 50,
            maxQuantity: 15000,
            maxSpeed: 20000
          },
          isActive: true
        },
        {
          platformId: 'instagram',
          serviceType: 'likes',
          quality: 'vip',
          basePrice: 0.1,
          deliveryLimits: {
            instant: { min: 25, max: 1000, isActive: true },
            '24h': { min: 50, max: 750, isActive: true },
            '3days': { min: 100, max: 500, isActive: true },
            '7days': { min: 250, max: 250, isActive: false },
            '1month': { min: 500, max: 100, isActive: false }
          },
          japMapping: {
            japServiceId: '9346',
            japServiceName: 'Instagram Likes [VIP]',
            minQuantity: 25,
            maxQuantity: 1000,
            maxSpeed: 10000
          },
          isActive: true
        },

        // Instagram Followers
        {
          platformId: 'instagram',
          serviceType: 'followers',
          quality: 'standard',
          basePrice: 0.005,
          deliveryLimits: {
            instant: { min: 100, max: 200000, isActive: true },
            '24h': { min: 150, max: 150000, isActive: true },
            '3days': { min: 200, max: 100000, isActive: true },
            '7days': { min: 500, max: 50000, isActive: true },
            '1month': { min: 1000, max: 20000, isActive: true }
          },
          japMapping: {
            japServiceId: '9566',
            japServiceName: 'Instagram Followers [Standard]',
            minQuantity: 10,
            maxQuantity: 200000,
            maxSpeed: 50000
          },
          isActive: true
        },
        {
          platformId: 'instagram',
          serviceType: 'followers',
          quality: 'premium',
          basePrice: 0.06,
          deliveryLimits: {
            instant: { min: 50, max: 10000, isActive: true },
            '24h': { min: 100, max: 7500, isActive: true },
            '3days': { min: 200, max: 5000, isActive: true },
            '7days': { min: 500, max: 2500, isActive: true },
            '1month': { min: 1000, max: 1000, isActive: false }
          },
          japMapping: {
            japServiceId: '6074',
            japServiceName: 'Instagram Followers [Premium]',
            minQuantity: 50,
            maxQuantity: 10000,
            maxSpeed: 20000
          },
          isActive: true
        },
        {
          platformId: 'instagram',
          serviceType: 'followers',
          quality: 'vip',
          basePrice: 0.1,
          deliveryLimits: {
            instant: { min: 25, max: 1000, isActive: true },
            '24h': { min: 50, max: 750, isActive: true },
            '3days': { min: 100, max: 500, isActive: true },
            '7days': { min: 250, max: 250, isActive: false },
            '1month': { min: 500, max: 100, isActive: false }
          },
          japMapping: {
            japServiceId: '9345',
            japServiceName: 'Instagram Followers [VIP]',
            minQuantity: 25,
            maxQuantity: 1000,
            maxSpeed: 10000
          },
          isActive: true
        },

        // Instagram Views
        {
          platformId: 'instagram',
          serviceType: 'views',
          quality: 'standard',
          basePrice: 0.0005,
          deliveryLimits: {
            instant: { min: 100, max: 100000000, isActive: true },
            '24h': { min: 200, max: 50000000, isActive: true },
            '3days': { min: 500, max: 20000000, isActive: true },
            '7days': { min: 1000, max: 10000000, isActive: true },
            '1month': { min: 2000, max: 5000000, isActive: true }
          },
          japMapping: {
            japServiceId: '3528',
            japServiceName: 'Instagram Views [Standard]',
            minQuantity: 100,
            maxQuantity: 100000000,
            maxSpeed: 10000000
          },
          isActive: true
        },
        {
          platformId: 'instagram',
          serviceType: 'views',
          quality: 'vip',
          basePrice: 0.0025,
          deliveryLimits: {
            instant: { min: 100, max: 100000000, isActive: true },
            '24h': { min: 200, max: 50000000, isActive: true },
            '3days': { min: 500, max: 20000000, isActive: true },
            '7days': { min: 1000, max: 10000000, isActive: true },
            '1month': { min: 2000, max: 5000000, isActive: true }
          },
          japMapping: {
            japServiceId: '3528',
            japServiceName: 'Instagram Views [VIP]',
            minQuantity: 100,
            maxQuantity: 100000000,
            maxSpeed: 10000000
          },
          isActive: true
        },

        // TikTok Likes
        {
          platformId: 'tiktok',
          serviceType: 'likes',
          quality: 'standard',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 100, max: 100000, isActive: true },
            '24h': { min: 150, max: 75000, isActive: true },
            '3days': { min: 200, max: 50000, isActive: true },
            '7days': { min: 500, max: 25000, isActive: true },
            '1month': { min: 1000, max: 10000, isActive: true }
          },
          japMapping: {
            japServiceId: '9297',
            japServiceName: 'TikTok Likes [Standard]',
            minQuantity: 10,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          isActive: true
        },
        {
          platformId: 'tiktok',
          serviceType: 'likes',
          quality: 'premium',
          basePrice: 0.01,
          deliveryLimits: {
            instant: { min: 25, max: 2500, isActive: true },
            '24h': { min: 50, max: 2000, isActive: true },
            '3days': { min: 100, max: 1500, isActive: true },
            '7days': { min: 250, max: 1000, isActive: false },
            '1month': { min: 500, max: 500, isActive: false }
          },
          japMapping: {
            japServiceId: '9367',
            japServiceName: 'TikTok Likes [Premium]',
            minQuantity: 25,
            maxQuantity: 2500,
            maxSpeed: 10000
          },
          isActive: true
        },

        // TikTok Followers
        {
          platformId: 'tiktok',
          serviceType: 'followers',
          quality: 'standard',
          basePrice: 0.006,
          deliveryLimits: {
            instant: { min: 100, max: 100000, isActive: true },
            '24h': { min: 150, max: 75000, isActive: true },
            '3days': { min: 200, max: 50000, isActive: true },
            '7days': { min: 500, max: 25000, isActive: true },
            '1month': { min: 1000, max: 10000, isActive: true }
          },
          japMapping: {
            japServiceId: '8548',
            japServiceName: 'TikTok Followers [Standard]',
            minQuantity: 10,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          isActive: true
        },
        {
          platformId: 'tiktok',
          serviceType: 'followers',
          quality: 'premium',
          basePrice: 0.009,
          deliveryLimits: {
            instant: { min: 25, max: 2500, isActive: true },
            '24h': { min: 50, max: 2000, isActive: true },
            '3days': { min: 100, max: 1500, isActive: true },
            '7days': { min: 250, max: 1000, isActive: false },
            '1month': { min: 500, max: 500, isActive: false }
          },
          japMapping: {
            japServiceId: '8728',
            japServiceName: 'TikTok Followers [Premium]',
            minQuantity: 25,
            maxQuantity: 2500,
            maxSpeed: 10000
          },
          isActive: true
        },

        // TikTok Views
        {
          platformId: 'tiktok',
          serviceType: 'views',
          quality: 'standard',
          basePrice: 0.00002,
          deliveryLimits: {
            instant: { min: 50, max: 30000000, isActive: true },
            '24h': { min: 100, max: 20000000, isActive: true },
            '3days': { min: 250, max: 10000000, isActive: true },
            '7days': { min: 500, max: 5000000, isActive: true },
            '1month': { min: 1000, max: 1000000, isActive: true }
          },
          japMapping: {
            japServiceId: '2260',
            japServiceName: 'TikTok Views [Standard]',
            minQuantity: 50,
            maxQuantity: 30000000,
            maxSpeed: 5000000
          },
          isActive: true
        },
        {
          platformId: 'tiktok',
          serviceType: 'views',
          quality: 'vip',
          basePrice: 0.0001,
          deliveryLimits: {
            instant: { min: 50, max: 30000000, isActive: true },
            '24h': { min: 100, max: 20000000, isActive: true },
            '3days': { min: 250, max: 10000000, isActive: true },
            '7days': { min: 500, max: 5000000, isActive: true },
            '1month': { min: 1000, max: 1000000, isActive: true }
          },
          japMapping: {
            japServiceId: '2260',
            japServiceName: 'TikTok Views [VIP]',
            minQuantity: 50,
            maxQuantity: 30000000,
            maxSpeed: 5000000
          },
          isActive: true
        },

        // TikTok Saves & Shares
        {
          platformId: 'tiktok',
          serviceType: 'saves',
          quality: 'standard',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 50, max: 100000, isActive: true },
            '24h': { min: 100, max: 75000, isActive: true },
            '3days': { min: 250, max: 50000, isActive: true },
            '7days': { min: 500, max: 25000, isActive: true },
            '1month': { min: 1000, max: 10000, isActive: true }
          },
          japMapping: {
            japServiceId: '54',
            japServiceName: 'TikTok Saves [Standard]',
            minQuantity: 50,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          isActive: true
        },
        {
          platformId: 'tiktok',
          serviceType: 'shares',
          quality: 'standard',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 100, max: 2000000, isActive: true },
            '24h': { min: 200, max: 1500000, isActive: true },
            '3days': { min: 500, max: 1000000, isActive: true },
            '7days': { min: 1000, max: 500000, isActive: true },
            '1month': { min: 2000, max: 200000, isActive: true }
          },
          japMapping: {
            japServiceId: '8105',
            japServiceName: 'TikTok Shares [Standard]',
            minQuantity: 10,
            maxQuantity: 2000000,
            maxSpeed: 500000
          },
          isActive: true
        },

        // Telegram Services
        {
          platformId: 'telegram',
          serviceType: 'members',
          quality: 'standard',
          basePrice: 0.01,
          deliveryLimits: {
            instant: { min: 500, max: 10000, isActive: true },
            '24h': { min: 750, max: 7500, isActive: true },
            '3days': { min: 1000, max: 5000, isActive: true },
            '7days': { min: 2500, max: 2500, isActive: true },
            '1month': { min: 5000, max: 1000, isActive: false }
          },
          japMapping: {
            japServiceId: '363',
            japServiceName: 'Telegram Channel Members [Public]',
            minQuantity: 500,
            maxQuantity: 10000,
            maxSpeed: 5000
          },
          isActive: true
        },
        {
          platformId: 'telegram',
          serviceType: 'reactions',
          quality: 'standard',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 500, max: 100000, isActive: true },
            '24h': { min: 1000, max: 75000, isActive: true },
            '3days': { min: 2000, max: 50000, isActive: true },
            '7days': { min: 5000, max: 25000, isActive: true },
            '1month': { min: 10000, max: 10000, isActive: true }
          },
          japMapping: {
            japServiceId: '364',
            japServiceName: 'Telegram Post Reactions',
            minQuantity: 100,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          isActive: true
        },
        {
          platformId: 'telegram',
          serviceType: 'views',
          quality: 'standard',
          basePrice: 0.0005,
          deliveryLimits: {
            instant: { min: 100, max: 100000, isActive: true },
            '24h': { min: 200, max: 75000, isActive: true },
            '3days': { min: 500, max: 50000, isActive: true },
            '7days': { min: 1000, max: 25000, isActive: true },
            '1month': { min: 2000, max: 10000, isActive: true }
          },
          japMapping: {
            japServiceId: '365',
            japServiceName: 'Telegram Post Views',
            minQuantity: 100,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          isActive: true
        },
        {
          platformId: 'telegram',
          serviceType: 'votes',
          quality: 'standard',
          basePrice: 0.003,
          deliveryLimits: {
            instant: { min: 100, max: 300000, isActive: true },
            '24h': { min: 200, max: 200000, isActive: true },
            '3days': { min: 500, max: 100000, isActive: true },
            '7days': { min: 1000, max: 50000, isActive: true },
            '1month': { min: 2000, max: 20000, isActive: false }
          },
          japMapping: {
            japServiceId: '366',
            japServiceName: 'Telegram Poll Votes',
            minQuantity: 100,
            maxQuantity: 300000,
            maxSpeed: 100000
          },
          isActive: true
        }
      ];

      // Créer les nouveaux prix
      for (const price of prices) {
        try {
          const priceRef = doc(collection(db, 'servicePrices'));
          const now = new Date();
          
          await setDoc(priceRef, {
            id: priceRef.id,
            ...price,
            updatedAt: Timestamp.fromDate(now),
            updatedBy: 'system'
          });
          
          console.log(`✅ Prix créé pour ${price.platformId} - ${price.serviceType} (${price.quality})`);
          await new Promise(resolve => setTimeout(resolve, 500)); // Attendre un peu entre chaque création
        } catch (error) {
          console.error(`❌ Erreur lors de la création du prix pour ${price.platformId} - ${price.serviceType} (${price.quality}):`, error);
        }
      }

      console.log('✨ Initialisation des prix terminée avec succès !');
      toast.success('Prix initialisés avec succès');
      onSuccess();
    } catch (error) {
      console.error('❌ Erreur lors de l\'initialisation des prix:', error);
      toast.error('Erreur lors de l\'initialisation des prix');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-6 right-6"
    >
      <button
        onClick={initializePrices}
        disabled={loading}
        className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-3 rounded-xl shadow-lg hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 transition-all duration-300"
      >
        {loading ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Initialisation...</span>
          </>
        ) : (
          <>
            <span>Initialiser les prix</span>
          </>
        )}
      </button>
    </motion.div>
  );
};

export default InitializePrices;