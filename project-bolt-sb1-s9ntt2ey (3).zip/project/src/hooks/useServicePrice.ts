import { useState, useEffect } from 'react';
import { SimulatorFormData } from '../types/simulator';
import { Service } from '../types/service';
import { servicesCache } from '../utils/servicesCache';

export const useServicePrice = (formData: SimulatorFormData) => {
  const [price, setPrice] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [service, setService] = useState<Service | null>(null);

  useEffect(() => {
    const calculatePrice = () => {
      try {
        // Convertir la quantité en nombre
        const quantity = typeof formData.quantity === 'string' ? 
          parseInt(formData.quantity, 10) : formData.quantity;

        // Vérifier si on a une quantité valide
        if (isNaN(quantity) || quantity <= 0) {
          setPrice(0);
          return;
        }

        // Récupérer le service depuis le cache
        const cachedServices = servicesCache.get(formData.platform.toLowerCase());
        if (!cachedServices) {
          setError('Service non disponible');
          setPrice(0);
          return;
        }

        const serviceData = cachedServices.data.find(s => s.type === formData.service);
        if (!serviceData) {
          setError('Service non disponible');
          setPrice(0);
          return;
        }

        setService(serviceData);

        // Vérifier les limites de quantité
        if (quantity < serviceData.minQuantity) {
          setError(`Minimum ${serviceData.minQuantity.toLocaleString()}`);
          setPrice(0);
          return;
        }

        if (quantity > serviceData.maxQuantity) {
          setError(`Maximum ${serviceData.maxQuantity.toLocaleString()}`);
          setPrice(0);
          return;
        }

        // Vérifier la qualité
        const quality = serviceData.qualities.find(q => q.type === formData.quality);
        if (!quality) {
          setError('Qualité non disponible');
          setPrice(0);
          return;
        }

        if (!quality.isAvailable) {
          setError(`La qualité ${formData.quality} n'est pas disponible`);
          setPrice(0);
          return;
        }

        // Vérifier le temps de livraison
        const deliveryTime = serviceData.deliveryTimes.find(t => t.type === formData.deliveryTime);
        if (!deliveryTime) {
          setError('Temps de livraison non disponible');
          setPrice(0);
          return;
        }

        if (!deliveryTime.isAvailable) {
          setError(`Le temps de livraison ${formData.deliveryTime} n'est pas disponible`);
          setPrice(0);
          return;
        }

        // Calculer le prix
        const basePrice = quantity * serviceData.basePrice;
        const qualityMultiplier = quality.multiplier;
        const deliveryMultiplier = deliveryTime.multiplier;
        
        const finalPrice = basePrice * qualityMultiplier * deliveryMultiplier;
        const roundedPrice = Math.round(finalPrice * 100) / 100;

        setPrice(roundedPrice);
        setError(null);

      } catch (error) {
        console.error('Erreur lors du calcul du prix:', error);
        setError('Erreur lors du calcul du prix');
        setPrice(0);
      }
    };

    calculatePrice();
  }, [formData]);

  return { price, error, service };
};

export default useServicePrice;