import { collection, doc, getDoc, getDocs, query, where, Timestamp, runTransaction, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Commission, CommissionWithdrawal } from '../types/affiliate';

export const createCommission = async (
  userId: string,
  fromUserId: string,
  depositId: string,
  amount: number,
  level: 1 | 2
): Promise<Commission> => {
  try {
    return await runTransaction(db, async (transaction) => {
      // Créer la commission
      const commissionRef = doc(collection(db, 'commissions'));
      const now = new Date();
      
      const commission: Commission = {
        id: commissionRef.id,
        userId,
        fromUserId,
        depositId,
        amount,
        level,
        status: 'pending',
        createdAt: now
      };

      transaction.set(commissionRef, {
        ...commission,
        createdAt: Timestamp.fromDate(now)
      });

      // Mettre à jour les stats de l'utilisateur
      const userRef = doc(db, 'users', userId);
      transaction.update(userRef, {
        'affiliate.stats.totalEarnings': increment(amount),
        'affiliate.stats.pendingEarnings': increment(amount),
        updatedAt: Timestamp.now()
      });

      return commission;
    });
  } catch (error) {
    console.error('Error creating commission:', error);
    throw error;
  }
};

export const getUserCommissions = async (userId: string): Promise<Commission[]> => {
  try {
    const q = query(
      collection(db, 'commissions'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate(),
      processedAt: doc.data().processedAt?.toDate()
    })) as Commission[];
  } catch (error) {
    console.error('Error getting user commissions:', error);
    throw error;
  }
};

export const createWithdrawalRequest = async (
  userId: string,
  amount: number,
  bankDetails: CommissionWithdrawal['bankDetails']
): Promise<CommissionWithdrawal> => {
  if (amount < 50) {
    throw new Error('Le montant minimum de retrait est de 50€');
  }

  try {
    return await runTransaction(db, async (transaction) => {
      // Vérifier le solde disponible
      const userRef = doc(db, 'users', userId);
      const userDoc = await transaction.get(userRef);
      
      if (!userDoc.exists()) {
        throw new Error('User not found');
      }

      const userData = userDoc.data();
      if (userData.affiliate.stats.pendingEarnings < amount) {
        throw new Error('Montant insuffisant');
      }

      // Récupérer les commissions en attente
      const commissionsQuery = query(
        collection(db, 'commissions'),
        where('userId', '==', userId),
        where('status', '==', 'pending'),
        orderBy('createdAt', 'asc')
      );
      const commissionsSnapshot = await transaction.get(commissionsQuery);

      let remainingAmount = amount;
      const selectedCommissions: string[] = [];

      for (const doc of commissionsSnapshot.docs) {
        if (remainingAmount <= 0) break;
        
        const commission = doc.data();
        selectedCommissions.push(doc.id);
        remainingAmount -= commission.amount;

        // Mettre à jour le statut de la commission
        transaction.update(doc.ref, {
          status: 'processing',
          updatedAt: Timestamp.now()
        });
      }

      // Créer la demande de retrait
      const withdrawalRef = doc(collection(db, 'commissionWithdrawals'));
      const now = new Date();
      
      const withdrawal: CommissionWithdrawal = {
        id: withdrawalRef.id,
        userId,
        amount,
        bankDetails,
        status: 'pending',
        commissionIds: selectedCommissions,
        createdAt: now
      };

      transaction.set(withdrawalRef, {
        ...withdrawal,
        createdAt: Timestamp.fromDate(now)
      });

      // Mettre à jour les stats de l'utilisateur
      transaction.update(userRef, {
        'affiliate.stats.pendingEarnings': increment(-amount),
        updatedAt: Timestamp.now()
      });

      return withdrawal;
    });
  } catch (error) {
    console.error('Error creating withdrawal request:', error);
    throw error;
  }
};