import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ShoppingCart, Lock, Wallet, Send } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { getWalletBalance } from '../../services/wallet';
import { createOrder } from '../../services/orders';
import { SimulatorPaymentData } from '../../types/simulator';
import { toast } from 'sonner';
import LinkInputModal from './LinkInputModal';

interface PaymentButtonProps {
  price: number;
  isValid: boolean;
  formData: SimulatorPaymentData;
}

const PaymentButton: React.FC<PaymentButtonProps> = ({ price, isValid, formData }) => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false); // Nouvel état pour éviter les doubles soumissions

  React.useEffect(() => {
    if (currentUser) {
      loadWalletBalance();
    }
  }, [currentUser]);

  const loadWalletBalance = async () => {
    try {
      const wallet = await getWalletBalance(currentUser!.id);
      setWalletBalance(wallet.balance);
    } catch (error) {
      console.error('Error loading wallet balance:', error);
    }
  };

  const handlePayment = async () => {
    if (!currentUser) {
      navigate('/auth/login');
      return;
    }

    if (typeof formData.quantity !== 'number' || formData.quantity <= 0) {
      toast.error('Quantité invalide');
      return;
    }

    setShowLinkModal(true);
  };

  const handleSubmitOrder = async (link: string) => {
    if (!currentUser || typeof formData.quantity !== 'number' || isSubmitting) {
      return;
    }

    setIsSubmitting(true); // Empêcher les soumissions multiples
    setLoading(true);
    setError(null);

    try {
      // Vérifier le solde
      const wallet = await getWalletBalance(currentUser.id);
      if (wallet.balance < price) {
        setError(`Solde insuffisant. Il vous manque ${(price - wallet.balance).toFixed(2)}€`);
        return;
      }

      console.log('Creating order with data:', {
        ...formData,
        link,
        price,
        userId: currentUser.id
      });

      // Créer la commande
      await createOrder(currentUser.id, {
        service: {
          platform: formData.platform,
          type: formData.service,
          quality: formData.quality
        },
        link,
        quantity: formData.quantity,
        price,
        selectedEmojis: formData.selectedEmojis,
        deliveryTime: formData.deliveryTime
      });

      // Rediriger vers les commandes
      navigate('/orders');
      toast.success('Commande créée avec succès');
    } catch (error) {
      console.error('Error processing order:', error);
      if (error instanceof Error) {
        setError(error.message);
        toast.error(error.message);
      } else {
        setError('Une erreur est survenue lors de la commande');
        toast.error('Une erreur est survenue lors de la commande');
      }
    } finally {
      setLoading(false);
      setShowLinkModal(false);
      setIsSubmitting(false); // Réinitialiser l'état de soumission
    }
  };

  const insufficientFunds = currentUser && walletBalance < price;

  return (
    <div>
      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm"
        >
          {error}
        </motion.div>
      )}

      {insufficientFunds ? (
        <div className="space-y-4">
          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              Solde insuffisant. Il vous manque {(price - walletBalance).toFixed(2)}€
            </p>
          </div>
          <button
            onClick={() => navigate('/wallet')}
            className="w-full bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors"
          >
            Recharger mon compte
          </button>
        </div>
      ) : (
        <motion.button
          onClick={handlePayment}
          disabled={!isValid || loading || price === 0 || isSubmitting}
          className={`
            w-full flex items-center justify-center gap-2 py-4 px-6 rounded-xl font-semibold
            transition-all duration-300 transform hover:scale-105
            ${isValid && price > 0
              ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-700 hover:to-indigo-700'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }
          `}
        >
          {loading ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
              Traitement en cours...
            </>
          ) : currentUser ? (
            <>
              <Wallet className="h-5 w-5" />
              Payer avec mon solde ({price.toFixed(2)}€)
            </>
          ) : (
            <>
              <ShoppingCart className="h-5 w-5" />
              Commander maintenant pour {price.toFixed(2)}€
            </>
          )}
        </motion.button>
      )}

      <p className="text-center text-sm text-gray-500 mt-2">
        Paiement sécurisé • Livraison garantie • Support 24/7
      </p>

      <LinkInputModal
        isOpen={showLinkModal}
        onClose={() => {
          setShowLinkModal(false);
          setIsSubmitting(false); // Réinitialiser l'état en cas de fermeture
        }}
        onSubmit={handleSubmitOrder}
        platform={formData.platform}
        service={formData.service}
      />
    </div>
  );
};

export default PaymentButton;