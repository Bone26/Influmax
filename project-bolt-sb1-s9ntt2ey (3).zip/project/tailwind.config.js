/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      animation: {
        'gradient': 'gradient 8s linear infinite',
        'blob': 'blob 7s infinite',
        'float-slow': 'float-slow 3s ease-in-out infinite'
      },
      backgroundSize: {
        '300%': '300% 300%'
      }
    }
  },
  plugins: []
};