import React from 'react';
import { motion } from 'framer-motion';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface FeatureProps {
  icon: LucideIcon;
  title: string;
  description: string;
  gradient: string;
  glowColor: string;
  index?: number;
}

const Feature: React.FC<FeatureProps> = ({ 
  icon: Icon, 
  title, 
  description, 
  gradient,
  glowColor,
  index = 0 
}) => {
  const getGlowStyle = (color: string) => {
    switch (color) {
      case 'pink':
        return 'from-pink-400/40 to-rose-400/40';
      case 'blue':
        return 'from-blue-400/40 to-cyan-400/40';
      case 'purple':
        return 'from-purple-400/40 to-indigo-400/40';
      case 'green':
        return 'from-green-400/40 to-emerald-400/40';
      default:
        return 'from-purple-400/40 to-indigo-400/40';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      className="relative group"
    >
      {/* Glow effect */}
      <div className={`absolute -inset-0.5 bg-gradient-to-r ${getGlowStyle(glowColor)} rounded-2xl blur opacity-0 group-hover:opacity-100 transition duration-500`}></div>
      
      {/* Card content */}
      <div className="relative bg-white rounded-2xl shadow-xl p-8 text-center transform transition-all duration-500 hover:-translate-y-2">
        {/* Icon container with gradient background */}
        <div className="mb-8 relative mx-auto w-20 h-20">
          {/* Glow behind icon */}
          <div className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-20 blur-2xl rounded-full`}></div>
          
          {/* Icon background */}
          <div className={`relative bg-gradient-to-br ${gradient} w-20 h-20 rounded-2xl flex items-center justify-center transform transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3 mx-auto`}>
            <Icon className="h-10 w-10 text-white" />
          </div>

          {/* Animated particles */}
          <div className="absolute inset-0">
            <div className={`absolute top-0 left-1/2 w-2 h-2 rounded-full bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-60 transition-all duration-1000 delay-100 animate-float-slow`}></div>
            <div className={`absolute bottom-0 right-1/2 w-2 h-2 rounded-full bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-60 transition-all duration-1000 delay-300 animate-float-slow`}></div>
            <div className={`absolute top-1/2 right-0 w-2 h-2 rounded-full bg-gradient-to-br ${gradient} opacity-0 group-hover:opacity-60 transition-all duration-1000 delay-500 animate-float-slow`}></div>
          </div>
        </div>

        {/* Text content */}
        <h3 className={`text-2xl font-bold mb-4 bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}>
          {title}
        </h3>
        <p className="text-gray-600 leading-relaxed">
          {description}
        </p>

        {/* Decorative elements */}
        <div className={`absolute top-4 right-4 w-24 h-24 bg-gradient-to-br ${gradient} opacity-5 rounded-full blur-xl transform rotate-45`}></div>
        <div className={`absolute bottom-4 left-4 w-20 h-20 bg-gradient-to-br ${gradient} opacity-5 rounded-full blur-lg transform -rotate-45`}></div>
        
        {/* Bottom gradient line */}
        <div className="absolute bottom-0 left-0 right-0 h-1">
          <div className={`absolute inset-0 bg-gradient-to-r ${gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-b-2xl`}></div>
        </div>
      </div>
    </motion.div>
  );
};

export default Feature;