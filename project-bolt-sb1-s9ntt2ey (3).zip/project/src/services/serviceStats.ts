import { 
  collection, 
  query, 
  where, 
  getDocs, 
  Timestamp,
  startOfDay,
  endOfDay,
  orderBy,
  limit 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { subDays, format } from 'date-fns';

interface ServiceStats {
  totalOrders: number;
  totalRevenue: number;
  averageOrderValue: number;
  successRate: number;
  averageDeliveryTime: number;
  dailyStats: Array<{
    date: string;
    orders: number;
    revenue: number;
  }>;
  qualityDistribution: {
    standard: number;
    premium: number;
    vip: number;
  };
  deliveryTimeDistribution: {
    instant: number;
    '24h': number;
    '3days': number;
    '7days': number;
    '1month': number;
  };
}

export const getServiceStats = async (serviceId: string, days: number = 30): Promise<ServiceStats> => {
  try {
    const endDate = new Date();
    const startDate = subDays(endDate, days);

    // Récupérer toutes les commandes pour ce service
    const ordersQuery = query(
      collection(db, 'orders'),
      where('service.id', '==', serviceId),
      where('timestamps.createdAt', '>=', Timestamp.fromDate(startDate)),
      where('timestamps.createdAt', '<=', Timestamp.fromDate(endDate)),
      orderBy('timestamps.createdAt', 'desc')
    );

    const ordersSnapshot = await getDocs(ordersQuery);
    const orders = ordersSnapshot.docs.map(doc => ({
      ...doc.data(),
      timestamps: {
        createdAt: doc.data().timestamps.createdAt.toDate(),
        updatedAt: doc.data().timestamps.updatedAt.toDate(),
        startedAt: doc.data().timestamps.startedAt?.toDate(),
        completedAt: doc.data().timestamps.completedAt?.toDate()
      }
    }));

    // Calculer les statistiques globales
    const totalOrders = orders.length;
    const totalRevenue = orders.reduce((sum, order) => sum + order.price, 0);
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    
    const completedOrders = orders.filter(order => order.status === 'completed');
    const successRate = totalOrders > 0 ? completedOrders.length / totalOrders : 0;

    // Calculer le temps moyen de livraison
    const deliveryTimes = completedOrders
      .filter(order => order.timestamps.completedAt && order.timestamps.startedAt)
      .map(order => {
        const start = order.timestamps.startedAt;
        const end = order.timestamps.completedAt;
        return (end.getTime() - start.getTime()) / (1000 * 60 * 60); // en heures
      });
    const averageDeliveryTime = deliveryTimes.length > 0
      ? deliveryTimes.reduce((sum, time) => sum + time, 0) / deliveryTimes.length
      : 0;

    // Préparer les statistiques journalières
    const dailyStats: { [key: string]: { orders: number; revenue: number } } = {};
    for (let i = 0; i < days; i++) {
      const date = format(subDays(endDate, i), 'yyyy-MM-dd');
      dailyStats[date] = { orders: 0, revenue: 0 };
    }

    // Remplir les statistiques journalières
    orders.forEach(order => {
      const date = format(order.timestamps.createdAt, 'yyyy-MM-dd');
      if (dailyStats[date]) {
        dailyStats[date].orders++;
        dailyStats[date].revenue += order.price;
      }
    });

    // Calculer la distribution des qualités
    const qualityCount = {
      standard: 0,
      premium: 0,
      vip: 0
    };
    orders.forEach(order => {
      if (qualityCount[order.service.quality]) {
        qualityCount[order.service.quality]++;
      }
    });

    const qualityDistribution = {
      standard: totalOrders > 0 ? qualityCount.standard / totalOrders : 0,
      premium: totalOrders > 0 ? qualityCount.premium / totalOrders : 0,
      vip: totalOrders > 0 ? qualityCount.vip / totalOrders : 0
    };

    // Calculer la distribution des temps de livraison
    const deliveryTimeCount = {
      instant: 0,
      '24h': 0,
      '3days': 0,
      '7days': 0,
      '1month': 0
    };
    orders.forEach(order => {
      if (deliveryTimeCount[order.deliveryTime]) {
        deliveryTimeCount[order.deliveryTime]++;
      }
    });

    const deliveryTimeDistribution = {
      instant: totalOrders > 0 ? deliveryTimeCount.instant / totalOrders : 0,
      '24h': totalOrders > 0 ? deliveryTimeCount['24h'] / totalOrders : 0,
      '3days': totalOrders > 0 ? deliveryTimeCount['3days'] / totalOrders : 0,
      '7days': totalOrders > 0 ? deliveryTimeCount['7days'] / totalOrders : 0,
      '1month': totalOrders > 0 ? deliveryTimeCount['1month'] / totalOrders : 0
    };

    return {
      totalOrders,
      totalRevenue,
      averageOrderValue,
      successRate,
      averageDeliveryTime,
      dailyStats: Object.entries(dailyStats).map(([date, stats]) => ({
        date,
        ...stats
      })),
      qualityDistribution,
      deliveryTimeDistribution
    };
  } catch (error) {
    console.error('Error getting service stats:', error);
    throw error;
  }
};