import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, getDocs, query, where, Timestamp, writeBatch } from 'firebase/firestore';

// Configuration Firebase
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.VITE_FIREBASE_APP_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const initializeJAPServices = async () => {
  try {
    console.log('🚀 Initialisation des services avec mapping JAP...');
    
    // Supprimer les anciens services
    const batch = writeBatch(db);
    const oldServicesQuery = query(collection(db, 'services'));
    const oldServicesSnapshot = await getDocs(oldServicesQuery);
    oldServicesSnapshot.docs.forEach(doc => {
      batch.delete(doc.ref);
    });
    await batch.commit();
    console.log('🗑️ Anciens services supprimés');

    // Définir les services avec leur mapping JAP
    const services = [
      // Instagram Services
      {
        name: 'Followers Instagram',
        platformId: 'instagram',
        type: 'followers',
        basePrice: 0.005,
        deliveryLimits: {
          instant: { min: 100, max: 200000, isActive: true },
          '24h': { min: 150, max: 150000, isActive: true },
          '3days': { min: 200, max: 100000, isActive: true },
          '7days': { min: 500, max: 50000, isActive: true },
          '1month': { min: 1000, max: 20000, isActive: true }
        },
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'premium', multiplier: 1.5, isAvailable: true },
          { type: 'vip', multiplier: 2, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        japMapping: {
          standard: {
            japServiceId: '4343',
            japServiceName: 'Instagram Followers [Refill: No] [Max: 300K] [Start Time: 0 - 1 Hr] [Speed: 50K/D]',
            minQuantity: 10,
            maxQuantity: 300000,
            maxSpeed: 50000
          },
          premium: {
            japServiceId: '4344',
            japServiceName: 'Instagram Followers Premium [Refill: 30 Days] [Max: 100K] [Start Time: 0 - 1 Hr] [Speed: 20K/D]',
            minQuantity: 10,
            maxQuantity: 100000,
            maxSpeed: 20000
          },
          vip: {
            japServiceId: '4345',
            japServiceName: 'Instagram Followers VIP [Refill: Lifetime] [Max: 50K] [Start Time: 0 - 1 Hr] [Speed: 10K/D]',
            minQuantity: 10,
            maxQuantity: 50000,
            maxSpeed: 10000
          }
        },
        isActive: true
      },
      {
        name: 'Likes Instagram',
        platformId: 'instagram',
        type: 'likes',
        basePrice: 0.002,
        deliveryLimits: {
          instant: { min: 100, max: 500000, isActive: true },
          '24h': { min: 150, max: 400000, isActive: true },
          '3days': { min: 200, max: 300000, isActive: true },
          '7days': { min: 500, max: 200000, isActive: true },
          '1month': { min: 1000, max: 100000, isActive: true }
        },
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'premium', multiplier: 1.5, isAvailable: true },
          { type: 'vip', multiplier: 2, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        japMapping: {
          standard: {
            japServiceId: '4346',
            japServiceName: 'Instagram Likes [Refill: No] [Max: 500K] [Start Time: 0 - 1 Hr] [Speed: 100K/D]',
            minQuantity: 10,
            maxQuantity: 500000,
            maxSpeed: 100000
          },
          premium: {
            japServiceId: '4347',
            japServiceName: 'Instagram Likes Premium [Refill: 30 Days] [Max: 200K] [Start Time: 0 - 1 Hr] [Speed: 50K/D]',
            minQuantity: 10,
            maxQuantity: 200000,
            maxSpeed: 50000
          },
          vip: {
            japServiceId: '4348',
            japServiceName: 'Instagram Likes VIP [Refill: Lifetime] [Max: 100K] [Start Time: 0 - 1 Hr] [Speed: 20K/D]',
            minQuantity: 10,
            maxQuantity: 100000,
            maxSpeed: 20000
          }
        },
        isActive: true
      },
      // Ajouter les autres services avec leur mapping JAP...
    ];

    // Créer les nouveaux services
    for (const service of services) {
      const serviceRef = doc(collection(db, 'services'));
      const now = new Date();
      
      await setDoc(serviceRef, {
        id: serviceRef.id,
        ...service,
        createdAt: Timestamp.fromDate(now),
        updatedAt: Timestamp.fromDate(now)
      });
      
      console.log(`✅ Service créé : ${service.name}`);
    }

    console.log('✨ Initialisation des services terminée avec succès !');
  } catch (error) {
    console.error('Error initializing services:', error);
    throw error;
  }
};

// Exécuter l'initialisation
initializeJAPServices().catch(console.error);