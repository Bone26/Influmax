import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Download, Check, X, AlertTriangle, Wallet } from 'lucide-react';
import WithdrawalList from '../../components/admin/WithdrawalList';
import WithdrawalStats from '../../components/admin/WithdrawalStats';
import { getWithdrawals, completeWithdrawal, rejectWithdrawal } from '../../services/admin';
import { Withdrawal } from '../../types/affiliate';
import { toast } from 'sonner';

const WithdrawalManagement = () => {
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  useEffect(() => {
    loadWithdrawals();
  }, []);

  const loadWithdrawals = async () => {
    try {
      setLoading(true);
      const data = await getWithdrawals();
      setWithdrawals(data);
    } catch (error) {
      console.error('Error loading withdrawals:', error);
      setError('Erreur lors du chargement des retraits');
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = async (withdrawalId: string) => {
    try {
      await completeWithdrawal(withdrawalId);
      await loadWithdrawals();
      toast.success('Retrait marqué comme terminé');
    } catch (error) {
      console.error('Error completing withdrawal:', error);
      toast.error('Erreur lors de la finalisation du retrait');
    }
  };

  const handleReject = async (withdrawalId: string) => {
    try {
      await rejectWithdrawal(withdrawalId);
      await loadWithdrawals();
      toast.success('Retrait rejeté avec succès');
    } catch (error) {
      console.error('Error rejecting withdrawal:', error);
      toast.error('Erreur lors du rejet du retrait');
    }
  };

  const handleExport = () => {
    try {
      const csvContent = [
        ['ID', 'Montant', 'IBAN', 'BIC', 'Titulaire', 'Statut', 'Date'].join(','),
        ...withdrawals.map(w => [
          w.id,
          w.amount.toFixed(2),
          w.bankDetails.iban,
          w.bankDetails.bic,
          w.bankDetails.accountHolder,
          w.status,
          w.createdAt.toISOString()
        ].join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `retraits-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting withdrawals:', error);
      toast.error('Erreur lors de l\'export');
    }
  };

  const filteredWithdrawals = selectedStatus === 'all'
    ? withdrawals
    : withdrawals.filter(w => w.status === selectedStatus);

  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link to="/admin" className="text-white/80 hover:text-white">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div>
                  <h1 className="text-2xl font-bold text-white">Gestion des retraits</h1>
                  <p className="text-purple-100 text-sm">
                    {filteredWithdrawals.length} retrait{filteredWithdrawals.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
              <button
                onClick={handleExport}
                className="flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
              >
                <Download className="h-5 w-5 mr-2" />
                Export CSV
              </button>
            </div>
          </div>

          <div className="p-6">
            {/* Stats */}
            <WithdrawalStats withdrawals={withdrawals} />

            {/* Filters */}
            <div className="my-6">
              <div className="flex flex-wrap gap-2">
                {[
                  { value: 'all', label: 'Tous' },
                  { value: 'pending', label: 'En attente' },
                  { value: 'completed', label: 'Terminés' },
                  { value: 'rejected', label: 'Rejetés' }
                ].map((status) => (
                  <button
                    key={status.value}
                    onClick={() => setSelectedStatus(status.value)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      selectedStatus === status.value
                        ? 'bg-purple-600 text-white'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {status.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Withdrawals List */}
            <WithdrawalList
              withdrawals={filteredWithdrawals}
              loading={loading}
              error={error}
              onComplete={handleComplete}
              onReject={handleReject}
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default WithdrawalManagement;