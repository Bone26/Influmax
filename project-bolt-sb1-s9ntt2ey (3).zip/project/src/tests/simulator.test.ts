import { describe, it, expect } from 'vitest';
import { calculatePrice } from '../utils/priceCalculator';

describe('Price Calculator', () => {
  it('should calculate basic price correctly', () => {
    const pricing = {
      minQuantity: 100,
      pricePerUnit: 0.01
    };

    const price = calculatePrice(1000, pricing, 'instant');
    expect(price).toBe(10);
  });

  it('should apply delivery time multiplier', () => {
    const pricing = {
      minQuantity: 100,
      pricePerUnit: 0.01
    };

    const price = calculatePrice(1000, pricing, '24h');
    expect(price).toBe(11); // 10 * 1.1
  });

  it('should handle base quantity pricing', () => {
    const pricing = {
      minQuantity: 1000,
      pricePerUnit: 0.001,
      baseQuantity: 1000
    };

    const price = calculatePrice(2500, pricing, 'instant');
    expect(price).toBe(3); // Rounds up to 3 blocks of 1000
  });

  it('should return 0 for invalid inputs', () => {
    const pricing = {
      minQuantity: 100,
      pricePerUnit: 0.01
    };

    expect(calculatePrice(0, pricing, 'instant')).toBe(0);
    expect(calculatePrice(-100, pricing, 'instant')).toBe(0);
    expect(calculatePrice(100, null, 'instant')).toBe(0);
  });
});