import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Gift, Check, X, AlertTriangle, Crown, Shield, Star } from 'lucide-react';
import { collection, query, where, getDocs, updateDoc, doc, Timestamp, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { toast } from 'sonner';
import TopUsersStats from '../../components/admin/TopUsersStats';
import { getTopEarningUsers } from '../../services/admin';

interface RewardClaim {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  rewardLevel: 'bronze' | 'silver' | 'gold';
  reward: string;
  status: 'pending' | 'approved' | 'rejected' | 'shipped';
  createdAt: Date;
  updatedAt: Date;
  shippingDetails?: {
    address: string;
    trackingNumber?: string;
  };
}

const RewardManagement = () => {
  const [claims, setClaims] = useState<RewardClaim[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedClaim, setSelectedClaim] = useState<RewardClaim | null>(null);
  const [topUsers, setTopUsers] = useState<any[]>([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        await Promise.all([
          loadClaims(),
          loadTopUsers()
        ]);
      } catch (error) {
        console.error('Error loading data:', error);
        setError('Erreur lors du chargement des données');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const loadClaims = async () => {
    try {
      const claimsQuery = query(
        collection(db, 'rewardClaims'),
        orderBy('createdAt', 'desc')
      );
      
      const querySnapshot = await getDocs(claimsQuery);
      const claimsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt.toDate(),
        updatedAt: doc.data().updatedAt.toDate()
      })) as RewardClaim[];

      setClaims(claimsData);
    } catch (error) {
      console.error('Error loading claims:', error);
      setError('Erreur lors du chargement des réclamations');
    }
  };

  const loadTopUsers = async () => {
    try {
      const users = await getTopEarningUsers();
      setTopUsers(users);
    } catch (error) {
      console.error('Error loading top users:', error);
    }
  };

  const handleStatusChange = async (claimId: string, newStatus: RewardClaim['status']) => {
    try {
      const claimRef = doc(db, 'rewardClaims', claimId);
      await updateDoc(claimRef, {
        status: newStatus,
        updatedAt: Timestamp.now()
      });
      
      await loadClaims();
      toast.success('Statut mis à jour avec succès');
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Erreur lors de la mise à jour du statut');
    }
  };

  const filteredClaims = selectedStatus === 'all'
    ? claims
    : claims.filter(claim => claim.status === selectedStatus);

  const getStatusIcon = (status: RewardClaim['status']) => {
    switch (status) {
      case 'pending':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'approved':
        return <Check className="h-5 w-5 text-green-500" />;
      case 'rejected':
        return <X className="h-5 w-5 text-red-500" />;
      case 'shipped':
        return <Gift className="h-5 w-5 text-blue-500" />;
      default:
        return null;
    }
  };

  const getLevelIcon = (level: RewardClaim['rewardLevel']) => {
    switch (level) {
      case 'gold':
        return <Crown className="h-5 w-5 text-yellow-500" />;
      case 'silver':
        return <Shield className="h-5 w-5 text-gray-400" />;
      case 'bronze':
        return <Star className="h-5 w-5 text-orange-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <Link to="/admin" className="text-white/80 hover:text-white">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div className="text-sm text-white/80">
                  {claims.length} demande{claims.length !== 1 ? 's' : ''}
                </div>
              </div>
              <h1 className="text-2xl font-bold text-white">Gestion des récompenses</h1>
            </div>
          </div>

          <div className="p-4 md:p-6">
            {/* Top Users Stats */}
            <TopUsersStats users={topUsers} />

            {/* Status Filter */}
            <div className="mb-6">
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
              >
                <option value="all">Tous les statuts</option>
                <option value="pending">En attente</option>
                <option value="approved">Approuvé</option>
                <option value="rejected">Rejeté</option>
                <option value="shipped">Expédié</option>
              </select>
            </div>

            {/* Claims List */}
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto"></div>
                <p className="mt-4 text-gray-500">Chargement des données...</p>
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <div className="text-red-500 mb-2">
                  <AlertTriangle className="h-12 w-12 mx-auto" />
                </div>
                <p className="text-gray-900">{error}</p>
              </div>
            ) : filteredClaims.length === 0 ? (
              <div className="text-center py-12">
                <Gift className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucune demande trouvée</p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredClaims.map((claim) => (
                  <div
                    key={claim.id}
                    className="bg-white border rounded-lg shadow-sm hover:shadow-md transition-shadow p-4"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          {getLevelIcon(claim.rewardLevel)}
                        </div>
                        <div>
                          <h3 className="text-lg font-medium text-gray-900">{claim.userName}</h3>
                          <p className="text-sm text-gray-500">{claim.userEmail}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(claim.status)}
                          <span className="text-sm text-gray-700 capitalize">{claim.status}</span>
                        </div>
                        <select
                          value={claim.status}
                          onChange={(e) => handleStatusChange(claim.id, e.target.value as RewardClaim['status'])}
                          className="block w-32 pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        >
                          <option value="pending">En attente</option>
                          <option value="approved">Approuver</option>
                          <option value="rejected">Rejeter</option>
                          <option value="shipped">Expédié</option>
                        </select>
                      </div>
                    </div>
                    <div className="mt-4">
                      <div className="text-sm text-gray-700">
                        <span className="font-medium">Récompense:</span> {claim.reward}
                      </div>
                      {claim.shippingDetails && (
                        <div className="mt-2 text-sm text-gray-700">
                          <span className="font-medium">Adresse:</span> {claim.shippingDetails.address}
                          {claim.shippingDetails.trackingNumber && (
                            <div>
                              <span className="font-medium">Numéro de suivi:</span> {claim.shippingDetails.trackingNumber}
                            </div>
                          )}
                        </div>
                      )}
                      <div className="mt-2 text-xs text-gray-500">
                        Créé le {claim.createdAt.toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default RewardManagement;