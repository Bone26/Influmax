import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Clock, Eye, ExternalLink, RefreshCw, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { formatRemainingTime } from '../../utils/orderUtils';
import RefundOrderModal from './RefundOrderModal';

interface OrderListProps {
  orders: any[];
  isLoading: boolean;
  onValidate?: (orderId: string) => Promise<void>;
  onReject?: (orderId: string) => Promise<void>;
  adminId: string;
}

const OrderList: React.FC<OrderListProps> = ({
  orders,
  isLoading,
  adminId
}) => {
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [selectedOrderForRefund, setSelectedOrderForRefund] = useState<any | null>(null);

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'completed':
        return {
          icon: Check,
          color: 'text-green-600',
          bg: 'bg-green-100',
          text: 'Terminé'
        };
      case 'processing':
        return {
          icon: Clock,
          color: 'text-blue-600',
          bg: 'bg-blue-100',
          text: 'En cours'
        };
      case 'cancelled':
        return {
          icon: X,
          color: 'text-red-600',
          bg: 'bg-red-100',
          text: 'Annulé'
        };
      default:
        return {
          icon: Clock,
          color: 'text-gray-600',
          bg: 'bg-gray-100',
          text: status
        };
    }
  };

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        <p className="mt-4 text-gray-600">Chargement des commandes...</p>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Aucune commande trouvée</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead>
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              ID JAP
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Service JAP
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Lien
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Quantité
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Prix
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Durée d'envoi
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Statut
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Date
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {orders.map((order) => {
            const statusConfig = getStatusConfig(order.status);
            const StatusIcon = statusConfig.icon;

            return (
              <motion.tr
                key={order.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="hover:bg-gray-50"
              >
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <span className="font-mono text-sm text-gray-900">#{order.id}</span>
                    {order.metadata?.japOrderId && order.metadata.japOrderId !== order.id && (
                      <div className="ml-2 p-1 bg-red-100 rounded-full">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm font-medium text-gray-900">
                    {order.service?.japServiceName || `${order.service?.platform} - ${order.service?.type}`}
                  </span>
                  <br />
                  <span className="text-xs text-gray-500">
                    ID: {order.service?.japServiceId || 'N/A'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-500 truncate max-w-xs">
                      {order.link}
                    </span>
                    <a
                      href={order.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-600 hover:text-purple-700"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {order.quantity.toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {order.price?.toFixed(2)}€
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center text-sm text-purple-600">
                    <Clock className="h-4 w-4 mr-1" />
                    {order.deliveryTime || 'Instantané'}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex flex-col space-y-1">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusConfig.bg} ${statusConfig.color}`}>
                      <StatusIcon className="h-4 w-4 mr-1" />
                      {statusConfig.text}
                    </span>
                    {order.metadata?.refunded && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                        <RefreshCw className="h-3 w-3 mr-1" />
                        Remboursé
                      </span>
                    )}
                    {order.status === 'processing' && order.timestamps?.startedAt && (
                      <div className="text-xs text-blue-600 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {formatRemainingTime(new Date(order.timestamps.startedAt), order.deliveryTime)}
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {format(new Date(order.timestamps?.createdAt), 'PPp', { locale: fr })}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    {(order.status === 'completed' || order.status === 'cancelled') && !order.metadata?.refunded && (
                      <button
                        onClick={() => setSelectedOrderForRefund(order)}
                        className="text-orange-600 hover:text-orange-700 p-2 rounded-full hover:bg-orange-50 transition-colors"
                        title="Rembourser"
                      >
                        <RefreshCw className="h-5 w-5" />
                      </button>
                    )}
                    <button
                      onClick={() => setSelectedOrder(order)}
                      className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors"
                      title="Voir les détails"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                  </div>
                </td>
              </motion.tr>
            );
          })}
        </tbody>
      </table>

      <RefundOrderModal
        isOpen={!!selectedOrderForRefund}
        onClose={() => setSelectedOrderForRefund(null)}
        order={selectedOrderForRefund}
        adminId={adminId}
      />
    </div>
  );
};

export default OrderList;