import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Settings, DollarSign, Wallet, Gift, MessageSquare, Database, ShoppingBag } from 'lucide-react';
import AdminStats from '../components/admin/AdminStats';
import AdminCharts from '../components/admin/AdminCharts';
import NotificationManager from '../components/admin/NotificationManager';
import { getAllOrders } from '../services/orders';

const Admin = () => {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (currentUser?.isAdmin) {
      loadOrders();
    }
  }, [currentUser]);

  const loadOrders = async () => {
    try {
      const allOrders = await getAllOrders('admin');
      setOrders(allOrders);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  // Si l'utilisateur n'est pas admin, ne pas rendre le composant
  if (!currentUser?.isAdmin) {
    return null;
  }

  const adminLinks = [
    { to: '/admin/orders', icon: ShoppingBag, label: 'Commandes', primary: true },
    { to: '/admin/platforms', icon: Settings, label: 'Plateformes' },
    { to: '/admin/prices', icon: DollarSign, label: 'Prix' },
    { to: '/admin/withdrawals', icon: Wallet, label: 'Retraits' },
    { to: '/admin/rewards', icon: Gift, label: 'Récompenses' },
    { to: '/admin/tickets', icon: MessageSquare, label: 'Support' },
    { to: '/admin/api', icon: Database, label: 'API' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header avec gradient */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-8">
            <div className="flex flex-col space-y-4">
              <div>
                <h1 className="text-3xl font-bold text-white">Administration</h1>
                <p className="text-purple-100 mt-2">
                  Gérez les commandes et suivez les statistiques
                </p>
              </div>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Grid des liens d'administration */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {adminLinks.map((link, index) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`flex flex-col items-center justify-center p-6 rounded-xl transition-all duration-300 transform hover:-translate-y-1 ${
                    link.primary
                      ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg hover:shadow-xl'
                      : 'bg-gray-50 hover:bg-gray-100'
                  }`}
                >
                  <link.icon className={`h-8 w-8 mb-3 ${link.primary ? 'text-white' : 'text-purple-600'}`} />
                  <span className={`text-sm font-medium ${link.primary ? 'text-white' : 'text-gray-900'}`}>
                    {link.label}
                  </span>
                </Link>
              ))}
            </div>

            {/* Statistiques */}
            <AdminStats />

            {/* Graphiques */}
            <AdminCharts orders={orders} />

            {/* Gestionnaire de notifications */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <NotificationManager />
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Admin;