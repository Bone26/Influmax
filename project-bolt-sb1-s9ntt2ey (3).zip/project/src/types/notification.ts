export type NotificationType = 'info' | 'success' | 'warning' | 'error';
export type NotificationTarget = 'all' | 'user' | 'admin';

export interface NotificationCreate {
  title: string;
  message: string;
  type: NotificationType;
  target: NotificationTarget;
  userId?: string;
  expiresAt?: Date;
}

export interface Notification extends NotificationCreate {
  id: string;
  read: boolean;
  createdAt: Date;
  readAt?: Date;
  metadata?: {
    orderId?: string;
    withdrawalId?: string;
    amount?: number;
    ticketId?: string;
    refundReason?: string; // Ajout du motif de remboursement
  };
}

export interface NotificationPreferences {
  userId: string;
  orders: boolean;
  deposits: boolean;
  withdrawals: boolean;
  referrals: boolean;
  commissions: boolean;
  rewards: boolean;
  adminMessages: boolean;
  support: boolean;
  refunds: boolean; // Ajout des notifications de remboursement
  email: boolean;
  updatedAt: Date;
}