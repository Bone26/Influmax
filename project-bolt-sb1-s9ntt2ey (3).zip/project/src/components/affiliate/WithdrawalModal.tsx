import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Wallet, Bank } from 'lucide-react';
import { useAffiliate } from '../../contexts/AffiliateContext';

interface WithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
}

const WithdrawalModal: React.FC<WithdrawalModalProps> = ({ isOpen, onClose, amount }) => {
  const { affiliate } = useAffiliate();
  const [bankDetails, setBankDetails] = useState({
    iban: '',
    bic: '',
    accountHolder: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!affiliate) return;

    setLoading(true);
    setError('');

    try {
      // TODO: Implement withdrawal request
      await new Promise(resolve => setTimeout(resolve, 1000));
      onClose();
    } catch (err) {
      setError('Une erreur est survenue lors de la demande de retrait');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden"
      >
        <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Wallet className="h-6 w-6" />
              <h2 className="text-xl font-semibold">Retrait des gains</h2>
            </div>
            <button onClick={onClose} className="text-white/80 hover:text-white">
              <X className="h-6 w-6" />
            </button>
          </div>
          <p className="mt-2 text-white/90">Montant disponible : {amount.toFixed(2)}€</p>
        </div>

        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                IBAN
              </label>
              <input
                type="text"
                value={bankDetails.iban}
                onChange={(e) => setBankDetails({ ...bankDetails, iban: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                BIC/SWIFT
              </label>
              <input
                type="text"
                value={bankDetails.bic}
                onChange={(e) => setBankDetails({ ...bankDetails, bic: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Titulaire du compte
              </label>
              <input
                type="text"
                value={bankDetails.accountHolder}
                onChange={(e) => setBankDetails({ ...bankDetails, accountHolder: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500"
                required
              />
            </div>

            <div className="bg-gray-50 p-4 rounded-lg space-y-2 text-sm text-gray-600">
              <p>• Montant minimum de retrait : 50€</p>
              <p>• Délai de traitement : 1-3 jours ouvrés</p>
              <p>• Virement bancaire uniquement</p>
            </div>

            <div className="flex space-x-4">
              <button
                type="submit"
                disabled={loading || amount < 50}
                className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50"
              >
                {loading ? 'Traitement...' : 'Confirmer le retrait'}
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default WithdrawalModal;