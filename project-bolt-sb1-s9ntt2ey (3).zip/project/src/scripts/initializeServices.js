import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, getDocs, query, where, Timestamp, writeBatch } from 'firebase/firestore';

// Configuration Firebase
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.VITE_FIREBASE_APP_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const initializeServices = async () => {
  try {
    // 1. Supprimer les anciens services
    const batch = writeBatch(db);
    const oldServicesQuery = query(collection(db, 'services'));
    const oldServicesSnapshot = await getDocs(oldServicesQuery);
    oldServicesSnapshot.docs.forEach(doc => {
      batch.delete(doc.ref);
    });
    await batch.commit();

    // 2. Créer les nouveaux services avec les limites par durée
    const services = [
      {
        name: 'Followers Instagram',
        platformId: 'instagram',
        basePrice: 0.005,
        deliveryLimits: {
          instant: { min: 100, max: 200000 },
          '24h': { min: 150, max: 150000 },
          '3days': { min: 200, max: 100000 },
          '7days': { min: 500, max: 50000 },
          '1month': { min: 1000, max: 20000 }
        },
        qualities: [
          { type: 'standard', multiplier: 1, isAvailable: true },
          { type: 'premium', multiplier: 1.5, isAvailable: true },
          { type: 'vip', multiplier: 2, isAvailable: true }
        ],
        deliveryTimes: [
          { type: 'instant', multiplier: 1, isAvailable: true },
          { type: '24h', multiplier: 1.1, isAvailable: true },
          { type: '3days', multiplier: 1.2, isAvailable: true },
          { type: '7days', multiplier: 1.3, isAvailable: true },
          { type: '1month', multiplier: 1.5, isAvailable: true }
        ],
        isActive: true
      },
      // Ajouter les autres services avec leurs limites spécifiques...
    ];

    for (const service of services) {
      const serviceRef = doc(collection(db, 'services'));
      const now = new Date();
      
      await setDoc(serviceRef, {
        id: serviceRef.id,
        ...service,
        createdAt: Timestamp.fromDate(now),
        updatedAt: Timestamp.fromDate(now)
      });
      
      console.log(`✅ Service créé : ${service.name}`);
    }

    console.log('✨ Initialisation des services terminée avec succès !');
  } catch (error) {
    console.error('Error initializing services:', error);
    throw error;
  }
};

// Exécuter l'initialisation
initializeServices().catch(console.error);