import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  Timestamp,
  orderBy,
  writeBatch
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { NotificationPreferences } from '../types/notification';

// Vérifier les préférences de notification
const shouldSendNotification = async (userId: string, type: keyof NotificationPreferences): Promise<boolean> => {
  try {
    const prefsDoc = await getDoc(doc(db, 'notificationPreferences', userId));
    if (!prefsDoc.exists()) return true; // Par défaut, envoyer les notifications
    return prefsDoc.data()[type] === true;
  } catch (error) {
    console.error('Error checking notification preferences:', error);
    return false;
  }
};

// Créer des préférences par défaut
const createDefaultPreferences = async (userId: string): Promise<NotificationPreferences> => {
  const defaultPrefs: NotificationPreferences = {
    userId,
    orders: true,
    deposits: true,
    withdrawals: true,
    referrals: true,
    commissions: true,
    rewards: true,
    adminMessages: true,
    support: true,
    refunds: true,
    email: true,
    updatedAt: new Date()
  };

  const prefsRef = doc(db, 'notificationPreferences', userId);
  await setDoc(prefsRef, {
    ...defaultPrefs,
    updatedAt: Timestamp.fromDate(defaultPrefs.updatedAt)
  });

  return defaultPrefs;
};

export const getNotificationPreferences = async (userId: string): Promise<NotificationPreferences> => {
  try {
    const prefsRef = doc(db, 'notificationPreferences', userId);
    const prefsDoc = await getDoc(prefsRef);

    if (!prefsDoc.exists()) {
      return createDefaultPreferences(userId);
    }

    const data = prefsDoc.data();
    return {
      ...data,
      updatedAt: data.updatedAt.toDate()
    } as NotificationPreferences;
  } catch (error) {
    console.error('Error getting notification preferences:', error);
    throw error;
  }
};

export const updateNotificationPreferences = async (
  userId: string,
  preferences: Partial<NotificationPreferences>
): Promise<void> => {
  try {
    const prefsRef = doc(db, 'notificationPreferences', userId);
    await updateDoc(prefsRef, {
      ...preferences,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating notification preferences:', error);
    throw error;
  }
};

export const disableAllNotifications = async (userId: string): Promise<void> => {
  try {
    const prefsRef = doc(db, 'notificationPreferences', userId);
    await updateDoc(prefsRef, {
      orders: false,
      deposits: false,
      withdrawals: false,
      referrals: false,
      commissions: false,
      rewards: false,
      adminMessages: false,
      support: false,
      refunds: false,
      email: false,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error disabling all notifications:', error);
    throw error;
  }
};

export const enableAllNotifications = async (userId: string): Promise<void> => {
  try {
    const prefsRef = doc(db, 'notificationPreferences', userId);
    await updateDoc(prefsRef, {
      orders: true,
      deposits: true,
      withdrawals: true,
      referrals: true,
      commissions: true,
      rewards: true,
      adminMessages: true,
      support: true,
      refunds: true,
      email: true,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error enabling all notifications:', error);
    throw error;
  }
};

export const markNotificationAsRead = async (userId: string, notificationId: string): Promise<void> => {
  try {
    const notificationRef = doc(db, 'notifications', notificationId);
    await updateDoc(notificationRef, {
      read: true,
      readAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error marking notification as read:', error);
    throw error;
  }
};

export const markAllNotificationsAsRead = async (userId: string): Promise<void> => {
  try {
    const batch = writeBatch(db);
    const q = query(
      collection(db, 'notifications'),
      where('userId', 'in', [userId, 'all']),
      where('read', '==', false)
    );

    const querySnapshot = await getDocs(q);
    const now = Timestamp.now();

    querySnapshot.docs.forEach(doc => {
      batch.update(doc.ref, {
        read: true,
        readAt: now
      });
    });

    await batch.commit();
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    throw error;
  }
};

export const getUserNotifications = async (userId: string, options: { unreadOnly?: boolean } = {}) => {
  try {
    let q = query(
      collection(db, 'notifications'),
      where('userId', 'in', [userId, 'all']),
      orderBy('createdAt', 'desc')
    );

    if (options.unreadOnly) {
      q = query(q, where('read', '==', false));
    }

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt.toDate(),
      readAt: doc.data().readAt?.toDate()
    }));
  } catch (error) {
    console.error('Error getting notifications:', error);
    throw error;
  }
};

export const sendOrderNotification = async (userId: string, orderId: string) => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'orders');
    if (!shouldSend) return;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'order',
      title: 'Nouvelle commande',
      message: `Votre commande #${orderId.slice(0, 8)} a été créée avec succès.`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: { orderId }
    });
  } catch (error) {
    console.error('Error sending order notification:', error);
  }
};

export const sendDepositNotification = async (userId: string, amount: number) => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'deposits');
    if (!shouldSend) return;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'deposit',
      title: 'Dépôt effectué',
      message: `Votre dépôt de ${amount.toFixed(2)}€ a été effectué avec succès.`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: { amount }
    });
  } catch (error) {
    console.error('Error sending deposit notification:', error);
  }
};

export const sendWithdrawalProcessingNotification = async (userId: string, amount: number) => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'withdrawals');
    if (!shouldSend) return;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'withdrawal',
      title: 'Retrait en cours',
      message: `Votre retrait de ${amount.toFixed(2)}€ est en cours de traitement.`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: { amount }
    });
  } catch (error) {
    console.error('Error sending withdrawal processing notification:', error);
  }
};

export const sendWithdrawalCompletedNotification = async (userId: string, amount: number) => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'withdrawals');
    if (!shouldSend) return;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'withdrawal',
      title: 'Retrait terminé',
      message: `Votre retrait de ${amount.toFixed(2)}€ a été effectué avec succès.`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: { amount }
    });
  } catch (error) {
    console.error('Error sending withdrawal completed notification:', error);
  }
};

export const sendNewReferralNotification = async (userId: string, referralName: string) => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'referrals');
    if (!shouldSend) return;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'referral',
      title: 'Nouveau filleul',
      message: `${referralName} vient de s'inscrire avec votre code de parrainage !`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: { referralName }
    });
  } catch (error) {
    console.error('Error sending new referral notification:', error);
  }
};

export const sendCommissionNotification = async (userId: string, amount: number) => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'commissions');
    if (!shouldSend) return;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'commission',
      title: 'Commission reçue',
      message: `Vous avez reçu une commission de ${amount.toFixed(2)}€ !`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: { amount }
    });
  } catch (error) {
    console.error('Error sending commission notification:', error);
  }
};

export const sendRewardUnlockedNotification = async (userId: string, rewardName: string) => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'rewards');
    if (!shouldSend) return;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'reward',
      title: 'Récompense débloquée',
      message: `Félicitations ! Votre récompense ${rewardName} a été approuvée.`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: { rewardName }
    });
  } catch (error) {
    console.error('Error sending reward unlocked notification:', error);
  }
};

export const sendRefundNotification = async (userId: string, orderId: string, amount: number, reason: string): Promise<void> => {
  try {
    const shouldSend = await shouldSendNotification(userId, 'refunds');
    if (!shouldSend) return;

    // Récupérer les détails de la commande pour avoir l'ID JAP
    const orderRef = doc(db, 'orders', orderId);
    const orderDoc = await getDoc(orderRef);
    if (!orderDoc.exists()) {
      throw new Error('Order not found');
    }
    const orderData = orderDoc.data();
    const japOrderId = orderData.metadata?.japOrderId || orderId;

    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId,
      type: 'refund',
      title: 'Commande remboursée',
      message: `Votre commande #${japOrderId} a été remboursée. Motif : ${reason}. Le montant de ${amount.toFixed(2)}€ a été crédité sur votre compte.`,
      read: false,
      createdAt: Timestamp.now(),
      metadata: {
        orderId,
        amount,
        refundReason: reason
      }
    });
  } catch (error) {
    console.error('Error sending refund notification:', error);
  }
};

export const sendAdminNotification = async (title: string, message: string, userId?: string) => {
  try {
    const notificationRef = doc(collection(db, 'notifications'));
    await setDoc(notificationRef, {
      id: notificationRef.id,
      userId: userId || 'all',
      type: 'admin',
      title,
      message,
      read: false,
      createdAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error sending admin notification:', error);
    throw error;
  }
};