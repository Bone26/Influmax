import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, Timestamp } from 'firebase/firestore';

// Configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyDLECT_Z6EIgpDkAS9aJ48AqOdSkT3yaOY",
  authDomain: "influmax-v2.firebaseapp.com",
  projectId: "influmax-v2",
  storageBucket: "influmax-v2.firebasestorage.app",
  messagingSenderId: "200667014540",
  appId: "1:200667014540:web:8845501ed88b7da1f822a9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Structure d'un service
interface Service {
  id: string;
  platformId: string;
  name: string;
  type: string;
  description: string;
  basePrice: number;
  minQuantity: number;
  maxQuantity: number;
  isActive: boolean;
  qualities: {
    type: 'standard' | 'premium' | 'vip';
    multiplier: number;
    isAvailable: boolean;
  }[];
  deliveryTimes: {
    type: 'instant' | '24h' | '3days' | '7days' | '1month';
    multiplier: number;
    isAvailable: boolean;
  }[];
  features: string[];
  createdAt: Date;
  updatedAt: Date;
}

const createService = async (data: Partial<Service>) => {
  const serviceRef = doc(collection(db, 'services'));
  const now = new Date();
  
  await setDoc(serviceRef, {
    id: serviceRef.id,
    ...data,
    createdAt: Timestamp.fromDate(now),
    updatedAt: Timestamp.fromDate(now)
  });

  console.log(`✅ Service créé : ${data.name}`);
};

const initializeServices = async () => {
  console.log('🚀 Initialisation des services...');
  
  try {
    // Instagram Services
    await createService({
      platformId: 'PLATFORM_ID_INSTAGRAM', // À remplacer par l'ID réel
      name: 'Followers Instagram',
      type: 'followers',
      description: 'Augmentez votre nombre d\'abonnés Instagram',
      basePrice: 0.50,
      minQuantity: 100,
      maxQuantity: 10000,
      isActive: true,
      qualities: [
        { type: 'standard', multiplier: 1, isAvailable: true },
        { type: 'premium', multiplier: 1.5, isAvailable: true },
        { type: 'vip', multiplier: 2, isAvailable: true }
      ],
      deliveryTimes: [
        { type: 'instant', multiplier: 1, isAvailable: true },
        { type: '24h', multiplier: 1.1, isAvailable: true },
        { type: '3days', multiplier: 1.2, isAvailable: true },
        { type: '7days', multiplier: 1.3, isAvailable: true },
        { type: '1month', multiplier: 1.5, isAvailable: true }
      ],
      features: [
        'Profils de qualité',
        'Livraison progressive',
        'Garantie de remplacement',
        'Support 24/7'
      ]
    });

    await createService({
      platformId: 'PLATFORM_ID_INSTAGRAM',
      name: 'Likes Instagram',
      type: 'likes',
      description: 'Augmentez l\'engagement sur vos publications',
      basePrice: 0.20,
      minQuantity: 100,
      maxQuantity: 10000,
      isActive: true,
      qualities: [
        { type: 'standard', multiplier: 1, isAvailable: true },
        { type: 'premium', multiplier: 1.5, isAvailable: true },
        { type: 'vip', multiplier: 2, isAvailable: true }
      ],
      deliveryTimes: [
        { type: 'instant', multiplier: 1, isAvailable: true },
        { type: '24h', multiplier: 1.1, isAvailable: true },
        { type: '3days', multiplier: 1.2, isAvailable: true },
        { type: '7days', multiplier: 1.3, isAvailable: true },
        { type: '1month', multiplier: 1.5, isAvailable: true }
      ],
      features: [
        'Likes de qualité',
        'Livraison rapide',
        'Garantie de remplacement',
        'Support 24/7'
      ]
    });

    // TikTok Services
    await createService({
      platformId: 'PLATFORM_ID_TIKTOK',
      name: 'Followers TikTok',
      type: 'followers',
      description: 'Développez votre communauté TikTok',
      basePrice: 2,
      minQuantity: 100,
      maxQuantity: 10000,
      isActive: true,
      qualities: [
        { type: 'standard', multiplier: 1, isAvailable: true },
        { type: 'premium', multiplier: 1.5, isAvailable: true }
      ],
      deliveryTimes: [
        { type: 'instant', multiplier: 1, isAvailable: true },
        { type: '24h', multiplier: 1.1, isAvailable: true },
        { type: '3days', multiplier: 1.2, isAvailable: true },
        { type: '7days', multiplier: 1.3, isAvailable: true },
        { type: '1month', multiplier: 1.5, isAvailable: true }
      ],
      features: [
        'Followers actifs',
        'Livraison progressive',
        'Garantie de remplacement',
        'Support 24/7'
      ]
    });

    // Telegram Services
    await createService({
      platformId: 'PLATFORM_ID_TELEGRAM',
      name: 'Membres Telegram',
      type: 'members',
      description: 'Augmentez les membres de votre canal',
      basePrice: 10,
      minQuantity: 100,
      maxQuantity: 100000,
      isActive: true,
      qualities: [
        { type: 'standard', multiplier: 1, isAvailable: true }
      ],
      deliveryTimes: [
        { type: 'instant', multiplier: 1, isAvailable: true },
        { type: '24h', multiplier: 1.1, isAvailable: true },
        { type: '3days', multiplier: 1.2, isAvailable: true },
        { type: '7days', multiplier: 1.3, isAvailable: true },
        { type: '1month', multiplier: 1.5, isAvailable: true }
      ],
      features: [
        'Membres réels',
        'Livraison progressive',
        'Garantie de remplacement',
        'Support 24/7'
      ]
    });

    console.log('✨ Initialisation des services terminée avec succès');
  } catch (error) {
    console.error('❌ Erreur lors de l\'initialisation:', error);
  } finally {
    process.exit(0);
  }
};

initializeServices();