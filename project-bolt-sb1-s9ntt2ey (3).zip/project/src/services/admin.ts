import { 
  collection, 
  query, 
  where, 
  getDocs, 
  Timestamp,
  orderBy,
  limit as firestoreLimit,
  doc,
  updateDoc,
  increment,
  runTransaction
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { sendWithdrawalCompletedNotification } from './notifications';

// Export the getWithdrawals function
export const getWithdrawals = async () => {
  try {
    const q = query(
      collection(db, 'withdrawals'),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate()
    }));
  } catch (error) {
    console.error('Error getting withdrawals:', error);
    throw error;
  }
};

// Fonction pour récupérer les meilleurs affiliés
export const getTopEarningUsers = async (limit = 5) => {
  try {
    // 1. Récupérer les utilisateurs avec les gains les plus élevés
    const usersRef = collection(db, 'users');
    const q = query(
      usersRef,
      where('affiliate.stats.totalEarnings', '>', 0),
      orderBy('affiliate.stats.totalEarnings', 'desc'),
      firestoreLimit(limit)
    );

    const snapshot = await getDocs(q);
    if (snapshot.empty) {
      return [];
    }

    const users = await Promise.all(snapshot.docs.map(async (doc) => {
      const data = doc.data();
      const userId = doc.id;

      // Vérifier que les données requises existent
      if (!data.affiliate?.stats) {
        console.warn(`Missing affiliate stats for user ${userId}`);
        return null;
      }

      // Récupérer les filleuls directs (niveau 1)
      const level1Query = query(
        collection(db, 'users'),
        where('affiliate.referrerId', '==', userId)
      );
      const level1Snapshot = await getDocs(level1Query);
      const level1Referrals = level1Snapshot.size;
      let level1Earnings = 0;
      let level2Referrals = 0;
      let level2Earnings = 0;

      // Pour chaque filleul niveau 1
      for (const referralDoc of level1Snapshot.docs) {
        // Récupérer les dépôts du filleul niveau 1
        const depositsQuery = query(
          collection(db, 'walletDeposits'),
          where('userId', '==', referralDoc.id),
          where('type', '==', 'deposit'),
          where('status', '==', 'completed')
        );
        const depositsSnapshot = await getDocs(depositsQuery);
        const referralDeposits = depositsSnapshot.docs.reduce(
          (sum, doc) => sum + (doc.data().amount || 0),
          0
        );
        
        // Calculer les gains niveau 1 (20% des dépôts)
        level1Earnings += referralDeposits * 0.20;

        // Récupérer les filleuls niveau 2
        const level2Query = query(
          collection(db, 'users'),
          where('affiliate.referrerId', '==', referralDoc.id)
        );
        const level2Snapshot = await getDocs(level2Query);
        level2Referrals += level2Snapshot.size;

        // Pour chaque filleul niveau 2
        for (const level2Doc of level2Snapshot.docs) {
          // Récupérer les dépôts du filleul niveau 2
          const level2DepositsQuery = query(
            collection(db, 'walletDeposits'),
            where('userId', '==', level2Doc.id),
            where('type', '==', 'deposit'),
            where('status', '==', 'completed')
          );
          const level2DepositsSnapshot = await getDocs(level2DepositsQuery);
          const level2Deposits = level2DepositsSnapshot.docs.reduce(
            (sum, doc) => sum + (doc.data().amount || 0),
            0
          );
          
          // Calculer les gains niveau 2 (10% des dépôts)
          level2Earnings += level2Deposits * 0.10;
        }
      }

      // Calculer la croissance mensuelle
      const monthlyGrowth = data.affiliate.stats.lastMonthEarnings > 0
        ? ((data.affiliate.stats.totalEarnings - data.affiliate.stats.lastMonthEarnings) / data.affiliate.stats.lastMonthEarnings) * 100
        : 0;

      return {
        id: userId,
        name: data.name || 'Utilisateur',
        photoURL: data.photoURL,
        totalEarnings: data.affiliate.stats.totalEarnings || 0,
        level1Earnings,
        level2Earnings,
        totalReferrals: level1Referrals + level2Referrals,
        level1Referrals,
        level2Referrals,
        monthlyGrowth,
        lastMonthEarnings: data.affiliate.stats.lastMonthEarnings || 0
      };
    }));

    // Filtrer les utilisateurs null et trier par gains totaux
    return users
      .filter((user): user is NonNullable<typeof user> => user !== null)
      .sort((a, b) => b.totalEarnings - a.totalEarnings);

  } catch (error) {
    console.error('Error getting top earning users:', error);
    throw error;
  }
};

// Marquer un retrait comme terminé
export const completeWithdrawal = async (withdrawalId: string): Promise<void> => {
  try {
    await runTransaction(db, async (transaction) => {
      const withdrawalRef = doc(db, 'withdrawals', withdrawalId);
      const withdrawalDoc = await transaction.get(withdrawalRef);
      
      if (!withdrawalDoc.exists()) {
        throw new Error('Withdrawal not found');
      }
      
      const withdrawal = withdrawalDoc.data();
      
      // Vérifier que le retrait est en attente
      if (withdrawal.status !== 'pending') {
        throw new Error('Invalid withdrawal status');
      }
      
      // Mettre à jour le statut du retrait
      transaction.update(withdrawalRef, {
        status: 'completed',
        updatedAt: Timestamp.now()
      });

      // Mettre à jour les stats de l'utilisateur
      const userRef = doc(db, 'users', withdrawal.userId);
      transaction.update(userRef, {
        'affiliate.stats.totalWithdrawn': increment(withdrawal.amount),
        'affiliate.stats.pendingWithdrawals': increment(-withdrawal.amount),
        updatedAt: Timestamp.now()
      });

      // Envoyer la notification
      await sendWithdrawalCompletedNotification(withdrawal.userId, withdrawal.amount);
    });
  } catch (error) {
    console.error('Error completing withdrawal:', error);
    throw error;
  }
};

// Rejeter un retrait
export const rejectWithdrawal = async (withdrawalId: string): Promise<void> => {
  try {
    await runTransaction(db, async (transaction) => {
      const withdrawalRef = doc(db, 'withdrawals', withdrawalId);
      const withdrawalDoc = await transaction.get(withdrawalRef);
      
      if (!withdrawalDoc.exists()) {
        throw new Error('Withdrawal not found');
      }
      
      const withdrawal = withdrawalDoc.data();
      
      // Vérifier que le retrait est en attente
      if (withdrawal.status !== 'pending') {
        throw new Error('Invalid withdrawal status');
      }
      
      // Mettre à jour le statut du retrait
      transaction.update(withdrawalRef, {
        status: 'rejected',
        updatedAt: Timestamp.now()
      });

      // Remettre le montant dans les gains disponibles
      const userRef = doc(db, 'users', withdrawal.userId);
      transaction.update(userRef, {
        'affiliate.stats.availableEarnings': increment(withdrawal.amount),
        'affiliate.stats.pendingWithdrawals': increment(-withdrawal.amount),
        updatedAt: Timestamp.now()
      });
    });
  } catch (error) {
    console.error('Error rejecting withdrawal:', error);
    throw error;
  }
};

// Récupérer le total des commissions d'affiliation
export const getTotalAffiliateCommissions = async (): Promise<number> => {
  try {
    // Récupérer tous les utilisateurs
    const usersSnapshot = await getDocs(collection(db, 'users'));
    
    // Calculer le total des commissions
    const totalCommissions = usersSnapshot.docs.reduce((total, doc) => {
      const userData = doc.data();
      return total + (userData.affiliate?.stats?.totalEarnings || 0);
    }, 0);

    return totalCommissions;
  } catch (error) {
    console.error('Error getting total affiliate commissions:', error);
    throw error;
  }
};