import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface BadgeProps {
  icon: LucideIcon;
  text: string;
  delay?: number;
  gradient: string;
}

const Badge: React.FC<BadgeProps> = ({ icon: Icon, text, delay = 0, gradient }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="relative group"
    >
      {/* Glow effect */}
      <div className={`absolute inset-0 bg-gradient-to-r ${gradient} opacity-20 blur-lg rounded-full transform group-hover:scale-110 transition-transform duration-300`} />
      
      {/* Glass background */}
      <div className="relative flex items-center bg-white/10 backdrop-blur-md rounded-full px-4 py-2 border border-white/20 hover:border-white/40 transition-all duration-300 group-hover:scale-105 group-hover:bg-white/15">
        {/* Icon container with gradient */}
        <div className={`bg-gradient-to-r ${gradient} p-1.5 rounded-full mr-3 transform group-hover:scale-110 transition-transform duration-300`}>
          <Icon className="h-4 w-4 text-white" />
        </div>
        
        {/* Text */}
        <span className="text-sm text-white font-medium whitespace-nowrap">
          {text}
        </span>
      </div>
    </motion.div>
  );
};

export default Badge;