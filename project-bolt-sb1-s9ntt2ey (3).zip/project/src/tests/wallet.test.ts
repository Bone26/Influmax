import { describe, it, expect, beforeEach, vi } from 'vitest';
import { getWalletBalance, addFunds, deductFunds } from '../services/wallet';
import { db } from '../lib/firebase';

// Mock Firebase
vi.mock('../lib/firebase', () => ({
  db: {
    doc: vi.fn(),
    collection: vi.fn(),
    getDoc: vi.fn(),
    setDoc: vi.fn(),
    updateDoc: vi.fn(),
    increment: vi.fn()
  }
}));

describe('Wallet Service', () => {
  const userId = 'test-user-id';

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('getWalletBalance', () => {
    it('should return wallet balance for existing wallet', async () => {
      const mockWallet = {
        balance: 100,
        updatedAt: new Date()
      };

      vi.mocked(db.getDoc).mockResolvedValueOnce({
        exists: () => true,
        data: () => mockWallet
      });

      const result = await getWalletBalance(userId);
      expect(result.balance).toBe(100);
    });

    it('should create new wallet if none exists', async () => {
      vi.mocked(db.getDoc).mockResolvedValueOnce({
        exists: () => false
      });

      const result = await getWalletBalance(userId);
      expect(result.balance).toBe(0);
      expect(db.setDoc).toHaveBeenCalled();
    });
  });

  describe('addFunds', () => {
    it('should add funds to wallet', async () => {
      const amount = 50;
      vi.mocked(db.updateDoc).mockResolvedValueOnce(undefined);
      
      await addFunds(userId, amount);
      
      expect(db.updateDoc).toHaveBeenCalled();
      expect(db.collection).toHaveBeenCalledWith('transactions');
    });

    it('should throw error if amount is below minimum', async () => {
      const amount = 1;
      
      await expect(addFunds(userId, amount)).rejects.toThrow();
    });
  });

  describe('deductFunds', () => {
    it('should deduct funds from wallet', async () => {
      const amount = 50;
      vi.mocked(db.getDoc).mockResolvedValueOnce({
        exists: () => true,
        data: () => ({ balance: 100 })
      });
      
      await deductFunds(userId, amount);
      
      expect(db.updateDoc).toHaveBeenCalled();
      expect(db.collection).toHaveBeenCalledWith('transactions');
    });

    it('should throw error if insufficient funds', async () => {
      const amount = 150;
      vi.mocked(db.getDoc).mockResolvedValueOnce({
        exists: () => true,
        data: () => ({ balance: 100 })
      });
      
      await expect(deductFunds(userId, amount)).rejects.toThrow('Insufficient funds');
    });
  });
});