import { initializeApp } from 'firebase/app';
import { getFirestore, collection, doc, setDoc, Timestamp } from 'firebase/firestore';
import { EMOJI_JAP_MAPPING, MIXED_PACKS } from './constants.js';
import 'dotenv/config';

// Configuration Firebase
const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.VITE_FIREBASE_APP_ID
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const initializeTelegramServices = async () => {
  try {
    console.log('🚀 Initialisation des services Telegram...');

    // Service de réactions
    const reactionsService = {
      name: 'Réactions Telegram',
      platformId: 'telegram',
      type: 'reactions',
      basePrice: 0.001,
      deliveryLimits: {
        instant: { min: 500, max: 100000, isActive: true },
        '24h': { min: 1000, max: 75000, isActive: true },
        '3days': { min: 2000, max: 50000, isActive: true },
        '7days': { min: 5000, max: 25000, isActive: true },
        '1month': { min: 10000, max: 10000, isActive: true }
      },
      qualities: [
        { 
          type: 'standard', 
          multiplier: 1, 
          isAvailable: true,
          name: 'Standard',
          description: 'Réactions de qualité',
          imageUrl: 'https://i.imgur.com/LpgsIxY.jpeg',
          features: [
            { label: 'Réactions réelles', value: true },
            { label: 'Choix des émojis', value: true },
            { label: 'Profils actifs', value: true },
            { label: 'Durée de vie', value: true, info: '∞' }
          ]
        }
      ],
      deliveryTimes: [
        { type: 'instant', multiplier: 1, isAvailable: true },
        { type: '24h', multiplier: 1.1, isAvailable: true },
        { type: '3days', multiplier: 1.2, isAvailable: true },
        { type: '7days', multiplier: 1.3, isAvailable: true },
        { type: '1month', multiplier: 1.5, isAvailable: true }
      ],
      telegramReactions: {
        individual: Object.entries(EMOJI_JAP_MAPPING).map(([emoji, japServiceId]) => ({
          emoji,
          japServiceId,
          japServiceName: `Telegram Reaction (${emoji})`,
          minQuantity: 100,
          maxQuantity: 100000,
          maxSpeed: 50000
        })),
        mixedPacks: {
          positive: {
            japServiceId: MIXED_PACKS.positive,
            japServiceName: 'Telegram Post Reactions + Views [Positive] [Mixed]',
            minQuantity: 100,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          negative: {
            japServiceId: MIXED_PACKS.negative,
            japServiceName: 'Telegram Post Reactions + Views [Negative] [Mixed]',
            minQuantity: 100,
            maxQuantity: 100000,
            maxSpeed: 50000
          }
        }
      },
      isActive: true
    };

    // Créer le service de réactions
    const serviceRef = doc(collection(db, 'services'));
    const now = new Date();
    
    await setDoc(serviceRef, {
      id: serviceRef.id,
      ...reactionsService,
      createdAt: Timestamp.fromDate(now),
      updatedAt: Timestamp.fromDate(now)
    });
    
    console.log('✅ Service de réactions Telegram créé');
    console.log('✨ Initialisation terminée avec succès !');
    process.exit(0);
  } catch (error) {
    console.error('Error initializing Telegram services:', error);
    process.exit(1);
  }
};

// Exécuter l'initialisation
initializeTelegramServices().catch(console.error);