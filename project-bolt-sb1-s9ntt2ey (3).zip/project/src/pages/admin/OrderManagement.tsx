import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Download, 
  ExternalLink, 
  Users, 
  Clock, 
  Check, 
  X, 
  RefreshCw,
  Loader2,
  AlertTriangle,
  User
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getAllOrders, updateOrderStatus } from '../../services/orders';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { formatRemainingTime } from '../../utils/orderUtils';
import RefundOrderModal from '../../components/admin/RefundOrderModal';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

const OrderManagement = () => {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedOrderForRefund, setSelectedOrderForRefund] = useState<any | null>(null);
  const [clientsData, setClientsData] = useState<{[key: string]: {name: string, email: string}}>({});

  useEffect(() => {
    if (currentUser?.isAdmin) {
      loadOrders();
    }
  }, [currentUser?.isAdmin]);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const ordersData = await getAllOrders('admin');
      setOrders(ordersData);

      // Charger les données des clients
      const uniqueUserIds = [...new Set(ordersData.map(order => order.userId))];
      const clientsInfo: {[key: string]: {name: string, email: string}} = {};
      
      await Promise.all(uniqueUserIds.map(async (userId) => {
        const userDoc = await getDoc(doc(db, 'users', userId));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          clientsInfo[userId] = {
            name: userData.name || 'Utilisateur inconnu',
            email: userData.email || 'Email inconnu'
          };
        }
      }));

      setClientsData(clientsInfo);
    } catch (error) {
      console.error('Error loading orders:', error);
      setError('Erreur lors du chargement des commandes');
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      await updateOrderStatus(orderId, newStatus);
      await loadOrders();
      toast.success('Statut mis à jour avec succès');
    } catch (error) {
      console.error('Error updating order status:', error);
      toast.error('Erreur lors de la mise à jour du statut');
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return {
          icon: Check,
          color: 'bg-green-100 text-green-800 border-green-200',
          text: 'Terminé'
        };
      case 'processing':
        return {
          icon: Clock,
          color: 'bg-blue-100 text-blue-800 border-blue-200',
          text: 'En cours'
        };
      case 'cancelled':
        return {
          icon: X,
          color: 'bg-red-100 text-red-800 border-red-200',
          text: 'Annulé'
        };
      default:
        return {
          icon: Clock,
          color: 'bg-gray-100 text-gray-800 border-gray-200',
          text: status
        };
    }
  };

  const filteredOrders = orders.filter(order => {
    const clientName = clientsData[order.userId]?.name.toLowerCase() || '';
    const clientEmail = clientsData[order.userId]?.email.toLowerCase() || '';
    
    const matchesSearch = 
      order.id.toString().includes(searchTerm.toLowerCase()) ||
      order.service?.japServiceName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.link?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      clientName.includes(searchTerm.toLowerCase()) ||
      clientEmail.includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link to="/admin" className="text-white/80 hover:text-white">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div>
                  <h1 className="text-2xl font-bold text-white">Gestion des commandes</h1>
                  <p className="text-purple-100 text-sm">
                    {filteredOrders.length} commande{filteredOrders.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Search & Filters */}
          <div className="p-4 bg-gray-50 border-b">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Rechercher par ID, service, lien ou client..."
                  className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="processing">En cours</option>
                <option value="completed">Terminés</option>
                <option value="cancelled">Annulés</option>
              </select>
            </div>
          </div>

          {/* Orders List */}
          <div className="p-4">
            {error ? (
              <div className="text-center py-12">
                <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <p className="text-red-500">{error}</p>
              </div>
            ) : filteredOrders.length === 0 ? (
              <div className="text-center py-12">
                <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Aucune commande trouvée</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        ID JAP
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Client
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Service
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Lien
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Quantité
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Prix
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Statut
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredOrders.map((order) => {
                      const statusConfig = getStatusBadge(order.status);
                      const StatusIcon = statusConfig.icon;
                      const clientInfo = clientsData[order.userId];

                      return (
                        <motion.tr
                          key={order.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="hover:bg-gray-50"
                        >
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            <div className="flex items-center">
                              <span className="font-mono text-sm text-gray-900">#{order.id}</span>
                              {order.metadata?.japOrderId && order.metadata.japOrderId !== order.id && (
                                <div className="ml-2 p-1 bg-red-100 rounded-full">
                                  <AlertTriangle className="h-4 w-4 text-red-600" />
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-8 w-8 bg-purple-100 rounded-full flex items-center justify-center">
                                <User className="h-4 w-4 text-purple-600" />
                              </div>
                              <div className="ml-3">
                                <p className="text-sm font-medium text-gray-900">{clientInfo?.name}</p>
                                <p className="text-sm text-gray-500">{clientInfo?.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {order.service?.japServiceName || `${order.service?.platform} - ${order.service?.type}`}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex items-center space-x-2">
                              <span className="text-sm text-gray-500 truncate max-w-xs">
                                {order.link}
                              </span>
                              <a
                                href={order.link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-purple-600 hover:text-purple-700"
                              >
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {order.quantity.toLocaleString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {order.price.toFixed(2)}€
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex flex-col space-y-1">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusConfig.color}`}>
                                <StatusIcon className="h-4 w-4 mr-1" />
                                {statusConfig.text}
                              </span>
                              {order.status === 'processing' && order.timestamps?.startedAt && (
                                <div className="text-xs text-blue-600 flex items-center">
                                  <Clock className="h-3 w-3 mr-1" />
                                  {formatRemainingTime(
                                    new Date(order.timestamps.startedAt),
                                    order.deliveryTime
                                  )}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {format(new Date(order.timestamps.createdAt), 'PPp', { locale: fr })}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              <select
                                value={order.status}
                                onChange={(e) => handleStatusChange(order.id, e.target.value)}
                                className={`px-2 py-1 rounded-full text-xs font-medium ${statusConfig.color} border-none focus:ring-2 focus:ring-purple-500`}
                              >
                                <option value="processing">En cours</option>
                                <option value="completed">Terminé</option>
                                <option value="cancelled">Annulé</option>
                              </select>
                              {(order.status === 'completed' || order.status === 'cancelled') && !order.metadata?.refunded && (
                                <button
                                  onClick={() => setSelectedOrderForRefund(order)}
                                  className="text-orange-600 hover:text-orange-700 p-2 rounded-full hover:bg-orange-50 transition-colors"
                                  title="Rembourser"
                                >
                                  <RefreshCw className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </td>
                        </motion.tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      <RefundOrderModal
        isOpen={!!selectedOrderForRefund}
        onClose={() => setSelectedOrderForRefund(null)}
        order={selectedOrderForRefund}
        adminId={currentUser?.id || ''}
      />
    </div>
  );
};

export default OrderManagement;