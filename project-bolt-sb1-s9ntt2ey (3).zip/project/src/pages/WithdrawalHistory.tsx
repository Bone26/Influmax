import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Wallet, Clock, Check, X } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useEffect, useState } from 'react';
import { getUserWithdrawals } from '../services/affiliate';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

const WithdrawalHistory = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadWithdrawals = async () => {
      if (!currentUser) return;
      
      try {
        const data = await getUserWithdrawals(currentUser.id);
        setWithdrawals(data);
      } catch (error) {
        console.error('Error loading withdrawals:', error);
      } finally {
        setLoading(false);
      }
    };

    loadWithdrawals();
  }, [currentUser]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border border-green-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 border border-blue-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border border-yellow-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 border border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <Check className="h-5 w-5" />;
      case 'processing':
        return <Clock className="h-5 w-5" />;
      case 'rejected':
        return <X className="h-5 w-5" />;
      default:
        return <Clock className="h-5 w-5" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Terminé';
      case 'processing':
        return 'En cours';
      case 'pending':
        return 'En attente';
      case 'rejected':
        return 'Rejeté';
      default:
        return status;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/affiliate')}
                className="text-white/80 hover:text-white"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-white">Historique des retraits</h1>
                <p className="text-purple-100 text-sm">
                  {withdrawals.length} retrait{withdrawals.length !== 1 ? 's' : ''}
                </p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {withdrawals.length === 0 ? (
              <div className="text-center py-12">
                <Wallet className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">Aucun retrait</h3>
                <p className="mt-2 text-gray-500">
                  Vous n'avez pas encore effectué de retrait
                </p>
              </div>
            ) : (
              <div className="space-y-6">
                {withdrawals.map((withdrawal) => (
                  <motion.div
                    key={withdrawal.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border rounded-lg shadow-sm p-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-lg ${getStatusBadge(withdrawal.status)}`}>
                          {getStatusIcon(withdrawal.status)}
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">
                            {withdrawal.amount.toFixed(2)}€
                          </div>
                          <div className="text-sm text-gray-500">
                            {format(withdrawal.createdAt, 'PPP à HH:mm', { locale: fr })}
                          </div>
                        </div>
                      </div>
                      <div className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusBadge(withdrawal.status)}`}>
                        {getStatusText(withdrawal.status)}
                      </div>
                    </div>

                    <div className="mt-4 bg-gray-50 rounded-lg p-4">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <div className="text-sm text-gray-500">IBAN</div>
                          <div className="font-medium">{withdrawal.bankDetails.iban}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-500">BIC</div>
                          <div className="font-medium">{withdrawal.bankDetails.bic}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-500">Titulaire</div>
                          <div className="font-medium">{withdrawal.bankDetails.accountHolder}</div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default WithdrawalHistory;