import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bell, Mail, ShoppingBag, Wallet, Users, Gift, MessageCircle, PowerOff, Power, MessageSquare, RefreshCw } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getNotificationPreferences, updateNotificationPreferences, disableAllNotifications, enableAllNotifications } from '../../services/notifications';
import { toast } from 'sonner';

const NotificationSettings = () => {
  const { currentUser } = useAuth();
  const [preferences, setPreferences] = useState({
    orders: true,
    deposits: true,
    withdrawals: true,
    referrals: true,
    commissions: true,
    rewards: true,
    support: true,
    adminMessages: true,
    refunds: true,
    email: true
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (currentUser) {
      loadPreferences();
    }
  }, [currentUser]);

  const loadPreferences = async () => {
    try {
      const prefs = await getNotificationPreferences(currentUser!.id);
      setPreferences(prefs);
    } catch (error) {
      console.error('Error loading preferences:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (key: keyof typeof preferences) => {
    try {
      const newPreferences = {
        ...preferences,
        [key]: !preferences[key]
      };
      
      await updateNotificationPreferences(currentUser!.id, newPreferences);
      setPreferences(newPreferences);
      toast.success('Préférences mises à jour');
    } catch (error) {
      console.error('Error updating preferences:', error);
      toast.error('Erreur lors de la mise à jour');
    }
  };

  const handleDisableAll = async () => {
    try {
      setLoading(true);
      await disableAllNotifications(currentUser!.id);
      await loadPreferences();
      toast.success('Toutes les notifications ont été désactivées');
    } catch (error) {
      console.error('Error disabling notifications:', error);
      toast.error('Erreur lors de la désactivation des notifications');
    } finally {
      setLoading(false);
    }
  };

  const handleEnableAll = async () => {
    try {
      setLoading(true);
      await enableAllNotifications(currentUser!.id);
      await loadPreferences();
      toast.success('Toutes les notifications ont été activées');
    } catch (error) {
      console.error('Error enabling notifications:', error);
      toast.error('Erreur lors de l\'activation des notifications');
    } finally {
      setLoading(false);
    }
  };

  const notificationTypes = [
    {
      key: 'orders',
      label: 'Commandes',
      description: 'Notifications sur vos commandes',
      icon: ShoppingBag
    },
    {
      key: 'deposits',
      label: 'Dépôts',
      description: 'Notifications de dépôts',
      icon: Wallet
    },
    {
      key: 'withdrawals',
      label: 'Retraits',
      description: 'Notifications de retraits',
      icon: Wallet
    },
    {
      key: 'referrals',
      label: 'Filleuls',
      description: 'Notifications de nouveaux filleuls',
      icon: Users
    },
    {
      key: 'commissions',
      label: 'Commissions',
      description: 'Notifications de commissions',
      icon: Wallet
    },
    {
      key: 'rewards',
      label: 'Récompenses',
      description: 'Notifications de récompenses',
      icon: Gift
    },
    {
      key: 'support',
      label: 'Support',
      description: 'Notifications des réponses du support',
      icon: MessageSquare
    },
    {
      key: 'adminMessages',
      label: 'Messages administratifs',
      description: 'Messages importants de l\'équipe',
      icon: MessageCircle
    },
    {
      key: 'refunds',
      label: 'Remboursements',
      description: 'Notifications de remboursement de commandes',
      icon: RefreshCw
    },
    {
      key: 'email',
      label: 'Notifications par email',
      description: 'Recevoir les notifications par email',
      icon: Mail
    }
  ];

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-8 w-48 bg-gray-200 rounded mb-4"></div>
        <div className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-16 bg-gray-100 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <h2 className="text-2xl font-bold text-gray-900">Notifications</h2>
          <Bell className="h-6 w-6 text-gray-400" />
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={handleEnableAll}
            disabled={Object.values(preferences).every(value => value === true)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              Object.values(preferences).every(value => value === true)
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-green-100 text-green-600 hover:bg-green-200'
            }`}
          >
            <Power className="h-4 w-4" />
            <span>Tout activer</span>
          </button>
          <button
            onClick={handleDisableAll}
            disabled={Object.values(preferences).every(value => value === false)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              Object.values(preferences).every(value => value === false)
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-red-100 text-red-600 hover:bg-red-200'
            }`}
          >
            <PowerOff className="h-4 w-4" />
            <span>Tout désactiver</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="divide-y">
          {notificationTypes.map((type) => (
            <motion.div
              key={type.key}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <type.icon className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{type.label}</h3>
                    <p className="text-sm text-gray-500">{type.description}</p>
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={preferences[type.key as keyof typeof preferences] || false}
                    onChange={() => handleToggle(type.key as keyof typeof preferences)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NotificationSettings;