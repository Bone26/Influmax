import React from 'react';
import { Link as LinkIcon } from 'lucide-react';

interface LinkInputProps {
  platform: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

const LinkInput: React.FC<LinkInputProps> = ({ platform, value, onChange, error }) => {
  const getPlaceholder = () => {
    switch (platform) {
      case 'instagram':
        return 'https://instagram.com/p/...';
      case 'tiktok':
        return 'https://vm.tiktok.com/...';
      case 'telegram':
        return 'https://t.me/...';
      default:
        return 'https://...';
    }
  };

  const validateLink = (link: string) => {
    if (!link) return true; // Empty link is valid (will be caught by form validation)
    
    try {
      const url = new URL(link);
      switch (platform) {
        case 'instagram':
          return url.hostname === 'instagram.com' || url.hostname === 'www.instagram.com';
        case 'tiktok':
          // Accepter uniquement les liens vm.tiktok.com
          return url.hostname === 'vm.tiktok.com';
        case 'telegram':
          return url.hostname === 't.me' || url.hostname === 'telegram.me';
        default:
          return true;
      }
    } catch {
      return false;
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-2">
        Lien de la publication
      </label>
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <LinkIcon className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="url"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={getPlaceholder()}
          className={`
            w-full pl-10 pr-3 py-2 border rounded-xl
            ${error ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-purple-500 focus:border-purple-500'}
          `}
        />
      </div>
      {error && (
        <p className="mt-2 text-sm text-red-600">
          {error}
        </p>
      )}
      {value && !validateLink(value) && (
        <p className="mt-2 text-sm text-red-600">
          {platform === 'tiktok' 
            ? 'Veuillez entrer un lien TikTok au format vm.tiktok.com'
            : `Veuillez entrer un lien ${platform} valide`
          }
        </p>
      )}
    </div>
  );
};

export default LinkInput;