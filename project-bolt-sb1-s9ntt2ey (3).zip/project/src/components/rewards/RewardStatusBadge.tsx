import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Check, X, Package } from 'lucide-react';

interface RewardStatusBadgeProps {
  status: 'pending' | 'approved' | 'rejected' | 'shipped';
  className?: string;
}

const RewardStatusBadge: React.FC<RewardStatusBadgeProps> = ({ status, className = '' }) => {
  const getStatusConfig = () => {
    switch (status) {
      case 'pending':
        return {
          icon: Clock,
          text: 'En attente',
          color: 'bg-yellow-100 text-yellow-800 border-yellow-200'
        };
      case 'approved':
        return {
          icon: Check,
          text: 'Approuvé',
          color: 'bg-green-100 text-green-800 border-green-200'
        };
      case 'rejected':
        return {
          icon: X,
          text: 'Rejeté',
          color: 'bg-red-100 text-red-800 border-red-200'
        };
      case 'shipped':
        return {
          icon: Package,
          text: 'Expédié',
          color: 'bg-blue-100 text-blue-800 border-blue-200'
        };
      default:
        return {
          icon: Clock,
          text: 'En attente',
          color: 'bg-gray-100 text-gray-800 border-gray-200'
        };
    }
  };

  const config = getStatusConfig();
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`inline-flex items-center px-3 py-1 rounded-full border ${config.color} ${className}`}
    >
      <Icon className="h-4 w-4 mr-1.5" />
      <span className="text-sm font-medium">{config.text}</span>
    </motion.div>
  );
};

export default RewardStatusBadge;