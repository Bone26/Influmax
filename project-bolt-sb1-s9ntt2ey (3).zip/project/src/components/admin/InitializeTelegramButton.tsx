import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Loader2, MessageCircle } from 'lucide-react';
import { toast } from 'sonner';
import { collection, getDocs, query, where, writeBatch, doc, setDoc, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { EMOJI_JAP_MAPPING, MIXED_PACKS } from '../telegram/emoji/constants';

const InitializeTelegramButton = () => {
  const [loading, setLoading] = useState(false);

  const initializeTelegramPrices = async () => {
    try {
      console.log('🚀 Initialisation des prix Telegram...');

      // Configuration des prix pour les différents services
      const telegramPrices = [
        // Service de réactions
        {
          platformId: 'telegram',
          serviceType: 'reactions',
          quality: 'standard',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 500, max: 100000, isActive: true },
            '24h': { min: 1000, max: 75000, isActive: true },
            '3days': { min: 2000, max: 50000, isActive: true },
            '7days': { min: 5000, max: 25000, isActive: true },
            '1month': { min: 10000, max: 10000, isActive: true }
          },
          telegramReactions: {
            individual: Object.entries(EMOJI_JAP_MAPPING).map(([emoji, japServiceId]) => ({
              emoji,
              japServiceId,
              japServiceName: `Telegram Reaction (${emoji})`,
              minQuantity: 100,
              maxQuantity: 100000,
              maxSpeed: 50000
            })),
            mixedPacks: {
              positive: {
                japServiceId: MIXED_PACKS.positive,
                japServiceName: 'Telegram Post Reactions + Views [Positive] [Mixed]',
                minQuantity: 100,
                maxQuantity: 100000,
                maxSpeed: 50000
              },
              negative: {
                japServiceId: MIXED_PACKS.negative,
                japServiceName: 'Telegram Post Reactions + Views [Negative] [Mixed]',
                minQuantity: 100,
                maxQuantity: 100000,
                maxSpeed: 50000
              }
            }
          },
          isActive: true
        },

        // Service de membres
        {
          platformId: 'telegram',
          serviceType: 'members',
          quality: 'standard',
          basePrice: 0.01,
          deliveryLimits: {
            instant: { min: 500, max: 100000, isActive: true },
            '24h': { min: 750, max: 75000, isActive: true },
            '3days': { min: 1000, max: 50000, isActive: true },
            '7days': { min: 2500, max: 25000, isActive: true },
            '1month': { min: 5000, max: 10000, isActive: true }
          },
          japMapping: {
            japServiceId: '363',
            japServiceName: 'Telegram Channel Members [Public]',
            minQuantity: 500,
            maxQuantity: 100000,
            maxSpeed: 5000
          },
          isActive: true
        },

        // Service de vues
        {
          platformId: 'telegram',
          serviceType: 'views',
          quality: 'standard',
          basePrice: 0.0005,
          deliveryLimits: {
            instant: { min: 100, max: 100000, isActive: true },
            '24h': { min: 200, max: 75000, isActive: true },
            '3days': { min: 500, max: 50000, isActive: true },
            '7days': { min: 1000, max: 25000, isActive: true },
            '1month': { min: 2000, max: 10000, isActive: true }
          },
          japMapping: {
            japServiceId: '365',
            japServiceName: 'Telegram Post Views',
            minQuantity: 100,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          isActive: true
        }
      ];

      // Créer les documents de prix
      for (const price of telegramPrices) {
        const priceRef = doc(collection(db, 'servicePrices'));
        const now = new Date();
        
        await setDoc(priceRef, {
          id: priceRef.id,
          ...price,
          updatedAt: Timestamp.fromDate(now),
          updatedBy: 'system'
        });
        
        console.log(`✅ Prix créé pour ${price.serviceType}`);
      }

      console.log('✨ Initialisation terminée avec succès !');
      toast.success('Prix Telegram initialisés avec succès');
    } catch (error) {
      console.error('Error initializing Telegram prices:', error);
      toast.error('Erreur lors de l\'initialisation des prix Telegram');
      throw error;
    }
  };

  const handleInitialize = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir réinitialiser les prix Telegram ? Cette action est irréversible.')) {
      return;
    }

    setLoading(true);
    try {
      // 1. Supprimer les anciens prix Telegram
      const batch = writeBatch(db);
      const telegramPricesQuery = query(
        collection(db, 'servicePrices'),
        where('platformId', '==', 'telegram')
      );
      const snapshot = await getDocs(telegramPricesQuery);
      snapshot.docs.forEach(doc => {
        batch.delete(doc.ref);
      });
      await batch.commit();

      // 2. Initialiser les nouveaux prix
      await initializeTelegramPrices();
      
      toast.success('Prix Telegram initialisés avec succès');
    } catch (error) {
      console.error('Error initializing Telegram prices:', error);
      toast.error('Erreur lors de l\'initialisation des prix Telegram');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-6 right-6"
    >
      <button
        onClick={handleInitialize}
        disabled={loading}
        className="flex items-center space-x-2 bg-gradient-to-r from-blue-400 to-cyan-500 text-white px-6 py-3 rounded-xl shadow-lg hover:from-blue-500 hover:to-cyan-600 disabled:opacity-50 transition-all duration-300"
      >
        {loading ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Initialisation...</span>
          </>
        ) : (
          <>
            <MessageCircle className="h-5 w-5" />
            <span>Initialiser les prix Telegram</span>
          </>
        )}
      </button>
    </motion.div>
  );
};

export default InitializeTelegramButton;