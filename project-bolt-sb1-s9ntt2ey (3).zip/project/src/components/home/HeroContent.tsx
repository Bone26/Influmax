import React from 'react';
import HeroAction from './HeroAction';

const HeroContent = () => {
  return (
    <div className="text-center">
      <h1 className="text-5xl md:text-7xl font-bold mb-8 leading-tight animate-fade-in">
        Propulsez votre présence sur<br />
        <span className="bg-gradient-to-r from-pink-400 to-purple-200 bg-clip-text text-transparent">
          les réseaux sociaux
        </span>
      </h1>
      <p className="text-xl md:text-2xl mb-12 text-purple-100 max-w-3xl mx-auto animate-fade-in-up">
        Service premium de croissance Instagram et TikTok sans donner vos accès.
        <br />
        <span className="font-semibold">Résultats garantis ou remboursés.</span>
      </p>
      <HeroAction />
    </div>
  );
};

export default HeroContent;