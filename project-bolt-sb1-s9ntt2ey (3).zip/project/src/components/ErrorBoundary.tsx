import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  isOffline: boolean;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    isOffline: !navigator.onLine
  };

  constructor(props: Props) {
    super(props);
    this.handleOnlineStatus = this.handleOnlineStatus.bind(this);
  }

  componentDidMount() {
    window.addEventListener('online', this.handleOnlineStatus);
    window.addEventListener('offline', this.handleOnlineStatus);
  }

  componentWillUnmount() {
    window.removeEventListener('online', this.handleOnlineStatus);
    window.removeEventListener('offline', this.handleOnlineStatus);
  }

  handleOnlineStatus() {
    this.setState({ isOffline: !navigator.onLine });
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, isOffline: !navigator.onLine };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Erreur non gérée:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError || this.state.isOffline) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl p-8 max-w-lg w-full text-center">
            {this.state.isOffline ? (
              <>
                <div className="bg-yellow-100 rounded-full p-3 w-12 h-12 mx-auto mb-4">
                  <AlertTriangle className="h-6 w-6 text-yellow-600" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900 mb-4">
                  Connexion Internet perdue
                </h1>
                <p className="text-gray-600 mb-6">
                  Vérifiez votre connexion Internet et réessayez.
                </p>
              </>
            ) : (
              <>
                <div className="bg-red-100 rounded-full p-3 w-12 h-12 mx-auto mb-4">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
                <h1 className="text-2xl font-bold text-gray-900 mb-4">
                  Oups ! Quelque chose s'est mal passé
                </h1>
                <p className="text-gray-600 mb-6">
                  Une erreur inattendue s'est produite. Veuillez rafraîchir la page ou réessayer plus tard.
                </p>
              </>
            )}
            <button
              onClick={() => window.location.reload()}
              className="inline-flex items-center px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <RefreshCw className="h-5 w-5 mr-2" />
              Rafraîchir la page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;