import React from 'react';
import { Check } from 'lucide-react';

interface PricingTier {
  name: string;
  price: string;
  unit: string;
  description: string;
  features?: string[];
}

interface ServicePricingProps {
  tiers: PricingTier[];
  onSelect: (tier: PricingTier) => void;
}

const ServicePricing: React.FC<ServicePricingProps> = ({ tiers, onSelect }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {tiers.map((tier, index) => (
        <div
          key={index}
          className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
        >
          <div className="p-6">
            <h3 className="text-xl font-semibold mb-2">{tier.name}</h3>
            <div className="flex items-baseline mb-4">
              <span className="text-3xl font-bold">{tier.price}€</span>
              <span className="text-gray-500 ml-2">/ {tier.unit}</span>
            </div>
            <p className="text-gray-600 mb-6">{tier.description}</p>
            {tier.features && (
              <ul className="space-y-3">
                {tier.features.map((feature, i) => (
                  <li key={i} className="flex items-center">
                    <Check className="h-5 w-5 text-green-500 mr-2" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="p-6 bg-gray-50 border-t">
            <button
              onClick={() => onSelect(tier)}
              className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors"
            >
              Sélectionner
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ServicePricing;