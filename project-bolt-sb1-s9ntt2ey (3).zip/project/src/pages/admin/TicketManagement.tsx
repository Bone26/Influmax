import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, MessageSquare, BarChart } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Ticket, TicketMessage } from '../../types/ticket';
import { getAllTickets, subscribeToTicketMessages } from '../../services/tickets';
import TicketList from '../../components/support/admin/TicketList';
import TicketChat from '../../components/support/admin/TicketChat';
import TicketStats from '../../components/support/admin/TicketStats';

const TicketManagement = () => {
  const { currentUser } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [messages, setMessages] = useState<TicketMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [showStats, setShowStats] = useState(false);

  useEffect(() => {
    if (currentUser?.isAdmin) {
      loadData();
    }
  }, [currentUser?.isAdmin]);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    if (selectedTicket) {
      unsubscribe = subscribeToTicketMessages(selectedTicket.id, (newMessages) => {
        setMessages(newMessages);
      });
    }

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, [selectedTicket]);

  const loadData = async () => {
    try {
      setLoading(true);
      const ticketsData = await getAllTickets();
      setTickets(ticketsData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectTicket = (ticket: Ticket) => {
    setSelectedTicket(ticket);
  };

  const handleCloseChat = () => {
    setSelectedTicket(null);
  };

  // Si un ticket est sélectionné, afficher uniquement le chat
  if (selectedTicket) {
    return (
      <div className="min-h-screen bg-gray-50">
        <TicketChat
          ticket={selectedTicket}
          messages={messages}
          onClose={handleCloseChat}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white shadow-xl min-h-screen md:min-h-0 md:rounded-2xl md:my-12 overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Link to="/admin" className="text-white/80 hover:text-white">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div>
                  <h1 className="text-2xl font-bold text-white">Support</h1>
                  <p className="text-purple-100 text-sm">
                    {tickets.length} ticket{tickets.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowStats(!showStats)}
                className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors"
              >
                <BarChart className="h-5 w-5" />
                <span>{showStats ? 'Masquer' : 'Voir'} les statistiques</span>
              </button>
            </div>
          </div>

          {/* Stats Section */}
          {showStats && <TicketStats tickets={tickets} />}

          {/* Liste des tickets */}
          <div className="h-[calc(100vh-12rem)] md:h-[calc(100vh-16rem)] overflow-y-auto">
            <TicketList
              tickets={tickets}
              loading={loading}
              onSelectTicket={handleSelectTicket}
              selectedTicketId={selectedTicket?.id}
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default TicketManagement;