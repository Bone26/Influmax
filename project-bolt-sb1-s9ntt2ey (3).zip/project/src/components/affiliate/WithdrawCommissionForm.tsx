import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wallet, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useAffiliate } from '../../contexts/AffiliateContext';
import { createWithdrawal } from '../../services/affiliate';

interface WithdrawCommissionFormProps {
  pendingAmount: number;
}

const WithdrawCommissionForm: React.FC<WithdrawCommissionFormProps> = ({ pendingAmount }) => {
  const { currentUser } = useAuth();
  const { affiliate } = useAffiliate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [withdrawalType, setWithdrawalType] = useState<'percentage' | 'custom'>('percentage');
  const [selectedPercentage, setSelectedPercentage] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [bankDetails, setBankDetails] = useState({
    iban: '',
    bic: '',
    accountHolder: ''
  });

  const percentageOptions = [25, 50, 75, 100];
  const availableAmount = affiliate?.stats.availableEarnings || 0;

  const calculateAmount = (percentage: number): number => {
    return Math.floor((availableAmount * percentage) / 100);
  };

  const getWithdrawalAmount = (): number => {
    if (withdrawalType === 'percentage' && selectedPercentage) {
      return calculateAmount(selectedPercentage);
    }
    return parseFloat(customAmount) || 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setLoading(true);
    setError('');

    try {
      const amount = getWithdrawalAmount();
      
      if (amount < 50) {
        throw new Error('Le montant minimum de retrait est de 50€');
      }

      if (amount > availableAmount) {
        throw new Error('Montant invalide');
      }

      await createWithdrawal(currentUser.id, amount, bankDetails);
      // Rafraîchir les stats après le retrait
      window.location.reload();
    } catch (err: any) {
      console.error('[WithdrawCommissionForm] Erreur:', err);
      setError(err.message || 'Une erreur est survenue lors de la demande de retrait');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Wallet className="h-6 w-6 text-purple-600" />
          <h3 className="text-lg font-semibold">Retirer mes gains</h3>
        </div>
      </div>

      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm"
        >
          {error}
        </motion.div>
      )}

      <div className="bg-purple-50 p-4 rounded-lg mb-6">
        <div className="flex items-center justify-between">
          <p className="text-purple-900 font-medium">Gains disponibles</p>
          {affiliate?.stats.pendingWithdrawals > 0 && (
            <span className="text-sm text-purple-700">
              ({affiliate.stats.pendingWithdrawals.toFixed(2)}€ en attente)
            </span>
          )}
        </div>
        <p className="text-2xl font-bold text-purple-700">{availableAmount.toFixed(2)}€</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Type de retrait */}
        <div className="flex space-x-4">
          <button
            type="button"
            onClick={() => setWithdrawalType('percentage')}
            className={`flex-1 py-2 px-4 rounded-lg border-2 transition-colors ${
              withdrawalType === 'percentage'
                ? 'border-purple-500 bg-purple-50 text-purple-700'
                : 'border-gray-200 hover:border-purple-200'
            }`}
          >
            Par pourcentage
          </button>
          <button
            type="button"
            onClick={() => setWithdrawalType('custom')}
            className={`flex-1 py-2 px-4 rounded-lg border-2 transition-colors ${
              withdrawalType === 'custom'
                ? 'border-purple-500 bg-purple-50 text-purple-700'
                : 'border-gray-200 hover:border-purple-200'
            }`}
          >
            Montant personnalisé
          </button>
        </div>

        {/* Sélection du montant */}
        {withdrawalType === 'percentage' ? (
          <div className="grid grid-cols-2 gap-3">
            {percentageOptions.map((percentage) => {
              const amount = calculateAmount(percentage);
              return (
                <button
                  key={percentage}
                  type="button"
                  onClick={() => setSelectedPercentage(percentage)}
                  className={`p-4 rounded-xl border-2 transition-colors ${
                    selectedPercentage === percentage
                      ? 'border-purple-600 bg-purple-50 text-purple-600'
                      : 'border-gray-200 hover:border-purple-200'
                  }`}
                >
                  <div className="text-lg font-semibold">{percentage}%</div>
                  <div className="text-sm text-gray-500">{amount.toFixed(2)}€</div>
                </button>
              );
            })}
          </div>
        ) : (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Montant à retirer
            </label>
            <div className="relative">
              <input
                type="number"
                value={customAmount}
                onChange={(e) => setCustomAmount(e.target.value)}
                min="50"
                max={availableAmount}
                step="0.01"
                className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500"
                placeholder="Montant en €"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">€</span>
            </div>
          </div>
        )}

        {/* Coordonnées bancaires */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            IBAN
          </label>
          <input
            type="text"
            value={bankDetails.iban}
            onChange={(e) => setBankDetails({ ...bankDetails, iban: e.target.value.toUpperCase() })}
            className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="FR76..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            BIC/SWIFT
          </label>
          <input
            type="text"
            value={bankDetails.bic}
            onChange={(e) => setBankDetails({ ...bankDetails, bic: e.target.value.toUpperCase() })}
            className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="BNPAFRPP..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Titulaire du compte
          </label>
          <input
            type="text"
            value={bankDetails.accountHolder}
            onChange={(e) => setBankDetails({ ...bankDetails, accountHolder: e.target.value })}
            className="w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-purple-500"
            placeholder="Prénom NOM"
            required
          />
        </div>

        <div className="bg-gray-50 p-4 rounded-lg space-y-2">
          <div className="flex items-center text-sm text-gray-600">
            <span>Informations importantes</span>
          </div>
          <p className="text-sm text-gray-600">• Montant minimum de retrait : 50€</p>
          <p className="text-sm text-gray-600">• Délai de traitement : 1-3 jours ouvrés</p>
          <p className="text-sm text-gray-600">• Virement bancaire uniquement</p>
        </div>

        <button
          type="submit"
          disabled={loading || (withdrawalType === 'percentage' ? !selectedPercentage : !customAmount) || getWithdrawalAmount() < 50}
          className={`w-full flex items-center justify-center space-x-2 py-3 px-4 rounded-lg transition-colors ${
            !selectedPercentage && withdrawalType === 'percentage' || !customAmount && withdrawalType === 'custom'
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : 'bg-purple-600 text-white hover:bg-purple-700'
          }`}
        >
          {loading ? (
            <span className="flex items-center">
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2" />
              Traitement en cours...
            </span>
          ) : (
            <span>
              {withdrawalType === 'percentage' 
                ? selectedPercentage 
                  ? `Retirer ${calculateAmount(selectedPercentage).toFixed(2)}€ (${selectedPercentage}%)` 
                  : 'Sélectionnez un pourcentage'
                : customAmount
                  ? `Retirer ${parseFloat(customAmount).toFixed(2)}€`
                  : 'Entrez un montant'
              }
            </span>
          )}
        </button>
      </form>
    </motion.div>
  );
};

export default WithdrawCommissionForm;