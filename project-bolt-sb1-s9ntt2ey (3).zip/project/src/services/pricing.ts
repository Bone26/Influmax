import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  Timestamp,
  orderBy 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ServicePriceConfig, TelegramReactionMapping } from '../types/pricing';
import { EMOJI_JAP_MAPPING, MIXED_PACKS } from '../components/telegram/emoji/constants';

// Récupérer tous les prix
export const getAllPrices = async (): Promise<ServicePriceConfig[]> => {
  try {
    const q = query(
      collection(db, 'servicePrices'),
      orderBy('updatedAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      updatedAt: doc.data().updatedAt.toDate()
    })) as ServicePriceConfig[];
  } catch (error) {
    console.error('Error getting prices:', error);
    throw error;
  }
};

// Récupérer les prix par plateforme
export const getPricesByPlatform = async (platformId: string): Promise<ServicePriceConfig[]> => {
  try {
    const q = query(
      collection(db, 'servicePrices'),
      where('platformId', '==', platformId),
      where('isActive', '==', true)
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      updatedAt: doc.data().updatedAt.toDate()
    })) as ServicePriceConfig[];
  } catch (error) {
    console.error('Error getting platform prices:', error);
    throw error;
  }
};

// Mettre à jour un prix
export const updatePrice = async (
  id: string,
  data: Partial<ServicePriceConfig>,
  userId: string
): Promise<void> => {
  try {
    const priceRef = doc(db, 'servicePrices', id);
    await updateDoc(priceRef, {
      ...data,
      updatedAt: Timestamp.now(),
      updatedBy: userId
    });
  } catch (error) {
    console.error('Error updating price:', error);
    throw error;
  }
};

// Créer un nouveau prix
export const createPrice = async (data: Partial<ServicePriceConfig>): Promise<void> => {
  try {
    const priceRef = doc(collection(db, 'servicePrices'));
    
    // Si c'est un service de réactions Telegram, ajouter le mapping des emojis
    if (data.platformId === 'telegram' && data.serviceType === 'reactions') {
      const telegramReactions: {
        individual: TelegramReactionMapping[];
        mixedPacks: {
          positive: any;
          negative: any;
        };
      } = {
        individual: [],
        mixedPacks: {
          positive: {
            japServiceId: MIXED_PACKS.positive,
            japServiceName: 'Telegram Post Reactions + Views [Positive] [Mixed]',
            minQuantity: 100,
            maxQuantity: 100000,
            maxSpeed: 50000
          },
          negative: {
            japServiceId: MIXED_PACKS.negative,
            japServiceName: 'Telegram Post Reactions + Views [Negative] [Mixed]',
            minQuantity: 100,
            maxQuantity: 100000,
            maxSpeed: 50000
          }
        }
      };

      // Ajouter le mapping pour chaque emoji
      Object.entries(EMOJI_JAP_MAPPING).forEach(([emoji, japServiceId]) => {
        telegramReactions.individual.push({
          emoji,
          japServiceId,
          japServiceName: `Telegram Reaction (${emoji})`,
          minQuantity: 50,
          maxQuantity: 300000,
          maxSpeed: 300000
        });
      });

      data.telegramReactions = telegramReactions;
    }

    await setDoc(priceRef, {
      id: priceRef.id,
      ...data,
      updatedAt: Timestamp.now(),
      updatedBy: 'system'
    });
  } catch (error) {
    console.error('Error creating price:', error);
    throw error;
  }
};

// Calculer le prix total pour les réactions Telegram
export const calculateTelegramReactionsPrice = (
  selectedEmojis: string[],
  quantity: number,
  mode: 'custom' | 'mixed',
  priceConfig: ServicePriceConfig
): number => {
  if (!priceConfig.telegramReactions) return 0;

  if (mode === 'mixed') {
    // Prix pour un pack mixé
    const basePrice = priceConfig.basePrice;
    return quantity * basePrice;
  } else {
    // Prix pour chaque emoji sélectionné
    return selectedEmojis.reduce((total, emoji) => {
      const mapping = priceConfig.telegramReactions?.individual.find(m => m.emoji === emoji);
      if (mapping) {
        return total + (quantity * priceConfig.basePrice);
      }
      return total;
    }, 0);
  }
};