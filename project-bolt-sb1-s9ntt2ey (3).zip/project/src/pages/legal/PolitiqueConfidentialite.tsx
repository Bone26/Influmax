import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Lock } from 'lucide-react';

const PolitiqueConfidentialite = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center space-x-4">
              <Link to="/" className="text-white/80 hover:text-white">
                <ArrowLeft className="h-6 w-6" />
              </Link>
              <div className="flex items-center">
                <Lock className="h-6 w-6 text-white mr-3" />
                <h1 className="text-2xl font-bold text-white">Politique de Confidentialité</h1>
              </div>
            </div>
          </div>

          <div className="p-6 md:p-8 space-y-8">
            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">1. Introduction</h2>
              <p className="text-gray-600">
                La présente politique de confidentialité décrit la manière dont Influmax collecte,
                utilise et protège vos données personnelles lorsque vous utilisez notre site web
                et nos services. Nous accordons une grande importance à la protection de votre vie
                privée et nous nous engageons à traiter vos données personnelles de manière
                transparente et sécurisée.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">2. Données collectées</h2>
              <p className="text-gray-600 mb-4">
                Nous collectons les types de données suivants :
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600">
                <li>Données d'identification (nom, prénom, adresse email)</li>
                <li>Données de connexion (adresse IP, logs de connexion)</li>
                <li>Données de paiement (historique des transactions)</li>
                <li>Données d'utilisation (statistiques, préférences)</li>
                <li>Informations sur les commandes et services utilisés</li>
                <li>Communications avec notre service client</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">3. Utilisation des données</h2>
              <p className="text-gray-600 mb-4">
                Vos données personnelles sont utilisées pour :
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600">
                <li>Gérer votre compte et vous fournir nos services</li>
                <li>Traiter vos commandes et paiements</li>
                <li>Vous envoyer des notifications importantes</li>
                <li>Améliorer nos services et votre expérience utilisateur</li>
                <li>Prévenir la fraude et assurer la sécurité</li>
                <li>Respecter nos obligations légales</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">4. Base légale du traitement</h2>
              <p className="text-gray-600">
                Nous traitons vos données personnelles sur les bases légales suivantes :
              </p>
              <ul className="mt-4 list-disc list-inside space-y-2 text-gray-600">
                <li>L'exécution du contrat lorsque vous utilisez nos services</li>
                <li>Votre consentement pour l'envoi de communications marketing</li>
                <li>Nos obligations légales</li>
                <li>Notre intérêt légitime à protéger et améliorer nos services</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">5. Conservation des données</h2>
              <p className="text-gray-600">
                Nous conservons vos données personnelles aussi longtemps que nécessaire pour :
              </p>
              <ul className="mt-4 list-disc list-inside space-y-2 text-gray-600">
                <li>Fournir nos services et maintenir votre compte</li>
                <li>Respecter nos obligations légales et fiscales</li>
                <li>Résoudre les litiges éventuels</li>
                <li>Protéger nos droits et intérêts légitimes</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">6. Sécurité des données</h2>
              <p className="text-gray-600">
                Nous mettons en œuvre des mesures de sécurité techniques et organisationnelles
                appropriées pour protéger vos données personnelles contre tout accès non autorisé,
                modification, divulgation ou destruction. Ces mesures incluent le chiffrement des
                données, des contrôles d'accès stricts et des audits réguliers de sécurité.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">7. Partage des données</h2>
              <p className="text-gray-600 mb-4">
                Nous pouvons partager vos données personnelles avec :
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600">
                <li>Nos prestataires de services (hébergement, paiement)</li>
                <li>Les autorités compétentes lorsque la loi l'exige</li>
                <li>Nos partenaires commerciaux avec votre consentement</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">8. Vos droits</h2>
              <p className="text-gray-600 mb-4">
                Conformément au RGPD, vous disposez des droits suivants :
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-600">
                <li>Droit d'accès à vos données personnelles</li>
                <li>Droit de rectification des données inexactes</li>
                <li>Droit à l'effacement de vos données</li>
                <li>Droit à la limitation du traitement</li>
                <li>Droit à la portabilité de vos données</li>
                <li>Droit d'opposition au traitement</li>
                <li>Droit de retirer votre consentement</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">9. Cookies</h2>
              <p className="text-gray-600">
                Notre site utilise des cookies et technologies similaires pour améliorer votre
                expérience de navigation. Vous pouvez contrôler l'utilisation des cookies via
                les paramètres de votre navigateur. Pour plus d'informations, consultez notre
                politique de cookies.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">10. Transferts internationaux</h2>
              <p className="text-gray-600">
                Vos données peuvent être transférées et traitées dans des pays situés en dehors
                de l'Union européenne. Dans ce cas, nous nous assurons que ces transferts sont
                effectués conformément aux réglementations applicables en matière de protection
                des données.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">11. Contact</h2>
              <p className="text-gray-600">
                Pour toute question concernant cette politique de confidentialité ou pour exercer
                vos droits, vous pouvez nous contacter à l'adresse suivante : contact@influmax.fr
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">12. Modifications</h2>
              <p className="text-gray-600">
                Nous nous réservons le droit de modifier cette politique de confidentialité à
                tout moment. Les modifications entrent en vigueur dès leur publication sur le
                site. Nous vous encourageons à consulter régulièrement cette page pour rester
                informé des éventuelles mises à jour.
              </p>
              <p className="mt-4 text-sm text-gray-500">
                Dernière mise à jour : {new Date().toLocaleDateString('fr-FR')}
              </p>
            </section>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default PolitiqueConfidentialite;