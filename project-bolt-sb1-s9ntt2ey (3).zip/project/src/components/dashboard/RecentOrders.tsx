import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Users, ExternalLink, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getAllOrders } from '../../services/orders';
import { useAuth } from '../../contexts/AuthContext';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

const RecentOrders = () => {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadOrders = async () => {
      if (currentUser) {
        try {
          const allOrders = await getAllOrders(currentUser.id);
          // Filtrer pour n'avoir que les commandes actives (pending ou processing)
          const activeOrders = allOrders
            .filter(order => ['pending', 'processing'].includes(order.status))
            .slice(0, 5); // Limiter à 5 commandes
          setOrders(activeOrders);
        } catch (error) {
          console.error('Error loading orders:', error);
        } finally {
          setLoading(false);
        }
      }
    };

    loadOrders();
  }, [currentUser]);

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Commandes actives</h2>
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-gray-100 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-6">Commandes actives</h2>
        <div className="text-center py-8">
          <Users className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Aucune commande</h3>
          <p className="mt-1 text-sm text-gray-500">
            Commencez par commander un service pour voir vos commandes ici.
          </p>
          <div className="mt-6">
            <Link
              to="/simulateur"
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700"
            >
              Commander un service
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-6">Commandes actives</h2>
      <div className="space-y-4">
        {orders.map((order) => (
          <motion.div
            key={order.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <div className="flex flex-col md:flex-row items-center md:space-x-4 text-center md:text-left mb-3 md:mb-0">
              <div className="bg-purple-100 p-2 rounded-full mb-2 md:mb-0">
                <Clock className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">
                  {order.service.platform} - {order.service.type}
                </p>
                <p className="text-sm text-gray-500">
                  {format(new Date(order.timestamps.createdAt), 'PPP à HH:mm', { locale: fr })}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                order.status === 'processing' 
                  ? 'bg-blue-100 text-blue-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {order.status === 'processing' ? 'En cours' : 'En attente'}
              </span>
              <a
                href={order.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-gray-600"
              >
                <ExternalLink className="h-5 w-5" />
              </a>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default RecentOrders;