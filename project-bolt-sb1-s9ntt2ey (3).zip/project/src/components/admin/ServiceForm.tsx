import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Platform } from '../../types/service';
import { Check, AlertCircle, Info, Power } from 'lucide-react';

interface ServiceFormProps {
  service: any;
  platforms: Platform[];
  onSubmit: (data: any) => Promise<void>;
  onCancel: () => void;
}

const ServiceForm: React.FC<ServiceFormProps> = ({
  service,
  platforms,
  onSubmit,
  onCancel
}) => {
  const [formData, setFormData] = useState({
    name: service?.name || '',
    platformId: service?.platformId || '',
    basePrice: service?.basePrice || 0,
    minQuantity: service?.minQuantity || 100,
    maxQuantity: service?.maxQuantity || 10000,
    isActive: service?.isActive ?? true,
    deliveryLimits: service?.deliveryLimits || {
      instant: { min: 100, max: 10000 },
      '24h': { min: 150, max: 10000 },
      '3days': { min: 220, max: 10000 },
      '7days': { min: 290, max: 10000 },
      '1month': { min: 1000, max: 10000 }
    },
    qualities: service?.qualities || [
      { 
        type: 'standard', 
        multiplier: 1, 
        isAvailable: true,
        name: 'Standard',
        description: 'Idéal pour débuter',
        imageUrl: '',
        features: [
          { label: 'Profils français', value: false },
          { label: 'Profils réalistes', value: false },
          { label: 'Profils avec photo', value: true },
          { label: 'Durée de vie', value: false, info: '6-12 mois' }
        ]
      },
      { 
        type: 'premium', 
        multiplier: 1.5, 
        isAvailable: false,
        name: 'Premium',
        description: 'Les plus réalistes',
        imageUrl: '',
        features: [
          { label: 'Profils français', value: false },
          { label: 'Profils réalistes', value: true },
          { label: 'Profils avec photo', value: true },
          { label: 'Durée de vie', value: true, info: '∞' }
        ]
      },
      { 
        type: 'vip', 
        multiplier: 2, 
        isAvailable: false,
        name: 'VIP 🇫🇷',
        description: 'L\'excellence',
        imageUrl: '',
        features: [
          { label: 'Profils français', value: true },
          { label: 'Profils réalistes', value: true },
          { label: 'Profils avec photo', value: true },
          { label: 'Durée de vie', value: true, info: '∞' }
        ]
      }
    ],
    deliveryTimes: service?.deliveryTimes || [
      { type: 'instant', multiplier: 1, isAvailable: true },
      { type: '24h', multiplier: 1.1, isAvailable: true },
      { type: '3days', multiplier: 1.2, isAvailable: true },
      { type: '7days', multiplier: 1.3, isAvailable: true },
      { type: '1month', multiplier: 1.5, isAvailable: true }
    ]
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeSection, setActiveSection] = useState<string>('basic');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    // Gestion spéciale pour les nombres avec beaucoup de décimales
    if (name === 'basePrice') {
      // Permettre jusqu'à 8 décimales pour le prix de base
      const numValue = parseFloat(value);
      if (!isNaN(numValue)) {
        setFormData(prev => ({
          ...prev,
          [name]: numValue
        }));
      }
      return;
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? (value === '' ? 0 : parseFloat(value)) : value
    }));
  };

  const handleDeliveryLimitChange = (
    deliveryTime: string,
    field: 'min' | 'max',
    value: string
  ) => {
    const numValue = parseInt(value, 10);
    if (isNaN(numValue)) return;

    setFormData(prev => ({
      ...prev,
      deliveryLimits: {
        ...prev.deliveryLimits,
        [deliveryTime]: {
          ...prev.deliveryLimits[deliveryTime],
          [field]: numValue
        }
      }
    }));
  };

  const handleQualityChange = (quality: string, field: 'multiplier' | 'isAvailable' | 'name' | 'description' | 'imageUrl', value: any) => {
    setFormData(prev => ({
      ...prev,
      qualities: prev.qualities.map(q => 
        q.type === quality ? { 
          ...q, 
          [field]: field === 'multiplier' ? (value === '' ? 1 : parseFloat(value)) : value 
        } : q
      )
    }));
  };

  const handleFeatureChange = (quality: string, featureIndex: number, field: 'label' | 'value' | 'info', value: any) => {
    setFormData(prev => ({
      ...prev,
      qualities: prev.qualities.map(q => 
        q.type === quality ? {
          ...q,
          features: q.features.map((f, i) => 
            i === featureIndex ? { ...f, [field]: value } : f
          )
        } : q
      )
    }));
  };

  const handleDeliveryTimeChange = (time: string, field: 'multiplier' | 'isAvailable', value: any) => {
    setFormData(prev => ({
      ...prev,
      deliveryTimes: prev.deliveryTimes.map(t => 
        t.type === time ? { 
          ...t, 
          [field]: field === 'multiplier' ? (value === '' ? 1 : parseFloat(value)) : value 
        } : t
      )
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onSubmit(formData);
    } catch (err) {
      setError('Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  };

  const sections = [
    { id: 'basic', label: 'Informations de base' },
    { id: 'qualities', label: 'Qualités' },
    { id: 'delivery', label: 'Temps de livraison' }
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Navigation des sections */}
      <div className="flex space-x-2 p-2 bg-gray-50 rounded-xl">
        {sections.map((section) => (
          <button
            key={section.id}
            type="button"
            onClick={() => setActiveSection(section.id)}
            className={`flex-1 px-4 py-2 rounded-lg transition-all ${
              activeSection === section.id
                ? 'bg-white shadow-sm text-purple-600 font-medium'
                : 'text-gray-600 hover:bg-white/50'
            }`}
          >
            {section.label}
          </button>
        ))}
      </div>

      {/* Section Informations de base */}
      <motion.div
        initial={false}
        animate={{ height: activeSection === 'basic' ? 'auto' : 0, opacity: activeSection === 'basic' ? 1 : 0 }}
        className={`space-y-6 overflow-hidden ${activeSection !== 'basic' ? 'hidden' : ''}`}
      >
        {/* Statut du service */}
        <div className="bg-gray-50 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-lg ${formData.isActive ? 'bg-green-100' : 'bg-red-100'}`}>
              <Power className={`h-5 w-5 ${formData.isActive ? 'text-green-600' : 'text-red-600'}`} />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">Statut du service</h3>
              <p className="text-sm text-gray-500">
                {formData.isActive ? 'Service actif' : 'Service désactivé'}
              </p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={formData.isActive}
              onChange={(e) => setFormData(prev => ({ ...prev, isActive: e.target.checked }))}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
          </label>
        </div>

        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Nom du service
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Plateforme
            </label>
            <select
              name="platformId"
              value={formData.platformId}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              required
            >
              <option value="">Sélectionner une plateforme</option>
              {platforms.map(platform => (
                <option key={platform.id} value={platform.id}>
                  {platform.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Prix de base (€)
          </label>
          <div className="relative">
            <input
              type="number"
              name="basePrice"
              value={formData.basePrice}
              onChange={handleChange}
              step="0.00000001"
              min="0"
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              required
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <Info className="h-4 w-4 text-gray-400" />
            </div>
          </div>
        </div>

        {/* Limites de quantité par durée d'envoi */}
        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            Limites de quantité par durée d'envoi
          </h3>
          <div className="space-y-4">
            {Object.entries(formData.deliveryLimits).map(([deliveryTime, limits]) => (
              <div key={deliveryTime} className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {deliveryTime === 'instant' ? 'Instantané' :
                     deliveryTime === '24h' ? '24 heures' :
                     deliveryTime === '3days' ? '3 jours' :
                     deliveryTime === '7days' ? '7 jours' : '1 mois'} - Min
                  </label>
                  <input
                    type="number"
                    value={limits.min}
                    onChange={(e) => handleDeliveryLimitChange(deliveryTime, 'min', e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                    min="1"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {deliveryTime === 'instant' ? 'Instantané' :
                     deliveryTime === '24h' ? '24 heures' :
                     deliveryTime === '3days' ? '3 jours' :
                     deliveryTime === '7days' ? '7 jours' : '1 mois'} - Max
                  </label>
                  <input
                    type="number"
                    value={limits.max}
                    onChange={(e) => handleDeliveryLimitChange(deliveryTime, 'max', e.target.value)}
                    className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                    min="1"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Section Qualités */}
      <motion.div
        initial={false}
        animate={{ height: activeSection === 'qualities' ? 'auto' : 0, opacity: activeSection === 'qualities' ? 1 : 0 }}
        className={`space-y-6 overflow-hidden ${activeSection !== 'qualities' ? 'hidden' : ''}`}
      >
        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-6">Qualités disponibles</h3>
          <div className="space-y-6">
            {formData.qualities.map((quality) => (
              <div
                key={quality.type}
                className="bg-white rounded-xl p-6 border border-gray-200 hover:border-purple-200 transition-colors"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      quality.isAvailable ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
                    }`}>
                      <Check className="h-5 w-5" />
                    </div>
                    <h4 className="text-lg font-medium capitalize">{quality.type}</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={quality.isAvailable}
                      onChange={(e) => handleQualityChange(quality.type, 'isAvailable', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                  </label>
                </div>

                {quality.isAvailable && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Nom affiché
                      </label>
                      <input
                        type="text"
                        value={quality.name}
                        onChange={(e) => handleQualityChange(quality.type, 'name', e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <input
                        type="text"
                        value={quality.description}
                        onChange={(e) => handleQualityChange(quality.type, 'description', e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        URL de l'image
                      </label>
                      <input
                        type="url"
                        value={quality.imageUrl}
                        onChange={(e) => handleQualityChange(quality.type, 'imageUrl', e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                        placeholder="https://..."
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Multiplicateur de prix
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        min="1"
                        value={quality.multiplier}
                        onChange={(e) => handleQualityChange(quality.type, 'multiplier', e.target.value)}
                        className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Caractéristiques
                      </label>
                      <div className="space-y-3">
                        {quality.features.map((feature, index) => (
                          <div key={index} className="flex items-center space-x-4">
                            <input
                              type="text"
                              value={feature.label}
                              onChange={(e) => handleFeatureChange(quality.type, index, 'label', e.target.value)}
                              className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                            />
                            <label className="inline-flex items-center">
                              <input
                                type="checkbox"
                                checked={feature.value}
                                onChange={(e) => handleFeatureChange(quality.type, index, 'value', e.target.checked)}
                                className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                              />
                              <span className="ml-2 text-sm text-gray-600">Activé</span>
                            </label>
                            {feature.info !== undefined && (
                              <input
                                type="text"
                                value={feature.info}
                                onChange={(e) => handleFeatureChange(quality.type, index, 'info', e.target.value)}
                                className="w-32 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                                placeholder="Info"
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Section Temps de livraison */}
      <motion.div
        initial={false}
        animate={{ height: activeSection === 'delivery' ? 'auto' : 0, opacity: activeSection === 'delivery' ? 1 : 0 }}
        className={`space-y-6 overflow-hidden ${activeSection !== 'delivery' ? 'hidden' : ''}`}
      >
        <div className="bg-gray-50 rounded-xl p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-6">Temps de livraison disponibles</h3>
          <div className="space-y-6">
            {formData.deliveryTimes.map((time) => (
              <div
                key={time.type}
                className="bg-white rounded-xl p-6 border border-gray-200 hover:border-purple-200 transition-colors"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${
                      time.isAvailable ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
                    }`}>
                      <Check className="h-5 w-5" />
                    </div>
                    <h4 className="text-lg font-medium">{time.type}</h4>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={time.isAvailable}
                      onChange={(e) => handleDeliveryTimeChange(time.type, 'isAvailable', e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                  </label>
                </div>

                {time.isAvailable && (
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Multiplicateur de prix
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="1"
                      value={time.multiplier}
                      onChange={(e) => handleDeliveryTimeChange(time.type, 'multiplier', e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Boutons d'action */}
      <div className="flex justify-end space-x-4 pt-6 border-t">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-3 text-gray-700 hover:text-gray-900 font-medium rounded-xl hover:bg-gray-50 transition-colors"
        >
          Annuler
        </button>
        <button
          type="submit"
          disabled={loading}
          className="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 disabled:opacity-50 font-medium transition-colors"
        >
          {loading ? (
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
              <span>Enregistrement...</span>
            </div>
          ) : (
            'Enregistrer'
          )}
        </button>
      </div>
    </form>
  );
};

export default ServiceForm;