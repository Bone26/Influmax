import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Instagram, Music2, MessageCircle, Gift, Users, Rocket, Shield, Clock, ArrowRight, Wallet, TrendingUp, Check } from 'lucide-react';
import { platformStyles } from '../config/platformStyles';
import Footer from '../components/Footer';

const Services = () => {
  const [selectedPlatform, setSelectedPlatform] = useState('all');

  const platforms = [
    { 
      id: 'instagram', 
      name: 'Instagram', 
      icon: Instagram,
      styles: platformStyles.instagram,
      services: ['Abonnés', 'Likes', 'Vues']
    },
    { 
      id: 'tiktok', 
      name: 'TikTok', 
      icon: Music2,
      styles: platformStyles.tiktok,
      services: ['Abonnés', 'Likes', 'Vues', 'Partages', 'Enregistrements']
    },
    { 
      id: 'telegram', 
      name: 'Telegram', 
      icon: MessageCircle,
      styles: platformStyles.telegram,
      services: ['Membres', 'Réactions', 'Vues', 'Votes sondage']
    }
  ];

  const features = [
    {
      icon: Shield,
      title: "100% Sécurisé",
      description: "Aucun mot de passe requis",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      icon: Clock,
      title: "Livraison Express",
      description: "Résultats visibles en quelques heures",
      gradient: "from-purple-500 to-pink-500"
    }
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <div className="flex-grow">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-purple-600 to-indigo-600 text-white py-24">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557264322-b44d383a2906?auto=format&fit=crop&q=80')] opacity-10 bg-center bg-cover"></div>
            <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent"></div>
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Solutions de croissance
                <span className="block mt-2 bg-gradient-to-r from-purple-200 to-pink-200 bg-clip-text text-transparent">
                  pour votre audience.
                </span>
              </h1>
              <p className="text-xl text-purple-100 max-w-3xl mx-auto mb-12">
                Découvrez nos services premium pour développer votre présence sociale.
                <span className="block mt-2 font-semibold">Résultats garantis sans donner vos accès.</span>
              </p>

              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Link
                  to="/auth/register"
                  className="group bg-white text-purple-600 hover:bg-purple-50 px-8 py-4 rounded-full font-bold text-lg inline-flex items-center justify-center transition-all duration-300 transform hover:scale-105"
                >
                  <Gift className="mr-2 h-5 w-5" />
                  10€ offerts à l'inscription
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
                <Link
                  to="/simulateur"
                  className="group border-2 border-white text-white hover:bg-white/10 px-8 py-4 rounded-full font-bold text-lg inline-flex items-center justify-center transition-all duration-300"
                >
                  Simuler un service
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </div>
            </motion.div>

            {/* Les 3 cartes principales */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 flex flex-col items-center justify-center text-center"
              >
                <Users className="h-8 w-8 text-purple-200 mb-4" />
                <h3 className="text-3xl font-bold mb-2">5k+</h3>
                <p className="text-purple-100">Clients satisfaits</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 flex flex-col items-center justify-center text-center"
              >
                <TrendingUp className="h-8 w-8 text-purple-200 mb-4" />
                <h3 className="text-3xl font-bold mb-2">1M+</h3>
                <p className="text-purple-100">Interactions livrées</p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20 flex flex-col items-center justify-center text-center"
              >
                <Wallet className="h-8 w-8 text-purple-200 mb-4" />
                <h3 className="text-3xl font-bold mb-2">30%</h3>
                <p className="text-purple-100">Commission d'affiliation</p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Section Plateformes */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Nos services par plateforme
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Des solutions adaptées à chaque réseau social
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {platforms.map((platform, index) => (
                <motion.div
                  key={platform.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-2xl shadow-xl overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl"
                >
                  <div className={`bg-gradient-to-r ${platform.styles.gradients.primary} p-6`}>
                    <platform.icon className="h-8 w-8 text-white mb-4" />
                    <h3 className="text-2xl font-bold text-white mb-2">{platform.name}</h3>
                  </div>
                  <div className="p-6">
                    <ul className="space-y-3">
                      {platform.services.map((service, i) => (
                        <li key={i} className="flex items-center text-gray-700">
                          <Check className="h-5 w-5 text-green-500 mr-2" />
                          {service}
                        </li>
                      ))}
                    </ul>
                    <Link
                      to="/simulateur"
                      className={`mt-6 w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-gradient-to-r ${platform.styles.gradients.primary} hover:opacity-90 transition-opacity`}
                    >
                      Voir les tarifs
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Section Caractéristiques */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Pourquoi nous choisir ?
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Des services de qualité, une livraison rapide et un support réactif
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 text-center"
                >
                  <div className={`bg-gradient-to-r ${feature.gradient} p-4 rounded-xl inline-block mb-6 mx-auto`}>
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Final */}
        <section className="py-24 bg-gradient-to-br from-purple-600 to-indigo-600 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-3xl mx-auto"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Prêt à booster votre présence sociale ?
              </h2>
              <p className="text-xl text-purple-100 mb-8">
                Inscrivez-vous maintenant et recevez 10€ offerts pour votre premier dépôt de 50€ ou plus !
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Link
                  to="/auth/register"
                  className="group bg-white text-purple-600 hover:bg-purple-50 px-8 py-4 rounded-full font-bold text-lg inline-flex items-center justify-center transition-all duration-300 transform hover:scale-105"
                >
                  <Gift className="mr-2 h-5 w-5" />
                  Créer mon compte
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
                <Link
                  to="/simulateur"
                  className="group border-2 border-white text-white hover:bg-white/10 px-8 py-4 rounded-full font-bold text-lg inline-flex items-center justify-center transition-all duration-300"
                >
                  Simuler un service
                  <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default Services;