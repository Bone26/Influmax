import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ArrowDownLeft, Gift, ShoppingBag } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Transaction } from '../../types/wallet';

interface TransactionHistoryProps {
  transactions: Transaction[];
  loading: boolean;
}

const TransactionHistory: React.FC<TransactionHistoryProps> = ({ transactions, loading }) => {
  if (loading) {
    return (
      <div className="animate-pulse space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-16 bg-gray-100 rounded-lg" />
        ))}
      </div>
    );
  }

  // Statistiques
  const stats = {
    deposits: transactions
      .filter(tx => tx.type === 'deposit')
      .reduce((sum, tx) => sum + tx.amount, 0),
    orders: Math.abs(transactions
      .filter(tx => tx.type === 'order')
      .reduce((sum, tx) => sum + tx.amount, 0)),
    refunds: transactions
      .filter(tx => tx.type === 'refund')
      .reduce((sum, tx) => sum + tx.amount, 0)
  };

  return (
    <div className="space-y-4">
      {/* Statistiques */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-green-50 p-3 rounded-lg">
          <div className="text-sm text-green-600">Total dépôts</div>
          <div className="text-lg font-semibold text-green-700">
            {stats.deposits.toFixed(2)}€
          </div>
        </div>
        <div className="bg-red-50 p-3 rounded-lg">
          <div className="text-sm text-red-600">Total commandes</div>
          <div className="text-lg font-semibold text-red-700">
            {stats.orders.toFixed(2)}€
          </div>
        </div>
        <div className="bg-green-50 p-3 rounded-lg">
          <div className="text-sm text-green-600">Total remboursements</div>
          <div className="text-lg font-semibold text-green-700">
            {stats.refunds.toFixed(2)}€
          </div>
        </div>
      </div>

      {/* Liste des transactions */}
      {transactions.length === 0 ? (
        <div className="text-center py-8">
          <Gift className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Aucune transaction</h3>
          <p className="mt-1 text-sm text-gray-500">
            Commencez par effectuer un dépôt pour voir vos transactions ici.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {transactions.map((transaction) => {
            const isPositive = transaction.amount > 0;
            const Icon = transaction.type === 'order' ? ShoppingBag :
                        transaction.type === 'bonus' ? Gift :
                        isPositive ? ArrowUpRight : ArrowDownLeft;

            return (
              <motion.div
                key={transaction.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className={`p-2 rounded-lg ${
                      transaction.type === 'order' ? 'bg-red-100 text-red-600' :
                      transaction.type === 'refund' ? 'bg-green-100 text-green-600' :
                      'bg-green-100 text-green-600'
                    }`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">
                        {transaction.description || (
                          transaction.type === 'deposit' ? 'Dépôt' :
                          transaction.type === 'order' ? 'Commande' :
                          transaction.type === 'refund' ? 'Remboursement' :
                          'Transaction'
                        )}
                      </p>
                      <p className="text-sm text-gray-500">
                        {format(new Date(transaction.createdAt), 'PPP à HH:mm', { locale: fr })}
                      </p>
                    </div>
                  </div>
                  <span className={`font-semibold ${
                    transaction.type === 'order' ? 'text-red-600' :
                    transaction.type === 'refund' ? 'text-green-600' :
                    'text-green-600'
                  }`}>
                    {isPositive ? '+' : ''}{transaction.amount.toFixed(2)}€
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default TransactionHistory;