import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, ArrowRight, RefreshCw } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { resendVerificationEmail, checkEmailVerification } from '../../services/auth';
import { toast } from 'sonner';

const VerifyEmail = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [sending, setSending] = useState(false);
  const [checking, setChecking] = useState(false);
  const [hasShownSuccess, setHasShownSuccess] = useState(false);

  useEffect(() => {
    // Si l'utilisateur n'est pas connecté, rediriger vers la connexion
    if (!currentUser) {
      navigate('/auth/login');
      return;
    }

    // Si l'email est déjà vérifié, rediriger vers le dashboard
    if (currentUser.emailVerified) {
      navigate('/dashboard');
      return;
    }

    // Vérifier immédiatement au chargement
    checkVerification();

    // Vérifier toutes les 5 secondes
    const interval = setInterval(checkVerification, 5000);

    // Nettoyer l'intervalle quand le composant est démonté
    return () => {
      clearInterval(interval);
      setHasShownSuccess(false); // Réinitialiser l'état
    };
  }, [currentUser, navigate]);

  const checkVerification = async () => {
    if (!currentUser || checking) return;

    setChecking(true);
    try {
      const isVerified = await checkEmailVerification();
      
      if (isVerified && !hasShownSuccess) {
        setHasShownSuccess(true);
        toast.success('Email vérifié avec succès !');
        // Rediriger après un court délai pour laisser le temps de voir le message
        setTimeout(() => {
          navigate('/dashboard');
        }, 1500);
      }
    } catch (error) {
      console.error('Error checking verification:', error);
    } finally {
      setChecking(false);
    }
  };

  const handleResend = async () => {
    if (sending) return;
    
    setSending(true);
    try {
      await resendVerificationEmail();
    } finally {
      setSending(false);
    }
  };

  // Si l'utilisateur n'est pas connecté, ne rien afficher
  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <Link to="/" className="flex justify-center mb-6">
          <img 
            src="https://i.imgur.com/b9jRROr.png" 
            alt="Logo" 
            className="h-12"
          />
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white py-8 px-4 shadow-xl sm:rounded-xl sm:px-10 border border-purple-100"
        >
          <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-purple-100 mb-6">
              <Mail className="h-8 w-8 text-purple-600" />
            </div>
            
            <h2 className="text-3xl font-extrabold text-gray-900 mb-4">
              Vérifiez votre email
            </h2>
            
            <div className="bg-purple-50 rounded-xl p-4 mb-6">
              <p className="text-purple-900">
                Un email de vérification a été envoyé à{' '}
                <span className="font-semibold">{currentUser.email}</span>
              </p>
            </div>

            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-xl">
                <h3 className="text-sm font-medium text-gray-900 mb-2">Instructions :</h3>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li className="flex items-center">
                    <span className="flex-shrink-0 w-5 h-5 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 mr-2">1</span>
                    Vérifiez votre boîte de réception
                  </li>
                  <li className="flex items-center">
                    <span className="flex-shrink-0 w-5 h-5 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 mr-2">2</span>
                    Vérifiez également vos spams si nécessaire
                  </li>
                  <li className="flex items-center">
                    <span className="flex-shrink-0 w-5 h-5 flex items-center justify-center rounded-full bg-purple-100 text-purple-600 mr-2">3</span>
                    Cliquez sur le lien de vérification dans l'email
                  </li>
                </ul>
              </div>

              <div className="flex flex-col space-y-3">
                <button
                  onClick={handleResend}
                  disabled={sending || checking}
                  className="flex items-center justify-center px-4 py-3 border border-transparent text-sm font-medium rounded-xl text-white bg-gradient-to-r from-purple-600 to-indigo-600 hover:opacity-90 disabled:opacity-50 transition-all duration-300 transform hover:scale-105"
                >
                  {sending ? (
                    <>
                      <RefreshCw className="animate-spin h-5 w-5 mr-2" />
                      Envoi en cours...
                    </>
                  ) : (
                    <>
                      <Mail className="h-5 w-5 mr-2" />
                      Renvoyer l'email de vérification
                    </>
                  )}
                </button>

                <button
                  onClick={checkVerification}
                  disabled={checking || sending}
                  className="flex items-center justify-center px-4 py-2 text-sm font-medium text-purple-600 hover:text-purple-700 group"
                >
                  {checking ? (
                    <>
                      <RefreshCw className="animate-spin h-5 w-5 mr-2" />
                      Vérification...
                    </>
                  ) : (
                    <>
                      Vérifier maintenant
                      <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default VerifyEmail;