import React from 'react';
import { TrendingUp, Shield, Clock, Headphones } from 'lucide-react';

export const features = [
  {
    icon: TrendingUp,
    title: "Crédibilité Sociale",
    description: "Nos services vous permettent d'acheter votre crédibilité digitale afin d'atteindre plus facilement vos objectifs.",
    gradient: "from-pink-500 to-rose-500"
  },
  {
    icon: Shield,
    title: "100% Sécurisé",
    description: "Aucun mot de passe requis, un simple lien suffit.",
    gradient: "from-blue-500 to-cyan-500"
  },
  {
    icon: Clock,
    title: "Livraison Rapide",
    description: "Résultats visibles en quelques heures. Vous choisissez vous-même votre délai de livraison.",
    gradient: "from-purple-500 to-indigo-500"
  },
  {
    icon: Headphones,
    title: "Besoin d'aide ?",
    description: "Support client disponible 24/7 pour vous accompagner !",
    gradient: "from-green-500 to-emerald-500"
  }
];

const FeaturesList = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
      {features.map((feature, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 }}
          className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
        >
          <div className={`bg-gradient-to-r ${feature.gradient} p-4 rounded-xl inline-block mb-4`}>
            <feature.icon className="h-6 w-6 text-white" />
          </div>
          <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
          <p className="text-gray-600">{feature.description}</p>
        </motion.div>
      ))}
    </div>
  );
};

export default FeaturesList;