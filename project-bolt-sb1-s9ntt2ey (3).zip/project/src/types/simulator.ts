export interface SimulatorFormData {
  platform: 'instagram' | 'tiktok' | 'telegram';
  service: string;
  quantity: number | '';
  quality: string;
  deliveryTime: string;
}

export interface SimulatorPaymentData extends SimulatorFormData {
  selectedEmojis: string[];
}