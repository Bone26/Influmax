import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

interface Step {
  id: string;
  label: string;
  description: string;
}

interface ProgressStepsProps {
  currentStep: number;
  steps: Step[];
}

const ProgressSteps: React.FC<ProgressStepsProps> = ({ currentStep, steps }) => {
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4">
        <nav aria-label="Progress">
          <ol className="flex items-center justify-between">
            {steps.map((step, index) => (
              <li key={step.id} className="relative">
                {index !== 0 && (
                  <div 
                    className="absolute left-0 top-1/2 h-0.5 w-full -translate-x-full -translate-y-1/2"
                    aria-hidden="true"
                  >
                    <div
                      className={`h-full transition-colors ${
                        index <= currentStep ? 'bg-purple-600' : 'bg-gray-200'
                      }`}
                    />
                  </div>
                )}

                <div className="relative flex flex-col items-center group">
                  <span className="h-9 flex items-center">
                    <span className={`
                      relative z-10 w-8 h-8 flex items-center justify-center rounded-full
                      transition-colors
                      ${
                        index < currentStep
                          ? 'bg-purple-600 text-white'
                          : index === currentStep
                            ? 'border-2 border-purple-600 bg-white text-purple-600'
                            : 'border-2 border-gray-300 bg-white text-gray-500'
                      }
                    `}>
                      {index < currentStep ? (
                        <Check className="h-5 w-5" />
                      ) : (
                        <span>{index + 1}</span>
                      )}
                    </span>
                  </span>

                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute top-14 hidden md:block"
                  >
                    <span className="block text-sm font-medium text-gray-900">
                      {step.label}
                    </span>
                    <span className="block text-xs text-gray-500">
                      {step.description}
                    </span>
                  </motion.div>
                </div>
              </li>
            ))}
          </ol>
        </nav>
      </div>
    </div>
  );
};

export default ProgressSteps;