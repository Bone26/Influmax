import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Music2, MessageCircle } from 'lucide-react';

const ServicesHeader = () => {
  return (
    <section className="relative overflow-hidden py-24 bg-gradient-to-br from-purple-600 to-indigo-600">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557264322-b44d383a2906?auto=format&fit=crop&q=80')] opacity-10 bg-center bg-cover"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <div className="flex justify-center space-x-4 mb-8">
            <Instagram className="h-8 w-8 text-white" />
            <Music2 className="h-8 w-8 text-white" />
            <MessageCircle className="h-8 w-8 text-white" />
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white">
            Nos Services
          </h1>
          <p className="text-xl text-purple-100 max-w-3xl mx-auto">
            Des solutions sur mesure pour développer votre présence sociale
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default ServicesHeader;