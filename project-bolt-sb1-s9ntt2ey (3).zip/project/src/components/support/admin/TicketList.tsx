import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { MessageSquare, AlertCircle, Clock, CheckCircle, XCircle, ExternalLink } from 'lucide-react';
import { Ticket } from '../../../types/ticket';
import { updateTicketStatus } from '../../../services/tickets';
import { toast } from 'sonner';

interface TicketListProps {
  tickets: Ticket[];
  loading: boolean;
  selectedTicketId?: string;
  onSelectTicket: (ticket: Ticket) => void;
}

const TicketList: React.FC<TicketListProps> = ({
  tickets,
  loading,
  selectedTicketId,
  onSelectTicket
}) => {
  const getStatusConfig = (status: Ticket['status']) => {
    switch (status) {
      case 'open':
        return {
          icon: AlertCircle,
          color: 'text-yellow-600',
          bg: 'bg-yellow-100',
          text: 'En attente'
        };
      case 'processing':
        return {
          icon: Clock,
          color: 'text-blue-600',
          bg: 'bg-blue-100',
          text: 'En cours'
        };
      case 'resolved':
        return {
          icon: CheckCircle,
          color: 'text-green-600',
          bg: 'bg-green-100',
          text: 'Résolu'
        };
      case 'closed':
        return {
          icon: XCircle,
          color: 'text-gray-600',
          bg: 'bg-gray-100',
          text: 'Fermé'
        };
      default:
        return {
          icon: MessageSquare,
          color: 'text-gray-600',
          bg: 'bg-gray-100',
          text: status
        };
    }
  };

  const getCategoryText = (category: Ticket['category']) => {
    switch (category) {
      case 'order':
        return 'Commande';
      case 'deposit':
        return 'Dépôt';
      case 'withdrawal':
        return 'Retrait';
      case 'affiliate':
        return 'Affiliation';
      case 'technical':
        return 'Technique';
      case 'other':
        return 'Autre';
      default:
        return category;
    }
  };

  const handleStatusChange = async (ticketId: string, newStatus: Ticket['status']) => {
    try {
      await updateTicketStatus(ticketId, newStatus);
      toast.success('Statut du ticket mis à jour');
    } catch (error) {
      console.error('Error updating ticket status:', error);
      toast.error('Erreur lors de la mise à jour du statut');
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="bg-white rounded-lg p-4 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }

  if (tickets.length === 0) {
    return (
      <div className="text-center py-12">
        <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900">Aucun ticket</h3>
        <p className="mt-2 text-gray-500">
          Aucun ticket ne correspond aux critères sélectionnés
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-2">
      {tickets.map((ticket) => {
        const statusConfig = getStatusConfig(ticket.status);
        const StatusIcon = statusConfig.icon;

        return (
          <motion.div
            key={ticket.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`w-full text-left p-4 rounded-lg transition-all ${
              selectedTicketId === ticket.id
                ? 'bg-purple-50 border-2 border-purple-200'
                : 'bg-white hover:bg-gray-50 border border-gray-200'
            }`}
            onClick={() => onSelectTicket(ticket)}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <h3 className="text-sm font-medium text-gray-900 truncate">
                    {ticket.subject}
                  </h3>
                  {ticket.unreadCount > 0 && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800">
                      {ticket.unreadCount} {ticket.unreadCount === 1 ? 'nouveau' : 'nouveaux'}
                    </span>
                  )}
                </div>
                <div className="mt-1 flex items-center space-x-2 text-sm text-gray-500">
                  <span className="truncate">#{ticket.id.slice(0, 8)}</span>
                  <span>•</span>
                  <span>{format(ticket.createdAt, 'PPp', { locale: fr })}</span>
                </div>
              </div>

              <div className="flex items-center space-x-2 ml-4">
                <select
                  value={ticket.status}
                  onChange={(e) => handleStatusChange(ticket.id, e.target.value as Ticket['status'])}
                  className={`px-2 py-1 rounded-full text-xs font-medium ${statusConfig.bg} ${statusConfig.color} border-none focus:ring-2 focus:ring-purple-500`}
                  onClick={(e) => e.stopPropagation()}
                >
                  <option value="open">En attente</option>
                  <option value="processing">En cours</option>
                  <option value="resolved">Résolu</option>
                  <option value="closed">Fermé</option>
                </select>
                <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                  {getCategoryText(ticket.category)}
                </span>
                {ticket.orderId && (
                  <ExternalLink className="h-4 w-4 text-gray-400" />
                )}
              </div>
            </div>

            {ticket.lastMessage && (
              <div className="mt-2 text-sm text-gray-600 line-clamp-1">
                <span className="font-medium">{ticket.lastMessage.content}</span>
              </div>
            )}
          </motion.div>
        );
      })}
    </div>
  );
};

export default TicketList;