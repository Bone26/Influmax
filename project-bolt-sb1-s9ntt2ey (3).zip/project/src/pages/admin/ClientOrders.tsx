import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Search, Filter, Download, ExternalLink, Users, Clock, Check, X } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getAllOrders } from '../../services/orders';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

const ClientOrders = () => {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState<string | null>(null);
  const [clientsData, setClientsData] = useState<{[key: string]: {name: string, email: string}}>({});

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const allOrders = await getAllOrders('admin');
      setOrders(allOrders);

      // Charger les données des clients
      const uniqueUserIds = [...new Set(allOrders.map(order => order.userId))];
      const clientsInfo: {[key: string]: {name: string, email: string}} = {};
      
      await Promise.all(uniqueUserIds.map(async (userId) => {
        const userDoc = await getDoc(doc(db, 'users', userId));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          clientsInfo[userId] = {
            name: userData.name || 'Utilisateur inconnu',
            email: userData.email || 'Email inconnu'
          };
        }
      }));

      setClientsData(clientsInfo);
    } catch (error) {
      console.error('Error loading data:', error);
      setError('Erreur lors du chargement des données');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return {
          icon: Check,
          color: 'bg-green-100 text-green-800 border-green-200',
          text: 'Terminé'
        };
      case 'processing':
        return {
          icon: Clock,
          color: 'bg-blue-100 text-blue-800 border-blue-200',
          text: 'En cours'
        };
      case 'cancelled':
        return {
          icon: X,
          color: 'bg-red-100 text-red-800 border-red-200',
          text: 'Annulé'
        };
      default:
        return {
          icon: Clock,
          color: 'bg-gray-100 text-gray-800 border-gray-200',
          text: status
        };
    }
  };

  // Regrouper les commandes par client
  const clientOrders = orders.reduce((acc, order) => {
    if (!acc[order.userId]) {
      acc[order.userId] = {
        orders: [],
        totalSpent: 0,
        lastOrder: null
      };
    }
    acc[order.userId].orders.push(order);
    acc[order.userId].totalSpent += order.price;
    if (!acc[order.userId].lastOrder || new Date(order.timestamps.createdAt) > new Date(acc[order.userId].lastOrder.timestamps.createdAt)) {
      acc[order.userId].lastOrder = order;
    }
    return acc;
  }, {} as Record<string, { orders: any[]; totalSpent: number; lastOrder: any; }>);

  const handleExport = () => {
    try {
      const csvContent = [
        ['Client ID', 'Nom', 'Email', 'Commandes totales', 'Montant total', 'Dernière commande'].join(','),
        ...Object.entries(clientOrders).map(([userId, data]) => [
          userId,
          clientsData[userId]?.name || 'Inconnu',
          clientsData[userId]?.email || 'Inconnu',
          data.orders.length,
          data.totalSpent.toFixed(2),
          format(new Date(data.lastOrder.timestamps.createdAt), 'yyyy-MM-dd HH:mm:ss')
        ].join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `clients-${format(new Date(), 'yyyy-MM-dd')}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting client data:', error);
      toast.error('Erreur lors de l\'export');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex flex-col space-y-4">
              <div className="flex items-center justify-between">
                <Link to="/admin" className="text-white/80 hover:text-white">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div className="text-sm text-white/80">
                  {Object.keys(clientOrders).length} client{Object.keys(clientOrders).length !== 1 ? 's' : ''}
                </div>
              </div>
              <div className="flex items-center justify-between">
                <h1 className="text-2xl font-bold text-white">Commandes par client</h1>
                <button
                  onClick={handleExport}
                  className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors"
                >
                  <Download className="h-5 w-5" />
                  <span>Export CSV</span>
                </button>
              </div>
            </div>
          </div>

          {/* Search */}
          <div className="p-4 bg-gray-50 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Rechercher un client..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          {/* Client List */}
          <div className="p-4">
            <div className="grid gap-4">
              {Object.entries(clientOrders).map(([userId, data]) => (
                <motion.div
                  key={userId}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="bg-white rounded-lg border shadow-sm hover:shadow-md transition-shadow p-4"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {clientsData[userId]?.name || 'Client inconnu'}
                      </h3>
                      <p className="text-sm text-gray-500">
                        {clientsData[userId]?.email || 'Email inconnu'}
                      </p>
                      <p className="text-sm text-gray-500 mt-1">
                        {data.orders.length} commande{data.orders.length !== 1 ? 's' : ''}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-500">Total dépensé</p>
                      <p className="text-lg font-semibold text-purple-600">
                        {data.totalSpent.toFixed(2)}€
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Dernière commande</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Service</p>
                          <p className="font-medium">{data.lastOrder.service?.japServiceName}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Date</p>
                          <p className="font-medium">
                            {format(new Date(data.lastOrder.timestamps.createdAt), 'PPp', { locale: fr })}
                          </p>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedClient(selectedClient === userId ? null : userId)}
                      className="w-full text-left text-sm text-purple-600 hover:text-purple-700"
                    >
                      {selectedClient === userId ? 'Masquer les commandes' : 'Voir toutes les commandes'}
                    </button>

                    {selectedClient === userId && (
                      <div className="space-y-2">
                        {data.orders.map((order) => {
                          const statusConfig = getStatusBadge(order.status);
                          const StatusIcon = statusConfig.icon;
                          
                          return (
                            <div key={order.id} className="bg-gray-50 p-3 rounded-lg text-sm">
                              <div className="flex justify-between items-center">
                                <span className="font-medium">#{order.id}</span>
                                <span className="text-gray-500">
                                  {format(new Date(order.timestamps.createdAt), 'PPp', { locale: fr })}
                                </span>
                              </div>
                              <div className="mt-2 grid grid-cols-2 gap-2">
                                <div>
                                  <span className="text-gray-500">Service: </span>
                                  <span>{order.service?.japServiceName}</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Prix: </span>
                                  <span>{order.price.toFixed(2)}€</span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Statut: </span>
                                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${statusConfig.color}`}>
                                    <StatusIcon className="h-3 w-3 mr-1" />
                                    {statusConfig.text}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-gray-500">Quantité: </span>
                                  <span>{order.quantity}</span>
                                </div>
                              </div>
                              <div className="mt-2 flex items-center justify-between">
                                <div className="flex items-center space-x-2">
                                  <span className="text-gray-500">Lien: </span>
                                  <a
                                    href={order.link}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-purple-600 hover:text-purple-700 flex items-center"
                                  >
                                    <span className="truncate max-w-[200px]">{order.link}</span>
                                    <ExternalLink className="h-4 w-4 ml-1" />
                                  </a>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ClientOrders;