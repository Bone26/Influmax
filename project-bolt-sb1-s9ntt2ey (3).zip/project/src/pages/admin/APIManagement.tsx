import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Activity, AlertTriangle, Package } from 'lucide-react';
import APIStats from '../../components/admin/APIStats';
import { collection, query, orderBy, getDocs, Timestamp, doc, setDoc, where } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { toast } from 'sonner';
import axios from 'axios';
import qs from 'qs';

const APIManagement = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [orderTestLoading, setOrderTestLoading] = useState(false);
  const [stats, setStats] = useState({
    totalCalls: 0,
    successfulCalls: 0,
    failedCalls: 0,
    averageResponseTime: 0,
    serviceErrors: [] as Array<{
      japServiceId: string;
      japServiceName: string;
      errorCount: number;
      lastError: string;
      lastErrorTime: Date;
    }>,
    dailyStats: [] as Array<{
      date: string;
      calls: number;
      successRate: number;
      averageResponseTime: number;
    }>
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      await loadStats();
    } catch (error) {
      console.error('Error loading API data:', error);
      setError('Erreur lors du chargement des données');
    } finally {
      setLoading(false);
    }
  };

  const handleTestOrder = async () => {
    console.log('🚀 Starting order test...');
    setOrderTestLoading(true);
    
    try {
      const startTime = Date.now();
      console.log('📝 Preparing order data...');
      
      const orderData = {
        key: import.meta.env.VITE_API_KEY,
        action: 'add',
        service: '4343',
        link: 'https://www.instagram.com/p/example',
        quantity: 100
      };
      
      console.log('📦 Order data:', orderData);

      const response = await axios.post('/api/v2', qs.stringify(orderData), {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/x-www-form-urlencoded',
          'Cache-Control': 'no-cache',
          'User-Agent': 'PostmanRuntime/7.43.0'
        },
        timeout: 10000
      });

      console.log('✅ Response:', response.data);
      const duration = Date.now() - startTime;

      // Track API call
      const statsRef = doc(collection(db, 'japAPIStats'));
      await setDoc(statsRef, {
        id: statsRef.id,
        action: 'add',
        japServiceId: '4343',
        japServiceName: 'Instagram Likes [Standard]',
        success: !response.data.error,
        error: response.data.error ? {
          message: String(response.data.error),
          timestamp: new Date().toISOString()
        } : null,
        duration,
        timestamp: Timestamp.now(),
        params: orderData
      });

      if (response.data.error) {
        throw new Error(String(response.data.error));
      }

      toast.success('Test de commande réussi !');
      console.log('🎉 Order test completed successfully');
      
      await loadStats();
    } catch (error) {
      console.error('❌ Error testing order:', error instanceof Error ? error.message : 'Unknown error');
      
      if (axios.isAxiosError(error)) {
        console.error('🔍 Order error details:', {
          status: error.response?.status,
          data: error.response?.data,
          headers: error.config?.headers
        });
      }
      
      const errorMessage = error instanceof Error ? error.message : 'Erreur lors du test de commande';
      toast.error(errorMessage);
    } finally {
      setOrderTestLoading(false);
      console.log('🏁 Order test process completed');
    }
  };

  const loadStats = async () => {
    try {
      // Initialize global stats if they don't exist
      const globalStatsRef = doc(db, 'japAPIGlobalStats', 'current');
      await setDoc(globalStatsRef, {
        totalCalls: 0,
        successfulCalls: 0,
        failedCalls: 0,
        updatedAt: Timestamp.now()
      }, { merge: true });

      // Get API stats from the last 30 days
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const q = query(
        collection(db, 'japAPIStats'),
        where('timestamp', '>=', Timestamp.fromDate(thirtyDaysAgo)),
        orderBy('timestamp', 'desc')
      );

      const snapshot = await getDocs(q);
      const calls = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          ...data,
          timestamp: data.timestamp.toDate(),
          error: data.error ? {
            message: String(data.error.message),
            timestamp: new Date(data.error.timestamp)
          } : null
        };
      });

      // Calculate stats
      const totalCalls = calls.length;
      const successfulCalls = calls.filter(call => call.success).length;
      const averageResponseTime = calls.reduce((sum, call) => sum + (call.duration || 0), 0) / totalCalls;

      // Group errors by service
      const errorsByService = calls
        .filter(call => !call.success && call.japServiceId)
        .reduce((acc: any, call) => {
          const key = call.japServiceId;
          if (!acc[key]) {
            acc[key] = {
              japServiceId: call.japServiceId,
              japServiceName: call.japServiceName || `Service #${call.japServiceId}`,
              errorCount: 0,
              lastError: '',
              lastErrorTime: null
            };
          }
          acc[key].errorCount++;
          if (!acc[key].lastErrorTime || call.timestamp > acc[key].lastErrorTime) {
            acc[key].lastError = call.error?.message || 'Unknown error';
            acc[key].lastErrorTime = call.timestamp;
          }
          return acc;
        }, {});

      // Group by day for daily stats
      const dailyStats = calls.reduce((acc: any, call) => {
        const date = call.timestamp.toISOString().split('T')[0];
        if (!acc[date]) {
          acc[date] = {
            date,
            calls: 0,
            successRate: 0,
            averageResponseTime: 0,
            totalDuration: 0
          };
        }
        acc[date].calls++;
        acc[date].successRate = (acc[date].calls > 0)
          ? (calls.filter(c => 
              c.timestamp.toISOString().split('T')[0] === date && 
              c.success
            ).length / acc[date].calls) * 100
          : 0;
        acc[date].totalDuration += call.duration || 0;
        acc[date].averageResponseTime = acc[date].totalDuration / acc[date].calls;
        return acc;
      }, {});

      setStats({
        totalCalls,
        successfulCalls,
        failedCalls: totalCalls - successfulCalls,
        averageResponseTime,
        serviceErrors: Object.values(errorsByService),
        dailyStats: Object.values(dailyStats)
      });
    } catch (error) {
      console.error('Error loading API stats:', error);
      throw error;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link to="/admin" className="text-white/80 hover:text-white">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div>
                  <h1 className="text-2xl font-bold text-white">API Management</h1>
                  <p className="text-purple-100 text-sm">
                    Monitoring de l'API JAP
                  </p>
                </div>
              </div>
              <button
                onClick={handleTestOrder}
                disabled={orderTestLoading}
                className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg transition-colors disabled:opacity-50"
              >
                <Package className="h-5 w-5" />
                <span>Tester commande</span>
              </button>
            </div>
          </div>

          <div className="p-6">
            {error && (
              <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-lg flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                {error}
              </div>
            )}

            {/* API Stats */}
            <APIStats stats={stats} />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default APIManagement;