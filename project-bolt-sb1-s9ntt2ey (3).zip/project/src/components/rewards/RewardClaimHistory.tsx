import React from 'react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import RewardStatusBadge from './RewardStatusBadge';

interface RewardClaimHistoryProps {
  claims: Array<{
    id: string;
    reward: string;
    rewardLevel: string;
    status: 'pending' | 'approved' | 'rejected' | 'shipped';
    createdAt: Date;
    updatedAt: Date;
    shippingDetails?: {
      trackingNumber?: string;
    };
    rejectionReason?: string;
  }>;
}

const RewardClaimHistory: React.FC<RewardClaimHistoryProps> = ({ claims }) => {
  if (claims.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        Aucune récompense réclamée pour le moment
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {claims.map((claim, index) => (
        <motion.div
          key={claim.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-white rounded-lg shadow-sm border p-4"
        >
          <div className="flex items-center justify-between mb-2">
            <div>
              <h4 className="font-medium text-gray-900">{claim.reward}</h4>
              <p className="text-sm text-gray-500">Niveau {claim.rewardLevel}</p>
            </div>
            <RewardStatusBadge status={claim.status} />
          </div>

          <div className="text-sm text-gray-600">
            <p>Réclamé le {format(claim.createdAt, 'PPP', { locale: fr })}</p>
            {claim.status === 'shipped' && claim.shippingDetails?.trackingNumber && (
              <p className="mt-1">
                Numéro de suivi: {claim.shippingDetails.trackingNumber}
              </p>
            )}
            {claim.status === 'rejected' && claim.rejectionReason && (
              <p className="mt-1 text-red-600">
                Raison: {claim.rejectionReason}
              </p>
            )}
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default RewardClaimHistory;