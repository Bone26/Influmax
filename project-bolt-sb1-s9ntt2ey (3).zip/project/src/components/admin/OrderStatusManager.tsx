import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Check, X, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { toast } from 'sonner';

interface OrderStatusManagerProps {
  order: {
    id: string;
    status: string;
    timestamps: {
      createdAt: Date;
      startedAt?: Date;
      completedAt?: Date;
      cancelledAt?: Date;
    };
  };
  onValidate: (orderId: string) => Promise<void>;
  onReject: (orderId: string) => Promise<void>;
}

const OrderStatusManager: React.FC<OrderStatusManagerProps> = ({
  order,
  onValidate,
  onReject
}) => {
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Terminé';
      case 'processing':
        return 'En cours';
      case 'pending':
        return 'En attente';
      case 'cancelled':
        return 'Annulé';
      default:
        return status;
    }
  };

  const handleAction = async (action: 'validate' | 'reject') => {
    setLoading(true);
    try {
      if (action === 'validate') {
        await onValidate(order.id);
        toast.success('Commande validée avec succès');
      } else {
        await onReject(order.id);
        toast.success('Commande rejetée avec succès');
      }
    } catch (error) {
      console.error(`Error ${action}ing order:`, error);
      toast.error(`Erreur lors de la ${action === 'validate' ? 'validation' : 'rejet'} de la commande`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-4">
      {/* Status Header */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between"
      >
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${
            order.status === 'pending' ? 'bg-yellow-100' :
            order.status === 'processing' ? 'bg-blue-100' :
            order.status === 'completed' ? 'bg-green-100' :
            'bg-red-100'
          }`}>
            {order.status === 'pending' ? (
              <Clock className="h-5 w-5 text-yellow-700" />
            ) : order.status === 'processing' ? (
              <Clock className="h-5 w-5 text-blue-700" />
            ) : order.status === 'completed' ? (
              <Check className="h-5 w-5 text-green-700" />
            ) : (
              <X className="h-5 w-5 text-red-700" />
            )}
          </div>
          <div>
            <div className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
              {getStatusText(order.status)}
            </div>
            <div className="text-sm text-gray-500 mt-1">
              {format(order.timestamps.createdAt, 'PPp', { locale: fr })}
            </div>
          </div>
        </div>
        {expanded ? (
          <ChevronUp className="h-5 w-5 text-gray-400" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-400" />
        )}
      </button>

      {/* Expanded Content */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-4 space-y-4"
          >
            {/* Timeline */}
            <div className="relative pl-8 space-y-6">
              <div className="absolute left-3 top-0 bottom-0 w-px bg-gray-200" />

              {/* Created */}
              <div className="relative">
                <div className="absolute left-[-1.625rem] w-4 h-4 rounded-full bg-white border-2 border-purple-600" />
                <div>
                  <div className="text-sm font-medium">Commande créée</div>
                  <div className="text-xs text-gray-500">
                    {format(order.timestamps.createdAt, 'PPp', { locale: fr })}
                  </div>
                </div>
              </div>

              {/* Started */}
              {order.timestamps.startedAt && (
                <div className="relative">
                  <div className="absolute left-[-1.625rem] w-4 h-4 rounded-full bg-white border-2 border-blue-600" />
                  <div>
                    <div className="text-sm font-medium">Traitement démarré</div>
                    <div className="text-xs text-gray-500">
                      {format(order.timestamps.startedAt, 'PPp', { locale: fr })}
                    </div>
                  </div>
                </div>
              )}

              {/* Completed */}
              {order.timestamps.completedAt && (
                <div className="relative">
                  <div className="absolute left-[-1.625rem] w-4 h-4 rounded-full bg-white border-2 border-green-600" />
                  <div>
                    <div className="text-sm font-medium">Commande terminée</div>
                    <div className="text-xs text-gray-500">
                      {format(order.timestamps.completedAt, 'PPp', { locale: fr })}
                    </div>
                  </div>
                </div>
              )}

              {/* Cancelled */}
              {order.timestamps.cancelledAt && (
                <div className="relative">
                  <div className="absolute left-[-1.625rem] w-4 h-4 rounded-full bg-white border-2 border-red-600" />
                  <div>
                    <div className="text-sm font-medium">Commande annulée</div>
                    <div className="text-xs text-gray-500">
                      {format(order.timestamps.cancelledAt, 'PPp', { locale: fr })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Actions */}
            {order.status === 'pending' && (
              <div className="flex flex-col space-y-2 pt-4 border-t">
                <button
                  onClick={() => handleAction('validate')}
                  disabled={loading}
                  className="flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg disabled:opacity-50"
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                  ) : (
                    <>
                      <Check className="h-5 w-5 mr-2" />
                      Valider la commande
                    </>
                  )}
                </button>
                <button
                  onClick={() => handleAction('reject')}
                  disabled={loading}
                  className="flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded-lg disabled:opacity-50"
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
                  ) : (
                    <>
                      <X className="h-5 w-5 mr-2" />
                      Rejeter la commande
                    </>
                  )}
                </button>
              </div>
            )}

            {/* Warning for Processing Orders */}
            {order.status === 'processing' && (
              <div className="flex items-center p-3 bg-yellow-50 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2 flex-shrink-0" />
                <p className="text-sm text-yellow-700">
                  Cette commande est en cours de traitement. Elle sera automatiquement marquée comme terminée une fois le délai écoulé.
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default OrderStatusManager;