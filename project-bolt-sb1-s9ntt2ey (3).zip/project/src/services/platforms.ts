import { collection, doc, getDoc, getDocs, setDoc, updateDoc, Timestamp, query, where, writeBatch } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Platform } from '../types/platform';

// Récupérer toutes les plateformes
export const getPlatforms = async (includeInactive = false): Promise<Platform[]> => {
  try {
    let q = collection(db, 'platforms');
    
    if (!includeInactive) {
      q = query(q, where('isActive', '==', true));
    }
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate()
    })) as Platform[];
  } catch (error) {
    console.error('Error getting platforms:', error);
    throw error;
  }
};

// Créer une nouvelle plateforme
export const createPlatform = async (data: Partial<Platform>): Promise<Platform> => {
  try {
    const platformRef = doc(collection(db, 'platforms'));
    const now = new Date();
    
    const platform: Platform = {
      id: platformRef.id,
      name: data.name || '',
      icon: data.icon || 'HelpCircle',
      description: data.description || '',
      gradient: data.gradient || 'from-purple-500 to-indigo-500',
      isActive: data.isActive ?? true,
      createdAt: now,
      updatedAt: now
    };

    await setDoc(platformRef, {
      ...platform,
      createdAt: Timestamp.fromDate(now),
      updatedAt: Timestamp.fromDate(now)
    });

    return platform;
  } catch (error) {
    console.error('Error creating platform:', error);
    throw error;
  }
};

// Mettre à jour une plateforme
export const updatePlatform = async (id: string, data: Partial<Platform>): Promise<void> => {
  try {
    const platformRef = doc(db, 'platforms', id);
    await updateDoc(platformRef, {
      ...data,
      updatedAt: Timestamp.fromDate(new Date())
    });
  } catch (error) {
    console.error('Error updating platform:', error);
    throw error;
  }
};

// Supprimer une plateforme (désactivation)
export const deletePlatform = async (id: string): Promise<void> => {
  try {
    const batch = writeBatch(db);
    
    // 1. Désactiver la plateforme
    const platformRef = doc(db, 'platforms', id);
    batch.update(platformRef, {
      isActive: false,
      updatedAt: Timestamp.fromDate(new Date())
    });

    // 2. Désactiver les services associés
    const servicesQuery = query(
      collection(db, 'services'),
      where('platformId', '==', id),
      where('isActive', '==', true)
    );
    
    const servicesSnapshot = await getDocs(servicesQuery);
    servicesSnapshot.docs.forEach(serviceDoc => {
      batch.update(serviceDoc.ref, {
        isActive: false,
        updatedAt: Timestamp.fromDate(new Date())
      });
    });

    // 3. Exécuter toutes les opérations
    await batch.commit();
  } catch (error) {
    console.error('Error deleting platform:', error);
    throw error;
  }
};

// Réorganiser les plateformes
export const reorderPlatforms = async (platformIds: string[]): Promise<void> => {
  try {
    const batch = writeBatch(db);
    const now = Timestamp.fromDate(new Date());

    platformIds.forEach((id, index) => {
      const platformRef = doc(db, 'platforms', id);
      batch.update(platformRef, {
        order: index,
        updatedAt: now
      });
    });

    await batch.commit();
  } catch (error) {
    console.error('Error reordering platforms:', error);
    throw error;
  }
};