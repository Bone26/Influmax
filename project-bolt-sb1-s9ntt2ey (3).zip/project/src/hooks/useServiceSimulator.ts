import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { SimulatorFormData } from '../types/simulator';
import { getAllPrices } from '../services/pricing';
import { ServicePriceConfig } from '../types/pricing';
import { calculateDripFeed } from '../utils/serviceUtils';
import { DeliveryLimits } from '../types/service';

export const useServiceSimulator = () => {
  const location = useLocation();
  const [formData, setFormData] = useState<SimulatorFormData>({
    platform: '',
    service: '',
    quantity: '',
    quality: 'standard',
    deliveryTime: 'instant'
  });

  const [selectedEmojis, setSelectedEmojis] = useState<string[]>([]);
  const [emojiMode, setEmojiMode] = useState<'custom' | 'pack'>('custom');
  const [selectedPack, setSelectedPack] = useState<'positive' | 'negative' | null>(null);
  const [price, setPrice] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [prices, setPrices] = useState<ServicePriceConfig[]>([]);
  const [minQuantity, setMinQuantity] = useState<number>(0);
  const [maxQuantity, setMaxQuantity] = useState<number>(0);

  // Charger les prix au démarrage
  useEffect(() => {
    const loadPrices = async () => {
      try {
        const allPrices = await getAllPrices();
        setPrices(allPrices);
      } catch (error) {
        console.error('Error loading prices:', error);
        setError('Erreur lors du chargement des prix');
      }
    };

    loadPrices();
  }, []);

  // Initialiser avec les paramètres de l'URL si présents
  useEffect(() => {
    const state = location.state as { platform?: string; service?: string };
    if (state?.platform) {
      setFormData(prev => ({ ...prev, platform: state.platform }));
    }
    if (state?.service) {
      setFormData(prev => ({ ...prev, service: state.service }));
    }
  }, [location]);

  // Mettre à jour les limites quand le service ou la durée change
  useEffect(() => {
    const updateLimits = async () => {
      try {
        const priceConfig = prices.find(p => 
          p.platformId === formData.platform &&
          p.serviceType === formData.service &&
          p.quality === formData.quality &&
          p.isActive
        );

        if (!priceConfig) {
          setError('Service non disponible');
          setPrice(0);
          setMinQuantity(0);
          setMaxQuantity(0);
          return;
        }

        // Récupérer les limites pour la durée sélectionnée
        const deliveryLimit = priceConfig.deliveryLimits[formData.deliveryTime];
        if (!deliveryLimit?.isActive) {
          setError('Durée d\'envoi non disponible');
          setPrice(0);
          setMinQuantity(0);
          setMaxQuantity(0);
          return;
        }

        // Mettre à jour les limites min/max
        setMinQuantity(deliveryLimit.min);
        setMaxQuantity(deliveryLimit.max);
        setError(null);

        // Calculer le prix si la quantité est valide
        const quantity = typeof formData.quantity === 'number' ? formData.quantity : 0;
        if (quantity >= deliveryLimit.min && quantity <= deliveryLimit.max) {
          // Prix de base
          let basePrice = quantity * priceConfig.basePrice;

          // Appliquer les modificateurs pour les réactions Telegram
          if (formData.platform === 'telegram' && formData.service === 'reactions') {
            if (emojiMode === 'pack') {
              // Prix unique pour le pack
              basePrice = quantity * priceConfig.basePrice;
            } else if (selectedEmojis.length > 0) {
              // Prix pour chaque emoji sélectionné
              basePrice = quantity * priceConfig.basePrice * selectedEmojis.length;
            }
          }

          // Appliquer le multiplicateur de temps de livraison
          let deliveryMultiplier = 1;
          switch (formData.deliveryTime) {
            case '24h':
              deliveryMultiplier = 1.1;
              break;
            case '3days':
              deliveryMultiplier = 1.2;
              break;
            case '7days':
              deliveryMultiplier = 1.3;
              break;
            case '1month':
              deliveryMultiplier = 1.5;
              break;
          }

          const finalPrice = basePrice * deliveryMultiplier;
          setPrice(Math.round(finalPrice * 100) / 100);
        } else {
          if (quantity < deliveryLimit.min) {
            setError(`Minimum ${deliveryLimit.min.toLocaleString()}`);
          } else if (quantity > deliveryLimit.max) {
            setError(`Maximum ${deliveryLimit.max.toLocaleString()}`);
          }
          setPrice(0);
        }
      } catch (error) {
        console.error('Error calculating price:', error);
        setError('Erreur lors du calcul du prix');
        setPrice(0);
      }
    };

    if (formData.platform && formData.service && formData.quality && formData.deliveryTime) {
      updateLimits();
    }
  }, [formData, prices, selectedEmojis, emojiMode, selectedPack]);

  const handleChange = (field: keyof SimulatorFormData, value: any) => {
    setFormData(prev => {
      const newData = { ...prev };
      
      if (field === 'platform') {
        return {
          ...newData,
          platform: value,
          service: '',
          quality: 'standard',
          quantity: '',
          deliveryTime: 'instant'
        };
      } 
      
      if (field === 'service') {
        return {
          ...newData,
          service: value,
          quality: 'standard',
          quantity: '',
          deliveryTime: 'instant'
        };
      }

      newData[field] = value;
      return newData;
    });
  };

  const handleEmojiSelect = (emoji: string) => {
    setSelectedEmojis(prev => [...prev, emoji]);
  };

  const handleEmojiRemove = (emoji: string) => {
    setSelectedEmojis(prev => prev.filter(e => e !== emoji));
  };

  const handlePackSelect = (type: 'positive' | 'negative') => {
    setSelectedPack(type);
    setSelectedEmojis([]); // Vider les emojis sélectionnés en mode personnalisé
  };

  return {
    formData,
    selectedEmojis,
    price,
    error,
    minQuantity,
    maxQuantity,
    handleChange,
    handleEmojiSelect,
    handleEmojiRemove,
    handlePackSelect,
    emojiMode,
    setEmojiMode,
    selectedPack
  };
};