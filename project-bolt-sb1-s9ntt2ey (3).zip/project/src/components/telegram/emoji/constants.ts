// Packs d'emojis prédéfinis pour l'interface uniquement
export const POSITIVE_EMOJIS = ['👍🏼', '❤️', '🔥', '🎉', '🤩'] as const;
export const NEGATIVE_EMOJIS = ['👎🏼', '😥', '💩', '🤮'] as const;

// Mapping des emojis vers les IDs JAP
export const EMOJI_JAP_MAPPING = {
  '👍': '6571',
  '❤️': '6573',
  '🔥': '6574',
  '🎉': '6575',
  '🤩': '6576',
  '😁': '6578',
  '💯': '8806',
  '🍾': '8800',
  '🏆': '8805',
  '🙏': '8794',
  '👌': '8798',
  '👎': '6572',
  '😢': '6579',
  '💩': '6580',
  '🤮': '6581',
  '😱': '6577',
  '🤡': '8795',
  '😐': '8809',
  '🖕': '8803',
  '🥱': '8799'
} as const;

// IDs des packs d'emojis mixés
export const MIXED_PACKS = {
  positive: '7256', // Pack d'emojis positifs mixés
  negative: '7257'  // Pack d'emojis négatifs mixés
} as const;