import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link2, Copy, Check } from 'lucide-react';
import { useAffiliate } from '../../contexts/AffiliateContext';

const ReferralLink = () => {
  const { affiliate } = useAffiliate();
  const [copied, setCopied] = useState(false);

  const referralLink = `${window.location.origin}/?ref=${affiliate?.referralCode}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg p-6"
    >
      <div className="flex items-center space-x-2 mb-4">
        <Link2 className="h-5 w-5 text-purple-600" />
        <h3 className="text-lg font-semibold">Votre lien d'affiliation</h3>
      </div>
      
      <div className="flex items-center space-x-2">
        <input
          type="text"
          value={referralLink}
          readOnly
          className="flex-1 p-3 bg-gray-50 rounded-lg text-gray-600 focus:outline-none"
        />
        <button
          onClick={handleCopy}
          className="p-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          {copied ? (
            <Check className="h-5 w-5" />
          ) : (
            <Copy className="h-5 w-5" />
          )}
        </button>
      </div>
      
      <div className="mt-4 p-4 bg-purple-50 rounded-lg">
        <h4 className="font-medium text-purple-900 mb-2">Programme de commission</h4>
        <ul className="space-y-2 text-sm text-purple-800">
          <li>• 20% de commission sur les dépôts de vos affiliés directs</li>
          <li>• 10% sur les dépôts des affiliés de vos affiliés</li>
          <li>• Des récompenses inédites</li>
          <li>• Commissions calculées uniquement sur les dépôts de wallet</li>
          <li>• Retrait minimum : 50€</li>
        </ul>
      </div>
    </motion.div>
  );
};

export default ReferralLink;