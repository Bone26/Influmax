import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, Ban } from 'lucide-react';
import { platformStyles } from '../../config/platformStyles';

interface PriceDisplayProps {
  price: number;
  isValid: boolean;
  platform: string;
  error?: string | null;
}

const PriceDisplay: React.FC<PriceDisplayProps> = ({ 
  price, 
  isValid, 
  platform, 
  error
}) => {
  const styles = platformStyles[platform as keyof typeof platformStyles];

  const formatPrice = (price: number): string => {
    return price.toFixed(5).replace(/\.?0+$/, '');
  };

  const getErrorDisplay = () => {
    if (!error) return null;

    // Messages spécifiques pour les indisponibilités
    if (error.includes('non disponible')) {
      return (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center space-y-2"
        >
          <Ban className="h-8 w-8 text-red-500" />
          <span className="text-lg font-medium text-red-600">Indisponible</span>
          <span className="text-sm text-red-500">{error}</span>
        </motion.div>
      );
    }

    // Messages pour les limites de quantité
    if (error.includes('Minimum') || error.includes('Maximum')) {
      return (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-center space-x-2 text-orange-600"
        >
          <AlertCircle className="h-6 w-6" />
          <span className="text-lg font-medium">{error}</span>
        </motion.div>
      );
    }

    // Autres erreurs
    return (
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-center space-x-2 text-red-600"
      >
        <AlertCircle className="h-6 w-6" />
        <span className="text-lg font-medium">{error}</span>
      </motion.div>
    );
  };

  return (
    <motion.div 
      className="bg-gray-50 p-6 rounded-xl"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.2 }}
    >
      <div className="text-center">
        <div className="text-gray-600 mb-4">Prix estimé</div>
        
        {error ? (
          getErrorDisplay()
        ) : isValid && price > 0 ? (
          <div className={`text-4xl font-bold bg-gradient-to-r ${styles.gradients.text} bg-clip-text text-transparent`}>
            {formatPrice(price)}€
          </div>
        ) : (
          <div className="text-xl text-gray-400 flex flex-col items-center space-y-2">
            <AlertCircle className="h-6 w-6" />
            <span>Entrez une quantité valide</span>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default PriceDisplay;