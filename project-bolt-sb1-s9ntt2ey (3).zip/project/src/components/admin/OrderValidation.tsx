import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Clock, Timer } from 'lucide-react';

interface OrderValidationProps {
  order: any;
  onValidate: (orderId: string) => Promise<void>;
  onReject: (orderId: string) => Promise<void>;
  onClose: () => void;
}

const OrderValidation: React.FC<OrderValidationProps> = ({ order, onValidate, onReject, onClose }) => {
  const [loading, setLoading] = useState(false);

  const handleAction = async (action: 'validate' | 'reject') => {
    setLoading(true);
    try {
      if (action === 'validate') {
        await onValidate(order.id);
      } else {
        await onReject(order.id);
      }
      onClose();
    } catch (error) {
      console.error(`Error ${action}ing order:`, error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-lg shadow-xl max-w-md w-full p-6"
      >
        <h2 className="text-xl font-bold mb-4">Validation de la commande</h2>
        
        <div className="space-y-4 mb-6">
          <div>
            <p className="text-sm text-gray-500">ID de la commande</p>
            <p className="font-medium">#{order.id}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Service</p>
            <p className="font-medium">{order.service.platform} - {order.service.type}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Quantité</p>
            <p className="font-medium">{order.quantity}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Durée d'envoi</p>
            <div className="flex items-center space-x-2 text-purple-600">
              <Timer className="h-4 w-4" />
              <p className="font-medium">{order.deliveryTime || 'Instantané'}</p>
            </div>
          </div>
          {order.service.type === 'reactions' && order.metadata?.selectedEmojis && (
            <div>
              <p className="text-sm text-gray-500">Réactions sélectionnées</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {order.metadata.selectedEmojis.map((emoji: string, index: number) => (
                  <span key={index} className="text-2xl bg-gray-50 p-2 rounded-lg">
                    {emoji}
                  </span>
                ))}
              </div>
            </div>
          )}
          <div>
            <p className="text-sm text-gray-500">Lien</p>
            <a 
              href={order.link}
              target="_blank"
              rel="noopener noreferrer"
              className="text-purple-600 hover:text-purple-700 break-all"
            >
              {order.link}
            </a>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
          <div className="flex items-center text-yellow-800">
            <Clock className="h-5 w-5 mr-2" />
            <p className="text-sm">
              La commande passera en statut "En cours" pendant la durée d'envoi avant d'être marquée comme terminée.
            </p>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-4">
          <button
            onClick={() => handleAction('validate')}
            disabled={loading}
            className="flex-1 flex items-center justify-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
            ) : (
              <>
                <Check className="h-5 w-5 mr-2" />
                Valider
              </>
            )}
          </button>
          <button
            onClick={() => handleAction('reject')}
            disabled={loading}
            className="flex-1 flex items-center justify-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent" />
            ) : (
              <>
                <X className="h-5 w-5 mr-2" />
                Rejeter
              </>
            )}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default OrderValidation;