import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc,
  deleteDoc,
  query, 
  where, 
  orderBy,
  Timestamp 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Service } from '../types/service';

// Récupérer tous les services (actifs uniquement)
export const getServices = async (): Promise<Service[]> => {
  try {
    const servicesQuery = query(
      collection(db, 'services'),
      where('isActive', '==', true)
    );
    
    const querySnapshot = await getDocs(servicesQuery);
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      createdAt: doc.data().createdAt?.toDate(),
      updatedAt: doc.data().updatedAt?.toDate()
    })) as Service[];
  } catch (error) {
    console.error('Error getting services:', error);
    throw error;
  }
};

// Créer un nouveau service
export const createService = async (data: Partial<Service>): Promise<Service> => {
  try {
    const serviceRef = doc(collection(db, 'services'));
    const now = new Date();
    
    const service: Service = {
      id: serviceRef.id,
      ...data,
      isActive: true,
      createdAt: now,
      updatedAt: now
    } as Service;

    await setDoc(serviceRef, {
      ...service,
      createdAt: Timestamp.fromDate(now),
      updatedAt: Timestamp.fromDate(now)
    });

    return service;
  } catch (error) {
    console.error('Error creating service:', error);
    throw error;
  }
};

// Mettre à jour un service
export const updateService = async (id: string, data: Partial<Service>): Promise<void> => {
  try {
    const serviceRef = doc(db, 'services', id);
    await updateDoc(serviceRef, {
      ...data,
      updatedAt: Timestamp.fromDate(new Date())
    });
  } catch (error) {
    console.error('Error updating service:', error);
    throw error;
  }
};

// Supprimer un service (suppression réelle)
export const deleteService = async (id: string): Promise<void> => {
  try {
    const serviceRef = doc(db, 'services', id);
    await deleteDoc(serviceRef);
  } catch (error) {
    console.error('Error deleting service:', error);
    throw error;
  }
};