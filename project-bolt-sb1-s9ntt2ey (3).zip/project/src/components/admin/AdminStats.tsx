import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, Users, ShoppingBag, CreditCard, ArrowUpRight, ArrowDownRight, Wallet } from 'lucide-react';
import { useAdminStats } from '../../hooks/useAdminStats';

const AdminStats = () => {
  const { stats, loading, error } = useAdminStats();
  const [selectedStat, setSelectedStat] = useState<string | null>(null);

  const formatTrend = (trend: number) => {
    const isPositive = trend >= 0;
    return {
      icon: isPositive ? ArrowUpRight : ArrowDownRight,
      color: isPositive ? 'text-green-600' : 'text-red-600',
      value: Math.abs(trend).toFixed(1)
    };
  };

  if (loading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm p-4 animate-pulse">
            <div className="h-4 w-24 bg-gray-200 rounded mb-2"></div>
            <div className="h-8 w-32 bg-gray-300 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-lg">
        {error}
      </div>
    );
  }

  const statCards = [
    {
      id: 'orders',
      title: "Total des commandes",
      value: stats.totalOrders.value,
      trend: stats.totalOrders.trend,
      icon: ShoppingBag,
      color: "from-blue-500 to-blue-600",
      details: [
        { label: "En attente", value: stats.orders.pending },
        { label: "En cours", value: stats.orders.processing },
        { label: "Terminées", value: stats.orders.completed },
        { label: "Annulées", value: stats.orders.cancelled },
        { label: "Dernier mois", value: stats.orders.lastMonth },
        { label: "Évolution", value: `${stats.orders.trend >= 0 ? '+' : ''}${stats.orders.trend.toFixed(1)}%` }
      ]
    },
    {
      id: 'revenue',
      title: "Revenu total",
      value: `${stats.revenue.total.toFixed(2)}€`,
      trend: stats.revenue.trend,
      icon: CreditCard,
      color: "from-green-500 to-green-600",
      details: [
        { label: "Moyenne/commande", value: `${stats.revenue.average.toFixed(2)}€` },
        { label: "Plus haut", value: `${stats.revenue.highest.toFixed(2)}€` },
        { label: "Plus bas", value: `${stats.revenue.lowest.toFixed(2)}€` },
        { label: "Dernier mois", value: `${stats.revenue.lastMonth.toFixed(2)}€` },
        { label: "Évolution", value: `${stats.revenue.trend >= 0 ? '+' : ''}${stats.revenue.trend.toFixed(1)}%` }
      ]
    },
    {
      id: 'deposits',
      title: "Total des dépôts",
      value: `${stats.deposits.total.toFixed(2)}€`,
      trend: stats.deposits.trend,
      icon: Wallet,
      color: "from-purple-500 to-indigo-500",
      details: [
        { label: "Dernier mois", value: `${stats.deposits.lastMonth.toFixed(2)}€` },
        { label: "Évolution", value: `${stats.deposits.trend >= 0 ? '+' : ''}${stats.deposits.trend.toFixed(1)}%` }
      ]
    },
    {
      id: 'clients',
      title: "Clients",
      value: stats.clients.total,
      trend: stats.clients.trend,
      icon: Users,
      color: "from-purple-500 to-purple-600",
      details: [
        { label: "Commandes/client", value: stats.clients.ordersPerClient.toFixed(1) },
        { label: "Revenu/client", value: `${stats.clients.revenuePerClient.toFixed(2)}€` },
        { label: "Actifs (30j)", value: stats.clients.activeLastMonth },
        { label: "Évolution", value: `${stats.clients.trend >= 0 ? '+' : ''}${stats.clients.trend.toFixed(1)}%` }
      ]
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {statCards.map((stat) => {
        const trend = formatTrend(stat.trend);
        
        return (
          <motion.div
            key={stat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl shadow-sm p-4 cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setSelectedStat(stat.id)}
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-lg bg-gradient-to-r ${stat.color}`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <div className={`flex items-center ${trend.color}`}>
                <trend.icon className="h-4 w-4" />
                <span className="text-sm font-medium">{trend.value}%</span>
              </div>
            </div>
            <p className="text-sm text-gray-600">{stat.title}</p>
            <p className="text-2xl font-bold mt-1">{stat.value}</p>
          </motion.div>
        );
      })}

      <AnimatePresence>
        {selectedStat && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedStat(null)}
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-xl font-bold mb-4">
                {statCards.find(s => s.id === selectedStat)?.title}
              </h3>
              {statCards.find(s => s.id === selectedStat)?.details.map((detail, index) => (
                <div
                  key={index}
                  className="flex justify-between items-center py-3 border-b last:border-0"
                >
                  <span className="text-gray-600">{detail.label}</span>
                  <span className="font-semibold">{detail.value}</span>
                </div>
              ))}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AdminStats;