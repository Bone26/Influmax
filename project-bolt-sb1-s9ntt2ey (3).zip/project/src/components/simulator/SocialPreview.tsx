import React from 'react';
import { motion } from 'framer-motion';
import { Users, Heart, Eye, MessageCircle, Bookmark, Share2 } from 'lucide-react';

interface SocialPreviewProps {
  platform: 'instagram' | 'tiktok';
  stats: {
    followers: number;
    posts?: number;
    likes: number;
    views?: number;
    comments?: number;
    shares?: number;
    saves?: number;
  };
}

const SocialPreview: React.FC<SocialPreviewProps> = ({ platform, stats }) => {
  const formatNumber = (num: number): string => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    }
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  if (platform === 'instagram') {
    return (
      <div className="max-w-sm mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-gray-200 rounded-full"></div>
            <div>
              <h3 className="font-semibold">@username</h3>
              <div className="text-sm text-gray-500">Description du compte</div>
            </div>
          </div>

          {/* Stats */}
          <div className="flex justify-around mt-4 text-center">
            <div>
              <div className="font-semibold">{formatNumber(stats.posts || 0)}</div>
              <div className="text-xs text-gray-500">Publications</div>
            </div>
            <div>
              <div className="font-semibold">{formatNumber(stats.followers)}</div>
              <div className="text-xs text-gray-500">Abonnés</div>
            </div>
            <div>
              <div className="font-semibold">0</div>
              <div className="text-xs text-gray-500">Abonnements</div>
            </div>
          </div>
        </div>

        {/* Sample Post */}
        <div className="border-b">
          <div className="aspect-square bg-gray-100"></div>
          <div className="p-4">
            <div className="flex justify-between mb-2">
              <div className="flex space-x-4">
                <button className="text-gray-900">
                  <Heart className="h-6 w-6" />
                </button>
                <button className="text-gray-900">
                  <MessageCircle className="h-6 w-6" />
                </button>
                <button className="text-gray-900">
                  <Share2 className="h-6 w-6" />
                </button>
              </div>
              <button className="text-gray-900">
                <Bookmark className="h-6 w-6" />
              </button>
            </div>
            <div className="font-semibold">{formatNumber(stats.likes)} J'aime</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-sm mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
      {/* TikTok Profile */}
      <div className="p-4 border-b">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 bg-gray-200 rounded-full"></div>
          <div>
            <h3 className="font-semibold">@username</h3>
            <div className="text-sm text-gray-500">Description du compte</div>
          </div>
        </div>

        {/* Stats */}
        <div className="flex justify-around mt-4 text-center">
          <div>
            <div className="font-semibold">{formatNumber(stats.followers)}</div>
            <div className="text-xs text-gray-500">Abonnés</div>
          </div>
          <div>
            <div className="font-semibold">0</div>
            <div className="text-xs text-gray-500">Abonnements</div>
          </div>
          <div>
            <div className="font-semibold">{formatNumber(stats.likes)}</div>
            <div className="text-xs text-gray-500">J'aime</div>
          </div>
        </div>
      </div>

      {/* Sample Video */}
      <div className="border-b">
        <div className="aspect-[9/16] bg-gray-100"></div>
        <div className="p-4">
          <div className="flex flex-col space-y-2">
            <div className="flex items-center space-x-2">
              <Heart className="h-5 w-5" />
              <span>{formatNumber(stats.likes)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5" />
              <span>{formatNumber(stats.comments || 0)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Bookmark className="h-5 w-5" />
              <span>{formatNumber(stats.saves || 0)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Share2 className="h-5 w-5" />
              <span>{formatNumber(stats.shares || 0)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Eye className="h-5 w-5" />
              <span>{formatNumber(stats.views || 0)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SocialPreview;