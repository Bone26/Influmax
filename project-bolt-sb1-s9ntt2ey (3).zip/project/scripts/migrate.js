import { initializeApp } from 'firebase/app';
import { getFirestore, collection, query, where, getDocs, writeBatch, doc, Timestamp, updateDoc } from 'firebase/firestore';

// Configuration Firebase
const firebaseConfig = {
  apiKey: "AIzaSyDLECT_Z6EIgpDkAS9aJ48AqOdSkT3yaOY",
  authDomain: "influmax-v2.firebaseapp.com",
  projectId: "influmax-v2",
  storageBucket: "influmax-v2.firebasestorage.app",
  messagingSenderId: "200667014540",
  appId: "1:200667014540:web:8845501ed88b7da1f822a9"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const generateReferralCode = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
};

const migrate = async () => {
  console.log('🚀 Début de la migration...');
  
  try {
    // 1. Récupérer tous les utilisateurs
    console.log('📚 Récupération des utilisateurs...');
    const usersSnapshot = await getDocs(collection(db, 'users'));
    const users = usersSnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    console.log(`📊 ${users.length} utilisateurs trouvés`);

    // 2. Récupérer tous les affiliés
    console.log('📚 Récupération des affiliés...');
    const affiliatesSnapshot = await getDocs(collection(db, 'affiliates'));
    const affiliates = affiliatesSnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
    console.log(`📊 ${affiliates.length} affiliés trouvés`);

    // 3. Migrer les données
    console.log('🔄 Migration des données...');
    for (const user of users) {
      try {
        // Trouver l'affilié correspondant
        const userAffiliates = affiliates.filter(a => a.userId === user.id);
        
        if (userAffiliates.length > 0) {
          console.log(`👤 Migration de l'utilisateur ${user.id}...`);
          
          // Prendre le plus ancien affilié
          const affiliate = userAffiliates.sort((a, b) => 
            a.createdAt.toDate().getTime() - b.createdAt.toDate().getTime()
          )[0];

          // Mettre à jour l'utilisateur
          await updateDoc(doc(db, 'users', user.id), {
            affiliate: {
              referralCode: affiliate.referralCode,
              referrerId: affiliate.referrerId || null,
              level: affiliate.level || 1,
              stats: {
                totalEarnings: affiliate.totalEarnings || 0,
                pendingEarnings: affiliate.pendingEarnings || 0,
                totalReferrals: affiliate.totalReferrals || 0,
                activeReferrals: affiliate.activeReferrals || 0
              }
            },
            updatedAt: Timestamp.now()
          });

          console.log(`✅ Utilisateur ${user.id} migré avec succès`);
        } else {
          // Créer une nouvelle structure d'affiliation
          console.log(`👤 Création d'une nouvelle structure pour ${user.id}...`);
          await updateDoc(doc(db, 'users', user.id), {
            affiliate: {
              referralCode: generateReferralCode(),
              level: 1,
              stats: {
                totalEarnings: 0,
                pendingEarnings: 0,
                totalReferrals: 0,
                activeReferrals: 0
              }
            },
            updatedAt: Timestamp.now()
          });
          console.log(`✅ Structure créée pour ${user.id}`);
        }
      } catch (error) {
        console.error(`❌ Erreur lors de la migration de l'utilisateur ${user.id}:`, error);
      }
    }

    // 4. Supprimer les anciens affiliés
    console.log('🧹 Nettoyage des anciens affiliés...');
    const batch = writeBatch(db);
    affiliatesSnapshot.docs.forEach(doc => {
      batch.delete(doc.ref);
    });
    await batch.commit();
    console.log(`🗑️ ${affiliates.length} anciens affiliés supprimés`);

    console.log('✨ Migration terminée avec succès !');

  } catch (error) {
    console.error('💥 Erreur fatale lors de la migration:', error);
    throw error;
  }
};

// Exécuter la migration
console.log('🏃 Démarrage du script de migration...');
migrate().then(() => {
  console.log('🎉 Script terminé avec succès');
  process.exit(0);
}).catch(error => {
  console.error('💥 Erreur fatale:', error);
  process.exit(1);
});