import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL;

export interface PaymentIntent {
  clientSecret: string;
  orderId: string;
}

export interface SavedPaymentMethod {
  id: string;
  type: string;
  card?: {
    brand: string;
    last4: string;
    exp_month: number;
    exp_year: number;
  };
}

export const createPaymentIntent = async (amount: number, currency: string = 'eur'): Promise<PaymentIntent> => {
  try {
    const response = await axios.post(`${API_URL}/payment/create-intent`, {
      amount,
      currency,
    });

    return response.data;
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw error;
  }
};

export const getSavedPaymentMethods = async (customerId: string): Promise<SavedPaymentMethod[]> => {
  try {
    const response = await axios.get(`${API_URL}/payment/methods/${customerId}`);
    return response.data.payment_methods;
  } catch (error) {
    console.error('Error fetching saved payment methods:', error);
    throw error;
  }
};

export const deletePaymentMethod = async (paymentMethodId: string): Promise<void> => {
  try {
    await axios.delete(`${API_URL}/payment/methods/${paymentMethodId}`);
  } catch (error) {
    console.error('Error deleting payment method:', error);
    throw error;
  }
};