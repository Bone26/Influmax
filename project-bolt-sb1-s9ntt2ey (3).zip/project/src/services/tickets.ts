import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  query, 
  where, 
  orderBy,
  Timestamp,
  increment,
  runTransaction,
  onSnapshot
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Ticket, TicketMessage } from '../types/ticket';
import { uploadTicketAttachment } from './storage';

// Récupérer les tickets d'un utilisateur
export const getUserTickets = async (userId: string): Promise<Ticket[]> => {
  try {
    const q = query(
      collection(db, 'tickets'),
      where('userId', '==', userId),
      orderBy('updatedAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate(),
      closedAt: doc.data().closedAt?.toDate()
    })) as Ticket[];
  } catch (error) {
    console.error('Error getting user tickets:', error);
    throw error;
  }
};

// Récupérer tous les tickets (admin)
export const getAllTickets = async (): Promise<Ticket[]> => {
  try {
    const q = query(
      collection(db, 'tickets'),
      orderBy('updatedAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate(),
      updatedAt: doc.data().updatedAt.toDate(),
      closedAt: doc.data().closedAt?.toDate()
    })) as Ticket[];
  } catch (error) {
    console.error('Error getting all tickets:', error);
    throw error;
  }
};

// Récupérer les statistiques des tickets
export const getTicketStats = async (days: number = 30) => {
  try {
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - (days * 24 * 60 * 60 * 1000));

    // Récupérer tous les tickets
    const ticketsQuery = query(
      collection(db, 'tickets'),
      where('createdAt', '>=', Timestamp.fromDate(startDate)),
      where('createdAt', '<=', Timestamp.fromDate(endDate))
    );

    const ticketsSnapshot = await getDocs(ticketsQuery);
    const tickets = ticketsSnapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate()
    }));

    // Calculer les statistiques
    const stats = {
      totalTickets: tickets.length,
      openTickets: tickets.filter(t => t.status === 'open').length,
      resolvedTickets: tickets.filter(t => t.status === 'resolved').length,
      averageResponseTime: 0,
      dailyStats: [] as Array<{
        date: string;
        tickets: number;
        responseTime: number;
      }>,
      categoryDistribution: {} as { [key: string]: number }
    };

    // Calculer la distribution par catégorie
    tickets.forEach(ticket => {
      if (ticket.category) {
        stats.categoryDistribution[ticket.category] = (stats.categoryDistribution[ticket.category] || 0) + 1;
      }
    });

    // Calculer les statistiques journalières
    const dailyData = new Map();
    for (let i = 0; i < days; i++) {
      const date = new Date(endDate);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      dailyData.set(dateStr, {
        tickets: 0,
        responseTime: 0
      });
    }

    // Remplir les données journalières
    tickets.forEach(ticket => {
      const dateStr = ticket.createdAt.toISOString().split('T')[0];
      if (dailyData.has(dateStr)) {
        const data = dailyData.get(dateStr);
        data.tickets++;
        dailyData.set(dateStr, data);
      }
    });

    // Convertir les données journalières en tableau
    stats.dailyStats = Array.from(dailyData.entries()).map(([date, data]) => ({
      date,
      tickets: data.tickets,
      responseTime: data.responseTime
    }));

    return stats;
  } catch (error) {
    console.error('Error getting ticket stats:', error);
    throw error;
  }
};

// Créer un ticket
export const createTicket = async (
  userId: string,
  userName: string,
  subject: string,
  category: Ticket['category'],
  message: string,
  orderId?: string
): Promise<Ticket> => {
  try {
    return await runTransaction(db, async (transaction) => {
      // Créer le ticket
      const ticketRef = doc(collection(db, 'tickets'));
      const now = Timestamp.now();
      
      const ticket: Ticket = {
        id: ticketRef.id,
        userId,
        userName,
        subject,
        category,
        status: 'open',
        orderId: orderId || null,
        unreadCount: 0,
        createdAt: now.toDate(),
        updatedAt: now.toDate()
      };

      transaction.set(ticketRef, ticket);

      // Créer le premier message
      const messageRef = doc(collection(db, 'ticketMessages'));
      const ticketMessage: TicketMessage = {
        id: messageRef.id,
        ticketId: ticket.id,
        content: message,
        senderId: userId,
        senderName: userName,
        senderRole: 'user',
        read: false,
        createdAt: now.toDate()
      };

      transaction.set(messageRef, ticketMessage);

      // Mettre à jour le ticket avec le dernier message
      transaction.update(ticketRef, {
        lastMessage: {
          content: message,
          createdAt: now
        }
      });

      return ticket;
    });
  } catch (error) {
    console.error('Error creating ticket:', error);
    throw error;
  }
};

// Supprimer un ticket
export const deleteTicket = async (ticketId: string, userId: string): Promise<void> => {
  try {
    return await runTransaction(db, async (transaction) => {
      // 1. Vérifier que le ticket existe et appartient à l'utilisateur
      const ticketRef = doc(db, 'tickets', ticketId);
      const ticketDoc = await transaction.get(ticketRef);
      
      if (!ticketDoc.exists()) {
        throw new Error('Ticket not found');
      }
      
      const ticketData = ticketDoc.data();
      if (ticketData.userId !== userId) {
        throw new Error('Unauthorized');
      }

      // 2. Vérifier que le ticket peut être supprimé (statut open ou pending)
      if (!['open', 'pending'].includes(ticketData.status)) {
        throw new Error('Cannot delete ticket - already being processed');
      }

      // 3. Supprimer les messages associés
      const messagesQuery = query(
        collection(db, 'ticketMessages'),
        where('ticketId', '==', ticketId)
      );
      const messagesSnapshot = await getDocs(messagesQuery);
      
      messagesSnapshot.docs.forEach(messageDoc => {
        transaction.delete(messageDoc.ref);
      });

      // 4. Supprimer le statut de frappe
      const typingQuery = query(
        collection(db, 'ticketTyping'),
        where('ticketId', '==', ticketId)
      );
      const typingSnapshot = await getDocs(typingQuery);
      
      typingSnapshot.docs.forEach(typingDoc => {
        transaction.delete(typingDoc.ref);
      });

      // 5. Supprimer le ticket
      transaction.delete(ticketRef);
    });
  } catch (error) {
    console.error('Error deleting ticket:', error);
    throw error;
  }
};

// Gestion du statut de frappe
export const updateTypingStatus = async (
  ticketId: string,
  userId: string,
  userName: string,
  isTyping: boolean
): Promise<void> => {
  try {
    const typingRef = doc(db, 'ticketTyping', `${ticketId}_${userId}`);
    await setDoc(typingRef, {
      ticketId,
      userId,
      userName,
      isTyping,
      timestamp: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating typing status:', error);
    throw error;
  }
};

// S'abonner au statut de frappe
export const subscribeToTypingStatus = (
  ticketId: string,
  currentUserId: string,
  callback: (users: { userId: string; userName: string }[]) => void
): (() => void) => {
  const q = query(
    collection(db, 'ticketTyping'),
    where('ticketId', '==', ticketId),
    where('isTyping', '==', true)
  );

  return onSnapshot(q, (snapshot) => {
    const typingUsers = snapshot.docs
      .map(doc => doc.data())
      .filter(data => data.userId !== currentUserId)
      .map(data => ({
        userId: data.userId,
        userName: data.userName
      }));
    callback(typingUsers);
  });
};

// Ajouter un message
export const addTicketMessage = async (
  ticketId: string,
  senderId: string,
  senderName: string,
  content: string,
  isAdmin: boolean,
  attachments?: File[]
): Promise<TicketMessage> => {
  try {
    return await runTransaction(db, async (transaction) => {
      const ticketRef = doc(db, 'tickets', ticketId);
      const ticketDoc = await transaction.get(ticketRef);
      
      if (!ticketDoc.exists()) {
        throw new Error('Ticket not found');
      }

      const ticketData = ticketDoc.data();
      const now = Timestamp.now();

      // Gérer les pièces jointes
      const uploadedAttachments = attachments ? await Promise.all(
        attachments.map(async file => {
          const url = await uploadTicketAttachment(ticketId, file);
          return {
            url,
            name: file.name,
            type: file.type,
            size: file.size
          };
        })
      ) : undefined;

      // Créer le message
      const messageRef = doc(collection(db, 'ticketMessages'));
      const message: TicketMessage = {
        id: messageRef.id,
        ticketId,
        content,
        senderId,
        senderName,
        senderRole: isAdmin ? 'admin' : 'user',
        attachments: uploadedAttachments,
        read: false,
        createdAt: now.toDate()
      };

      // Mettre à jour le ticket
      const updates: any = {
        lastMessage: {
          content,
          createdAt: now
        },
        updatedAt: now,
        unreadCount: increment(1)
      };

      // Mettre à jour le statut si c'est une réponse admin
      if (isAdmin && ticketData.status === 'open') {
        updates.status = 'processing';
      }

      transaction.update(ticketRef, updates);
      transaction.set(messageRef, {
        ...message,
        createdAt: now
      });

      return message;
    });
  } catch (error) {
    console.error('Error adding ticket message:', error);
    throw error;
  }
};

// Mettre à jour le statut d'un ticket
export const updateTicketStatus = async (ticketId: string, newStatus: Ticket['status']): Promise<void> => {
  try {
    const ticketRef = doc(db, 'tickets', ticketId);
    await updateDoc(ticketRef, {
      status: newStatus,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error updating ticket status:', error);
    throw error;
  }
};

// Marquer un ticket comme lu
export const markTicketAsRead = async (ticketId: string): Promise<void> => {
  try {
    const ticketRef = doc(db, 'tickets', ticketId);
    await updateDoc(ticketRef, {
      unreadCount: 0,
      updatedAt: Timestamp.now()
    });
  } catch (error) {
    console.error('Error marking ticket as read:', error);
    throw error;
  }
};

// S'abonner aux messages d'un ticket
export const subscribeToTicketMessages = (
  ticketId: string,
  callback: (messages: TicketMessage[]) => void
): (() => void) => {
  const q = query(
    collection(db, 'ticketMessages'),
    where('ticketId', '==', ticketId),
    orderBy('createdAt', 'asc')
  );

  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map(doc => ({
      ...doc.data(),
      id: doc.id,
      createdAt: doc.data().createdAt.toDate()
    })) as TicketMessage[];
    callback(messages);
  });
};