import React from 'react';
import { motion } from 'framer-motion';
import DashboardStats from '../components/dashboard/DashboardStats';
import RecentOrders from '../components/dashboard/RecentOrders';
import AffiliateCard from '../components/dashboard/AffiliateCard';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = () => {
  const { currentUser } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50 py-6 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 md:mb-8"
        >
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Tableau de bord</h1>
          <p className="text-gray-600 text-sm md:text-base">
            Bienvenue {currentUser?.name || 'sur votre espace personnel'}
          </p>
        </motion.div>

        <div className="space-y-6 md:space-y-8">
          <DashboardStats />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <RecentOrders />
            </div>
            <div className="order-first lg:order-none">
              <AffiliateCard />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;