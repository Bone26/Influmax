import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Star, Crown } from 'lucide-react';

interface RewardCardProps {
  level: string;
  name: string;
  icon: any;
  unlockAmount: number;
  color: string;
  reward: string;
  imageUrl: string;
  description: string;
  isUnlocked: boolean;
  isClaimed: boolean;
  onClaim: () => void;
}

const RewardCard: React.FC<RewardCardProps> = ({
  level,
  name,
  icon: Icon,
  unlockAmount,
  color,
  reward,
  imageUrl,
  description,
  isUnlocked,
  isClaimed,
  onClaim
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-xl"
    >
      <div className="relative h-48">
        <img
          src={imageUrl}
          alt={reward}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        <div className="absolute top-4 right-4">
          <div className={`bg-gradient-to-r ${color} px-4 py-1 rounded-full text-sm font-medium text-white`}>
            Niveau {name}
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`p-3 rounded-lg bg-gradient-to-r ${color}`}>
            <Icon className="h-6 w-6 text-white" />
          </div>
          <div className="text-right">
            <div className="text-gray-500 text-sm">Débloqué à</div>
            <div className="text-xl font-bold">{unlockAmount.toLocaleString()}€</div>
          </div>
        </div>

        <h3 className="text-2xl font-bold mb-2">{reward}</h3>
        <p className="text-gray-600 text-sm mb-4">{description}</p>

        <button
          onClick={onClaim}
          disabled={!isUnlocked || isClaimed}
          className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
            !isUnlocked
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : isClaimed
              ? 'bg-green-100 text-green-700 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:opacity-90'
          }`}
        >
          {!isUnlocked 
            ? 'À débloquer' 
            : isClaimed 
            ? 'Déjà réclamé' 
            : 'Réclamer ma récompense'}
        </button>
      </div>
    </motion.div>
  );
};

export default RewardCard;