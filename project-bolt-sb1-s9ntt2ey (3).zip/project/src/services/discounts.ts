import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  Timestamp,
  increment
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ServiceDiscount } from '../types/service';

// Créer une nouvelle réduction
export const createDiscount = async (data: Omit<ServiceDiscount, 'id' | 'currentUsage' | 'createdAt' | 'updatedAt'>): Promise<ServiceDiscount> => {
  try {
    const discountRef = doc(collection(db, 'serviceDiscounts'));
    const now = new Date();
    
    const discount: ServiceDiscount = {
      id: discountRef.id,
      ...data,
      currentUsage: 0,
      createdAt: now,
      updatedAt: now
    };

    await setDoc(discountRef, {
      ...discount,
      validFrom: Timestamp.fromDate(discount.validFrom),
      validTo: Timestamp.fromDate(discount.validTo),
      createdAt: Timestamp.fromDate(now),
      updatedAt: Timestamp.fromDate(now)
    });

    return discount;
  } catch (error) {
    console.error('Error creating discount:', error);
    throw error;
  }
};

// Récupérer les réductions actives pour un service
export const getActiveDiscounts = async (serviceId: string): Promise<ServiceDiscount[]> => {
  try {
    const now = new Date();
    const q = query(
      collection(db, 'serviceDiscounts'),
      where('serviceId', '==', serviceId),
      where('isActive', '==', true),
      where('validFrom', '<=', Timestamp.fromDate(now)),
      where('validTo', '>=', Timestamp.fromDate(now))
    );

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs
      .map(doc => ({
        ...doc.data(),
        validFrom: doc.data().validFrom.toDate(),
        validTo: doc.data().validTo.toDate(),
        createdAt: doc.data().createdAt.toDate(),
        updatedAt: doc.data().updatedAt.toDate()
      }))
      .filter(discount => 
        !discount.usageLimit || discount.currentUsage < discount.usageLimit
      ) as ServiceDiscount[];
  } catch (error) {
    console.error('Error getting active discounts:', error);
    throw error;
  }
};

// Mettre à jour une réduction
export const updateDiscount = async (id: string, data: Partial<ServiceDiscount>): Promise<void> => {
  try {
    const discountRef = doc(db, 'serviceDiscounts', id);
    await updateDoc(discountRef, {
      ...data,
      updatedAt: Timestamp.fromDate(new Date())
    });
  } catch (error) {
    console.error('Error updating discount:', error);
    throw error;
  }
};

// Supprimer une réduction
export const deleteDiscount = async (id: string): Promise<void> => {
  try {
    const discountRef = doc(db, 'serviceDiscounts', id);
    await updateDoc(discountRef, {
      isActive: false,
      updatedAt: Timestamp.fromDate(new Date())
    });
  } catch (error) {
    console.error('Error deleting discount:', error);
    throw error;
  }
};

// Utiliser une réduction
export const useDiscount = async (id: string): Promise<void> => {
  try {
    const discountRef = doc(db, 'serviceDiscounts', id);
    await updateDoc(discountRef, {
      currentUsage: increment(1),
      updatedAt: Timestamp.fromDate(new Date())
    });
  } catch (error) {
    console.error('Error using discount:', error);
    throw error;
  }
};