import React from 'react';
import { motion } from 'framer-motion';
import { Edit2, Trash2, Power } from 'lucide-react';
import { Service } from '../../types/service';

interface ServiceCardProps {
  service: Service;
  onEdit: () => void;
  onDelete: () => void;
  onToggleActive: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({
  service,
  onEdit,
  onDelete,
  onToggleActive
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 ${
        !service.isActive ? 'opacity-60' : ''
      }`}
    >
      <div className="flex justify-between items-start mb-6">
        <div>
          <h3 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
            {service.name}
          </h3>
          <p className="text-sm text-gray-500">{service.type}</p>
        </div>
        <div className="flex space-x-2">
          <button
            onClick={onToggleActive}
            className={`p-2 rounded-lg transition-colors ${
              service.isActive 
                ? 'text-green-600 hover:bg-green-50' 
                : 'text-red-600 hover:bg-red-50'
            }`}
            title={service.isActive ? 'Désactiver' : 'Activer'}
          >
            <Power className="h-5 w-5" />
          </button>
          <button
            onClick={onEdit}
            className="p-2 text-gray-600 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition-colors"
          >
            <Edit2 className="h-5 w-5" />
          </button>
          <button
            onClick={onDelete}
            className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <Trash2 className="h-5 w-5" />
          </button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
          <span className="text-gray-600">Prix de base</span>
          <span className="text-lg font-bold text-purple-600">{service.basePrice}€</span>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-gray-50 rounded-lg">
            <span className="text-sm text-gray-500">Min</span>
            <p className="text-lg font-semibold">{service.minQuantity}</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <span className="text-sm text-gray-500">Max</span>
            <p className="text-lg font-semibold">{service.maxQuantity}</p>
          </div>
        </div>

        <div>
          <span className="text-sm text-gray-500 block mb-2">Qualités disponibles</span>
          <div className="flex flex-wrap gap-2">
            {service.qualities?.filter(q => q.isAvailable).map(q => (
              <span
                key={q.type}
                className="px-3 py-1 bg-gradient-to-r from-purple-500 to-indigo-500 text-white rounded-full text-sm font-medium"
              >
                {q.type}
              </span>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ServiceCard;