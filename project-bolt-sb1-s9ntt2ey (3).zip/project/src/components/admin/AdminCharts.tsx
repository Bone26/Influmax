import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';

interface AdminChartsProps {
  orders: any[];
}

const AdminCharts: React.FC<AdminChartsProps> = ({ orders }) => {
  // Préparer les données pour le graphique des commandes par jour
  const ordersByDay = orders.reduce((acc: any, order) => {
    if (!order.timestamps?.createdAt) {
      return acc;
    }

    const date = format(
      typeof order.timestamps.createdAt === 'string' 
        ? new Date(order.timestamps.createdAt)
        : order.timestamps.createdAt,
      'yyyy-MM-dd'
    );

    if (!acc[date]) {
      acc[date] = {
        date,
        orders: 0,
        revenue: 0
      };
    }
    acc[date].orders++;
    acc[date].revenue += order.price || 0;
    return acc;
  }, {});

  const chartData = Object.values(ordersByDay).sort((a: any, b: any) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  // Préparer les données pour le graphique des statuts
  const statusData = [
    { name: 'En cours', value: orders.filter(o => o.status === 'processing').length },
    { name: 'Terminées', value: orders.filter(o => o.status === 'completed').length },
    { name: 'Annulées', value: orders.filter(o => o.status === 'cancelled').length }
  ];

  // Préparer les données pour le graphique de répartition par qualité
  const qualityData = [
    { name: 'Standard', value: orders.filter(o => o.service?.quality === 'standard').length },
    { name: 'Premium', value: orders.filter(o => o.service?.quality === 'premium').length },
    { name: 'VIP', value: orders.filter(o => o.service?.quality === 'vip').length }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h3 className="text-lg font-semibold mb-4">Commandes par jour</h3>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => format(new Date(date), 'dd/MM', { locale: fr })}
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(date) => format(new Date(date), 'PPP', { locale: fr })}
                formatter={(value: number) => [value, 'Commandes']}
              />
              <Line 
                type="monotone" 
                dataKey="orders" 
                stroke="#8b5cf6" 
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h3 className="text-lg font-semibold mb-4">Revenu par jour</h3>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => format(new Date(date), 'dd/MM', { locale: fr })}
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(date) => format(new Date(date), 'PPP', { locale: fr })}
                formatter={(value: number) => [`${value.toFixed(2)}€`, 'Revenu']}
              />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="#10b981" 
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h3 className="text-lg font-semibold mb-4">Statuts des commandes</h3>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={statusData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-white rounded-xl shadow-sm p-6"
      >
        <h3 className="text-lg font-semibold mb-4">Répartition par qualité</h3>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={qualityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#6366f1" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminCharts;