export interface JAPService {
  id: string;
  japServiceId: string;
  japServiceName: string;
  platform: 'instagram' | 'tiktok' | 'telegram';
  type: string;
  quality: 'standard' | 'premium' | 'vip';
  rate: number;
  minQuantity: number;
  maxQuantity: number;
  maxSpeed: number;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface JAPServiceMapping {
  serviceId: string;
  japServiceId: string;
  platform: string;
  type: string;
  quality: string;
  isActive: boolean;
}

export interface JAPServiceStats {
  totalOrders: number;
  successfulOrders: number;
  failedOrders: number;
  averageDeliveryTime: number;
  lastSync: Date;
}