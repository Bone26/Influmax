import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Clock, ShoppingBag, Wallet } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getWalletBalance } from '../../services/wallet';
import { getAllOrders } from '../../services/orders';

const DashboardStats = () => {
  const { currentUser } = useAuth();
  const [balance, setBalance] = useState(0);
  const [activeOrders, setActiveOrders] = useState(0);
  const [completedOrders, setCompletedOrders] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      if (currentUser) {
        try {
          // Charger le solde
          const walletData = await getWalletBalance(currentUser.id);
          setBalance(walletData.balance);

          // Charger les commandes
          const orders = await getAllOrders(currentUser.id);
          const activeOrdersCount = orders.filter(
            order => order.status === 'pending' || order.status === 'processing'
          ).length;
          const completedOrdersCount = orders.filter(
            order => order.status === 'completed'
          ).length;
          
          setActiveOrders(activeOrdersCount);
          setCompletedOrders(completedOrdersCount);
        } catch (error) {
          console.error('Error loading dashboard data:', error);
        } finally {
          setLoading(false);
        }
      }
    };

    loadData();
  }, [currentUser]);

  const stats = [
    {
      icon: Wallet,
      label: "Solde",
      value: `${balance.toFixed(2)}€`,
      color: 'bg-purple-100',
      textColor: 'text-purple-600'
    },
    {
      icon: Clock,
      label: "Commandes actives",
      value: activeOrders,
      color: 'bg-blue-100',
      textColor: 'text-blue-600'
    },
    {
      icon: ShoppingBag,
      label: "Commandes terminées",
      value: completedOrders,
      color: 'bg-green-100',
      textColor: 'text-green-600'
    },
    {
      icon: TrendingUp,
      label: "Total des commandes",
      value: activeOrders + completedOrders,
      color: 'bg-pink-100',
      textColor: 'text-pink-600'
    }
  ];

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm p-6 animate-pulse">
            <div className="h-4 w-24 bg-gray-200 rounded mb-4"></div>
            <div className="h-8 w-32 bg-gray-300 rounded"></div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">{stat.label}</p>
              <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
            </div>
            <div className={`${stat.color} rounded-lg p-3`}>
              <stat.icon className={`h-6 w-6 ${stat.textColor}`} />
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default DashboardStats;