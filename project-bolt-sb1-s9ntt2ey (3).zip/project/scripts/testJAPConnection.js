import 'dotenv/config';
import axios from 'axios';

const testJAPConnection = async () => {
  console.log('🔍 Test de connexion à l\'API JAP...\n');

  // Vérifier les variables d'environnement
  if (!process.env.VITE_API_URL) {
    console.error('❌ URL de l\'API manquante dans .env');
    process.exit(1);
  }

  if (!process.env.VITE_API_KEY) {
    console.error('❌ Clé API manquante dans .env');
    process.exit(1);
  }

  console.log('URL:', process.env.VITE_API_URL);
  console.log('API Key:', '✓ Présente\n');

  // Créer l'instance axios avec la bonne configuration
  const japApi = axios.create({
    baseURL: process.env.VITE_API_URL,
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache',
      'User-Agent': 'PostmanRuntime/7.43.0'
    },
    timeout: 30000
  });

  try {
    // Test de récupération des services
    console.log('1️⃣ Test de l\'endpoint /services...');
    const servicesResponse = await japApi.post('/services', {
      key: process.env.VITE_API_KEY,
      action: 'services'
    });
    const services = servicesResponse.data;

    if (!Array.isArray(services)) {
      throw new Error('Format de réponse invalide');
    }

    console.log(`✅ ${services.length} services récupérés\n`);

    // Afficher quelques services
    console.log('2️⃣ Échantillon de services:');
    services.slice(0, 3).forEach(service => {
      console.log(`
        ID: ${service.service}
        Nom: ${service.name}
        Min: ${service.min}
        Max: ${service.max}
        Prix: ${service.rate}
      `);
    });

    // Test de création d'une commande
    console.log('\n3️⃣ Test de l\'endpoint /add...');
    const testOrder = {
      key: process.env.VITE_API_KEY,
      action: 'add',
      service: '4343', // Instagram Likes
      link: 'https://www.instagram.com/p/example',
      quantity: 100
    };

    const orderResponse = await japApi.post('/add', testOrder);
    console.log('✅ Test de commande réussi:', orderResponse.data);

    console.log('\n🎉 Tests de connexion réussis !');
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Erreur lors des tests:', error.message);
    
    if (error.response) {
      console.error(`Status: ${error.response.status}`);
      console.error('Message:', error.response.data);
      
      if (error.response.status === 401) {
        console.log('\n👉 Erreur d\'authentification');
        console.log('Suggestions:');
        console.log('1. Vérifiez que votre clé API est correcte');
        console.log('2. Vérifiez que la clé n\'a pas expiré');
      }
    } else if (error.code === 'ECONNREFUSED') {
      console.log('\n👉 Impossible de se connecter au serveur.');
      console.log('Suggestions:');
      console.log('1. Vérifiez votre connexion Internet');
      console.log('2. Vérifiez que l\'URL de l\'API est accessible');
    }
    
    process.exit(1);
  }
};

testJAPConnection();