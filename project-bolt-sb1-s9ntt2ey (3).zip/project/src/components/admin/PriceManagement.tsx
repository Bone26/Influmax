// ... (garder le début du fichier inchangé jusqu'à la fonction renderTelegramReactionForm)

const renderTelegramReactionForm = (price: ServicePriceConfig) => {
  return (
    <TelegramReactionPriceForm
      price={price}
      formData={formData}
      onChange={setFormData}
    />
  );
};

// ... (garder le reste du fichier inchangé)