import { Rocket, Shield, BarChart, CheckCircle } from 'lucide-react';

export const steps = [
  {
    icon: Rocket,
    title: "1. Choisissez",
    description: "Sélectionnez le service qui correspond à vos besoins",
    color: "from-blue-500 to-purple-500"
  },
  {
    icon: Shield,
    title: "2. Commandez",
    description: "Passez votre commande en quelques clics",
    color: "from-purple-500 to-pink-500"
  },
  {
    icon: BarChart,
    title: "3. Suivez",
    description: "Visualisez la progression en temps réel",
    color: "from-pink-500 to-red-500"
  },
  {
    icon: CheckCircle,
    title: "4. Profitez",
    description: "Constatez l'augmentation de votre visibilité",
    color: "from-red-500 to-orange-500"
  }
];