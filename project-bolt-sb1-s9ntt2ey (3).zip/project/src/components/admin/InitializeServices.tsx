import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { collection, doc, setDoc, getDocs, query, where, Timestamp } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

interface InitializeServicesProps {
  onSuccess: () => void;
}

const InitializeServices: React.FC<InitializeServicesProps> = ({ onSuccess }) => {
  const [loading, setLoading] = useState(false);

  const initializeServices = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir réinitialiser tous les services ? Cette action est irréversible.')) {
      return;
    }

    setLoading(true);
    console.log('🚀 Initialisation des services...');

    try {
      // 1. Récupérer les IDs des plateformes
      const platformsQuery = query(
        collection(db, 'platforms'),
        where('isActive', '==', true)
      );
      
      const platformsSnapshot = await getDocs(platformsQuery);
      const platforms = {};
      platformsSnapshot.docs.forEach(doc => {
        platforms[doc.data().name.toLowerCase()] = doc.id;
      });

      // 2. Définir les services
      const services = [
        // Instagram Services
        {
          name: 'Followers Instagram',
          platformId: platforms.instagram,
          type: 'followers',
          basePrice: 0.005,
          deliveryLimits: {
            instant: { min: 100, max: 200000 },
            '24h': { min: 150, max: 150000 },
            '3days': { min: 200, max: 100000 },
            '7days': { min: 500, max: 50000 },
            '1month': { min: 1000, max: 20000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Idéal pour débuter',
              imageUrl: 'https://i.imgur.com/5E8ovBu.jpeg',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: false },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: false, info: '6-12 mois' }
              ]
            },
            { 
              type: 'premium', 
              multiplier: 1.5, 
              isAvailable: true,
              name: 'Premium',
              description: 'Les plus réalistes',
              imageUrl: 'https://i.imgur.com/LpgsIxY.jpeg',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: true },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            },
            { 
              type: 'vip', 
              multiplier: 2, 
              isAvailable: true,
              name: 'VIP 🇫🇷',
              description: 'L\'excellence',
              imageUrl: 'https://i.imgur.com/pNu9MVv.jpeg',
              features: [
                { label: 'Profils français', value: true },
                { label: 'Profils réalistes', value: true },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Likes Instagram',
          platformId: platforms.instagram,
          type: 'likes',
          basePrice: 0.002,
          deliveryLimits: {
            instant: { min: 100, max: 500000 },
            '24h': { min: 150, max: 400000 },
            '3days': { min: 200, max: 300000 },
            '7days': { min: 500, max: 200000 },
            '1month': { min: 1000, max: 100000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Idéal pour débuter',
              imageUrl: 'https://i.imgur.com/5E8ovBu.jpeg',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: false },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: false, info: '6-12 mois' }
              ]
            },
            { 
              type: 'premium', 
              multiplier: 1.5, 
              isAvailable: true,
              name: 'Premium',
              description: 'Les plus réalistes',
              imageUrl: 'https://i.imgur.com/LpgsIxY.jpeg',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: true },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            },
            { 
              type: 'vip', 
              multiplier: 2, 
              isAvailable: true,
              name: 'VIP 🇫🇷',
              description: 'L\'excellence',
              imageUrl: 'https://i.imgur.com/pNu9MVv.jpeg',
              features: [
                { label: 'Profils français', value: true },
                { label: 'Profils réalistes', value: true },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Vues Réels',
          platformId: platforms.instagram,
          type: 'views',
          basePrice: 0.0005,
          deliveryLimits: {
            instant: { min: 1000, max: 100000000 },
            '24h': { min: 2000, max: 50000000 },
            '3days': { min: 5000, max: 20000000 },
            '7days': { min: 10000, max: 10000000 },
            '1month': { min: 20000, max: 5000000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Vues de qualité',
              imageUrl: 'https://i.imgur.com/5E8ovBu.jpeg',
              features: [
                { label: 'Vues réelles', value: true },
                { label: 'Rétention élevée', value: true },
                { label: 'Engagement naturel', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },

        // TikTok Services
        {
          name: 'Followers TikTok',
          platformId: platforms.tiktok,
          type: 'followers',
          basePrice: 0.02,
          deliveryLimits: {
            instant: { min: 100, max: 100000 },
            '24h': { min: 150, max: 75000 },
            '3days': { min: 200, max: 50000 },
            '7days': { min: 500, max: 25000 },
            '1month': { min: 1000, max: 10000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Basique',
              imageUrl: 'https://i.imgur.com/cg3cJSh.jpeg',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: false },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: false, info: '6-12 mois' }
              ]
            },
            { 
              type: 'premium', 
              multiplier: 1.5, 
              isAvailable: true,
              name: 'Premium',
              description: 'Qualité supérieure',
              imageUrl: 'https://i.imgur.com/bShMrhQ.png',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: true },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Likes TikTok',
          platformId: platforms.tiktok,
          type: 'likes',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 100, max: 100000 },
            '24h': { min: 150, max: 75000 },
            '3days': { min: 200, max: 50000 },
            '7days': { min: 500, max: 25000 },
            '1month': { min: 1000, max: 10000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Basique',
              imageUrl: 'https://i.imgur.com/cg3cJSh.jpeg',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: false },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: false, info: '6-12 mois' }
              ]
            },
            { 
              type: 'premium', 
              multiplier: 1.5, 
              isAvailable: true,
              name: 'Premium',
              description: 'Qualité supérieure',
              imageUrl: 'https://i.imgur.com/bShMrhQ.png',
              features: [
                { label: 'Profils français', value: false },
                { label: 'Profils réalistes', value: true },
                { label: 'Profils avec photo', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Vues TikTok',
          platformId: platforms.tiktok,
          type: 'views',
          basePrice: 0.00002,
          deliveryLimits: {
            instant: { min: 1000, max: 30000000 },
            '24h': { min: 2000, max: 20000000 },
            '3days': { min: 5000, max: 10000000 },
            '7days': { min: 10000, max: 5000000 },
            '1month': { min: 20000, max: 1000000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Vues de qualité',
              imageUrl: 'https://i.imgur.com/cg3cJSh.jpeg',
              features: [
                { label: 'Vues réelles', value: true },
                { label: 'Rétention élevée', value: true },
                { label: 'Engagement naturel', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Enregistrements TikTok',
          platformId: platforms.tiktok,
          type: 'saves',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 1000, max: 100000 },
            '24h': { min: 2000, max: 75000 },
            '3days': { min: 5000, max: 50000 },
            '7days': { min: 10000, max: 25000 },
            '1month': { min: 20000, max: 10000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Enregistrements de qualité',
              imageUrl: 'https://i.imgur.com/cg3cJSh.jpeg',
              features: [
                { label: 'Profils réels', value: true },
                { label: 'Engagement naturel', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Partages TikTok',
          platformId: platforms.tiktok,
          type: 'shares',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 100, max: 2000000 },
            '24h': { min: 200, max: 1500000 },
            '3days': { min: 500, max: 1000000 },
            '7days': { min: 1000, max: 500000 },
            '1month': { min: 2000, max: 200000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Partages de qualité',
              imageUrl: 'https://i.imgur.com/cg3cJSh.jpeg',
              features: [
                { label: 'Profils réels', value: true },
                { label: 'Engagement naturel', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },

        // Telegram Services
        {
          name: 'Membres Telegram',
          platformId: platforms.telegram,
          type: 'members',
          basePrice: 0.01,
          deliveryLimits: {
            instant: { min: 500, max: 100000 },
            '24h': { min: 1000, max: 75000 },
            '3days': { min: 2000, max: 50000 },
            '7days': { min: 5000, max: 25000 },
            '1month': { min: 10000, max: 10000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Membres de qualité',
              imageUrl: 'https://i.imgur.com/LpgsIxY.jpeg',
              features: [
                { label: 'Membres actifs', value: true },
                { label: 'Photos de profil', value: true },
                { label: 'Noms réalistes', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Réactions Telegram',
          platformId: platforms.telegram,
          type: 'reactions',
          basePrice: 0.001,
          deliveryLimits: {
            instant: { min: 500, max: 100000 },
            '24h': { min: 1000, max: 75000 },
            '3days': { min: 2000, max: 50000 },
            '7days': { min: 5000, max: 25000 },
            '1month': { min: 10000, max: 10000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Réactions de qualité',
              imageUrl: 'https://i.imgur.com/LpgsIxY.jpeg',
              features: [
                { label: 'Réactions réelles', value: true },
                { label: 'Choix des émojis', value: true },
                { label: 'Profils actifs', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Vues Telegram',
          platformId: platforms.telegram,
          type: 'views',
          basePrice: 0.0005,
          deliveryLimits: {
            instant: { min: 100, max: 100000 },
            '24h': { min: 200, max: 75000 },
            '3days': { min: 500, max: 50000 },
            '7days': { min: 1000, max: 25000 },
            '1month': { min: 2000, max: 10000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Vues de qualité',
              imageUrl: 'https://i.imgur.com/LpgsIxY.jpeg',
              features: [
                { label: 'Vues réelles', value: true },
                { label: 'Rétention élevée', value: true },
                { label: 'Engagement naturel', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        },
        {
          name: 'Votes Sondage Telegram',
          platformId: platforms.telegram,
          type: 'votes',
          basePrice: 0.003,
          deliveryLimits: {
            instant: { min: 100, max: 300000 },
            '24h': { min: 200, max: 200000 },
            '3days': { min: 500, max: 100000 },
            '7days': { min: 1000, max: 50000 },
            '1month': { min: 2000, max: 20000 }
          },
          qualities: [
            { 
              type: 'standard', 
              multiplier: 1, 
              isAvailable: true,
              name: 'Standard',
              description: 'Votes de qualité',
              imageUrl: 'https://i.imgur.com/LpgsIxY.jpeg',
              features: [
                { label: 'Votes réels', value: true },
                { label: 'Profils actifs', value: true },
                { label: 'Durée de vie', value: true, info: '∞' }
              ]
            }
          ],
          deliveryTimes: [
            { type: 'instant', multiplier: 1, isAvailable: true },
            { type: '24h', multiplier: 1.1, isAvailable: true },
            { type: '3days', multiplier: 1.2, isAvailable: true },
            { type: '7days', multiplier: 1.3, isAvailable: true },
            { type: '1month', multiplier: 1.5, isAvailable: true }
          ],
          isActive: true
        }
      ];

      // 3. Créer les services
      for (const service of services) {
        const serviceRef = doc(collection(db, 'services'));
        const now = new Date();
        
        await setDoc(serviceRef, {
          id: serviceRef.id,
          ...service,
          createdAt: Timestamp.fromDate(now),
          updatedAt: Timestamp.fromDate(now)
        });
        
        console.log(`✅ Service créé : ${service.name}`);
        toast.success(`Service créé : ${service.name}`);
      }

      toast.success('Initialisation des services terminée avec succès !');
      onSuccess(); // Rafraîchir la liste des services
    } catch (error) {
      console.error('Error initializing services:', error);
      toast.error('Erreur lors de l\'initialisation des services');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-6 right-6"
    >
      <button
        onClick={initializeServices}
        disabled={loading}
        className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-3 rounded-xl shadow-lg hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 transition-all duration-300"
      >
        {loading ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Initialisation...</span>
          </>
        ) : (
          <>
            <span>Initialiser les services</span>
          </>
        )}
      </button>
    </motion.div>
  );
};

export default InitializeServices;