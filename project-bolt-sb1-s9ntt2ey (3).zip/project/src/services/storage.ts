import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'sonner';

const storage = getStorage();

// Taille maximale de 2MB pour les photos de profil
const MAX_PROFILE_PHOTO_SIZE = 2 * 1024 * 1024;
const ALLOWED_PROFILE_PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

// Taille maximale de 10MB pour les pièces jointes de tickets
const MAX_TICKET_ATTACHMENT_SIZE = 10 * 1024 * 1024;
const ALLOWED_TICKET_ATTACHMENT_TYPES = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];

export const uploadProfilePhoto = async (userId: string, file: File): Promise<string> => {
  try {
    // Validation du fichier
    if (file.size > MAX_PROFILE_PHOTO_SIZE) {
      throw new Error('La taille du fichier ne doit pas dépasser 2MB');
    }
    
    if (!ALLOWED_PROFILE_PHOTO_TYPES.includes(file.type)) {
      throw new Error('Format de fichier non supporté. Utilisez JPG, PNG ou WebP');
    }

    // Créer la référence du fichier
    const fileRef = ref(storage, `profile-photos/${userId}`);
    
    // Upload du fichier
    await uploadBytes(fileRef, file);
    
    // Récupérer l'URL
    const downloadURL = await getDownloadURL(fileRef);
    
    // Mettre à jour le document utilisateur
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, {
      photoURL: downloadURL,
      updatedAt: new Date()
    });

    return downloadURL;
  } catch (error) {
    console.error('Error uploading profile photo:', error);
    throw error;
  }
};

export const deleteProfilePhoto = async (userId: string): Promise<void> => {
  try {
    const fileRef = ref(storage, `profile-photos/${userId}`);
    await deleteObject(fileRef);
    
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, {
      photoURL: null,
      updatedAt: new Date()
    });
  } catch (error) {
    console.error('Error deleting profile photo:', error);
    throw error;
  }
};

export const uploadTicketAttachment = async (ticketId: string, file: File): Promise<string> => {
  console.log('🚀 Début de l\'upload pour le ticket', ticketId);
  console.log('📁 Fichier:', {
    name: file.name,
    type: file.type,
    size: `${(file.size / 1024 / 1024).toFixed(2)}MB`
  });

  try {
    // Validation du fichier
    if (file.size > MAX_TICKET_ATTACHMENT_SIZE) {
      console.error('❌ Fichier trop volumineux:', file.size);
      throw new Error('La taille du fichier ne doit pas dépasser 10MB');
    }

    if (!ALLOWED_TICKET_ATTACHMENT_TYPES.includes(file.type)) {
      console.error('❌ Type de fichier non supporté:', file.type);
      throw new Error('Format de fichier non supporté');
    }

    // Créer un nom de fichier unique
    const fileName = `${Date.now()}-${file.name}`;
    console.log('📝 Nom du fichier généré:', fileName);

    const fileRef = ref(storage, `ticket-attachments/${ticketId}/${fileName}`);
    console.log('🔗 Chemin de stockage:', `ticket-attachments/${ticketId}/${fileName}`);

    // Upload du fichier
    console.log('⏳ Début de l\'upload...');
    const snapshot = await uploadBytes(fileRef, file);
    console.log('✅ Upload terminé:', snapshot);

    // Récupérer l'URL
    console.log('🔍 Récupération de l\'URL...');
    const downloadURL = await getDownloadURL(fileRef);
    console.log('✅ URL obtenue:', downloadURL);

    return downloadURL;
  } catch (error) {
    console.error('❌ Erreur lors de l\'upload:', error);
    if (error instanceof Error) {
      // Log détaillé de l'erreur
      console.error('Type d\'erreur:', error.name);
      console.error('Message:', error.message);
      console.error('Stack:', error.stack);
    }
    throw error;
  }
};