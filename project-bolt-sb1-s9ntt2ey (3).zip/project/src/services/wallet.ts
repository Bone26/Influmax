import { collection, doc, getDoc, setDoc, updateDoc, increment, Timestamp, runTransaction, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { DepositWallet, WalletDeposit } from '../types/wallet';
import { getAffiliateByUserId } from './affiliate';
import { sendDepositNotification, sendCommissionNotification } from './notifications';
import { WALLET_CONFIG } from '../config/wallet';

// Récupérer le wallet de dépôt
export const getWalletBalance = async (userId: string): Promise<DepositWallet> => {
  try {
    const walletRef = doc(collection(db, 'depositWallets'), userId);
    const walletDoc = await getDoc(walletRef);

    if (!walletDoc.exists()) {
      // Créer un nouveau wallet si inexistant
      const now = new Date();
      const newWallet: DepositWallet = {
        id: userId,
        userId,
        balance: 0,
        hasReceivedWelcomeBonus: false,
        createdAt: now,
        updatedAt: now
      };

      await setDoc(walletRef, {
        ...newWallet,
        createdAt: Timestamp.fromDate(now),
        updatedAt: Timestamp.fromDate(now)
      });

      return newWallet;
    }

    const data = walletDoc.data();
    return {
      id: walletDoc.id,
      userId: data.userId,
      balance: data.balance || 0,
      hasReceivedWelcomeBonus: data.hasReceivedWelcomeBonus || false,
      createdAt: data.createdAt.toDate(),
      updatedAt: data.updatedAt.toDate()
    };
  } catch (error) {
    console.error('Error getting wallet balance:', error);
    throw error;
  }
};

// Ajouter des fonds au wallet
export const addFunds = async (userId: string, amount: number): Promise<DepositWallet> => {
  if (amount < WALLET_CONFIG.MIN_DEPOSIT) {
    throw new Error(`Le montant minimum de dépôt est de ${WALLET_CONFIG.MIN_DEPOSIT}€`);
  }

  if (amount > WALLET_CONFIG.MAX_DEPOSIT) {
    throw new Error(`Le montant maximum de dépôt est de ${WALLET_CONFIG.MAX_DEPOSIT}€`);
  }

  try {
    return await runTransaction(db, async (transaction) => {
      // 1. Récupérer le wallet
      const walletRef = doc(collection(db, 'depositWallets'), userId);
      const walletDoc = await transaction.get(walletRef);
      const wallet = walletDoc.exists() ? walletDoc.data() : null;
      const now = Timestamp.now();

      // 2. Vérifier si l'utilisateur peut recevoir le bonus
      const shouldReceiveBonus = !wallet?.hasReceivedWelcomeBonus && amount >= 50;
      const bonusAmount = shouldReceiveBonus ? 10 : 0;

      // 3. Créer ou mettre à jour le wallet
      const updatedWallet: DepositWallet = {
        id: userId,
        userId,
        balance: (wallet?.balance || 0) + amount + bonusAmount,
        hasReceivedWelcomeBonus: shouldReceiveBonus || (wallet?.hasReceivedWelcomeBonus || false),
        createdAt: wallet?.createdAt?.toDate() || now.toDate(),
        updatedAt: now.toDate()
      };

      transaction.set(walletRef, {
        ...updatedWallet,
        createdAt: Timestamp.fromDate(updatedWallet.createdAt),
        updatedAt: now
      });

      // 4. Enregistrer le dépôt
      const depositRef = doc(collection(db, 'walletDeposits'));
      const deposit: WalletDeposit = {
        id: depositRef.id,
        userId,
        amount,
        type: 'deposit',
        status: 'completed',
        description: 'Dépôt de fonds',
        createdAt: now.toDate()
      };

      transaction.set(depositRef, {
        ...deposit,
        createdAt: now
      });

      // 5. Enregistrer le bonus si applicable
      if (bonusAmount > 0) {
        const bonusRef = doc(collection(db, 'walletDeposits'));
        const bonus: WalletDeposit = {
          id: bonusRef.id,
          userId,
          amount: bonusAmount,
          type: 'bonus',
          status: 'completed',
          description: 'Bonus premier dépôt',
          createdAt: now.toDate()
        };

        transaction.set(bonusRef, {
          ...bonus,
          createdAt: now
        });
      }

      // 6. Gérer les commissions d'affiliation
      const user = await getAffiliateByUserId(userId);
      if (user?.affiliate?.referrerId) {
        // Commission niveau 1 (20%)
        const level1Commission = amount * 0.20;
        const referrerRef = doc(db, 'users', user.affiliate.referrerId);
        
        transaction.update(referrerRef, {
          'affiliate.stats.totalEarnings': increment(level1Commission),
          'affiliate.stats.availableEarnings': increment(level1Commission),
          updatedAt: now
        });

        // Envoyer la notification de commission niveau 1
        await sendCommissionNotification(user.affiliate.referrerId, level1Commission);

        // Chercher le parrain niveau 2
        const referrer = await getAffiliateByUserId(user.affiliate.referrerId);
        if (referrer?.affiliate?.referrerId) {
          // Commission niveau 2 (10%)
          const level2Commission = amount * 0.10;
          const level2ReferrerRef = doc(db, 'users', referrer.affiliate.referrerId);
          
          transaction.update(level2ReferrerRef, {
            'affiliate.stats.totalEarnings': increment(level2Commission),
            'affiliate.stats.availableEarnings': increment(level2Commission),
            updatedAt: now
          });

          // Envoyer la notification de commission niveau 2
          await sendCommissionNotification(referrer.affiliate.referrerId, level2Commission);
        }
      }

      // 7. Envoyer la notification de dépôt
      await sendDepositNotification(userId, amount);

      return updatedWallet;
    });
  } catch (error) {
    console.error('Error adding funds:', error);
    throw error;
  }
};

// Récupérer les transactions
export const getTransactions = async (userId: string): Promise<WalletDeposit[]> => {
  try {
    const depositsCollection = collection(db, 'walletDeposits');
    
    const q = query(
      depositsCollection,
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );

    const querySnapshot = await getDocs(q);
    return querySnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        userId: data.userId,
        amount: data.amount,
        type: data.type,
        status: data.status,
        description: data.description,
        orderId: data.orderId,
        createdAt: data.createdAt.toDate()
      };
    });
  } catch (error) {
    console.error('Error getting transactions:', error);
    throw error;
  }
};