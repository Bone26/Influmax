export interface User {
  id: string;
  email: string;
  name: string;
  photoURL?: string;
  emailVerified: boolean;
  isAdmin: boolean;
  affiliate: {
    referralCode: string;
    referrerId?: string;
    level: 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond' | 'legend';
    stats: {
      totalEarnings: number;
      availableEarnings: number;
      totalReferrals: number;
      pendingWithdrawals: number;
      processingWithdrawals: number;
    };
  };
  createdAt: Date;
  updatedAt: Date;
}