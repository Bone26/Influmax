import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Palette, ChevronDown, Check, Droplet, Brush } from 'lucide-react';
import { colorDatabase, getAllColors } from '../../data/colorDatabase';

interface ColorPickerProps {
  selectedColor: string;
  onChange: (color: string) => void;
}

const ColorPicker: React.FC<ColorPickerProps> = ({ selectedColor, onChange }) => {
  const [activeTab, setActiveTab] = useState('presets');
  const [customStart, setCustomStart] = useState('#6366f1');
  const [customEnd, setCustomEnd] = useState('#8b5cf6');
  const [showAllColors, setShowAllColors] = useState(false);

  const colorSchemes = Object.entries(colorDatabase).map(([key, category]) => ({
    name: category.name,
    colors: category.colors.flatMap(color => 
      color.variants.map(variant => ({
        gradient: variant.gradient,
        label: `${color.name} ${variant.name}`
      }))
    )
  }));

  const handleCustomGradientChange = () => {
    // Utiliser des classes Tailwind prédéfinies au lieu de valeurs dynamiques
    const startClass = `from-[${customStart}]`;
    const endClass = `to-[${customEnd}]`;
    onChange(`${startClass} ${endClass}`);
  };

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex items-center justify-between border-b pb-4">
        <div className="flex space-x-4">
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'presets'
                ? 'bg-purple-100 text-purple-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Palette className="h-4 w-4" />
            <span>Préréglages</span>
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'custom'
                ? 'bg-purple-100 text-purple-700'
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            <Droplet className="h-4 w-4" />
            <span>Personnalisé</span>
          </button>
        </div>
      </div>

      {activeTab === 'presets' ? (
        <div className="space-y-8">
          {(showAllColors ? colorSchemes : colorSchemes.slice(0, 3)).map((scheme) => (
            <motion.div
              key={scheme.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-gray-900 flex items-center space-x-2">
                  <Brush className="h-4 w-4 text-gray-400" />
                  <span>{scheme.name}</span>
                </h4>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {scheme.colors.map((color) => (
                  <motion.button
                    key={color.gradient}
                    type="button"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => onChange(color.gradient)}
                    className="group relative"
                  >
                    <div className={`
                      h-20 rounded-xl bg-gradient-to-r ${color.gradient}
                      transition-all duration-300 shadow-sm hover:shadow-lg
                      ${selectedColor === color.gradient ? 'ring-2 ring-purple-600' : ''}
                    `}>
                      {selectedColor === color.gradient && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/10">
                          <Check className="h-6 w-6 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="absolute inset-x-0 -bottom-6 opacity-0 group-hover:opacity-100 transition-opacity text-center">
                      <span className="text-xs font-medium text-gray-600 bg-white px-2 py-1 rounded-full shadow-sm">
                        {color.label}
                      </span>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ))}

          {!showAllColors && (
            <button
              onClick={() => setShowAllColors(true)}
              className="w-full py-3 text-purple-600 hover:text-purple-700 font-medium flex items-center justify-center space-x-2"
            >
              <span>Voir plus de couleurs</span>
              <ChevronDown className="h-4 w-4" />
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Couleur de début
            </label>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <input
                  type="color"
                  value={customStart}
                  onChange={(e) => {
                    setCustomStart(e.target.value);
                    handleCustomGradientChange();
                  }}
                  className="h-12 w-12 rounded-lg cursor-pointer border-0"
                />
              </div>
              <input
                type="text"
                value={customStart}
                onChange={(e) => {
                  setCustomStart(e.target.value);
                  handleCustomGradientChange();
                }}
                className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                placeholder="#000000"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Couleur de fin
            </label>
            <div className="flex items-center space-x-3">
              <div className="relative">
                <input
                  type="color"
                  value={customEnd}
                  onChange={(e) => {
                    setCustomEnd(e.target.value);
                    handleCustomGradientChange();
                  }}
                  className="h-12 w-12 rounded-lg cursor-pointer border-0"
                />
              </div>
              <input
                type="text"
                value={customEnd}
                onChange={(e) => {
                  setCustomEnd(e.target.value);
                  handleCustomGradientChange();
                }}
                className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                placeholder="#000000"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Aperçu du dégradé personnalisé
            </label>
            <div className="relative h-32 rounded-xl overflow-hidden">
              <div className={`absolute inset-0 bg-gradient-to-r from-[${customStart}] to-[${customEnd}]`} />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-white text-sm font-medium px-4 py-2 bg-black/20 rounded-lg">
                  Aperçu
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ColorPicker;