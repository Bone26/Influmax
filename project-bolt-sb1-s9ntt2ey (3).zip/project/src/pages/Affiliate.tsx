import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useAffiliate } from '../contexts/AffiliateContext';
import AffiliateStats from '../components/affiliate/AffiliateStats';
import ReferralLink from '../components/affiliate/ReferralLink';
import WithdrawCommissionForm from '../components/affiliate/WithdrawCommissionForm';

const Affiliate = () => {
  const { currentUser } = useAuth();
  const { affiliate, loading } = useAffiliate();
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 md:p-8">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="text-white/80 hover:text-white transition-colors"
              >
                <ArrowLeft className="h-6 w-6" />
              </button>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-white mb-2">
                  Programme d'affiliation
                </h1>
                <p className="text-purple-100 text-sm md:text-base">
                  Gagnez de l'argent en recommandant nos services
                </p>
              </div>
            </div>
          </div>

          <div className="p-8 space-y-8">
            {affiliate && (
              <>
                <AffiliateStats />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <ReferralLink />
                  <WithdrawCommissionForm 
                    pendingAmount={affiliate.stats.availableEarnings} 
                  />
                </div>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Affiliate;