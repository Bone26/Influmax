import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Send, Paperclip, ArrowLeft, X } from 'lucide-react';
import { Ticket, TicketMessage } from '../../../types/ticket';
import { addTicketMessage, markTicketAsRead, updateTypingStatus, subscribeToTypingStatus } from '../../../services/tickets';
import { useAuth } from '../../../contexts/AuthContext';
import MessageBubble from '../MessageBubble';
import TypingIndicator from '../TypingIndicator';
import QuickReplies from './QuickReplies';

interface TicketChatProps {
  ticket: Ticket;
  messages: TicketMessage[];
  onClose: () => void;
}

const TicketChat: React.FC<TicketChatProps> = ({ ticket, messages, onClose }) => {
  const { currentUser } = useAuth();
  const [newMessage, setNewMessage] = useState('');
  const [attachments, setAttachments] = useState<File[]>([]);
  const [sending, setSending] = useState(false);
  const [typingUsers, setTypingUsers] = useState<{ userId: string; userName: string }[]>([]);
  const [typingTimeout, setTypingTimeout] = useState<NodeJS.Timeout | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [textareaHeight, setTextareaHeight] = useState('auto');
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [showScrollButton, setShowScrollButton] = useState(false);

  useEffect(() => {
    let unsubscribeTyping: (() => void) | undefined;
    let typingTimeoutId: NodeJS.Timeout | undefined;

    if (currentUser && ticket) {
      // Scroll to bottom and mark as read
      scrollToBottom();
      if (ticket.unreadCount > 0) {
        markTicketAsRead(ticket.id).catch(console.error);
      }

      // Subscribe to typing status
      unsubscribeTyping = subscribeToTypingStatus(
        ticket.id,
        currentUser.id,
        setTypingUsers
      );
    }

    return () => {
      if (unsubscribeTyping) {
        unsubscribeTyping();
      }
      if (typingTimeoutId) {
        clearTimeout(typingTimeoutId);
      }
      // Clean up typing status when component unmounts
      if (currentUser && ticket) {
        updateTypingStatus(ticket.id, currentUser.id, currentUser.name, false).catch(console.error);
      }
    };
  }, [ticket?.id, currentUser]);

  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
      setShowScrollButton(!isNearBottom);
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToBottom = () => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || (!newMessage.trim() && attachments.length === 0)) return;

    try {
      setSending(true);
      await addTicketMessage(
        ticket.id,
        currentUser.id,
        currentUser.isAdmin ? 'Support' : currentUser.name,
        newMessage,
        currentUser.isAdmin,
        attachments
      );
      setNewMessage('');
      setAttachments([]);
      setTextareaHeight('auto');
      scrollToBottom();
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setSending(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setAttachments(prev => [...prev, ...files]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setNewMessage(value);
    
    // Adjust textarea height
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 150)}px`;
    setTextareaHeight(`${Math.min(e.target.scrollHeight, 150)}px`);

    // Handle typing status
    if (currentUser && ticket) {
      if (value.trim()) {
        updateTypingStatus(ticket.id, currentUser.id, currentUser.name, true).catch(console.error);
        
        if (typingTimeout) {
          clearTimeout(typingTimeout);
        }
        
        const timeout = setTimeout(() => {
          if (currentUser && ticket) {
            updateTypingStatus(ticket.id, currentUser.id, currentUser.name, false).catch(console.error);
          }
        }, 3000);
        
        setTypingTimeout(timeout);
      } else {
        if (typingTimeout) {
          clearTimeout(typingTimeout);
        }
        updateTypingStatus(ticket.id, currentUser.id, currentUser.name, false).catch(console.error);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleQuickReply = (reply: string) => {
    setNewMessage(reply);
    // Focus the textarea
    const textarea = document.querySelector('textarea');
    if (textarea) {
      textarea.focus();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white border-b">
        <button
          onClick={onClose}
          className="flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          <span>Retour</span>
        </button>
        <span className="text-sm text-gray-500">#{ticket.id.slice(0, 8)}</span>
      </div>

      {/* Messages */}
      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto"
        style={{ height: 'calc(100% - 180px)' }}
      >
        <div className="px-4 py-6 space-y-6">
          {messages.map((message, index) => (
            <MessageBubble
              key={message.id}
              message={message}
              isLastMessage={index === messages.length - 1}
            />
          ))}

          {/* Typing Indicator */}
          {typingUsers.length > 0 && (
            <TypingIndicator userName={typingUsers[0].userName} />
          )}
        </div>
      </div>

      {/* Scroll to bottom button */}
      {showScrollButton && (
        <button
          onClick={scrollToBottom}
          className="absolute bottom-24 right-4 p-2 bg-purple-600 text-white rounded-full shadow-lg hover:bg-purple-700 transition-colors"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </button>
      )}

      {/* Quick Replies */}
      <QuickReplies onSelect={handleQuickReply} />

      {/* Input */}
      <div className="bg-white border-t p-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Attachments */}
          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {attachments.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center bg-gray-100 rounded-lg p-2 pr-3"
                >
                  {file.type.startsWith('image/') ? (
                    <img
                      src={URL.createObjectURL(file)}
                      alt={file.name}
                      className="h-8 w-8 object-cover rounded mr-2"
                    />
                  ) : (
                    <div className="h-8 w-8 bg-gray-200 rounded flex items-center justify-center mr-2">
                      <span className="text-xs text-gray-600">{file.name.split('.').pop()}</span>
                    </div>
                  )}
                  <span className="text-sm text-gray-700 truncate max-w-[150px]">
                    {file.name}
                  </span>
                  <button
                    onClick={() => removeAttachment(index)}
                    className="ml-2 text-gray-400 hover:text-red-500"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-end space-x-2">
            <div className="flex-1">
              <textarea
                value={newMessage}
                onChange={handleTextareaChange}
                onKeyPress={handleKeyPress}
                placeholder="Écrivez votre message..."
                style={{ height: textareaHeight }}
                className="w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-purple-500 resize-none min-h-[44px] max-h-[150px]"
              />
            </div>
            <div className="flex space-x-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="p-3 text-gray-500 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-colors"
                title="Ajouter un fichier"
              >
                <Paperclip className="h-5 w-5" />
              </button>
              <button
                type="submit"
                disabled={sending || (!newMessage.trim() && attachments.length === 0)}
                className="p-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="h-5 w-5" />
              </button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept="image/*,.pdf,.doc,.docx"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
        </form>
      </div>
    </div>
  );
};

export default TicketChat;