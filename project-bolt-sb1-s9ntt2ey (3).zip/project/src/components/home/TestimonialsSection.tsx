import React from 'react';
import { motion } from 'framer-motion';
import { Quote, Instagram, Music2, MessageCircle } from 'lucide-react';

const testimonials = [
  {
    name: 'Laura C.',
    role: 'Salon de coiffure',
    image: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80',
    quote: "Les services TikTok d'Influmax ont boosté mon compte. Mes vidéos semblent populaires, ce qui attire plus de clients dans mon salon. Parfait pour développer ma visibilité !",
    platform: 'tiktok'
  },
  {
    name: 'Damien P.',
    role: 'Photographe freelance',
    image: 'https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80',
    quote: "Avec Influmax, mes publications Instagram paraissent beaucoup plus professionnelles. Les services personnalisées m'aident à engager efficacement mon audience.",
    platform: 'instagram'
  },
  {
    name: 'Sophie D.',
    role: 'Salon de coiffure',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80',
    quote: "Les services d'Influmax ont rendu mon profil Instagram bien plus attractif. Mes clients pensent que je suis une référence dans mon domaine, et j'ai beaucoup plus de demandes grâce à ça.",
    platform: 'instagram'
  },
  {
    name: 'Thomas L.',
    role: 'Coach et expert en marketing digital',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80',
    quote: "Les outils Influmax m'ont permis d'élargir ma visibilité sur Instagram et TikTok. Mes clients me font confiance en voyant mes comptes actifs et engageants. Un service fiable et efficace !",
    platform: 'multiple'
  },
  {
    name: 'Émilie R.',
    role: 'Make-up artist',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80',
    quote: "J'ai utilisé Influmax pour augmenter mes followers Instagram. Depuis, mes publications semblent vraiment professionnelles grâce aux likes et aux vues, je reçois plus de demandes qu'avant. Super service !",
    platform: 'instagram'
  },
  {
    name: 'Julien D.',
    role: 'Entrepreneur digital',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&h=300&q=80',
    quote: "Les vues Telegram m'ont aidé à rendre mes campagnes bien plus crédibles. Mes partenaires voient immédiatement l'impact de mes messages, grâce notamment aux réactions positives. Résultats rapides et visibles !",
    platform: 'telegram'
  }
];

const TestimonialsSection = () => {
  return (
    <section id="testimonials" className="py-24 bg-gradient-to-br from-gray-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Ils nous font confiance
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez les retours d'expérience de nos clients qui ont transformé leur présence sociale
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl shadow-xl overflow-hidden transform transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl"
            >
              <div className="p-8">
                <div className="flex items-center space-x-4 mb-6">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover ring-4 ring-purple-100"
                  />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{testimonial.name}</h3>
                    <p className="text-gray-600 flex items-center text-sm">
                      {testimonial.role}
                      <span className="flex ml-2">
                        {testimonial.platform === 'instagram' && <Instagram className="h-4 w-4" />}
                        {testimonial.platform === 'tiktok' && <Music2 className="h-4 w-4" />}
                        {testimonial.platform === 'telegram' && <MessageCircle className="h-4 w-4" />}
                        {testimonial.platform === 'multiple' && (
                          <>
                            <Instagram className="h-4 w-4" />
                            <Music2 className="h-4 w-4 ml-1" />
                          </>
                        )}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="relative">
                  <Quote className="absolute top-0 left-0 h-8 w-8 text-purple-100 transform -translate-x-4 -translate-y-4" />
                  <p className="text-gray-600 italic relative z-10 leading-relaxed">
                    {testimonial.quote}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;