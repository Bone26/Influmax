import React from 'react';
import { motion } from 'framer-motion';
import { Package, AlertTriangle, Save, Smile, Clock } from 'lucide-react';
import { ServicePriceConfig, TelegramReactionMapping } from '../../types/pricing';

interface TelegramReactionPriceFormProps {
  price: ServicePriceConfig;
  formData: Partial<ServicePriceConfig>;
  onChange: (data: Partial<ServicePriceConfig>) => void;
  onSave: () => void;
}

const TelegramReactionPriceForm: React.FC<TelegramReactionPriceFormProps> = ({
  price,
  formData,
  onChange,
  onSave
}) => {
  const handleBaseChange = (value: number) => {
    onChange({
      ...formData,
      basePrice: value
    });
  };

  const handleDeliveryLimitChange = (
    deliveryTime: string,
    field: 'min' | 'max' | 'isActive',
    value: number | boolean
  ) => {
    onChange({
      ...formData,
      deliveryLimits: {
        ...formData.deliveryLimits,
        [deliveryTime]: {
          ...formData.deliveryLimits?.[deliveryTime],
          [field]: value
        }
      }
    });
  };

  const handleMixedPackChange = (
    packType: 'positive' | 'negative',
    field: keyof TelegramReactionMapping,
    value: string | number
  ) => {
    if (!formData.telegramReactions) return;

    onChange({
      ...formData,
      telegramReactions: {
        ...formData.telegramReactions,
        mixedPacks: {
          ...formData.telegramReactions.mixedPacks,
          [packType]: {
            ...formData.telegramReactions.mixedPacks[packType],
            [field]: typeof value === 'string' ? value : Number(value)
          }
        }
      }
    });
  };

  const handleIndividualChange = (
    index: number,
    field: keyof TelegramReactionMapping,
    value: string | number
  ) => {
    if (!formData.telegramReactions) return;

    const newIndividual = [...formData.telegramReactions.individual];
    newIndividual[index] = {
      ...newIndividual[index],
      [field]: typeof value === 'string' ? value : Number(value)
    };

    onChange({
      ...formData,
      telegramReactions: {
        ...formData.telegramReactions,
        individual: newIndividual
      }
    });
  };

  // Ordre chronologique des durées d'envoi
  const deliveryTimeOrder = ['instant', '24h', '3days', '7days', '1month'] as const;
  const deliveryTimeLabels = {
    'instant': 'Instantané',
    '24h': '24 heures',
    '3days': '3 jours',
    '7days': '7 jours',
    '1month': '1 mois'
  };

  if (!formData.telegramReactions) {
    return (
      <div className="p-6 bg-yellow-50 rounded-xl">
        <div className="flex items-center space-x-2 text-yellow-800">
          <AlertTriangle className="h-5 w-5" />
          <p>Configuration des réactions manquante. Veuillez réinitialiser les prix Telegram.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Prix de base */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Prix de base</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Prix unitaire (€)
            </label>
            <input
              type="number"
              value={formData.basePrice || 0}
              onChange={(e) => handleBaseChange(parseFloat(e.target.value) || 0)}
              step="0.00000001"
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>
      </div>

      {/* Limites par durée d'envoi */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-2 mb-6">
          <Clock className="h-5 w-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Limites par durée d'envoi</h3>
        </div>

        <div className="space-y-4">
          {deliveryTimeOrder.map((time) => (
            <div key={time} className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.deliveryLimits?.[time]?.isActive ?? false}
                    onChange={(e) => handleDeliveryLimitChange(time, 'isActive', e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                  <span className="ml-3 text-sm font-medium text-gray-700">
                    {deliveryTimeLabels[time]}
                  </span>
                </label>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Min
                </label>
                <input
                  type="number"
                  value={formData.deliveryLimits?.[time]?.min || 0}
                  onChange={(e) => handleDeliveryLimitChange(time, 'min', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Max
                </label>
                <input
                  type="number"
                  value={formData.deliveryLimits?.[time]?.max || 0}
                  onChange={(e) => handleDeliveryLimitChange(time, 'max', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Packs mixés */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-2 mb-6">
          <Package className="h-5 w-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Packs mixés</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Pack positif */}
          <div className="bg-green-50 p-4 rounded-xl">
            <h4 className="font-medium text-green-800 mb-4 flex items-center">
              <span className="text-xl mr-2">✨</span>
              Pack positif
            </h4>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  ID du service JAP
                </label>
                <input
                  type="text"
                  value={formData.telegramReactions.mixedPacks.positive.japServiceId}
                  onChange={(e) => handleMixedPackChange('positive', 'japServiceId', e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom du service
                </label>
                <input
                  type="text"
                  value={formData.telegramReactions.mixedPacks.positive.japServiceName}
                  onChange={(e) => handleMixedPackChange('positive', 'japServiceName', e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Min</label>
                  <input
                    type="number"
                    value={formData.telegramReactions.mixedPacks.positive.minQuantity || 0}
                    onChange={(e) => handleMixedPackChange('positive', 'minQuantity', parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max</label>
                  <input
                    type="number"
                    value={formData.telegramReactions.mixedPacks.positive.maxQuantity || 0}
                    onChange={(e) => handleMixedPackChange('positive', 'maxQuantity', parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Vitesse</label>
                  <input
                    type="number"
                    value={formData.telegramReactions.mixedPacks.positive.maxSpeed || 0}
                    onChange={(e) => handleMixedPackChange('positive', 'maxSpeed', parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Pack négatif */}
          <div className="bg-red-50 p-4 rounded-xl">
            <h4 className="font-medium text-red-800 mb-4 flex items-center">
              <span className="text-xl mr-2">💢</span>
              Pack négatif
            </h4>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  ID du service JAP
                </label>
                <input
                  type="text"
                  value={formData.telegramReactions.mixedPacks.negative.japServiceId}
                  onChange={(e) => handleMixedPackChange('negative', 'japServiceId', e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom du service
                </label>
                <input
                  type="text"
                  value={formData.telegramReactions.mixedPacks.negative.japServiceName}
                  onChange={(e) => handleMixedPackChange('negative', 'japServiceName', e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Min</label>
                  <input
                    type="number"
                    value={formData.telegramReactions.mixedPacks.negative.minQuantity || 0}
                    onChange={(e) => handleMixedPackChange('negative', 'minQuantity', parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Max</label>
                  <input
                    type="number"
                    value={formData.telegramReactions.mixedPacks.negative.maxQuantity || 0}
                    onChange={(e) => handleMixedPackChange('negative', 'maxQuantity', parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Vitesse</label>
                  <input
                    type="number"
                    value={formData.telegramReactions.mixedPacks.negative.maxSpeed || 0}
                    onChange={(e) => handleMixedPackChange('negative', 'maxSpeed', parseInt(e.target.value) || 0)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Réactions individuelles */}
      <div className="bg-white p-6 rounded-xl shadow-sm">
        <div className="flex items-center space-x-2 mb-6">
          <Smile className="h-5 w-5 text-purple-600" />
          <h3 className="text-lg font-semibold text-gray-900">Réactions individuelles</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {formData.telegramReactions.individual.map((reaction, index) => (
            <div key={index} className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl">{reaction.emoji}</span>
                <span className="text-xs text-gray-500">#{index + 1}</span>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    ID du service
                  </label>
                  <input
                    type="text"
                    value={reaction.japServiceId}
                    onChange={(e) => handleIndividualChange(index, 'japServiceId', e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nom du service
                  </label>
                  <input
                    type="text"
                    value={reaction.japServiceName}
                    onChange={(e) => handleIndividualChange(index, 'japServiceName', e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Min</label>
                    <input
                      type="number"
                      value={reaction.minQuantity || 0}
                      onChange={(e) => handleIndividualChange(index, 'minQuantity', parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Max</label>
                    <input
                      type="number"
                      value={reaction.maxQuantity || 0}
                      onChange={(e) => handleIndividualChange(index, 'maxQuantity', parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Vitesse</label>
                    <input
                      type="number"
                      value={reaction.maxSpeed || 0}
                      onChange={(e) => handleIndividualChange(index, 'maxSpeed', parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bouton de validation */}
      <div className="flex justify-end pt-4 border-t">
        <button
          onClick={onSave}
          className="flex items-center space-x-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Save className="h-5 w-5" />
          <span>Enregistrer les modifications</span>
        </button>
      </div>
    </div>
  );
};

export default TelegramReactionPriceForm;