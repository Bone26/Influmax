export interface QualityFeature {
  label: string;
  value: boolean;
  info?: string;
}

export interface QualityLevel {
  name: string;
  description: string;
  imageUrl: string;
  features: QualityFeature[];
}

export const getQualityLevels = (platform: 'instagram' | 'tiktok', type: string): QualityLevel[] => {
  const getOrderedFeatures = (features: QualityFeature[]): QualityFeature[] => {
    return [...features].sort((a, b) => {
      if (a.label === 'Durée de vie') return 1;
      if (b.label === 'Durée de vie') return -1;
      return (a.value === b.value) ? 0 : a.value ? 1 : -1;
    });
  };

  const baseFeatures = [
    { label: 'Profils français', value: false },
    { label: 'Profils réalistes', value: false },
    { label: 'Profils avec photo', value: true },
    { label: 'Durée de vie', value: false, info: '6-12 mois' }
  ];

  if (platform === 'instagram' && (type === 'followers' || type === 'likes')) {
    return [
      {
        name: 'Standard',
        description: 'Idéal pour débuter',
        imageUrl: 'https://i.imgur.com/5E8ovBu.jpeg',
        features: getOrderedFeatures([...baseFeatures])
      },
      {
        name: 'Premium',
        description: 'Les plus réalistes',
        imageUrl: 'https://i.imgur.com/1CLnJgD.jpeg',
        features: getOrderedFeatures([
          { ...baseFeatures[0] },
          { ...baseFeatures[1], value: true },
          { ...baseFeatures[2] },
          { ...baseFeatures[3], value: true, info: '∞' }
        ])
      },
      {
        name: 'VIP 🇫🇷',
        description: 'L\'excellence',
        imageUrl: 'https://i.imgur.com/pNu9MVv.jpeg',
        features: getOrderedFeatures([
          { ...baseFeatures[0], value: true },
          { ...baseFeatures[1], value: true },
          { ...baseFeatures[2] },
          { ...baseFeatures[3], value: true, info: '∞' }
        ])
      }
    ];
  } else if (platform === 'tiktok' && (type === 'followers' || type === 'likes')) {
    return [
      {
        name: 'Standard',
        description: 'Basique',
        imageUrl: 'https://i.imgur.com/cg3cJSh.jpeg',
        features: getOrderedFeatures([...baseFeatures])
      },
      {
        name: 'Premium',
        description: 'Qualité supérieure',
        imageUrl: 'https://i.imgur.com/mtHg2ab.jpeg',
        features: getOrderedFeatures([
          { ...baseFeatures[0] },
          { ...baseFeatures[1], value: true },
          { ...baseFeatures[2] },
          { ...baseFeatures[3], value: true, info: '∞' }
        ])
      }
    ];
  }
  return [];
};