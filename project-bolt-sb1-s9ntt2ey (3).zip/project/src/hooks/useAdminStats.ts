import { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, where, onSnapshot, getDocs, Timestamp } from 'firebase/firestore';
import { startOfDay, endOfDay, subDays } from 'date-fns';

export const useAdminStats = () => {
  const [stats, setStats] = useState({
    orders: {
      total: 0,
      pending: 0,
      processing: 0,
      completed: 0,
      cancelled: 0,
      lastMonth: 0,
      trend: 0
    },
    revenue: {
      total: 0,
      average: 0,
      highest: 0,
      lowest: 0,
      lastMonth: 0,
      trend: 0
    },
    clients: {
      total: 0,
      ordersPerClient: 0,
      revenuePerClient: 0,
      activeLastMonth: 0,
      trend: 0
    },
    totalOrders: {
      value: 0,
      trend: 0
    },
    deposits: {
      total: 0,
      trend: 0,
      lastMonth: 0
    }
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    const unsubscribe = onSnapshot(
      query(collection(db, 'orders')),
      async (ordersSnapshot) => {
        try {
          // Récupérer les commandes
          const orders = ordersSnapshot.docs.map(doc => {
            const data = doc.data();
            return {
              id: doc.id,
              ...data,
              timestamps: {
                createdAt: data.timestamps?.createdAt?.toDate() || new Date(),
                updatedAt: data.timestamps?.updatedAt?.toDate() || new Date(),
                startedAt: data.timestamps?.startedAt?.toDate() || null,
                completedAt: data.timestamps?.completedAt?.toDate() || null,
                cancelledAt: data.timestamps?.cancelledAt?.toDate() || null
              }
            };
          });

          // Récupérer les dépôts
          const depositsQuery = query(
            collection(db, 'walletDeposits'),
            where('type', '==', 'deposit'),
            where('status', '==', 'completed')
          );
          const depositsSnapshot = await getDocs(depositsQuery);
          const deposits = depositsSnapshot.docs.map(doc => ({
            ...doc.data(),
            createdAt: doc.data().createdAt?.toDate()
          }));

          // Calculer les statistiques des commandes
          const orderStats = {
            total: orders.length,
            pending: orders.filter(o => o.status === 'pending').length,
            processing: orders.filter(o => o.status === 'processing').length,
            completed: orders.filter(o => o.status === 'completed').length,
            cancelled: orders.filter(o => o.status === 'cancelled').length,
            lastMonth: orders.filter(o => {
              const date = o.timestamps.createdAt;
              const thirtyDaysAgo = subDays(new Date(), 30);
              return date >= thirtyDaysAgo;
            }).length,
            trend: 0
          };

          // Calculer les statistiques de revenus (uniquement commandes en cours et terminées)
          const validOrders = orders.filter(o => ['processing', 'completed'].includes(o.status));
          const totalRevenue = validOrders.reduce((sum, order) => sum + (order.price || 0), 0);
          const revenueStats = {
            total: totalRevenue,
            average: validOrders.length > 0 ? totalRevenue / validOrders.length : 0,
            highest: Math.max(...validOrders.map(o => o.price || 0), 0),
            lowest: Math.min(...validOrders.filter(o => o.price > 0).map(o => o.price || 0), 0),
            lastMonth: validOrders
              .filter(o => {
                const date = o.timestamps.createdAt;
                const thirtyDaysAgo = subDays(new Date(), 30);
                return date >= thirtyDaysAgo;
              })
              .reduce((sum, o) => sum + (o.price || 0), 0),
            trend: 0
          };

          // Calculer les statistiques des dépôts
          const depositsStats = {
            total: deposits.reduce((sum, deposit) => sum + (deposit.amount || 0), 0),
            lastMonth: deposits.filter(d => {
              const date = d.createdAt;
              const thirtyDaysAgo = subDays(new Date(), 30);
              return date >= thirtyDaysAgo;
            }).reduce((sum, d) => sum + (d.amount || 0), 0),
            trend: 0
          };

          // Calculer les statistiques clients
          const uniqueUsers = new Set(orders.map(order => order.userId));
          const clientStats = {
            total: uniqueUsers.size,
            ordersPerClient: uniqueUsers.size > 0 ? orders.length / uniqueUsers.size : 0,
            revenuePerClient: uniqueUsers.size > 0 ? totalRevenue / uniqueUsers.size : 0,
            activeLastMonth: new Set(
              orders
                .filter(o => {
                  const date = o.timestamps.createdAt;
                  const thirtyDaysAgo = subDays(new Date(), 30);
                  return date >= thirtyDaysAgo;
                })
                .map(o => o.userId)
            ).size,
            trend: 0
          };

          // Calculer le total des commandes
          const totalOrdersStats = {
            value: orders.length,
            trend: 0
          };

          setStats({
            orders: orderStats,
            revenue: revenueStats,
            clients: clientStats,
            totalOrders: totalOrdersStats,
            deposits: depositsStats
          });

          setError(null);
        } catch (err) {
          console.error('Error processing stats:', err);
          setError('Erreur lors du calcul des statistiques');
        } finally {
          setLoading(false);
        }
      }
    );

    return () => unsubscribe();
  }, []);

  return { stats, loading, error };
};