import React, { createContext, useContext, useState } from 'react';
import { OrderResponse } from '../services/api';

interface OrderContextType {
  currentOrder: OrderResponse | null;
  setCurrentOrder: (order: OrderResponse | null) => void;
  orders: OrderResponse[];
  addOrder: (order: OrderResponse) => void;
  updateOrder: (orderId: string, updates: Partial<OrderResponse>) => void;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentOrder, setCurrentOrder] = useState<OrderResponse | null>(null);
  const [orders, setOrders] = useState<OrderResponse[]>([]);

  const addOrder = (order: OrderResponse) => {
    setOrders(prev => [...prev, order]);
  };

  const updateOrder = (orderId: string, updates: Partial<OrderResponse>) => {
    setOrders(prev => prev.map(order => 
      order.order.id === orderId ? { ...order, ...updates } : order
    ));
  };

  return (
    <OrderContext.Provider value={{
      currentOrder,
      setCurrentOrder,
      orders,
      addOrder,
      updateOrder
    }}>
      {children}
    </OrderContext.Provider>
  );
};

export const useOrder = () => {
  const context = useContext(OrderContext);
  if (context === undefined) {
    throw new Error('useOrder must be used within an OrderProvider');
  }
  return context;
};