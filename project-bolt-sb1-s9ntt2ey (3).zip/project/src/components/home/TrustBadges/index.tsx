import React from 'react';
import { Shield, Users, Clock } from 'lucide-react';
import Badge from './Badge';

const TrustBadges = () => {
  const badges = [
    {
      icon: Shield,
      text: 'Livraison garantie ou remboursé',
      gradient: 'from-green-400 to-emerald-500'
    },
    {
      icon: Users,
      text: '+5 000 clients satisfaits',
      gradient: 'from-purple-400 to-indigo-500'
    },
    {
      icon: Clock,
      text: 'Support 24/7',
      gradient: 'from-pink-400 to-rose-500'
    }
  ];

  return (
    <div className="relative">
      {/* Background blur effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-900/20 via-transparent to-indigo-900/20 blur-3xl" />
      
      {/* Badges container */}
      <div className="relative flex flex-col md:flex-row items-center justify-center gap-3">
        {badges.map((badge, index) => (
          <Badge
            key={index}
            icon={badge.icon}
            text={badge.text}
            gradient={badge.gradient}
            delay={0.8 + (index * 0.1)}
          />
        ))}
      </div>
    </div>
  );
};

export default TrustBadges;