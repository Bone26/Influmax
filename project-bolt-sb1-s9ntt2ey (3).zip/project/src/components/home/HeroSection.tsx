import React from 'react';
import { motion } from 'framer-motion';
import { Instagram, Music2, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import TrustBadges from './TrustBadges';

const HeroSection = () => {
  return (
    <section className="relative min-h-[90vh] bg-gradient-to-br from-purple-600 via-indigo-600 to-blue-700">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557264322-b44d383a2906?auto=format&fit=crop&q=80')] opacity-10 bg-center bg-cover"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-purple-900/50 to-transparent"></div>
        
        {/* Animated shapes */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute top-1/4 left-1/4 w-32 md:w-64 h-32 md:h-64 bg-purple-500/20 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            rotate: [0, -90, 0],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity }}
          className="absolute bottom-1/4 right-1/4 w-48 md:w-96 h-48 md:h-96 bg-blue-500/20 rounded-full blur-3xl"
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-32">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-center space-x-4 mb-6 md:mb-8"
          >
            <Instagram className="h-6 w-6 md:h-8 md:w-8 text-purple-300" />
            <span className="text-xl md:text-2xl text-white font-light">×</span>
            <Music2 className="h-6 w-6 md:h-8 md:w-8 text-purple-300" />
            <span className="text-xl md:text-2xl text-white font-light">×</span>
            <MessageCircle className="h-6 w-6 md:h-8 md:w-8 text-purple-300" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-3xl md:text-7xl font-bold mb-4 md:mb-8 text-white leading-tight"
          >
            Boostez votre visibilité
            <span className="block mt-2 bg-gradient-to-r from-purple-300 to-pink-300 bg-clip-text text-transparent">
              avec des solutions rapides.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-lg md:text-2xl mb-8 md:mb-12 text-purple-100 max-w-3xl mx-auto px-4"
          >
            Des services fiables pour renforcer votre crédibilité sur Instagram, TikTok et Telegram.
            <span className="block mt-2 font-semibold">Livraison express, résultats en quelques heures.</span>
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col space-y-4 md:space-y-0 md:flex-row md:gap-6 justify-center px-4 mb-12"
          >
            <Link
              to="/services"
              className="group bg-white text-purple-600 hover:bg-purple-50 px-6 md:px-8 py-3 md:py-4 rounded-full font-bold text-base md:text-lg inline-flex items-center justify-center transition-all duration-300 transform hover:scale-105"
            >
              Commencer maintenant
              <motion.span
                className="ml-2"
                animate={{ x: [0, 4, 0] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
              >
                →
              </motion.span>
            </Link>
            <a
              href="#testimonials"
              className="group border-2 border-white text-white hover:bg-white/10 px-6 md:px-8 py-3 md:py-4 rounded-full font-bold text-base md:text-lg inline-flex items-center justify-center transition-all duration-300"
            >
              Voir les avis clients
              <motion.span
                className="ml-2"
                animate={{ x: [0, 4, 0] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
              >
                →
              </motion.span>
            </a>
          </motion.div>

          {/* Trust Badges */}
          <div className="mt-8 md:mt-16">
            <TrustBadges />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;