import React from 'react';
import { Trash2 } from 'lucide-react';

interface SavedCard {
  id: string;
  brand: string;
  last4: string;
  expMonth: number;
  expYear: number;
}

interface SavedPaymentMethodsProps {
  cards: SavedCard[];
  onSelect: (cardId: string) => void;
  onDelete: (cardId: string) => void;
}

const SavedPaymentMethods: React.FC<SavedPaymentMethodsProps> = ({
  cards,
  onSelect,
  onDelete,
}) => {
  if (cards.length === 0) {
    return (
      <div className="text-center text-gray-500 py-4">
        Aucune carte enregistrée
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900">
        Cartes enregistrées
      </h3>
      <div className="space-y-2">
        {cards.map((card) => (
          <div
            key={card.id}
            className="flex items-center justify-between p-4 border rounded-lg hover:border-purple-500 cursor-pointer"
            onClick={() => onSelect(card.id)}
          >
            <div className="flex items-center space-x-4">
              <div className="text-gray-600 capitalize">
                {card.brand}
              </div>
              <div className="text-gray-900">
                •••• {card.last4}
              </div>
              <div className="text-gray-500">
                {card.expMonth.toString().padStart(2, '0')}/{card.expYear}
              </div>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete(card.id);
              }}
              className="text-gray-400 hover:text-red-500 transition-colors"
            >
              <Trash2 className="h-5 w-5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SavedPaymentMethods;