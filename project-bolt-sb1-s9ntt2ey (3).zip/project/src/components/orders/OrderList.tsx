import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, ExternalLink, Clock } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { formatRemainingTime } from '../../utils/orderUtils';
import { createTicket } from '../../services/tickets';
import { checkProcessingOrders } from '../../services/orders';
import { toast } from 'sonner';

interface OrderListProps {
  orders: any[];
  isLoading: boolean;
}

const OrderList: React.FC<OrderListProps> = ({ orders, isLoading }) => {
  const navigate = useNavigate();
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);

  useEffect(() => {
    // Vérifier les commandes toutes les minutes
    const interval = setInterval(() => {
      checkProcessingOrders().catch(console.error);
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  const handleOpenSupport = async (order: any) => {
    try {
      // Créer un ticket avec les informations de la commande
      const ticket = await createTicket(
        order.userId,
        order.userName || 'Client',
        `Support commande #${order.id}`,
        'order',
        `Je souhaite obtenir de l'aide concernant ma commande.`,
        order.id
      );

      // Rediriger vers la page de support avec le ticket ouvert
      navigate('/support', { state: { selectedTicketId: ticket.id } });
      
      toast.success('Ticket de support créé avec succès');
    } catch (error) {
      console.error('Error creating support ticket:', error);
      toast.error('Erreur lors de la création du ticket de support');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 border border-green-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 border border-blue-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Terminé';
      case 'processing':
        return 'En cours';
      case 'cancelled':
        return 'Annulé';
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        <p className="mt-4 text-gray-600">Chargement des commandes...</p>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Aucune commande trouvée</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => (
        <motion.div
          key={order.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-lg border border-gray-200 p-4 md:p-6 hover:shadow-md transition-shadow"
        >
          {/* En-tête de la commande */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
            <div className="flex items-center justify-between md:justify-start md:space-x-4">
              <div>
                <span className="text-xs text-gray-500">Commande</span>
                <h3 className="text-base font-semibold text-gray-900">#{order.id}</h3>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                {getStatusText(order.status)}
              </span>
            </div>
            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => handleOpenSupport(order)}
                className="text-purple-600 hover:text-purple-700 p-2 rounded-full hover:bg-purple-50 transition-colors"
                title="Contacter le support"
              >
                <MessageSquare className="h-5 w-5" />
              </button>
              <a
                href={order.link}
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-500 hover:text-gray-600 p-2 rounded-full hover:bg-gray-50 transition-colors"
                title="Voir sur la plateforme"
              >
                <ExternalLink className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Détails de la commande */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-gray-500 block mb-1">Service</span>
              <p className="font-medium text-gray-900">
                {order.service?.japServiceName || `${order.service?.platform} - ${order.service?.type}`}
              </p>
            </div>
            <div>
              <span className="text-gray-500 block mb-1">Quantité</span>
              <p className="font-medium text-gray-900">{order.quantity}</p>
            </div>
            <div>
              <span className="text-gray-500 block mb-1">Prix</span>
              <p className="font-medium text-gray-900">{order.price.toFixed(2)}€</p>
            </div>
            <div>
              <span className="text-gray-500 block mb-1">Date</span>
              <p className="font-medium text-gray-900">
                {format(new Date(order.timestamps.createdAt), 'PPP à HH:mm', { locale: fr })}
              </p>
            </div>
          </div>

          {/* Affichage des emojis pour les réactions Telegram */}
          {order.service.type === 'reactions' && order.metadata?.selectedEmojis && (
            <div className="mt-4 border-t pt-4">
              <span className="text-gray-500 text-sm block mb-2">Réactions sélectionnées</span>
              <div className="flex flex-wrap gap-2">
                {order.metadata.selectedEmojis.map((emoji: string, index: number) => (
                  <span key={index} className="text-2xl bg-gray-50 p-2 rounded-lg">
                    {emoji}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Temps restant pour les commandes en cours */}
          {order.status === 'processing' && (
            <div className="mt-4 flex items-center space-x-2 text-blue-600 text-sm">
              <Clock className="h-4 w-4" />
              <span className="font-medium">
                {formatRemainingTime(
                  new Date(order.timestamps.startedAt),
                  order.deliveryTime || 'instant'
                )}
              </span>
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
};

export default OrderList;