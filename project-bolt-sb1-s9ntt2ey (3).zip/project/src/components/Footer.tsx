import React from 'react';
import { MessageCircle, Shield, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          {/* Telegram Section */}
          <div className="flex flex-col items-center md:items-start">
            <h3 className="text-lg font-semibold mb-2">Rejoignez-nous</h3>
            <a
              href="https://t.me/influmax"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
            >
              <MessageCircle className="h-5 w-5" />
              <span>Telegram</span>
            </a>
          </div>

          {/* Legal Links */}
          <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-6">
            <Link 
              to="/mentions-legales" 
              className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
            >
              <Shield className="h-5 w-5" />
              <span>Mentions légales</span>
            </Link>
            <Link 
              to="/confidentialite" 
              className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
            >
              <Lock className="h-5 w-5" />
              <span>Politique de confidentialité</span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;