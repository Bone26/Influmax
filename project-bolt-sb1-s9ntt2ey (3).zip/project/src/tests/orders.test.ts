import { describe, it, expect, beforeEach, vi } from 'vitest';
import { createOrder, getAllOrders } from '../services/orders';
import { deductFunds } from '../services/wallet';
import { db } from '../lib/firebase';

// Mock dependencies
vi.mock('../services/wallet');
vi.mock('../lib/firebase');

describe('Orders Service', () => {
  const userId = 'test-user-id';
  const mockOrder = {
    service: {
      platform: 'instagram',
      type: 'followers',
      quality: 'standard'
    },
    link: 'https://instagram.com/test',
    quantity: 100,
    price: 50
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('createOrder', () => {
    it('should create order and deduct funds', async () => {
      vi.mocked(deductFunds).mockResolvedValueOnce({ balance: 50, updatedAt: new Date() });
      vi.mocked(db.addDoc).mockResolvedValueOnce({ id: 'test-order-id' });

      const result = await createOrder(userId, mockOrder);

      expect(deductFunds).toHaveBeenCalledWith(userId, mockOrder.price);
      expect(db.addDoc).toHaveBeenCalled();
      expect(result.id).toBeDefined();
      expect(result.status).toBe('pending');
    });

    it('should throw error if deducting funds fails', async () => {
      vi.mocked(deductFunds).mockRejectedValueOnce(new Error('Insufficient funds'));

      await expect(createOrder(userId, mockOrder)).rejects.toThrow();
    });
  });

  describe('getAllOrders', () => {
    it('should return user orders', async () => {
      const mockOrders = [
        { id: '1', ...mockOrder, status: 'completed' },
        { id: '2', ...mockOrder, status: 'pending' }
      ];

      vi.mocked(db.getDocs).mockResolvedValueOnce({
        docs: mockOrders.map(order => ({
          id: order.id,
          data: () => order
        }))
      });

      const result = await getAllOrders(userId);

      expect(result).toHaveLength(2);
      expect(result[0].id).toBe('1');
      expect(result[1].id).toBe('2');
    });
  });
});