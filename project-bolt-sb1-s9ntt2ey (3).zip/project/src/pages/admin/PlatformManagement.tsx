import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Plus, X, Edit2, Trash2, ArrowLeft, AlertTriangle, Settings, Power } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import PlatformForm from '../../components/admin/PlatformForm';
import { getPlatforms, createPlatform, updatePlatform, deletePlatform } from '../../services/platforms';
import { Platform } from '../../types/platform';
import { toast } from 'sonner';
import InitializePlatforms from '../../components/admin/InitializePlatforms';

const PlatformManagement = () => {
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [editingPlatform, setEditingPlatform] = useState<Partial<Platform> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState<string | null>(null);
  const [showInactive, setShowInactive] = useState(false);

  useEffect(() => {
    loadPlatforms();
  }, [showInactive]);

  const loadPlatforms = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getPlatforms(showInactive);
      setPlatforms(data);
    } catch (error) {
      console.error('Error loading platforms:', error);
      setError('Erreur lors du chargement des plateformes');
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePlatform = async (data: Partial<Platform>) => {
    try {
      const newPlatform = await createPlatform(data);
      setPlatforms(prev => [...prev, newPlatform]);
      setEditingPlatform(null);
      toast.success('Plateforme créée avec succès');
    } catch (error) {
      console.error('Error creating platform:', error);
      toast.error('Erreur lors de la création de la plateforme');
    }
  };

  const handleUpdatePlatform = async (id: string, data: Partial<Platform>) => {
    try {
      await updatePlatform(id, data);
      setPlatforms(prev => prev.map(p => p.id === id ? { ...p, ...data } : p));
      setEditingPlatform(null);
      toast.success('Plateforme mise à jour avec succès');
    } catch (error) {
      console.error('Error updating platform:', error);
      toast.error('Erreur lors de la mise à jour de la plateforme');
    }
  };

  const handleDeletePlatform = async (id: string) => {
    try {
      await deletePlatform(id);
      setPlatforms(prev => prev.filter(p => p.id !== id));
      setDeleteConfirmation(null);
      toast.success('Plateforme supprimée avec succès');
    } catch (error) {
      console.error('Error deleting platform:', error);
      toast.error('Erreur lors de la suppression de la plateforme');
    }
  };

  const getIcon = (iconName: string) => {
    // @ts-ignore - Nous savons que l'icône existe dans la bibliothèque
    const Icon = LucideIcons[iconName] || LucideIcons.HelpCircle;
    return Icon;
  };

  const filteredPlatforms = platforms.filter(platform => 
    showInactive || platform.isActive
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Link to="/admin" className="text-white/80 hover:text-white transition-colors">
                  <ArrowLeft className="h-6 w-6" />
                </Link>
                <div>
                  <h1 className="text-2xl font-bold text-white">Gestion des plateformes</h1>
                  <p className="text-purple-100 text-sm">
                    {platforms.length} plateforme{platforms.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setEditingPlatform({})}
                className="flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors"
              >
                <Plus className="h-5 w-5 mr-2" />
                Nouvelle plateforme
              </button>
            </div>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6 p-4 bg-red-50 text-red-600 rounded-xl border border-red-200 flex items-center"
            >
              <AlertTriangle className="h-5 w-5 mr-2" />
              {error}
            </motion.div>
          )}

          {/* Filters */}
          <div className="p-4">
            <label className="flex items-center space-x-2 text-sm text-gray-600">
              <input
                type="checkbox"
                checked={showInactive}
                onChange={(e) => setShowInactive(e.target.checked)}
                className="rounded border-gray-300 text-purple-600 focus:ring-purple-500"
              />
              <span>Afficher les plateformes inactives</span>
            </label>
          </div>

          {/* Platforms Grid */}
          <div className="p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPlatforms.map((platform) => {
                const PlatformIcon = getIcon(platform.icon);
                return (
                  <motion.div
                    key={platform.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${
                      !platform.isActive ? 'opacity-60' : ''
                    }`}
                  >
                    <div className={`bg-gradient-to-r ${platform.gradient} p-6`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <PlatformIcon className="h-8 w-8 text-white" />
                          <h3 className="text-xl font-bold text-white">{platform.name}</h3>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => setEditingPlatform(platform)}
                            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          >
                            <Edit2 className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmation(platform.id)}
                            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                          >
                            <Trash2 className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                      {platform.description && (
                        <p className="mt-2 text-white/80 text-sm">{platform.description}</p>
                      )}
                    </div>
                    <div className="p-6">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">Statut</span>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          platform.isActive 
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {platform.isActive ? 'Actif' : 'Inactif'}
                        </span>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Empty State */}
            {filteredPlatforms.length === 0 && (
              <div className="text-center py-12">
                <Settings className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900">Aucune plateforme trouvée</h3>
                <p className="mt-2 text-gray-500">
                  Commencez par créer une nouvelle plateforme
                </p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Edit/Create Modal */}
        {editingPlatform && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-y-auto"
            >
              <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 sticky top-0 z-10">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold text-white">
                    {editingPlatform.id ? 'Modifier la plateforme' : 'Nouvelle plateforme'}
                  </h2>
                  <button
                    onClick={() => setEditingPlatform(null)}
                    className="text-white/80 hover:text-white"
                  >
                    <X className="h-6 w-6" />
                  </button>
                </div>
              </div>

              <div className="p-6">
                <PlatformForm
                  platform={editingPlatform}
                  onSubmit={async (data) => {
                    if (editingPlatform.id) {
                      await handleUpdatePlatform(editingPlatform.id, data);
                    } else {
                      await handleCreatePlatform(data);
                    }
                  }}
                  onCancel={() => setEditingPlatform(null)}
                />
              </div>
            </motion.div>
          </div>
        )}

        {/* Delete Confirmation Modal */}
        {deleteConfirmation && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-xl shadow-xl p-6 max-w-md w-full"
            >
              <div className="flex items-center space-x-3 text-red-600 mb-4">
                <AlertTriangle className="h-6 w-6" />
                <h3 className="text-lg font-semibold">Confirmer la suppression</h3>
              </div>
              
              <p className="text-gray-600 mb-6">
                Êtes-vous sûr de vouloir supprimer cette plateforme ? Cette action désactivera également tous les services associés.
              </p>

              <div className="flex justify-end space-x-4">
                <button
                  onClick={() => setDeleteConfirmation(null)}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Annuler
                </button>
                <button
                  onClick={() => deleteConfirmation && handleDeletePlatform(deleteConfirmation)}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Supprimer
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {/* Initialize Platforms Button */}
        <InitializePlatforms />
      </div>
    </div>
  );
};

export default PlatformManagement;