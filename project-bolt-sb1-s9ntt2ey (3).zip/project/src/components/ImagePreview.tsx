import React from 'react';
import { X } from 'lucide-react';

interface ImagePreviewProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  title: string;
}

const ImagePreview: React.FC<ImagePreviewProps> = ({
  isOpen,
  onClose,
  imageUrl,
  title
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-[60] p-4">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 text-white hover:text-gray-300"
      >
        <X className="h-8 w-8" />
      </button>
      
      <div className="max-w-[90vw] max-h-[90vh]">
        <img
          src={imageUrl}
          alt={title}
          className="max-w-full max-h-[85vh] object-contain"
        />
        <p className="text-white text-center mt-4 text-lg">{title}</p>
      </div>
    </div>
  );
};

export default ImagePreview;