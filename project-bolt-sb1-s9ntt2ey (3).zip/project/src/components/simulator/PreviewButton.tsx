import React from 'react';
import { Eye } from 'lucide-react';
import { Link } from 'react-router-dom';

const PreviewButton = () => {
  return (
    <Link
      to="/preview"
      className="flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
    >
      <Eye className="h-5 w-5 mr-2" />
      <span className="hidden md:inline">Prévisualiser mon compte</span>
      <span className="md:hidden">Prévisualiser</span>
    </Link>
  );
};

export default PreviewButton;