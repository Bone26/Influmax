import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface StepProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color: string;
  index: number;
}

const Step: React.FC<StepProps> = ({ icon: Icon, title, description, color, index }) => {
  return (
    <motion.div
      key={index}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      className="relative group"
    >
      <div className="absolute inset-0 bg-white/5 rounded-2xl transform transition-transform group-hover:scale-105" />
      <div className="relative p-4 lg:p-8 text-center">
        <div className={`bg-gradient-to-r ${color} p-3 lg:p-4 rounded-xl inline-block mb-3`}>
          <Icon className="h-5 w-5 lg:h-8 lg:w-8 text-white" />
        </div>
        <h3 className="text-sm lg:text-xl font-bold mb-2">{title}</h3>
        <p className="text-xs lg:text-base text-purple-200 leading-relaxed">{description}</p>
      </div>
    </motion.div>
  );
};

export default Step;