import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Wallet, TrendingUp, Users, AlertTriangle } from 'lucide-react';
import { Withdrawal } from '../../types/affiliate';
import { getTotalAffiliateCommissions } from '../../services/admin';

interface WithdrawalStatsProps {
  withdrawals: Withdrawal[];
}

const WithdrawalStats: React.FC<WithdrawalStatsProps> = ({ withdrawals }) => {
  const [totalCommissions, setTotalCommissions] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTotalCommissions = async () => {
      try {
        const total = await getTotalAffiliateCommissions();
        setTotalCommissions(total);
      } catch (error) {
        console.error('Error loading total commissions:', error);
      } finally {
        setLoading(false);
      }
    };

    loadTotalCommissions();
  }, []);

  const stats = {
    totalAmount: withdrawals
      .filter(w => w.status === 'completed')
      .reduce((sum, w) => sum + w.amount, 0),
    pendingAmount: withdrawals
      .filter(w => w.status === 'pending')
      .reduce((sum, w) => sum + w.amount, 0),
    totalUsers: new Set(withdrawals.map(w => w.userId)).size
  };

  const quickStats = [
    {
      icon: Wallet,
      label: 'Total des retraits',
      value: `${stats.totalAmount.toFixed(2)}€`,
      color: 'from-purple-500 to-indigo-500'
    },
    {
      icon: AlertTriangle,
      label: 'En attente',
      value: `${stats.pendingAmount.toFixed(2)}€`,
      color: 'from-orange-500 to-red-500'
    },
    {
      icon: TrendingUp,
      label: 'Total commissions',
      value: loading ? '...' : `${totalCommissions.toFixed(2)}€`,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Users,
      label: 'Utilisateurs uniques',
      value: stats.totalUsers,
      color: 'from-green-500 to-emerald-500'
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {quickStats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="bg-white rounded-xl shadow-sm p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color}`}>
              <stat.icon className="h-6 w-6 text-white" />
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
          <p className="text-sm text-gray-600">{stat.label}</p>
        </motion.div>
      ))}
    </div>
  );
};

export default WithdrawalStats;