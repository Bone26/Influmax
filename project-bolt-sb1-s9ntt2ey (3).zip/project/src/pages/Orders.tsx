import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { getAllOrders, checkProcessingOrders } from '../services/orders';
import OrderList from '../components/orders/OrderList';
import OrderFilters from '../components/orders/OrderFilters';
import SupportModal from '../components/support/SupportModal';
import { ShoppingBag } from 'lucide-react';

const Orders = () => {
  const { currentUser } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showSupportModal, setShowSupportModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    if (currentUser) {
      loadOrders();
      // Vérifier les commandes en cours toutes les minutes
      const interval = setInterval(() => {
        checkProcessingOrders().then(() => {
          loadOrders(); // Recharger les commandes après la vérification
        });
      }, 60000);

      return () => clearInterval(interval);
    }
  }, [currentUser]);

  const loadOrders = async () => {
    try {
      setLoading(true);
      const ordersData = await getAllOrders(currentUser!.id);
      setOrders(ordersData);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenSupport = (order: any) => {
    setSelectedOrder(order);
    setShowSupportModal(true);
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.service.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-6 md:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          {/* En-tête avec gradient et statistiques */}
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-4 md:p-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
              <div className="flex items-center space-x-3">
                <div className="bg-white/10 p-2 rounded-lg">
                  <ShoppingBag className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl md:text-3xl font-bold text-white">Mes commandes</h1>
                  <p className="text-purple-100 text-sm md:text-base">
                    {filteredOrders.length} commande{filteredOrders.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
              
              {/* Statistiques rapides */}
              <div className="grid grid-cols-2 gap-4 md:flex md:space-x-6">
                <div className="bg-white/10 rounded-lg p-3">
                  <p className="text-purple-100 text-sm">En cours</p>
                  <p className="text-white font-bold text-lg">
                    {orders.filter(o => o.status === 'processing').length}
                  </p>
                </div>
                <div className="bg-white/10 rounded-lg p-3">
                  <p className="text-purple-100 text-sm">Terminées</p>
                  <p className="text-white font-bold text-lg">
                    {orders.filter(o => o.status === 'completed').length}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 md:p-6">
            <OrderFilters
              statusFilter={statusFilter}
              onFilterChange={setStatusFilter}
            />

            <div className="mt-4">
              <OrderList
                orders={filteredOrders}
                isLoading={loading}
                onOpenSupport={handleOpenSupport}
              />
            </div>
          </div>
        </motion.div>
      </div>

      <SupportModal
        isOpen={showSupportModal}
        onClose={() => setShowSupportModal(false)}
        order={selectedOrder}
      />
    </div>
  );
};

export default Orders;