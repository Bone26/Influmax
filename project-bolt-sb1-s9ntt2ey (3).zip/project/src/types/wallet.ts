```typescript
// Modifier l'interface WalletDeposit pour ajouter le type 'refund'

export interface WalletDeposit {
  id: string;
  userId: string;
  amount: number;
  type: 'deposit' | 'bonus' | 'order' | 'refund';
  status: 'completed' | 'pending' | 'failed';
  description?: string;
  orderId?: string;
  createdAt: Date;
}
```