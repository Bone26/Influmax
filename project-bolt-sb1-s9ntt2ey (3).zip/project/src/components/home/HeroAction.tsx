import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

const HeroAction = () => {
  return (
    <div className="flex flex-col sm:flex-row gap-6 justify-center animate-fade-in-up">
      <Link
        to="/services"
        className="group bg-white text-purple-600 hover:bg-purple-50 px-8 py-4 rounded-full font-bold text-lg inline-flex items-center justify-center transition-all duration-300 transform hover:scale-105"
      >
        Commencer maintenant
        <ChevronRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
      </Link>
      <a
        href="#how-it-works"
        className="group border-2 border-white text-white hover:bg-white/10 px-8 py-4 rounded-full font-bold text-lg inline-flex items-center justify-center transition-all duration-300"
      >
        Comment ça marche ?
        <ChevronRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
      </a>
    </div>
  );
};

export default HeroAction;