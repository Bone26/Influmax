import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Wallet, Gift, ChevronRight, Users, Crown } from 'lucide-react';
import { useAffiliate } from '../../contexts/AffiliateContext';
import { Link, useNavigate } from 'react-router-dom';

const AffiliateStats = () => {
  const { affiliate } = useAffiliate();
  const navigate = useNavigate();

  if (!affiliate) {
    return null;
  }

  const stats = [
    {
      icon: Wallet,
      label: 'Total retiré',
      value: `${(affiliate.stats?.totalWithdrawn || 0).toFixed(2)}€`,
      color: 'from-orange-500 to-red-500',
      onClick: () => navigate('/affiliate/withdrawals'),
      linkMessage: 'Voir l\'historique'
    },
    {
      icon: Wallet,
      label: 'Gains totaux',
      value: `${(affiliate.stats?.totalEarnings || 0).toFixed(2)}€`,
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: Users,
      label: 'Total d\'affiliés',
      value: `${(affiliate.stats?.totalReferrals || 0)}`,
      color: 'from-blue-500 to-cyan-500',
      onClick: () => navigate('/affiliate/tree'),
      linkMessage: 'Voir le détail'
    }
  ];

  // Calculer le niveau en fonction des gains totaux
  const getTotalEarnings = () => affiliate.stats?.totalEarnings || 0;
  const getLevel = () => {
    const earnings = getTotalEarnings();
    if (earnings >= 1000000) return { name: 'Diamond', color: 'from-blue-400 to-cyan-300' };
    if (earnings >= 250000) return { name: 'Platinum', color: 'from-slate-400 to-slate-300' };
    if (earnings >= 30000) return { name: 'Gold', color: 'from-yellow-500 to-yellow-400' };
    if (earnings >= 15000) return { name: 'Silver', color: 'from-gray-400 to-gray-300' };
    if (earnings >= 3000) return { name: 'Bronze', color: 'from-amber-700 to-amber-500' };
    return { name: 'Bronze', color: 'from-amber-700 to-amber-500' };
  };
  
  const level = getLevel();
  const nextLevelThresholds = {
    Bronze: 3000,
    Silver: 15000,
    Gold: 30000,
    Platinum: 250000,
    Diamond: 1000000,
    Legend: 5000000
  };

  const nextLevel = Object.entries(nextLevelThresholds).find(([_, threshold]) => getTotalEarnings() < threshold);
  const progress = nextLevel ? (getTotalEarnings() / nextLevel[1]) * 100 : 100;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className={`bg-white rounded-xl shadow-lg p-6 ${
            stat.onClick ? 'cursor-pointer hover:shadow-xl transition-all' : ''
          }`}
          onClick={stat.onClick}
        >
          <div className="flex items-center justify-between mb-4">
            <div className={`bg-gradient-to-r ${stat.color} p-3 rounded-lg`}>
              <stat.icon className="h-6 w-6 text-white" />
            </div>
          </div>
          <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
          <p className="text-sm text-gray-600">{stat.label}</p>
          {stat.linkMessage && (
            <div className="mt-2 flex items-center text-blue-600 text-sm hover:text-blue-700">
              <span>{stat.linkMessage}</span>
              <ChevronRight className="h-4 w-4 ml-1" />
            </div>
          )}
        </motion.div>
      ))}

      {/* Carte de statut améliorée en pleine largeur */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="md:col-span-3"
      >
        <Link
          to="/rewards"
          className="block bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden"
        >
          <div className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
              <div className="flex items-center space-x-4">
                <div className={`bg-gradient-to-r ${level.color} p-4 rounded-xl`}>
                  <Crown className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">Niveau {level.name}</h3>
                  {nextLevel && (
                    <p className="text-gray-600">
                      {`${(nextLevel[1] - getTotalEarnings()).toFixed(2)}€ restants pour le niveau ${nextLevel[0]}`}
                    </p>
                  )}
                </div>
              </div>
              
              <div className="flex items-center text-purple-600 font-medium">
                Voir mes récompenses
                <ChevronRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </div>
            </div>

            {nextLevel && (
              <div className="mt-6">
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full bg-gradient-to-r ${level.color} transition-all duration-500`}
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  />
                </div>
                <div className="mt-2 flex justify-between text-sm text-gray-500">
                  <span>{getTotalEarnings().toFixed(2)}€</span>
                  <span>{nextLevel[1].toLocaleString()}€</span>
                </div>
                <div className="text-center text-gray-500 text-sm mt-2">
                  {`${progress.toFixed(2)}% complété`}
                </div>
              </div>
            )}
          </div>
        </Link>
      </motion.div>
    </div>
  );
};

export default AffiliateStats;