import React from 'react';
import { motion } from 'framer-motion';

interface EmojiButtonProps {
  emoji: string;
  isSelected: boolean;
  disabled?: boolean;
  onClick: () => void;
}

export const EmojiButton: React.FC<EmojiButtonProps> = ({
  emoji,
  isSelected,
  disabled,
  onClick
}) => (
  <motion.button
    whileHover={{ scale: 1.1 }}
    whileTap={{ scale: 0.95 }}
    onClick={onClick}
    className={`text-2xl p-2 rounded-lg transition-colors ${
      isSelected
        ? 'bg-purple-100 border-2 border-purple-500'
        : 'bg-gray-50 hover:bg-gray-100'
    }`}
    disabled={disabled}
  >
    {emoji}
  </motion.button>
);