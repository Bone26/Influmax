import { Service, DeliveryLimits } from '../types/service';

interface DripFeedCalculation {
  runs: number;
  interval: number;
  quantityPerRun: number;
  isValid: boolean;
  error?: string;
}

export const calculateDripFeed = (
  quantity: number,
  deliveryTime: keyof DeliveryLimits,
  deliveryLimits: DeliveryLimits,
  japMinQuantity: number = 10,
  japMaxQuantity: number = 300000,
  japMaxSpeed: number = 50000
): DripFeedCalculation => {
  // Si livraison instantanée, pas de drip feed
  if (deliveryTime === 'instant') {
    return {
      runs: 1,
      interval: 0,
      quantityPerRun: quantity,
      isValid: quantity >= deliveryLimits.instant.min && quantity <= deliveryLimits.instant.max
    };
  }

  // Durées en minutes pour chaque type de livraison
  const durationMinutes = {
    '24h': 1440,
    '3days': 4320,
    '7days': 10080,
    '1month': 43200
  };

  // Intervalle minimum entre les runs (15 minutes)
  const minInterval = 15;
  
  // Calculer le nombre maximum de runs possible
  const maxRuns = Math.floor(durationMinutes[deliveryTime] / minInterval);
  
  // Calculer la quantité par run optimale
  let runs = Math.ceil(quantity / japMinQuantity);
  if (runs > maxRuns) runs = maxRuns;
  
  const quantityPerRun = Math.ceil(quantity / runs);
  const interval = Math.floor(durationMinutes[deliveryTime] / runs);

  // Vérifier les contraintes
  const speedPerDay = (quantityPerRun * 1440) / interval;
  const isValid = 
    quantityPerRun >= japMinQuantity &&
    quantityPerRun <= japMaxQuantity &&
    speedPerDay <= japMaxSpeed &&
    quantity >= deliveryLimits[deliveryTime].min &&
    quantity <= deliveryLimits[deliveryTime].max;

  let error;
  if (!isValid) {
    if (quantity < deliveryLimits[deliveryTime].min) {
      error = `Minimum ${deliveryLimits[deliveryTime].min} pour cette durée d'envoi`;
    } else if (quantity > deliveryLimits[deliveryTime].max) {
      error = `Maximum ${deliveryLimits[deliveryTime].max} pour cette durée d'envoi`;
    } else if (speedPerDay > japMaxSpeed) {
      error = `Vitesse maximale dépassée (${japMaxSpeed} par jour)`;
    }
  }

  return {
    runs,
    interval,
    quantityPerRun,
    isValid,
    error
  };
};

export const validateServiceLimits = (
  service: Service,
  quantity: number,
  deliveryTime: keyof DeliveryLimits
): { isValid: boolean; error?: string } => {
  const limits = service.deliveryLimits[deliveryTime];
  
  if (!limits.isActive) {
    return {
      isValid: false,
      error: `Cette durée d'envoi n'est pas disponible pour ce service`
    };
  }

  if (quantity < limits.min) {
    return {
      isValid: false,
      error: `Minimum ${limits.min} pour cette durée d'envoi`
    };
  }

  if (quantity > limits.max) {
    return {
      isValid: false,
      error: `Maximum ${limits.max} pour cette durée d'envoi`
    };
  }

  return { isValid: true };
};