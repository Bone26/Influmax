import React from 'react';
import { motion } from 'framer-motion';
import { Search, Filter } from 'lucide-react';

interface TicketFiltersProps {
  filters: {
    status: string;
    category: string;
    search: string;
  };
  onChange: (filters: any) => void;
  ticketCount: number;
}

const TicketFilters: React.FC<TicketFiltersProps> = ({
  filters,
  onChange,
  ticketCount
}) => {
  return (
    <div className="bg-white border-b p-4">
      <div className="flex flex-col space-y-4">
        {/* Search and Status Filters */}
        <div className="flex space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              value={filters.search}
              onChange={(e) => onChange({ ...filters, search: e.target.value })}
              placeholder="Rechercher un ticket..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <select
            value={filters.status}
            onChange={(e) => onChange({ ...filters, status: e.target.value })}
            className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
          >
            <option value="all">Tous les statuts</option>
            <option value="open">En attente</option>
            <option value="processing">En cours</option>
            <option value="resolved">Résolu</option>
            <option value="closed">Fermé</option>
          </select>
        </div>

        {/* Category Filter */}
        <div className="flex space-x-4">
          <select
            value={filters.category}
            onChange={(e) => onChange({ ...filters, category: e.target.value })}
            className="px-4 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
          >
            <option value="all">Toutes les catégories</option>
            <option value="order">Commandes</option>
            <option value="deposit">Dépôts</option>
            <option value="withdrawal">Retraits</option>
            <option value="affiliate">Affiliation</option>
            <option value="technical">Technique</option>
            <option value="other">Autre</option>
          </select>
        </div>

        {/* Active Filters */}
        {(filters.status !== 'all' || filters.category !== 'all' || filters.search) && (
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Filter className="h-4 w-4" />
            <span>{ticketCount} résultat{ticketCount !== 1 ? 's' : ''}</span>
            <button
              onClick={() => onChange({
                status: 'all',
                category: 'all',
                search: ''
              })}
              className="text-purple-600 hover:text-purple-700"
            >
              Réinitialiser les filtres
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default TicketFilters;