import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Plus, AlertTriangle } from 'lucide-react';
import { ServicePriceConfig } from '../../types/pricing';
import { toast } from 'sonner';

interface CreateServiceFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Partial<ServicePriceConfig>) => Promise<void>;
  platformId: string;
}

const CreateServiceForm: React.FC<CreateServiceFormProps> = ({
  isOpen,
  onClose,
  onSubmit,
  platformId
}) => {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Partial<ServicePriceConfig>>({
    platformId,
    serviceType: '',
    quality: 'standard',
    basePrice: 0,
    deliveryLimits: {
      instant: { min: 100, max: 10000, isActive: true },
      '24h': { min: 150, max: 7500, isActive: true },
      '3days': { min: 200, max: 5000, isActive: true },
      '7days': { min: 500, max: 2500, isActive: true },
      '1month': { min: 1000, max: 1000, isActive: true }
    },
    japMapping: {
      japServiceId: '',
      japServiceName: '',
      minQuantity: 10,
      maxQuantity: 300000,
      maxSpeed: 50000
    },
    isActive: true
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.serviceType || !formData.basePrice) {
      toast.error('Veuillez remplir tous les champs requis');
      return;
    }

    setLoading(true);
    try {
      await onSubmit(formData);
      onClose();
      toast.success('Service créé avec succès');
    } catch (error) {
      console.error('Error creating service:', error);
      toast.error('Erreur lors de la création du service');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-white">Nouveau service</h2>
            <button
              onClick={onClose}
              className="text-white/80 hover:text-white"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Informations de base */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Type de service
              </label>
              <input
                type="text"
                value={formData.serviceType}
                onChange={(e) => setFormData(prev => ({ ...prev, serviceType: e.target.value }))}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                placeholder="ex: followers"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prix de base (€)
              </label>
              <input
                type="number"
                value={formData.basePrice}
                onChange={(e) => setFormData(prev => ({ ...prev, basePrice: parseFloat(e.target.value) }))}
                step="0.00000001"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                required
              />
            </div>
          </div>

          {/* Limites de livraison */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900">Limites par durée d'envoi</h3>
            {Object.entries(formData.deliveryLimits || {}).map(([time, limits]) => (
              <div key={time} className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={limits.isActive}
                      onChange={(e) => setFormData(prev => ({
                        ...prev,
                        deliveryLimits: {
                          ...prev.deliveryLimits,
                          [time]: {
                            ...prev.deliveryLimits?.[time],
                            isActive: e.target.checked
                          }
                        }
                      }))}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                    <span className="ml-3 text-sm font-medium text-gray-700">
                      {time === 'instant' ? 'Instantané' :
                       time === '24h' ? '24 heures' :
                       time === '3days' ? '3 jours' :
                       time === '7days' ? '7 jours' : '1 mois'}
                    </span>
                  </label>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Min
                  </label>
                  <input
                    type="number"
                    value={limits.min}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      deliveryLimits: {
                        ...prev.deliveryLimits,
                        [time]: {
                          ...prev.deliveryLimits?.[time],
                          min: parseInt(e.target.value)
                        }
                      }
                    }))}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Max
                  </label>
                  <input
                    type="number"
                    value={limits.max}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      deliveryLimits: {
                        ...prev.deliveryLimits,
                        [time]: {
                          ...prev.deliveryLimits?.[time],
                          max: parseInt(e.target.value)
                        }
                      }
                    }))}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Configuration JAP */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900">Configuration API JAP</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  ID du service JAP
                </label>
                <input
                  type="text"
                  value={formData.japMapping?.japServiceId || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    japMapping: {
                      ...prev.japMapping,
                      japServiceId: e.target.value
                    }
                  }))}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  placeholder="ex: 4343"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom du service JAP
                </label>
                <input
                  type="text"
                  value={formData.japMapping?.japServiceName || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    japMapping: {
                      ...prev.japMapping,
                      japServiceName: e.target.value
                    }
                  }))}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  placeholder="ex: Instagram Likes"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quantité minimum JAP
                </label>
                <input
                  type="number"
                  value={formData.japMapping?.minQuantity || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    japMapping: {
                      ...prev.japMapping,
                      minQuantity: parseInt(e.target.value)
                    }
                  }))}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  min="10"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quantité maximum JAP
                </label>
                <input
                  type="number"
                  value={formData.japMapping?.maxQuantity || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    japMapping: {
                      ...prev.japMapping,
                      maxQuantity: parseInt(e.target.value)
                    }
                  }))}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  max="300000"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Vitesse maximum par jour
                </label>
                <input
                  type="number"
                  value={formData.japMapping?.maxSpeed || ''}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    japMapping: {
                      ...prev.japMapping,
                      maxSpeed: parseInt(e.target.value)
                    }
                  }))}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-purple-500"
                  max="50000"
                />
              </div>
            </div>
          </div>

          {/* Boutons d'action */}
          <div className="flex justify-end space-x-3 pt-6 border-t">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent mr-2" />
                  Création...
                </>
              ) : (
                <>
                  <Plus className="h-5 w-5 mr-2" />
                  Créer le service
                </>
              )}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default CreateServiceForm;