import { ServicePricing } from '../config/servicePricing';
import { ServicePriceConfig } from '../types/pricing';

const DELIVERY_TIME_MULTIPLIERS = {
  'instant': 1,
  '24h': 1.1,
  '3days': 1.2,
  '7days': 1.3,
  '1month': 1.5
} as const;

export const calculatePrice = (
  quantity: number,
  pricing: ServicePricing | ServicePriceConfig,
  deliveryTime: string,
  options?: {
    mode?: 'custom' | 'mixed';
    selectedEmojis?: string[];
  }
): number => {
  if (!quantity || quantity < 0 || !pricing?.basePrice) {
    return 0;
  }

  try {
    // Prix de base
    let basePrice = quantity * pricing.basePrice;

    // Si c'est un service de réactions Telegram
    if ('telegramReactions' in pricing && pricing.telegramReactions) {
      if (options?.mode === 'mixed') {
        // Prix unique pour le pack mixé
        basePrice = quantity * pricing.basePrice;
      } else if (options?.selectedEmojis?.length) {
        // Prix pour chaque emoji sélectionné (additionner les prix)
        basePrice = quantity * pricing.basePrice * options.selectedEmojis.length;
      }
    }

    // Appliquer le multiplicateur de temps de livraison
    const deliveryMultiplier = DELIVERY_TIME_MULTIPLIERS[deliveryTime as keyof typeof DELIVERY_TIME_MULTIPLIERS] || 1;
    const finalPrice = basePrice * deliveryMultiplier;
    
    // Arrondir à 5 décimales pour supporter les très petits prix
    return Number(Math.round(parseFloat(finalPrice + 'e5')) + 'e-5');
  } catch (error) {
    console.error('Error calculating price:', error);
    return 0;
  }
};