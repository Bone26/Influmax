import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Maximize2, Check, X as XIcon, Image, EyeOff } from 'lucide-react';
import ImagePreview from './ImagePreview';
import { getQualityLevels, QualityLevel } from '../utils/qualityComparison';

interface QualityComparisonProps {
  isOpen: boolean;
  onClose: () => void;
  platform: 'instagram' | 'tiktok';
  type: string;
}

const QualityComparison: React.FC<QualityComparisonProps> = ({
  isOpen,
  onClose,
  platform,
  type
}) => {
  const [selectedImage, setSelectedImage] = useState<{ url: string; title: string } | null>(null);
  const [showImages, setShowImages] = useState(true);
  const [selectedQuality, setSelectedQuality] = useState<string | null>(null);

  if (!isOpen) return null;

  const qualityLevels = getQualityLevels(platform, type);

  const renderFeatureValue = (feature: { label: string; value: boolean; info?: string }) => {
    if (feature.label === 'Durée de vie') {
      return (
        <span className="text-gray-500">
          {feature.info}
        </span>
      );
    }
    return feature.value ? (
      <Check className="h-5 w-5 text-green-500" />
    ) : (
      <XIcon className="h-5 w-5 text-red-500" />
    );
  };

  if (qualityLevels.length === 0) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Comparaison non disponible</h2>
          <p className="text-gray-600">
            La comparaison des qualités n'est pas disponible pour ce service.
          </p>
          <button
            onClick={onClose}
            className="mt-4 w-full bg-purple-600 text-white py-2 px-4 rounded-md hover:bg-purple-700 transition-colors"
          >
            Fermer
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-0 md:p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white w-full h-full md:h-auto md:rounded-xl md:max-w-4xl md:w-full overflow-hidden"
        >
          {/* Header fixe */}
          <div className="sticky top-0 z-10 bg-gradient-to-r from-purple-600 to-indigo-600 p-4 flex justify-between items-center">
            <h2 className="text-xl font-bold text-white">Comparaison des qualités</h2>
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setShowImages(!showImages)}
                className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                {showImages ? (
                  <>
                    <EyeOff className="h-4 w-4" />
                    <span className="hidden md:inline">Masquer les photos</span>
                  </>
                ) : (
                  <>
                    <Image className="h-4 w-4" />
                    <span className="hidden md:inline">Afficher les photos</span>
                  </>
                )}
              </button>
              <button
                onClick={onClose}
                className="text-white/80 hover:text-white"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
          </div>

          {/* Navigation des qualités (mobile uniquement) */}
          <div className="md:hidden bg-gray-50 border-b overflow-x-auto whitespace-nowrap p-2">
            <div className="flex space-x-2">
              {qualityLevels.map((level, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedQuality(level.name)}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    selectedQuality === level.name
                      ? 'bg-purple-600 text-white'
                      : 'bg-white text-gray-600'
                  }`}
                >
                  {level.name}
                </button>
              ))}
            </div>
          </div>

          {/* Contenu scrollable */}
          <div className="overflow-y-auto max-h-[calc(100vh-120px)] md:max-h-[70vh]">
            {/* Version mobile */}
            <div className="md:hidden">
              {qualityLevels.map((level, index) => (
                <div
                  key={index}
                  className={`p-4 ${
                    selectedQuality === null || selectedQuality === level.name
                      ? 'block'
                      : 'hidden'
                  }`}
                >
                  {showImages && (
                    <div className="relative mb-4">
                      <div className="aspect-square overflow-hidden rounded-lg">
                        <img
                          src={level.imageUrl}
                          alt={`Exemple ${level.name}`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <button
                        onClick={() => setSelectedImage({ url: level.imageUrl, title: level.name })}
                        className="absolute top-2 right-2 bg-black/50 p-2 rounded-full text-white"
                      >
                        <Maximize2 className="h-5 w-5" />
                      </button>
                    </div>
                  )}

                  <div className="bg-gray-50 rounded-xl p-4">
                    <h3 className="text-xl font-semibold mb-2">{level.name}</h3>
                    <p className="text-gray-600 mb-4">{level.description}</p>
                    
                    <div className="space-y-3">
                      {level.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center justify-between bg-white p-3 rounded-lg">
                          <span className="text-gray-700">{feature.label}</span>
                          <div className="flex items-center">
                            {renderFeatureValue(feature)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Version desktop */}
            <div className="hidden md:grid md:grid-cols-3 gap-6 p-6">
              {qualityLevels.map((level, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-4">
                  {showImages && (
                    <div className="relative group">
                      <div className="aspect-square mb-4 overflow-hidden rounded-lg">
                        <img
                          src={level.imageUrl}
                          alt={`Exemple ${level.name}`}
                          className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <button
                        onClick={() => setSelectedImage({ url: level.imageUrl, title: level.name })}
                        className="absolute top-2 right-2 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Maximize2 className="h-5 w-5" />
                      </button>
                    </div>
                  )}
                  <h3 className="text-xl font-semibold mb-2">{level.name}</h3>
                  <p className="text-gray-600 mb-4">{level.description}</p>
                  
                  <div className="space-y-2">
                    {level.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center justify-between">
                        <span className="text-gray-600">{feature.label}</span>
                        <div className="flex items-center">
                          {renderFeatureValue(feature)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      <ImagePreview
        isOpen={!!selectedImage}
        onClose={() => setSelectedImage(null)}
        imageUrl={selectedImage?.url || ''}
        title={selectedImage?.title || ''}
      />
    </>
  );
};

export default QualityComparison;