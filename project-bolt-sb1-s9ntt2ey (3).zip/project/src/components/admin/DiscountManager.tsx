import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Percent, Calendar, Tag, X, Plus } from 'lucide-react';
import { ServiceDiscount } from '../../types/service';

interface DiscountManagerProps {
  serviceId: string;
  discounts: ServiceDiscount[];
  onCreateDiscount: (data: Partial<ServiceDiscount>) => Promise<void>;
  onUpdateDiscount: (id: string, data: Partial<ServiceDiscount>) => Promise<void>;
  onDeleteDiscount: (id: string) => Promise<void>;
}

const DiscountManager: React.FC<DiscountManagerProps> = ({
  serviceId,
  discounts,
  onCreateDiscount,
  onUpdateDiscount,
  onDeleteDiscount
}) => {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState<Partial<ServiceDiscount>>({
    serviceId,
    type: 'percentage',
    value: 0,
    isActive: true
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await onCreateDiscount(formData);
      setShowForm(false);
      setFormData({
        serviceId,
        type: 'percentage',
        value: 0,
        isActive: true
      });
    } catch (error) {
      console.error('Error creating discount:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium text-gray-900">Réductions</h3>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center space-x-2 text-purple-600 hover:text-purple-700"
        >
          <Plus className="h-5 w-5" />
          <span>Ajouter une réduction</span>
        </button>
      </div>

      {/* Liste des réductions actives */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {discounts.map((discount) => (
          <motion.div
            key={discount.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-lg shadow p-4 border border-gray-200"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-100 rounded-lg">
                  <Percent className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{discount.name}</h4>
                  <p className="text-sm text-gray-500">{discount.description}</p>
                </div>
              </div>
              <button
                onClick={() => onDeleteDiscount(discount.id)}
                className="text-gray-400 hover:text-red-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Type</span>
                <p className="font-medium">
                  {discount.type === 'percentage' ? 'Pourcentage' : 'Montant fixe'}
                </p>
              </div>
              <div>
                <span className="text-gray-500">Valeur</span>
                <p className="font-medium">
                  {discount.type === 'percentage' ? `${discount.value}%` : `${discount.value}€`}
                </p>
              </div>
              <div>
                <span className="text-gray-500">Quantité min.</span>
                <p className="font-medium">{discount.minQuantity || 'Aucune'}</p>
              </div>
              <div>
                <span className="text-gray-500">Quantité max.</span>
                <p className="font-medium">{discount.maxQuantity || 'Aucune'}</p>
              </div>
              <div>
                <span className="text-gray-500">Limite d'utilisation</span>
                <p className="font-medium">
                  {discount.usageLimit 
                    ? `${discount.currentUsage}/${discount.usageLimit}`
                    : 'Illimité'
                  }
                </p>
              </div>
              <div>
                <span className="text-gray-500">Statut</span>
                <p className={`font-medium ${discount.isActive ? 'text-green-600' : 'text-red-600'}`}>
                  {discount.isActive ? 'Actif' : 'Inactif'}
                </p>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between text-sm text-gray-500">
              <div className="flex items-center space-x-1">
                <Calendar className="h-4 w-4" />
                <span>
                  Du {new Date(discount.validFrom).toLocaleDateString()} au{' '}
                  {new Date(discount.validTo).toLocaleDateString()}
                </span>
              </div>
              <button
                onClick={() => onUpdateDiscount(discount.id, { isActive: !discount.isActive })}
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  discount.isActive
                    ? 'bg-red-100 text-red-700 hover:bg-red-200'
                    : 'bg-green-100 text-green-700 hover:bg-green-200'
                }`}
              >
                {discount.isActive ? 'Désactiver' : 'Activer'}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Formulaire d'ajout de réduction */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
        >
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-medium text-gray-900">
                Nouvelle réduction
              </h3>
              <button
                onClick={() => setShowForm(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Nom de la réduction
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name || ''}
                  onChange={handleChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Description
                </label>
                <input
                  type="text"
                  name="description"
                  value={formData.description || ''}
                  onChange={handleChange}
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Type de réduction
                  </label>
                  <select
                    name="type"
                    value={formData.type}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  >
                    <option value="percentage">Pourcentage</option>
                    <option value="fixed">Montant fixe</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Valeur
                  </label>
                  <input
                    type="number"
                    name="value"
                    value={formData.value || ''}
                    onChange={handleChange}
                    step={formData.type === 'percentage' ? '1' : '0.01'}
                    min="0"
                    max={formData.type === 'percentage' ? '100' : undefined}
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Quantité minimum
                  </label>
                  <input
                    type="number"
                    name="minQuantity"
                    value={formData.minQuantity || ''}
                    onChange={handleChange}
                    min="0"
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Quantité maximum
                  </label>
                  <input
                    type="number"
                    name="maxQuantity"
                    value={formData.maxQuantity || ''}
                    onChange={handleChange}
                    min="0"
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Date de début
                  </label>
                  <input
                    type="date"
                    name="validFrom"
                    value={formData.validFrom?.toISOString().split('T')[0] || ''}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Date de fin
                  </label>
                  <input
                    type="date"
                    name="validTo"
                    value={formData.validTo?.toISOString().split('T')[0] || ''}
                    onChange={handleChange}
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Limite d'utilisation
                </label>
                <input
                  type="number"
                  name="usageLimit"
                  value={formData.usageLimit || ''}
                  onChange={handleChange}
                  min="0"
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"
                  placeholder="Laisser vide pour illimité"
                />
              </div>

              <div className="flex justify-end space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => setShowForm(false)}
                  className="px-4 py-2 text-gray-700 hover:text-gray-900"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50"
                >
                  {loading ? 'Création...' : 'Créer la réduction'}
                </button>
              </div>
            </form>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default DiscountManager;